﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;



namespace ProjWithoutMain
{
    public partial class Program
    {
        void Test(string[] args)
        {
            MessageBox.Show("No Main in proj");
        }

    }
}

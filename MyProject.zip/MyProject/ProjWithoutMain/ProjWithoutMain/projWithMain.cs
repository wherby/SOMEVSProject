﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

namespace ProjWithoutMain
{
     class projWithoutMain;

    public static class projWithMain
    {

        static void Main(string[] args)
        {
            projWithoutMain aa = new projWithoutMain();
           
        }
    }
}

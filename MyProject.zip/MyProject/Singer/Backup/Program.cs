/*    
    Signer - Strong name file updater
    Copyright (C) 2007  Alois Kraus

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Reflection;
using System.Diagnostics;

namespace Signer
{
    /// <summary>
    /// Main Entry point for Signer
    /// </summary>
    class Program
    {
        string myKeyFile = String.Empty;
        List<string> myAssemblies = new List<string>();

        string myAdditionalDeCompOptions = String.Empty;

        /// <summary>
        /// Additonal command line options for ILDASM
        /// </summary>
        public string AdditionalDeCompOptions
        {
            get { return myAdditionalDeCompOptions; }
        }

        string myAdditionalCompOptions = String.Empty;

        /// <summary>
        /// Additional command line options for ILASM
        /// </summary>
        public string AdditionalCompOptions
        {
            get { return myAdditionalCompOptions;  }
            set { myAdditionalCompOptions = value; }
        }

        string myOutDir = String.Empty;
        /// <summary>
        /// Output directory
        /// </summary>
        public string OutputDirectory
        {
            get { return myOutDir ?? ".\\"; }
        }

        bool myDebug = false;

        int myi = 0;
        string[] myArgs;


        static readonly string myHelp = String.Format("Signer (C) by Alois Kraus 2007 (akraus1@gmx.de) version {0}{1}{1}", Assembly.GetExecutingAssembly().GetName().Version, Environment.NewLine) +
                                        "Signer -k <KeyFile> -outdir <Output Dir> -a <Assembly1> <Assembly2> ... [-decomp \"Options\" -comp \"Options\" -debug]" + Environment.NewLine +
                                        "   Signer does sign all assemblies and updates their references if the assembly is not already signed" + Environment.NewLine +
                                        "   This way you can convert a whole bunch of assemblies which have never seen a key file into strong named assemblies without recompiling!" + Environment.NewLine +
                                        "   -k        Key File name of key container file which is created usually by the sign tool (sn -k)" + Environment.NewLine +
                                        "   -outdir   Output directory where the strong signed assemblies are copied to" + Environment.NewLine +
                                        "   -decomp   Additional ildasm options e.g. \"/STATS\"" + Environment.NewLine +
                                        "   -comp     Additional ilasm options e.g. \"/X64\"" + Environment.NewLine +
                                        "   -a        Can be a list of assembly names or a wildcard search pattern e.g. *.dll" + Environment.NewLine +
                                        "   -debug    Do not delete temporary IL files in %TEMP% flder after completion" + Environment.NewLine + Environment.NewLine +

                                        @" Example: Signer -k c:\key.snk -outdir .\build -a *.dll *.exe  Copy the signed assemblies into the newly created directory build." + Environment.NewLine +
                                        @" Example: Signer -k c:\key.snk -outdir . -a *.dll *.exe        Sign and overwrite the orignal binaries in current directory." + Environment.NewLine;



        void Help()
        {
            Console.WriteLine(myHelp);
        }

        static Program p;
        static public Program Data
        {
            get { return p; }
        }

        static void Main(string[] args)
        {
            try
            {
                AppDomain.CurrentDomain.UnhandledException += new UnhandledExceptionEventHandler(CurrentDomain_UnhandledException);

                p = new Program();
                if (p.ParseCmdLine(args))
                {
                    p.Execute();
                }
            }
            catch (Exception ex)
            {
                Console.WriteLine("An unexpected processing error did occur: {0}", ex);
                Trace.TraceError("Unhandled exception in another thread did happen: {0}", ex);
                Debug.Assert(false, "Unhandled exception in main thread did occur!");
            }
        }

        static void CurrentDomain_UnhandledException(object sender, UnhandledExceptionEventArgs e)
        {
            Trace.TraceError("Unhandled exception in another thread did happen: {0}", e.ExceptionObject);
            Debug.Assert(false, "Unhandled thread exception did occur!");
        }


        /// <summary>
        /// Get the next command line option which is not a command flag
        /// </summary>
        /// <returns>Next option string.</returns>
        string Next()
        {
            string ret = null;
            if (myArgs.Length - myi > 1 && !myArgs[myi+1].StartsWith("-"))
            {
                myi++;
                ret = myArgs[myi];
            }

            return ret;
        }

        public bool ParseCmdLine(string[] args)
        {
            myArgs = args;

            string arg;

            for (; myi < args.Length; myi++)
            {
                arg = args[myi];

                if (arg == "-k")
                {
                    myKeyFile = Next();
                    if (myKeyFile == null)
                    {
                        Help();
                        Console.WriteLine("Error: No key file given!");
                        return false;
                    }

                    if(!File.Exists(myKeyFile))
                    {
                        Help();
                        Console.WriteLine("Key file {0} was not found!", myKeyFile);
                        return false;
                    }
                }
                else if (arg == "-a")
                {
                    string curFile;
                    string curDir;
                    while( (curFile = Next()) != null)
                    {
                         curDir = Path.GetDirectoryName(curFile);
                        if (String.IsNullOrEmpty(curDir))
                            curDir = ".";

                        string fileName = Path.GetFileName(curFile);
                        string[] files = System.IO.Directory.GetFiles(curDir, fileName);
                        if (files.Length == 0)
                        {
                            Help();
                            Console.WriteLine("Error: The file {0} does not exist or the search query did return no files", curFile);
                            return false;
                        }
                        myAssemblies.AddRange(files);
                    }
                }
                else if (arg == "-decomp")
                {
                    myAdditionalDeCompOptions = Next();
                    if (String.IsNullOrEmpty(myAdditionalDeCompOptions))
                    {
                        Help();
                        Console.WriteLine("Error: No decompilation options for ildasm specified!");
                        return false;
                    }
                }
                else if (arg == "-comp")
                {
                    myAdditionalCompOptions = Next();
                    if (String.IsNullOrEmpty(myAdditionalCompOptions))
                    {
                        Help();
                        Console.WriteLine("Error: No compilation options for ilasm specified!");
                        return false;
                    }
                }
                else if (arg == "-outdir")
                {
                    myOutDir = Next();
                    if (myOutDir == null)
                    {
                        Help();
                        Console.WriteLine("Error: No output directory specified!");
                        return false;
                    }
                }
                else if (arg == "-debug")
                {
                    myDebug = true;
                }
                else
                {
                    Help();
                    Console.WriteLine("Invalid command line argument: " + arg);
                    return false;
                }
            }

            return CheckData(); // check if command line data is valid
        }

        /// <summary>
        /// Check if the parsed command line arguments are sufficient to execut a command.
        /// </summary>
        /// <returns>true if command line args are valid
        ///          false otherwise.</returns>
        bool CheckData()
        {
            StringBuilder errors = new StringBuilder();
            if( myKeyFile == String.Empty )
            {
                errors.AppendLine("Error: No Key file specifed (use -k KeyFile ).");
            }
            if( myOutDir == String.Empty )
            {
                errors.AppendLine("Error: No Output directory specifed (use -outdir Dir ).");
            }
            if( myAssemblies.Count == 0 )
            {
                errors.AppendLine("Error: No input assemblies specified (use -a Assembly ).");
            }

            if (errors.Length > 0)
            {
                Help();
                Console.WriteLine(errors.ToString());
                return false;
            }

            return true;
        }

        void CopyFileToOutputDirectoy(string fileName)
        {
            string copyTo = Path.Combine(OutputDirectory, Path.GetFileName(fileName));
            if (String.Compare(Path.GetFullPath(fileName), Path.GetFullPath(copyTo), true) != 0)
            {
                // Copy file to output directory if input directory is not the same output directory
                File.Copy(fileName, copyTo, true);
            }
        }

        /// <summary>
        /// Execute given signer command.
        /// </summary>
        public void Execute()
        {
            Executor exec = new Executor();

            List<string> invalidCommands = exec.GetInvalidCommands();

            if (invalidCommands.Count > 0)
            {
                Console.WriteLine("Error: Some necessary tools were not found. "+
                                  "You should start Signer inside a Visual Studio 2005 Shell {0} via Start->Programms->Microsoft Visual Studio 2005->Visual Studio 2005 Tools->Visual Studio 2005 Command Prompt{0}",
                                  Environment.NewLine);
                foreach (string cmd in invalidCommands)
                {
                    Console.WriteLine("Programm {0} is not in path or .NET version is below 2.0.", cmd);
                }
                return;
            }

            AssemblyNames names = new AssemblyNames(myAssemblies);
            ILUpdater updater = new ILUpdater(names);


            if (myAssemblies.Count == 0)
            {
                Help();
                Console.WriteLine("No assembly files found!");
                return;
            }

            if (!Directory.Exists(OutputDirectory))
            {
                Console.WriteLine("Output directory does not exist. Creating it now: {0}", Path.GetFullPath(OutputDirectory));
                Directory.CreateDirectory(OutputDirectory);
            }

            string publicToken = exec.DeterminePublicKeyTokenFromKeyFile(myKeyFile);

            AssemblyFlags asFlags = new AssemblyFlags();

            foreach (string file in myAssemblies)
            {
                try
                {
                    try
                    {
                        asFlags = exec.GetAssemblyFlags(file);
                        if (asFlags.IsSigned)
                        {
                            Console.WriteLine("Info: Assembly {0} is already signed. Ignored", file);
                            CopyFileToOutputDirectoy(file);
                            continue;
                        }

                        if (!asFlags.IsPureIL)
                        {
                            Console.WriteLine("Warning: The assembly {0} does contain unmanaged code. Ignored", file);
                            CopyFileToOutputDirectoy(file);
                            continue;
                        }
                    }
                    catch (InvalidDataException /* ex */ )
                    {
                        Console.WriteLine("Warning: The assembly {0} is either unmanaged or has 0 byte length. Ignored", file);
                        continue;
                    }

                    Console.Write("Strong naming {0} ... ", file);
                    string ilFile = exec.Disassemble(file);

                    if (updater.InsertPublicKeyTokenIntoReferences(ilFile, publicToken))
                    {
                        exec.Compile(ilFile, Path.Combine(OutputDirectory, Path.GetFileName(file)), myKeyFile);
                    }
                    else
                    {
                        Console.Write("Ignored. It is already signed. ");
                    }

                    Console.Write("Done" + Environment.NewLine);

                    if (!myDebug)
                    {
                        File.Delete(ilFile);
                    }
                }
                catch (InvalidOperationException ex)
                {
                    Console.WriteLine("{2}An error occured while processing file {0}: {1}{2}", file, ex.Message, Environment.NewLine);
                }
            }
        }
    }
}

/*    
    Signer - Strong name file updater
    Copyright (C) 2007  Alois Kraus

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


using System;
using System.Collections.Generic;
using System.Text;
using System.ComponentModel;
using System.IO;
using System.Diagnostics;
using System.Threading;
using System.Runtime.InteropServices;

namespace Signer
{
    /// <summary>
    /// Contains ouptut of executed command line programm. 
    /// Contents: stdout, stderr and the full command line with arguments to enable a
    /// meaningful error display or analysis after execution.
    /// </summary>
    public struct ExecResult
    {
        public string Command;
        public string StdOut;
        public string StdErr;
    }

    /// <summary>
    /// Contains the parsed Corflags output for a valid assembly for the flags needed by Signer
    /// </summary>
    public struct AssemblyFlags
    {
        public bool IsSigned;
        public bool IsPureIL;
    }

    /// <summary>
    /// Execute another exectuable and check the output if it did succeed.
    /// </summary>
    public class Executor
    {
        /// <summary>
        /// Temp file path where the decompiled .il and resource files will be created
        /// </summary>
        static readonly string TmpFilePath = Environment.ExpandEnvironmentVariables("%TEMP%\\");

        /// <summary>
        /// Executed commands
        /// </summary>
        const string ILDASM = "ildasm.exe";  // IL decompiler (part of the SDK)
        const string ILASM = "ilasm.exe";    // IL assembler
        const string CorFlags = "corflags.exe";  // binary assembly file checker (part of the SDK)

        // maximum execution time 
        const int ProcessTimeOut = 30000;

        /// <summary>
        /// Check if all needed command line tools are available and of the correct .NET version
        /// </summary>
        /// <returns>List of commands which could not be started or have a too small version</returns>
        public List<string> GetInvalidCommands()
        {
            List<string> ret = new List<string>();

            ExecResult res = new ExecResult();
            try
            {
                res = Execute(CorFlags, null);
            }
            catch (Win32Exception ex)
            {
                ret.Add(CorFlags);
                Debug.Print("Execute check for {0} failed with {1}", CorFlags, ex);
            }

            try
            {
                res = Execute(ILDASM, "/?");
            }
            catch (Win32Exception ex)
            {
                ret.Add(ILDASM);
                Debug.Print("Execute check for {0} failed with {1}", ILDASM, ex);
            }

            // Check ILDASM version
            string majorVersion = res.StdOut.Substring(res.StdOut.IndexOf("Version", StringComparison.InvariantCulture) + 8, 1);
            if (Int32.Parse(majorVersion) < 2)
            {
                ret.Add(ILDASM);
                Debug.Print("Execute check for {0} failed because version was < 2. Got: {1}", ILDASM, majorVersion);
            }

            try
            {
                res = Execute(ILASM, null);
            }
            catch (Win32Exception ex)
            {
                ret.Add(ILASM);
                Debug.Print("Execute check for {0} failed with {1}", ILASM, ex);
            }

            return ret;
        }


        /// <summary>
        /// Execute an external program and wait for exit. The fixed timeout value is current 30s.
        /// </summary>
        /// <param name="executable">File name of executable</param>
        /// <param name="arguments">optional command line arguments</param>
        /// <returns>Structure containing stdout, stderr and full command line</returns>
        public ExecResult Execute(string executable, string arguments)
        {
            ProcessStartInfo info = new ProcessStartInfo(executable, arguments);
            info.RedirectStandardError = true;
            info.RedirectStandardOutput = true;
            info.UseShellExecute = false;
#if !DEBUG
            info.CreateNoWindow = true;
#endif

            Process p;
            try
            {
                p = Process.Start(info);
            }
            catch (Exception /* ex */ )
            {
                string msg = String.Format("{0}Execute of {1} failed", Environment.NewLine, executable + " " + arguments);
                Debug.Print(msg);
                Console.WriteLine(msg);
                throw;                
            }

            ExecResult res = new ExecResult();
            res.Command = executable + " " + arguments;

            res.StdOut = p.StandardOutput.ReadToEnd();

            // prevent deadlock by reading the stderr from another thread
            Thread t = new Thread(delegate()
            {
                res.StdErr = p.StandardError.ReadToEnd();
            });

            t.Start();

            if (p.WaitForExit(ProcessTimeOut) == false)
            {
                throw new TimeoutException(String.Format("The execution of {0} with args {1} did take longer than {2}s!", executable, arguments, ProcessTimeOut));
            }

            t.Join();

        //    Console.WriteLine("Command {0}\nOutput: {1}\n{2}", res.Command, res.StdOut, res.StdErr);
            return res;
        }

        /// <summary>
        /// Decompile an assembly two times one with textual representation of binary blobs (/CAVERBAL)
        /// and another run with binary blobs. We build later a merged .il file which will contain parts
        /// of both .il files. The first file is file.il the second file is named file.binary.il.
        /// </summary>
        /// <param name="assemblyFileName">Assembly file name</param>
        /// <returns>The full qualified output il file name.</returns>
        public string Disassemble(string assemblyFileName)
        {
            string outFile = Path.Combine(TmpFilePath, Path.GetFileName(assemblyFileName)) + ".binary.il";
            string nextOption = "";
            for(int i=0;i<2;i++)
            {
                //  this option does cause a failure during round triping enum values which are assigned to objects
                string args = String.Format("/NOBAR /TYPELIST {0} /out={1} {2} {3}", assemblyFileName, outFile, Program.Data.AdditionalDeCompOptions, nextOption);
                ExecResult res = Execute(ILDASM, args);
                CheckForError(res, ErrorStrings);
                nextOption = "/CAVERBAL";
                outFile = Path.Combine(TmpFilePath, Path.GetFileName(assemblyFileName)) + ".il";
            }
            return outFile;
        }

        string [] myCompileErrors = new string [] {"***** FAILURE *****"};
        /// <summary>
        /// Compile an .il file to an assembly with a strong key
        /// </summary>
        /// <param name="ilFile">File to compile</param>
        /// <param name="assembly">output assembly name</param>
        /// <param name="keyFile">File Name of strong name key pair.</param>
        public void Compile(string ilFile, string assembly, string keyFile)
        {
            string resFile = Path.Combine(Path.GetDirectoryName(ilFile), Path.GetFileNameWithoutExtension(ilFile) + ".res");
            string resOptions = String.Empty;

            if (File.Exists(resFile))
            {
                resOptions = "/RES=\"" + resFile+"\"";
            }

            string args = String.Format("/{0} /QUIET /key={1}  /OUTPUT={2} {3} {4} {5}", Path.GetExtension(assembly).ToUpper().TrimStart(".".ToCharArray()),
                                           keyFile, assembly,Program.Data.AdditionalCompOptions, ilFile, resOptions);
            ExecResult res = Execute(ILASM, args);
            CheckForError(res, myCompileErrors, null);
        }

        string[] ErrorStrings = new string[] { "ERROR", "FAILURE", "CANNOT", "USAGE:"};

        /// <summary>
        /// Check if the returned strings in the executed command does contain any error messages.
        /// </summary>
        /// <param name="res">Comand result object</param>
        /// <param name="errSubStrings">list of string which are checked agains stdout and stderr</param>
        /// <exception cref="InvalidOperationException">Is thrown in case an invalid command output was detected.</exception>
        void CheckForError(ExecResult res, string[] errSubStrings)
        {
            CheckForError(res, errSubStrings, null);
        }

        /// <summary>
        /// Check if the returned strings in the executed command does contain any error messages.
        /// </summary>
        /// <param name="res">Comand result object</param>
        /// <param name="errSubStrings">list of string which are checked agains stdout and stderr. Can be null if successString is not null</param>
        /// <param name="successString"></param>
        void CheckForError(ExecResult res, string [] errSubStrings, string successString)
        {
            if (errSubStrings == null && successString == null)
            {
                throw new NotSupportedException("errSubStrings and successString cannot be null at the same time. Only one of the can be non null");
            }

            if (errSubStrings != null && successString != null)
            {
                throw new NotSupportedException("errSubStrings and successString cannot be set at the same time. You can check only for error strings or success message strings at one time.");
            }

            if (errSubStrings != null)
            {
                foreach (string eString in errSubStrings)
                {
                    if (res.StdErr.ToUpper().Contains(eString))
                        throw new InvalidOperationException(String.Format("Command {0}{1}Output: {2}", res.Command, Environment.NewLine, res.StdErr));
                    if (res.StdOut.ToUpper().Contains(eString))
                        throw new InvalidOperationException(String.Format("Command {0}{1}Output: {2}", res.Command, Environment.NewLine, res.StdOut));
                }
            }
            else
            {
                if (!res.StdOut.ToUpper().Contains(successString))
                    throw new InvalidOperationException(String.Format("Command {0}{1}Output: {2}", res.Command,Environment.NewLine, res.StdOut));
            }
        }



        [StructLayout(LayoutKind.Sequential, CharSet = CharSet.Unicode)]
        internal struct CRYPT_DATA_BLOB
        {
            internal uint cbData;
            internal IntPtr pbData;
        }
 

        [DllImport("mscorwks.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern int _AxlPublicKeyBlobToPublicKeyToken(ref CRYPT_DATA_BLOB pCspPublicKeyBlob, out IntPtr ppwszPublicKeyTokenString);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern bool HeapFree(IntPtr hHeap, uint dwFlags, IntPtr lpMem);

        [DllImport("kernel32.dll", CharSet = CharSet.Auto, SetLastError = true)]
        internal static extern IntPtr GetProcessHeap();

        /// <summary>
        /// Return the public key token string of the given strong key file (.snk).
        /// </summary>
        /// <param name="keyFile">Key file name</param>
        /// <returns></returns>
        public unsafe string DeterminePublicKeyTokenFromKeyFile(string keyFile)
        {
            if (String.IsNullOrEmpty(keyFile))
            {
                throw new ArgumentException("The Key file name is null or empty. Please provide a valid key file name");
            }


            byte[] publicKeyBlob = File.ReadAllBytes(keyFile);
            if( publicKeyBlob.Length == 0)
            {
                throw new InvalidDataException("The public key blob file must contain a valid public key. Key file was empty");
            }

            string publicKeyToken = null;
            fixed (byte* fixedBlob = publicKeyBlob)
            {
                CRYPT_DATA_BLOB crypt_data_blob1 = new CRYPT_DATA_BLOB();
                crypt_data_blob1.cbData = (uint)publicKeyBlob.Length;
                crypt_data_blob1.pbData = new IntPtr((void*)fixedBlob);
                IntPtr LPCTSTR = new IntPtr();
                int num1 = _AxlPublicKeyBlobToPublicKeyToken(ref crypt_data_blob1, out LPCTSTR);
                if (num1 != 0)
                {
                    throw new InvalidDataException(String.Format("Could not convert public key blob to a public key token. Error code: {0}", num1));
                }
                publicKeyToken = Marshal.PtrToStringUni(LPCTSTR);
                HeapFree(GetProcessHeap(), 0, LPCTSTR);
            }

            Debug.Print("Got public key token {0} from key file {1}", publicKeyToken, keyFile);
            return publicKeyToken;
        }


        string[] corFlagErrors = new string[] { "The specified file does not have a valid managed header", "Could not open file for reading", "error" };

        /// <summary>
        /// Get assembly flags by executing corflags.exe and parsing its output.
        /// </summary>
        /// <param name="assemblyFileName">Assembly file name</param>
        /// <returns>AssemblyFlags structure if the file is a valid assembly.</returns>
        /// <exception cref="InvalidDataException">Is thrown when the assembly is not valid (0 byte file, native dll, ...).</exception>
        /// <exception cref="ArgumentException">Is thrown when the input file name is null or empty.</exception>
        public AssemblyFlags GetAssemblyFlags(string assemblyFileName)
        {
            const string CorFlagsIl = "ILONLY";

            if (String.IsNullOrEmpty(assemblyFileName))
            {
                throw new ArgumentException("The assembly file name is null or empty. Please provide a valid assembly name");
            }


            ExecResult res = Execute(CorFlags, assemblyFileName);
            CheckForError(res, corFlagErrors);

            if (!res.StdOut.Contains(CorFlagsIl)) // the file is not an assembly
            {
                throw new InvalidDataException(String.Format("Corflags.exe ({0}) did not return valid data: {1}", assemblyFileName, res.StdOut));
            }

            string[] lines = res.StdOut.Split("\n".ToCharArray());
            
            string value;
            AssemblyFlags ret = new AssemblyFlags();

            foreach(string line in lines)
            {
                if (line.StartsWith(CorFlagsIl))
                {
                    value = line.Substring(line.IndexOf(':') + 1).Trim();
                    ret.IsPureIL = Int32.Parse(value) > 0;
                }
                    
                if(line.StartsWith("Signed"))
                {
                    value = line.Substring(line.IndexOf(':')+1).Trim();
                    ret.IsSigned = Int32.Parse(value) > 0;
                }
            }

            return ret;            
        }
    }
}

/*    
    Signer - Strong name file updater
    Copyright (C) 2007  Alois Kraus

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/

using System;
using System.Collections.Generic;
using System.IO;
using System.Text;
using System.Reflection;

namespace Signer
{
    /// <summary>
    /// Container Assembly Names which are read from a list of files
    /// </summary>
    public class AssemblyNames
    {
        Dictionary<string, AssemblyName> myNames = new Dictionary<string, AssemblyName>();

        /// <summary>
        /// Get all strong file names of the given list and store them in the class instance. Files
        /// which are not valid .NET assemblies are skipped.
        /// </summary>
        /// <param name="assemblyFiles">List of files for which the strong names are retrieved.</param>
        /// <exception cref="ArgumentNullException">Is thrown when the input list is null.</exception>
        public AssemblyNames(List<string> assemblyFiles)
        {
            if (assemblyFiles == null)
            {
                throw new ArgumentNullException("assemblyFiles", "Please provide a non null instance");
            }


            Executor exec = new Executor(); // create new command line executor

            foreach (string file in assemblyFiles)
            {
                try
                {
                    exec.GetAssemblyFlags(file);
                }
                catch (InvalidDataException /* ex */) // file is unmanaged or invalid skip it
                {
                    continue;
                }
               
                AssemblyName name = AssemblyName.GetAssemblyName(file);
                myNames.Add(name.Name, name);
            }
        }

        /// <summary>
        /// Get the stored assembly name where the file name is used as key.
        /// </summary>
        /// <param name="assemblyFileName">file name</param>
        /// <returns>Full AssemblyName structure if present. Null otherwise.</returns>
        /// <exception cref="ArgumentException">Thrown when assemblyFileName is null or empty.</exception>
        public AssemblyName GetAssemblyName(string assemblyFileName)
        {
            if (String.IsNullOrEmpty(assemblyFileName))
            {
                throw new ArgumentException("The assmembly file name is null or empty! Please provide a valid file name.");
            }

            AssemblyName ret;
            if (myNames.TryGetValue(assemblyFileName, out ret))
            {
                return ret;
            }
            else
                return null;
        }
    }
}

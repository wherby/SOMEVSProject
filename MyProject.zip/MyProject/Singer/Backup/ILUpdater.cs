/*    
    Signer - Strong name file updater
    Copyright (C) 2007  Alois Kraus

    This library is free software; you can redistribute it and/or
    modify it under the terms of the GNU Lesser General Public
    License as published by the Free Software Foundation; either
    version 2.1 of the License, or (at your option) any later version.

    This library is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the GNU
    Lesser General Public License for more details.

    You should have received a copy of the GNU Lesser General Public
    License along with this library; if not, write to the Free Software
    Foundation, Inc., 51 Franklin Street, Fifth Floor, Boston, MA  02110-1301  USA
*/


using System;
using System.Collections.Generic;
using System.Text;
using System.IO;
using System.Text.RegularExpressions;
using System.Reflection;


namespace Signer
{
    public class ILUpdater
    {
        AssemblyNames myNames;
        internal string[] myilFile;
        internal string[] myBinaryBlobilFile;

        internal int myi;
        internal int myTi;

        List<string> myTrimmedIlFile     = new List<string>();
        List<string> myTrimmedBlobilFile = new List<string>();


        List<int> myDeletePoints = new List<int>();
        Dictionary<int, string> myInsertPoints = new Dictionary<int, string>();
        Dictionary<int, string> myModifiedLines = new Dictionary<int, string>();



        const string AttributeInstanceToken = ".custom ";

        const string BinaryBlobToken = " = ( 01 00 ";

        const string ReferenceToken = ".assembly extern";
        const string PublicKeyToken = ".publickeytoken";

        const string StrongNameKeyToken = "PublicKeyToken";
        const string StrongNameCulturetoken = "Culture";

        const string PublicKeyValueToken = ".publickey =";


        void ClearTempData()
        {
            myilFile = null;
            myBinaryBlobilFile = null;
            myTrimmedIlFile.Clear();
            myTrimmedBlobilFile.Clear();
            myDeletePoints.Clear();
            myInsertPoints.Clear();
            myModifiedLines.Clear();
        }

        byte[] myPulicKeyTokenBlob;

        public ILUpdater(AssemblyNames names)
        {
            if (names == null)
            {
                throw new ArgumentNullException("names", "Please specify a non null assembly names list");
            }

            myNames = names;
        }

        public static byte[] ConvertToByteArray(string blob)
        {
            if (String.IsNullOrEmpty(blob))
            {
                throw new ArgumentException("blob string is null or empty");
            }

            if (blob.Length % 2 == 1)
            {
                throw new ArgumentException("blob string length is not even! Please add leading padding char to blob string.");
            }

            List<byte> ret = new List<byte>();

            

            string number;
            for (int i = 0; i < blob.Length; i+=2)
            {
                number = blob.Substring(i,2);
                ret.Add(Byte.Parse(number, System.Globalization.NumberStyles.HexNumber));
            }

            return ret.ToArray();
        }



        public bool InsertPublicKeyTokenIntoReferences(string ilFileName, string publicKeyToken)
        {
            ClearTempData();
            myPulicKeyTokenBlob = ConvertToByteArray(publicKeyToken);


            myilFile = File.ReadAllLines(ilFileName);

            // read second il file which contains all attributes as binary blobs
            myBinaryBlobilFile = File.ReadAllLines(Path.Combine(Path.GetDirectoryName(ilFileName), Path.GetFileNameWithoutExtension(ilFileName) + ".binary.il"));

            RemoveComments();
            RemoveInternalsVisibleToAttribute();
            MergeBinaryBlobs();
            
            string[] PatchedIL = InsertStrongReferences(publicKeyToken);

            if (PatchedIL == null)
            {
                return false;
            }
            else
            {
                File.WriteAllLines(ilFileName, PatchedIL);
            }

            return true;
        }


        const string ConfigPropertyAttribute = "System.Configuration.ConfigurationPropertyAttribute::.ctor(string)";


        public void RemoveInternalsVisibleToAttribute()
        {
            const string InternalsVisiblesToAttributeToken = "System.Runtime.CompilerServices.InternalsVisibleToAttribute";
            string line;
            for(int i=0;i<myTrimmedIlFile.Count;i++)
            {
                line = myTrimmedIlFile[i];
            NextCheck:
                if (line.Contains(InternalsVisiblesToAttributeToken))
                {
                    //Console.WriteLine("Removed InternalsVisibleToAttribute: {0}", line);
                    do
                    {
                        myDeletePoints.Add(i);
                        i++;
                        line = myTrimmedIlFile[i];
                    }
                    while (!line.StartsWith("."));
                    goto NextCheck;
                }
            }
        }


        public void MergeBinaryBlobs()
        {
            string line;
            string blobLine;

            int j = 0;

            for (int i = 0; i < myTrimmedIlFile.Count; i++)
            {
                line = myTrimmedIlFile[i];
                if (line.Contains(ConfigPropertyAttribute))
                {
                    for (; j < myTrimmedBlobilFile.Count; j++)
                    {
                        blobLine = myTrimmedBlobilFile[j];
                        if (blobLine.Contains(ConfigPropertyAttribute))
                        {
                            string InsertString = "";
                            do
                            {
                                InsertString += myBinaryBlobilFile[j] + Environment.NewLine;
                                j++;
                                blobLine = myTrimmedBlobilFile[j];
                            }
                            while (!blobLine.StartsWith("."));

                            myInsertPoints.Add(i, InsertString);
                            break;
                        }
                    }

                    do
                    {
                        myDeletePoints.Add(i);
                        i++;
                        line = myTrimmedIlFile[i];
                    }
                    while(!line.StartsWith("."));
                }

            }

        }

        public string RemoveComment(string line)
        {
            int bStart = line.IndexOf("//");
            if (bStart == -1)
                bStart = line.Length;
            return line.Substring(0, bStart);
        }

        internal void RemoveComments()
        {
            string line;
            for (int i = 0; i < myilFile.Length; i++)
            {
                line = RemoveComment(myilFile[i]).Trim();
                myTrimmedIlFile.Add(line);
            }

            for (int i = 0; i < myBinaryBlobilFile.Length; i++)
            {
                line = RemoveComment(myBinaryBlobilFile[i]).Trim();
                myTrimmedBlobilFile.Add(line);
            }
        }

        internal string[] InsertStrongReferences(string publicKeyToken)
        {
            //.assembly extern /*23000002*/ Microsoft.VisualStudio.HostingProcess.Utilities.Sync
            //{
            //  .publickeytoken = (B0 3F 5F 7F 11 D5 0A 3A )                         // .?_....:
            //  .ver 8:0:0:0
            //}
            StringBuilder token = new StringBuilder();
            string rawToken = publicKeyToken.ToUpper();
            for(int i=0;i<rawToken.Length;i+=2)
            {
                token.AppendFormat("{0}{1} ", rawToken[i], rawToken[i+1]);
            }
            
            string StrongRefIL = String.Format("  .publickeytoken = ({0})", token.ToString());

 
            bool bInReference = false;
            bool bInSide = false;
            bool bInMainModule = false;
            bool bPublicKeyTokenInReferencePresent = false;
            
            string line;

            for (myi = 0; myi < myTrimmedIlFile.Count; myi++)
            {
                line = myTrimmedIlFile[myi];

                if( line.Contains(StrongNameKeyToken) && line.Contains(StrongNameCulturetoken) )
                {
                    myModifiedLines.Add(myi, ModifyAttribute(line));
                }

                if (line.StartsWith(ReferenceToken))
                {
                    bInReference = true;
                }
                if (line.StartsWith("{"))
                {
                    bInSide = true;
                    continue;
                }
                if (line.StartsWith("}"))
                {
                    if (bInSide && !bInMainModule && bInReference && !bPublicKeyTokenInReferencePresent)
                    {
                        myInsertPoints.Add(myi - 1, StrongRefIL);
                    }
                    bInSide = false;
                    bInSide = false;
                    bInReference = false;
                    bPublicKeyTokenInReferencePresent = false;
                    if (bInMainModule)
                        break;


                    continue;
                }
                if (line.Contains(PublicKeyToken))
                {
                    bPublicKeyTokenInReferencePresent = true;
                }

                if (line.Contains(".custom") && line.Contains("System.Runtime.CompilerServices.InternalsVisibleToAttribute"))
                {
                  //  ExtractBytes();
                }


                // assembly header reached no more references to look for
                if (line.StartsWith(".assembly /*"))
                {
                    bInMainModule = true;
                }
            }

            return ExecuteInsertAddRemove();
 
        }

        /// <summary>
        /// After we did parse the il file we create a new file buffer where we copy the added/removed/modifed lines
        /// into as needed. The original file buffer is never changed.
        /// </summary>
        /// <returns>New modified file line array</returns>
        string[] ExecuteInsertAddRemove()
        {
            if (myInsertPoints.Count == 0 && myModifiedLines.Count == 0 && myDeletePoints.Count == 0)
                return myilFile;

            string[] fixedReferences = new string[myilFile.Length + myInsertPoints.Count];
            int curCounter = 0;
            for (int i = 0; i < myilFile.Length; i++)
            {
                if (myInsertPoints.ContainsKey(i))
                {
                    fixedReferences[curCounter] = myInsertPoints[i];
                    curCounter++;
                }

                if (myModifiedLines.ContainsKey(i))
                {
                    fixedReferences[curCounter] = myModifiedLines[i];
                    curCounter++;
                }
                else if (myDeletePoints.Contains(i))
                {
                    continue;
                }
                else
                {
                    fixedReferences[curCounter] = myilFile[i];
                    curCounter++;
                }
            }

            return fixedReferences;
        }

        Char[] mySpacesSep = new Char[] { ' ' };

        string GetBlobString(string blob)
        {
            byte[] bytes = ConvertToByteArray(blob);
            return Encoding.ASCII.GetString(bytes,3,bytes[3]-5);
        }

        internal string[] GenerateBlobLines(string blobText)
        {
            if (blobText == null)
            {
                throw new ArgumentNullException("blobText", "Parameter was null!");
            }
            if (blobText.Length == 0)
            {
                throw new ArgumentException("blobText was empty!");
            }

            StringBuilder curStr = new StringBuilder();

            // every line does contain 16 bytes at most
            // the whole blob length is string length + 2 bytes header + 1 byte string length + 2 bytes terminaton \0 char
            int iBlobLengthWithLengthAndTermination = blobText.Length + 5;

            // the length is encoded in two signed bytes for blobs > 127 bytes
            // 0 < l < 128: l
            // 128 <= l < 256 : (0x80 + l / 0x80) (0x80 + l % 0x80) 
            // 256 <= l       : (0x80 + l / 0x80) (l % 0x80) 
            int iCurByteCount = 0;
            if (blobText.Length > 127)
            {
                iBlobLengthWithLengthAndTermination++;
                if (blobText.Length < 256)
                {
                    // format start token and string length into binary blob
                    curStr.AppendFormat("( 01 00 {0:X2} {1:X2} ", 0x80 + blobText.Length / 0x80 - 1, 0x80 + blobText.Length % 0x80);
                }
                else
                {
                    // format start token and string length into binary blob
                    curStr.AppendFormat("( 01 00 {0:X2} {1:X2} ", 0x80 + blobText.Length / 0x80 - 1, blobText.Length % 0x80);
                }
                iCurByteCount = 4;
            }
            else
            {
                // format start token and string length into binary blob
                curStr.AppendFormat("( 01 00 {0:X2} ", blobText.Length);
                iCurByteCount = 3;
            }

            string[] ret = new string[(iBlobLengthWithLengthAndTermination) / 16 + ((iBlobLengthWithLengthAndTermination % 16 > 0) ? 1 : 0)];


            int iLine = 0;


            blobText += "\0\0"; // append terminating \0 character
            for (int i = 0; i < blobText.Length; i++)
            {
                curStr.AppendFormat("{0:X2} ", (int) blobText[i]);

                iCurByteCount++;
                if( iCurByteCount % 16 == 0)
                {
                    ret[iLine] = curStr.ToString();
                    curStr.Length = 0;
                    iLine++;
                }
            }

            // last line has not been written to array yet
            if (curStr.Length > 0)
            {
                ret[iLine] = curStr.ToString();
            }

            // add closing bracket
            ret[ret.Length - 1] = ret[ret.Length - 1] + ")";

            return ret;
        }

        Char[] myTrimEndBlob = new Char[] { ')' };

        void UpdateBlobReferences(int currentLine)
        {
            string line = myTrimmedIlFile[currentLine];
            int idx = line.IndexOf(BinaryBlobToken);
            StringBuilder fullBlob = new StringBuilder();

            int nBlobLines = 1;
            string blobLine = line.Substring(idx + 5);
            fullBlob.Append(blobLine.TrimEnd(myTrimEndBlob)+' ');
            // get other blob data
            while (!blobLine.Contains(")"))
            {
                currentLine++;
                nBlobLines++;
                blobLine = myTrimmedIlFile[currentLine];
                fullBlob.Append(blobLine.TrimEnd(myTrimEndBlob) + ' ');
            }

            string str = GetBlobString(fullBlob.ToString());
            string [] lines = GenerateBlobLines(str);

        }

        string ModifyAttribute(string line)
        {
            bool bInString = false;
            StringBuilder sb = new StringBuilder();
            foreach (Char c in line)
            {
                if (c == '\'')
                {
                    bInString = !bInString;
                    continue;
                }

                if (bInString)
                    sb.Append(c);
                else if (sb.Length > 0)
                {
                    break;
                }
            }


            string typeName = sb.ToString();

            string assemblyName;
            if (typeName.Contains("["))
                assemblyName = typeName.Substring(typeName.IndexOf("],") + 2);
            else
                assemblyName = typeName.Substring(typeName.IndexOf(',') + 1);

            if( String.IsNullOrEmpty(assemblyName))
            {
                throw new InvalidOperationException(String.Format("The assembly name was null or empty for type #{0}#, parsed line: {1}",typeName, line));
            }

            AssemblyName curName;
            try
            {
                // Console.WriteLine("Found strong type name: {0}\nAssembly: {1}", typeName, assemblyName);
                curName = new AssemblyName(assemblyName);
            }
            catch(FileLoadException ex)
            {
                Console.WriteLine("Could not determine assembly name of file {0}. Error: {1}", assemblyName, ex);
                throw;
            }

            //Console.WriteLine("PublicKeyToken Len: {0}", curName.GetPublicKeyToken().Length);
            if (curName.GetPublicKeyToken().Length == 0)
            {
                AssemblyName newName = myNames.GetAssemblyName(curName.Name) ?? curName;
                newName.SetPublicKeyToken(myPulicKeyTokenBlob);
                return line.Replace(assemblyName, newName.FullName);
            }
            else
            {
                //Console.WriteLine("Strong Name not touched: {0}", assemblyName);
                return line;
            }
        }
    }
}

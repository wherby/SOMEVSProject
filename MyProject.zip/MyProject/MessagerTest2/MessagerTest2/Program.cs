﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows.Forms;

namespace MessagerTest2
{
    class Program
    {
        static void Main(string[] args)
        {
            MessageBox.Show("Clicked","Test");
        }

        public void click()
        {
            MessageBox.Show("Clicked", "Test");
        }
    }
}

﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using PowerShellTestTools;
using System.Diagnostics;

namespace PowerShellAutomationTest
{
    [TestClass]
    public class TestDriver
    {
        [TestMethod]
        public void TestMethod1()
        {
            TestLog log = TestLog.GetInstance("TestSummary") ;
            log.LogTestCase("Test Driver Run");
            string cmdsString = HelperAdapter.GetProperty("CMDToTest");
            log.LogTestCase(string.Format("CMD to Test: {0}", cmdsString));
            //ExecuteCmd(@"dir . >C:\a.txt");

            StringBuilder sb = new StringBuilder();
            sb.AppendFormat(@"""C:\Program Files (x86)\Microsoft Visual Studio 10.0\Common7\IDE\MSTest.exe""");
            sb.Append(@" /nologo /usestderr /testSettings:"".\Local.testsettings""");
           // sb.Append(@" /resultsfileroot:""\\Lamanna-srv-vm5\6\PowerShellAutomation\PowerShellAutomation\TestResults""");
            
            sb.Append(@" /testcontainer:"".\PowerShellAutomation.dll""");

            string[] cmds = cmdsString.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries); 
            string runString=sb.ToString();
           
            foreach (string cmd in cmds)
            {
                sb.Clear();
                sb.AppendFormat(" /test:PS_{0}Test /test:PS_{0}NegativeTest", cmd);
                string time = DateTime.Now.ToString("Hms");
                string resultFile = @"\\Lamanna-srv-vm5\6\PowerShellAutomation\PowerShellAutomation\TestResults\"+cmd + time+".trx";
                sb.AppendFormat(" /resultsfile:{0}",resultFile);
                string buildString = runString+sb.ToString();
                ExecuteCmd(buildString);
            }
        }

        private void ExecuteCmd(string command)
        {
            TestLog log = TestLog.GetInstance();
            log.LogTestCase(string.Format("Start: {0}",command));
            Process p = new Process();
            p.StartInfo.FileName = "cmd.exe";
            p.StartInfo.UseShellExecute = false;
            p.StartInfo.RedirectStandardInput = true;
            p.StartInfo.RedirectStandardOutput = true;
            p.StartInfo.CreateNoWindow = true;
            p.Start();
            p.StandardInput.WriteLine(command);
            p.StandardInput.WriteLine("exit");
            log.LogTestCase(p.StandardOutput.ReadToEnd());
            log.LogTestCase("Finish");
            p.WaitForExit();

            p.Close();
        }
    }
}

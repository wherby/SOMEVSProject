﻿using System.Text;

using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Collections.ObjectModel;

using PowerShellTestTools;
using System.Collections.Generic;
using System.Threading;
using System;


namespace PowerShellAutomation
{
    public enum MountPoint
    {
        None,
        DriveLetter,
        MountPath
    }

    public class TestSetup
    {

        public static int InitForEMCStorage(PowershellMachine psMachine)
        {
            Runspace runspace = psMachine.GetRunspace();
            TestLog log = TestLog.GetInstance();
            //create a pipeline
            Pipeline pipeline = runspace.CreatePipeline();

            pipeline.Commands.AddScript("$error.clear()");
            log.LogInfo("Set Execution Policy to RemoteSigned");
            pipeline.Commands.AddScript("Set-ExecutionPolicy RemoteSigned");
            log.LogInfo("ImportESIPSToolKit Module");
            pipeline.Commands.AddScript("Import-Module -Name ESIPSToolKit");
            
            pipeline.Invoke();
            
            // Fetch the error output of PowerShell
            Pipeline pipeline2 = runspace.CreatePipeline();
            string scr = "if($error.count -gt 0){$error}";
            pipeline2.Commands.AddScript(scr);

            Collection<PSObject> errors = pipeline2.Invoke();

            if (errors.Count > 0)
            {
                foreach (PSObject err in errors)
                {
                    log.LogError(err.ToString());
                }

                log.LogInfo("Failed to import ESIPSToolKit Module");
                return 1;
            }
           
            return 0;
        }

        /// <summary>
        /// SetStorageEnvironment
        ///     Select an available storage system at random
        /// </summary>
        /// <param name="psMachine">PowerShell Machine instance</param>
        /// <param name="type">Block/File/All</param>
        /// <returns>storage system name</returns>
        public static string SetStorageEnvironment(PowershellMachine psMachine, string type = "Block")
        {
            TestLog log = TestLog.GetInstance();
            string path = HelperAdapter.GetProperty("SystemConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Storage");
            string storageValue = null;

            if (dic.TryGetValue(type, out storageValue) == false)
            {
                log.LogWarning("Can not find value of" + type + " in Storage");
                PSException pe = new PSException("Can not find value of" + type + " in Storage");
                throw pe;
            }
            else
            {
                string[] storages = storageValue.Split(new char[]{',', ' '}, StringSplitOptions.RemoveEmptyEntries);
                List<int> rdList = new List<int>();
                while (true)
                {
                    Random rn = new Random();
                    int iResult;
                    iResult = rn.Next(0, storages.Length);
                    if( rdList.Contains(iResult))
                    {
                        continue;
                    }
                    string blob = HelperAdapter.GetBlobContent(storages[iResult]);
                    if (blob != null)
                    {
                        return storages[iResult];
                    }
                    else
                    {
                        rdList.Add(iResult);
                        if (rdList.Count == storages.Length)
                        {
                            log.LogWarning("All storages of " + type + " are unavailable");
                            PSException pe = new PSException("All storages of " + type + " are unavailable");
                            throw pe;
                        }
                    }
                }
            }
        }

        /// <summary>
        /// The method is to initialize $pool parameter with selected pool from storagepools.
        /// </summary>
        /// <param name="psMachine">PowerShell Machine instance.</param>
        /// <param name="thin">The type of a pool.</param>
        /// <param name="capacity">The minimun capacity of a pool</param>
        /// <param name="poolType">The type of a pool: "RaidGroup", "Pool", "MetaLuns" and "SnapshotLuns" </param>
        /// <returns> The pool information.</returns>
        public static string SetPoolEnvironment(PowershellMachine psMachine, string thin="True",string capacity="5000", string poolType="Pool", string prefix = null)
        {
            string arrayPoolIDOrName;
            string path = HelperAdapter.GetProperty("LunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            string filter = dic["PoolFilter"];
            
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Pool");
            }            

            if (filter.Equals("true", StringComparison.OrdinalIgnoreCase))
            {
                SortedList<string, string> poolFilter = HelperAdapter.GenerateEmptyPoolFilter();
                poolFilter["Thin"] = thin;
                poolFilter["Capacity"] = capacity;
                poolFilter["PoolType"] = poolType;
                GetEmcStoragePool pool = new GetEmcStoragePool();
                string poolString = pool.RunCMD(psMachine, true);
                arrayPoolIDOrName = HelperAdapter.SelectPool(poolString, poolFilter);                              
            }
            else
            {
                arrayPoolIDOrName = dic["PoolName"];
            }

            if (arrayPoolIDOrName == null)
            {
                return null;
            }  
            GetEmcStoragePool getPool = new GetEmcStoragePool(arrayPoolIDOrName);
            getPool.PrefixString = prefix;
            string result = getPool.RunCMD(psMachine, true);
            return result;
        }

        /// <summary>
        /// SetLunEnvironment
        ///     Create a lun for test    
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="thinFlag">the flag for thin lun</param>
        /// <param name="poolPrefix">the prefix used for the pool</param>
        /// <param name="lunPrefix">the prefix used for the lun</param>
        /// <returns>New-EmcLun output string</returns>
        public static string SetLunEnvironment(PowershellMachine psMachine, bool thinFlag = true, string poolPrefix = null, string lunPrefix = null)
        {
            if (poolPrefix == null)
            {
                poolPrefix = HelperAdapter.GetParameter("Pool");
            }
            if (lunPrefix == null)
            {
                lunPrefix = HelperAdapter.GetParameter("Lun");
            }
            string lunName = HelperAdapter.GenerateLunName();
            string path = HelperAdapter.GetProperty("LunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            NewEmcLun lun;
            if (thinFlag)
            {
                lun = new NewEmcLun(poolPrefix, dic["CapacityInMB"], lunName, "Thin", dic["Description"]);
            }
            else
            {
                lun = new NewEmcLun(poolPrefix, dic["CapacityInMB"], lunName, null, dic["Description"]);
            }
            lun.PrefixString = lunPrefix;
            string result = lun.VerifyTheCMD(psMachine);

            return result;
        }

        /// <summary>
        /// The method is mask a lun to a host and find the lun.
        ///    After the method there will add $host for the host machine, $disk for disk whihc the lun is masked. 
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="prefix">The disk parameter.</param>
        /// <param name="host">The host parameter.</param>
        /// <param name="lun">The lun parameter.</param>
        /// <param name="cluster">The cluster parameter.</param>
        /// <param name="isInitialize">Flag to indicate whether to initialize a disk</param>
        /// <returns>The result for Find-EmcHostDisk.</returns>
        public static string SetDiskEnvironment(PowershellMachine psMachine, string prefix = null,string host=null,string lun=null,string cluster=null, bool isInitialize=true)
        {
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Disk");
            }
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (lun == null)
            {
                lun = HelperAdapter.GetParameter("Lun");
            }
            SetEmcLunAccess setLunAccess = new SetEmcLunAccess("Available", lun, host, null, null, null, cluster);
            setLunAccess.RunCMD(psMachine, false);
            FindEmcHostDisk findDisk = new FindEmcHostDisk(host, cluster, null, null, lun);
            findDisk.PrefixString = prefix;
            string result = findDisk.RunCMD(psMachine, true);
            if (isInitialize)
            {
                InitializeEmcHostDisk initializeDisk = new InitializeEmcHostDisk(null, prefix, host, cluster);
                if (cluster == null)
                {
                    initializeDisk.VerifyTheCMD(psMachine, lun, prefix, host);
                }
                else
                {
                    initializeDisk.VerifyTheCMD(psMachine, lun, prefix, null, cluster);
                }
            }

            return result; 
        }

        /// <summary>
        /// This method is used to set host environment.
        ///  After the method, $host is set to the host machine.
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="prefix">Prefix for host.</param>
        public static void SetHostEnvironment(PowershellMachine psMachine, string prefix = null)
        {
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Host");
            }
            string blob = HelperAdapter.GetBlobContent("Host");
            ConnectEmcSystem hostSystem = new ConnectEmcSystem(blob);
            hostSystem.RunCMD(psMachine);
            string path = HelperAdapter.GetProperty("SystemConfig");
            Dictionary<string, string> dicForHost = HelperAdapter.Load(path, "Host");
            string ipAddress = dicForHost["IPAddress"];
            GetEmcHostSystem host = new GetEmcHostSystem(ipAddress);
            host.PrefixString = prefix;
            host.RunCMD(psMachine, true);
        }

        /// <summary>
        /// SetVolumeEnvironment
        ///     New a volume on a host or cluster, set the mount point if required
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="lun">The lun parameter</param>
        /// <param name="disk">The host disk parameter</param>
        /// <param name="host">The host system parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        /// <param name="prefix">Prefix of the volume</param>
        /// <param name="mountPoint">Mount point of the volume</param>
        /// <returns>volume information</returns>
        public static string SetVolumeEnvironment(PowershellMachine psMachine, string disk = null, string host = null, string cluster = null, string prefix = null, MountPoint mountPoint = MountPoint.None, string mountPath = null)
        {
            if (disk == null)
            {
                disk = HelperAdapter.GetParameter("Disk");
            }
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Volume");
            }
            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Volume");
            
            string random = HelperAdapter.GenerateRandomString();
            string label = dic["LabelPrefix"] + random;
            NewEmcVolume volume = new NewEmcVolume(host, cluster, disk, null, null, null, label);
            volume.PrefixString = prefix;
            string result = volume.RunCMD(psMachine, true);

            SetEmcVolumeMountPoint setMountPoint = null;

            switch (mountPoint)
            {
                case MountPoint.DriveLetter:
                    {
                        string letter = GetRandomDriveLetter(psMachine, host, cluster);
                        setMountPoint = new SetEmcVolumeMountPoint(prefix, host, letter, null, cluster);
                        setMountPoint.RunCMD(psMachine);
                        break;
                    }
                case MountPoint.MountPath:
                    {
                        if (mountPath == null)
                        {
                            mountPath = dic["MountPathPrefix"] + random;
                        }
                        setMountPoint = new SetEmcVolumeMountPoint(prefix, host, null, mountPath, cluster);
                        setMountPoint.RunCMD(psMachine);
                        break;
                    }
                default:
                    {
                        break;
                    }
            }

            return result;
        }


        /// <summary>
        /// SetClusterDiskEnvironment
        ///     Add host disk to cluster system, must be used after New-EmcVolume
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instancea</param>
        /// <param name="hostDisk">The host disk parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        /// <returns>cluster disk information</returns>
        public static string SetClusterDiskEnvironment(PowershellMachine psMachine, string hostDisk = null, string cluster = null, string clusterDisk = null, bool isAddToSharedVolume = false)
        {
            string addToSharedVolume = null;
            if (hostDisk == null)
            {
                hostDisk = HelperAdapter.GetParameter("Disk");
            }
            if (cluster == null)
            {
                cluster = HelperAdapter.GetParameter("Cluster");
            }

            if (clusterDisk == null)
            {
                clusterDisk = HelperAdapter.GetParameter("ClusterDisk");
            }

            if (isAddToSharedVolume)
            {
                addToSharedVolume = "AddToClusterSharedVolume";
            }

            AddEmcHostDiskToCluster addDisk = new AddEmcHostDiskToCluster(cluster, hostDisk + ".HostLunIdentifier", null, addToSharedVolume);
            addDisk.PrefixString = clusterDisk;
            string result = addDisk.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// ClearClusterDiskEnvironment
        ///     Remove host disk from cluster system and update the cluster system
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="hostDisk">The host disk paramter</param>
        /// <param name="cluster">The cluster system paramter</param>
        public static void ClearClusterDiskEnvironment(PowershellMachine psMachine, string hostDisk = null, string cluster = null)
        {
            if (hostDisk == null)
            {
                hostDisk = HelperAdapter.GetParameter("Disk");
            }
            if (cluster == null)
            {
                cluster = HelperAdapter.GetParameter("Cluster");
            }
            RemoveEmcHostDiskFromCluster removeDisk = new RemoveEmcHostDiskFromCluster(null, cluster, hostDisk);
            removeDisk.RunCMD(psMachine);
            Thread.Sleep(5000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(null, null, cluster);
            updateSystem.RunCMD(psMachine);
        }

        /// <summary>
        /// ClearVolumeEnvironment
        ///     Remove the volume's mount point
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="volume">The volume parameter</param>
        /// <param name="host">The host system parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        public static void ClearVolumeEnvironment(PowershellMachine psMachine, string volume =null, string host = null, string cluster = null)
        {
            if (volume == null)
            {
                volume = HelperAdapter.GetParameter("Volume");
            }
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            RemoveEmcVolumeMountPoint removeVolume = new RemoveEmcVolumeMountPoint(volume, host, cluster);
            removeVolume.RunCMD(psMachine);
        }

        /// <summary>
        /// The method is unmask a lun from host.
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="host">The host parametere.</param>
        /// <param name="lun">The lun parameter.</param>
        public static void ClearDiskEnvironment(PowershellMachine psMachine,string host = null , string cluster = null, string lun = null)
        {
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (lun == null)
            {
                lun = HelperAdapter.GetParameter("Lun");
            }

            SetEmcLunAccess setLunAccess = new SetEmcLunAccess("Unavailable", lun, host, null, null, null, cluster);
            setLunAccess.RunCMD(psMachine, false);
            Thread.Sleep(5000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(host, null, cluster);
            updateSystem.RunCMD(psMachine);
        }

        /// <summary>
        /// ClearLunEnvironment
        ///     Remove a lun
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="lunPrefix">prefix used for a lun</param>
        public static void ClearLunEnvironment(PowershellMachine psMachine, string lunPrefix = null)
        {
            if (lunPrefix == null)
            {
                lunPrefix = HelperAdapter.GetParameter("Lun");
            }   
            RemoveEmcLun removeLun = new RemoveEmcLun(lunPrefix);
            removeLun.RunCMD(psMachine);
        }
        /// <summary>
        /// ConnectSystem
        ///     Connect Host/Storage/Cluster System
        /// </summary>
        /// <param name="psMachine"></param>
        /// <param name="type">"Host"/"Cluster"/"CLARiiON-CX4/"VMAX"/"VMAXe"/"VNX"/"VNX-Block"/"VNX-CIFS"</param>
        /// <param name="prefix">The parameter in powershell.</param>
        /// <returns>The result for connectsystem.</returns>
        public static string ConnectSystem(PowershellMachine psMachine, string type, string prefix = null)
        {
            if (prefix == null) 
            {
                prefix = HelperAdapter.GetParameter("System");
            }
            string blob = HelperAdapter.GetBlobContent(type);

            ConnectEmcSystem connectSystem = new ConnectEmcSystem(blob);

            connectSystem.PrefixString = prefix;

            string result = connectSystem.RunCMD(psMachine, true);

            return result;
        }



        /// <summary>
        /// The method is used to get value of parameter which is used in the powershell session.
        /// </summary>
        /// <param name="psMachine">The Powershell machine instance.</param>
        /// <param name="parameter">The parameter name defined in PSParameterConfig fiel.</param>
        /// <param name="parameterName">The parameter name defined in PS section.</param>
        /// <returns>The value for the parameter in the powershell session.</returns>
        public static string GetParameterValue(PowershellMachine psMachine, string parameter,string parameterName=null)
        {
            if (parameterName == null)
            {
                parameterName = HelperAdapter.GetParameter(parameter);
            }
            List<string> ps = new List<string>();
            ps.Add(parameterName);
            string parameterValue=psMachine.RunScript(ps, new List<PSParam> { }).OutStr;
            return parameterValue;
        }
        
        /// <summary>
        /// DisconnectSystem
        ///     Disconnect Host/Storage/Cluster System
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="id">User Friendly Name/Global Id</param>
        /// <param name="system">The system parameter</param>
        public static void DisconnectSystem(PowershellMachine psMachine, string id = null, string system = null)
        {
            DisconnectEmcSystem disconnectSystem = new DisconnectEmcSystem(id, system);
            disconnectSystem.RunCMD(psMachine);
        }

        /// <summary>
        /// GetRandomScsiController
        ///    Get Random ScsiController, including ScsiControllerIndex and ScsiControllerId
        /// </summary>
        /// <param name="psMachine">PowerShell machine</param>
        /// <param name="scsiControllerPrefix">the variable for ScsiController</param>
        /// <param name="vmConfigPrefix">the variable for Virtual machine configuraiton</param>
        /// <returns>A random picked up ScsiController</returns>
        public static SortedList<string, string> GetRandomScsiController(PowershellMachine psMachine, string scsiControllerPrefix = null, string vmConfigPrefix = null)
        {
            List<string> ps = new List<string>();
            Random rand = new Random();
            SortedList<string, string> scsiController = new SortedList<string, string>();

            if (scsiControllerPrefix == null)
            {
                scsiControllerPrefix = HelperAdapter.GetParameter("ScsiController");
            }

            if (vmConfigPrefix == null)
            {
                vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }

            // Get ScsiController 
            GetEmcVirtualMachineScsiController getScsiController = new GetEmcVirtualMachineScsiController(vmConfigPrefix);
            getScsiController.PrefixString = scsiControllerPrefix;
            getScsiController.RunCMD(psMachine, true);

            ps.Add(scsiControllerPrefix + ".count");
            string result = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            if (result.Trim() == string.Empty)
            {
                // scsiController object is not an array, mean there's only 1 scsi controller in the vm
                ps.Add(scsiControllerPrefix + ".ScsiControllerIndex");
                string scsiControllerIndex = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr.Trim();
                scsiController.Add("ScsiControllerIndex", scsiControllerIndex);

                ps.Clear();
                ps.Add(scsiControllerPrefix + ".ScsiControllerId");
                string scsiControllerId = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr.Trim();
                scsiController.Add("ScsiControllerId", scsiControllerId);
            }
            else
            {
                // multiple scsi controllers
                int count = int.Parse(result);
                int i = rand.Next(count);
                ps.Add(scsiControllerPrefix + "[" + i.ToString() + "]" + ".ScsiControllerIndex");
                string scsiControllerIndex = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr.Trim();
                scsiController.Add("ScsiControllerIndex", scsiControllerIndex);
                ps.Clear();
                ps.Add(scsiControllerPrefix + "[" + i.ToString() + "]" + ".ScsiControllerId");
                string scsiControllerId = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr.Trim();
                scsiController.Add("ScsiControllerId", scsiControllerId);
            }

            return scsiController;

        }

        /// <summary>
        /// GetRandomScsiControllerLocation
        ///    Get the random available scsi controller location
        /// </summary>
        /// <param name="psMachine">PowerShell machine</param>
        /// <param name="scsiControllerIndex">string of scsi controller index</param>
        /// <param name="scsiControllerId">string of scsi controller id</param>
        /// <param name="hypervPrefix">prefix for hyprvisor object</param>
        /// <param name="vmConfigurationPrefix">prefix for virtual machine configuration object</param>
        /// <returns></returns>
        public static string GetRandomScsiControllerLocation(PowershellMachine psMachine, string scsiControllerIndex = null, string scsiControllerId = null,
            string hypervPrefix = null, string vmConfigurationPrefix = null)
        {
            Random rand = new Random();

            if (hypervPrefix == null)
            {
                hypervPrefix = HelperAdapter.GetParameter("Hypervisor");
            }

            if (vmConfigurationPrefix == null)
            {
                vmConfigurationPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }
            GetEmcAvailableScsiControllerLocation getScsiControllerLocation = new GetEmcAvailableScsiControllerLocation(vmConfigurationPrefix, hypervPrefix,
                scsiControllerIndex, scsiControllerId);
            string result = getScsiControllerLocation.RunCMD(psMachine, true);
            string[] resultLines = result.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            int i = rand.Next(resultLines.Length);
            return resultLines[i];
        }

        /// <summary>
        /// GetRandomPassthroughDisk
        ///     Get the random available passthrough disk
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="hypervPrefix">The prefix of hypervisor</param>
        /// <param name="psthruDiskPrefix">The prefix of passthrough disk</param>
        /// <returns>The key/value pairs of the passthrough disk</returns>
        public static SortedList<string, string> GetRandomPassthroughDisk(PowershellMachine psMachine, string hypervPrefix = null, string psthruDiskPrefix = null)
        {
            Random rand = new Random();
            List<string> ps = new List<string>();

            if (hypervPrefix == null)
            {
                hypervPrefix = HelperAdapter.GetParameter("Hypervisor");
            }
            if (psthruDiskPrefix == null)
            {
                psthruDiskPrefix = HelperAdapter.GetParameter("PassthroughDisk");
            }

            GetEmcAvailablePassthroughDiskCandidate getPassthroughDisk = new GetEmcAvailablePassthroughDiskCandidate(hypervPrefix);
            getPassthroughDisk.PrefixString = HelperAdapter.GetParameter("PassthroughDisks");
            string result = getPassthroughDisk.RunCMD(psMachine, true);
            List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(result);

            int i = 0;
            if (disksList.Count == 1)
            {
                ps.Add(psthruDiskPrefix + " = " + getPassthroughDisk.PrefixString);
                psMachine.RunScript(ps, new List<PSParam>());
            }
            else
            {
                i = rand.Next(disksList.Count);

                ps.Add(psthruDiskPrefix + " = " + getPassthroughDisk.PrefixString + "[" + i + "]");
                psMachine.RunScript(ps, new List<PSParam>());
            }

            return disksList[i];
        }

        /// <summary>
        /// GetRandomDriveLetter
        ///     Get the random available drive letter of a host system or cluster system
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="host">The host system parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        /// <returns>drive letter</returns>
        public static string GetRandomDriveLetter( PowershellMachine psMachine, string host = null, string cluster = null )
        {
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }

            GetEmcAvailableDriverLetter getLetter = new GetEmcAvailableDriverLetter(host, cluster);
            string result = getLetter.RunCMD(psMachine, true);

            string[] resultLines = result.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);

            Random rand = new Random();
            int i = rand.Next(resultLines.Length);

            return resultLines[i];
        }

        /// <summary>
        /// The method is to set HostbusAdapter parameter.
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="hostString">The host system.</param>
        /// <param name="prefix">The parameter for HostbusAdapter.</param>
        public static void SetHBAEnvironment(PowershellMachine psMachine, string hostString = null, string prefix = null)
        {
            if (hostString == null)
            {
                hostString = HelperAdapter.GetParameter("Host");
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("HostbusAdapter");
            }
            UpdateEmcSystem update=new UpdateEmcSystem(hostString);
            update.RunCMD(psMachine);
            List<string> ps=new List<string>();
            ps.Add(string.Format("{0}.RefreshHostBusAdapters()",hostString));
            ps.Add(string.Format("{0}={1}.HostBusAdapters",prefix,hostString));
            psMachine.RunScript(ps,new List<PSParam>());
        }


    }
}

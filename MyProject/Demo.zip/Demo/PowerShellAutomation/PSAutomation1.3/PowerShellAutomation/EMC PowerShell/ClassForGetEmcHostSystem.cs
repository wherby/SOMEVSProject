﻿using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcHostSystem:BaseClass
    {
        #region CMD fields
        private string idString;
        private string diskString;
        private string volumeString;
        private string hostSystemTypeString;
        private string silentString;
        private int getSystemCount;
        private SortedList<string, string>[] connectSystemKeyValue;
        #endregion

        public int GetSystemCount
        {
            get
            {
                return getSystemCount;
            }
            set
            {
                getSystemCount = value;
            }
        }

        public SortedList<string, string>[] ConnectSystemKeyValue
        {
            get
            {
                return connectSystemKeyValue;
            }
            set
            {
                connectSystemKeyValue = value;
            }
        }

        public GetEmcHostSystem(string id = null, string disk = null, string volume = null, string hostSystemType = null, string silent = null, string cmd = null)
        {
            idString = id;
            diskString = disk;
            volumeString = volume;
            hostSystemTypeString = hostSystemType;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcHostSystem");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            if (hostSystemTypeString != null)
            {
                sb.AppendFormat(" -HostSystemType {0}", hostSystemTypeString);
            }
            if (diskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", diskString);
            }
            if (volumeString != null)
            {
                sb.AppendFormat(" -Volume {0}", volumeString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent {0}", silentString);
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getSystemKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            log.AreEqual<int>(getSystemCount, getSystemKeyValueList.Count, "Verify get system count");

            foreach (SortedList<string, string> keyValue in getSystemKeyValueList)
            {
                VerifyFields(keyValue, psMachine);
            }

            return result;
        }

        private void VerifyFields(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
      
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            #endregion

            if (hostSystemTypeString == "VmWare")
            {
                //TODO
            }
            else if (hostSystemTypeString == "HyperV")
            {
                log.AreEqual<string>("Hyper-V, PowerEdge R610", getSystemKeyValue["Model"], "Verify HyperV Module");
            }


            log.AreEqual<string>("HostSystem", getSystemKeyValue["AdapterType"], "Verify Adapter Type");

            string[] keys = { "HostDisks", "HostVolumes", "AvailablePassthroughDiskCandidates" };

            string[] result = new string[keys.Length];
            List<string> excludeKeys = new List<string>();
            GetEmcHostSystem system = new GetEmcHostSystem(getSystemKeyValue["GlobalId"]);
            system.PrefixString = "$verifyHost";
            system.RunCMD(psMachine);

            GetEmcHostDisk disk = new GetEmcHostDisk(null, null, null, system.PrefixString);
            disk.PrefixString = "$verifyDisk";
            result[0] = disk.RunCMD(psMachine);

            GetEmcHostVolume volume = new GetEmcHostVolume(null, null, system.PrefixString);
            volume.PrefixString = "$verifyVolume";
            result[1] = volume.RunCMD(psMachine);

            if (getSystemKeyValue.ContainsKey("AvailablePassthroughDiskCandidates"))
            {
                GetEmcAvailablePassthroughDiskCandidate psthruDisk = new GetEmcAvailablePassthroughDiskCandidate(system.PrefixString);
                result[2] = psthruDisk.RunCMD(psMachine);
            }

            
            string[] split1 = { "{[", "], [", "]}", "]...}", "],["};
            string[] split2 = { "."};
            string[] split3 = { ":"};

            for (int i = 0; i < keys.Length; i++)
            {
                string key = keys[i];
                if (getSystemKeyValue.ContainsKey(key) && getSystemKeyValue[key] != "{}")
                {
                    excludeKeys.Add(key);

                    VerifyComplexEntry(getSystemKeyValue[key], result[i], split1, split2, split3);
                }
            }
            if (getSystemKeyValue.ContainsKey("HostBusAdapters") && getSystemKeyValue["HostBusAdapters"] != "{}")
            {
                excludeKeys.Add("HostBusAdapters");
                
                string[] adapters = getSystemKeyValue["HostBusAdapters"].Split(new string[]{"{", "}", "[", "]", ",", "..."}, 3, StringSplitOptions.RemoveEmptyEntries);
                foreach(string adapter in adapters)
                {
                    bool adptersTrue = false;

                    string[] info = adapter.Split(new string[]{". HostName=", ". Id= "}, 3, StringSplitOptions.RemoveEmptyEntries);

                    string path = HelperAdapter.GetProperty("SystemConfig");
                    string[] hosts = { "Host", "Hypervisor" };
                    foreach (string host in hosts)
                    {
                        Dictionary<string, string> dic = HelperAdapter.Load(path, host);
                        if (dic["HostName"].ToLower() == info[1].Trim().ToLower() && dic["InitiatorId"].ToLower() == info[2].Trim().ToLower())
                        {
                            adptersTrue = true;
                            break;
                        }
                    }

                    log.AreEqual<bool>(true, adptersTrue, "Verify Host Bus Adapters");
                }
            }

            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, getSystemKeyValue, excludeKeys))
                {
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify host system key value exists in connected host systems");
            
        }

        private void VerifyComplexEntry(string entryValue, string result, string[] split1, string[] split2 = null , string[] split3 = null, string key = null)
        {
            TestLog log = TestLog.GetInstance();

            List<SortedList<string, string>> list = HelperAdapter.GenerateKeyValuePairsList(result);

            string[] bigArray = entryValue.Split(split1, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < bigArray.Length; i++)
            {                 
                if (split2 != null)
                {
                   string[] midArray = bigArray[i].Split(split2, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < midArray.Length; j++)
                    {
                        if (split3 != null)
                        {                        
                            string[] smallArray = midArray[j].Split(split3, 2, StringSplitOptions.None);
                            log.AreEqual<string>(smallArray[1].Trim(), list[i][smallArray[0].Trim()], string.Format("Verify {0}", smallArray[0]));
                        }
                        else
                        {
                            log.AreEqual<string>(midArray[1].Trim(), list[i][midArray[0].Trim()], string.Format("Verify {0}", midArray[0]));
                        }
                    }                    
                }
                else
                {
                    if (key != null)
                    {
                        log.AreEqual<string>(bigArray[i].Trim(), list[i][key], string.Format("Verify {0}", key));
                    }
                }
            }
            
        }
    }
}

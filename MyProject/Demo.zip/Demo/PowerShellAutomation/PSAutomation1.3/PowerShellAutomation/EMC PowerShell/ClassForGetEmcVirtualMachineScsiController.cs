﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualMachineScsiController:BaseClass
    {
        private string vmConfigurationString = null;
        private string vmString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcVirtualMachineScsiController
        ///     GetEmcVirtualMachineScsiController class constructor
        /// </summary>
        /// <param name="vmConfig">VirtualMachineConfiguration object</param>
        /// <param name="vm">VirtualMachine object</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcVirtualMachineScsiController(string vmConfig = null, string vm = null, string silent=null, string cmd = null)
        {
            vmConfigurationString = vmConfig;
            vmString = vm;
            silentString = silent;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualMachineScsiController");

            if (vmConfigurationString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", vmConfigurationString);
            }
            else if (vmString != null)
            {
                sb.AppendFormat(" -VirtualMachine {0}", vmString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualMachineScsiController command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <returns>Get-EmcVirtualMachineScsiController result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            List<string> ps = new List<string>();

            PrefixString = HelperAdapter.GetParameter("ScsiController");           

            string result = RunCMD(psMachine, true);
            
            ps.Add( PrefixString + ".count");
            string ret = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            if (ret.Trim() == string.Empty)
            {
                // ScsiController object is not an array, mean there's only 1 scsi controller in the vm
                ps.Clear();
                ps.Add(PrefixString + ".VmName");
                string vmName = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
                ps.Clear();
                ps.Add(PrefixString + ".ScsiControllerId");
                string scsiControllerId = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;

                VerifyFields(psMachine, vmName, scsiControllerId); 
            }
            else
            {
                // multiple scsi controllers
                int count = int.Parse(result);
                ps.Clear();
                for (int i = 0; i < count; i++)
                {
                    ps.Add(PrefixString + "[" + i.ToString() + "]" + ".VmName");
                    string vmName = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
                    ps.Clear();
                    ps.Add(PrefixString + "[" + i.ToString() + "]" + ".ScsiControllerId");
                    string scsiControllerId = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;

                    VerifyFields(psMachine, vmName, scsiControllerId);
                }
            }
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualMachineScsiController
        /// </summary>
        /// <param name="vmName">Virtual Machine Name</param>
        /// <param name="scsiControllerId">Scsi Controller Id</param>    
        private void VerifyFields(PowershellMachine psMachine, string vmName, string scsiControllerId)
        {
            List<string> ps = new List<string>();

            string vmConfigPrefix;

            if (vmConfigurationString == null)
            {
                vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }
            else
            {
                vmConfigPrefix = vmConfigurationString;
            }

            ps.Add(vmConfigPrefix + ".Name");   
            string expectedVMName = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            ps.Clear();
            ps.Add(vmConfigPrefix + ".ScsiControllersIds"); 
            string scsiControllersIds = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;

            #region verification for fields
            log.AreEqual(expectedVMName, vmName, "The name of the Virtual Machine: ");
            if (!scsiControllersIds.Contains(scsiControllerId.Trim()))
            {
                log.LogError(string.Format("ScsiControllerId {0} doesn't exist in Virtual Machine Configuration.", scsiControllerId));
                PSException pe = new PSException(string.Format("ScsiControllerId {0} doesn't exist in Virtual Machine Configuration.", scsiControllerId));
                throw pe;
            }
            #endregion
        }
    }
}
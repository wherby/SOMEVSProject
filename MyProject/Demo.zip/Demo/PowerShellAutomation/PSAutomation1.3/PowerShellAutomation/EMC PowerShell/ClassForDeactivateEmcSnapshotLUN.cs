﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class DeactivateEmcSnapshotLUN : BaseClass
    {
        #region CMD fields
        private string snapshotLunString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatIfString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// DeactivateEmcSnapshotLUN
        ///    Constructor for DeactivateEmcSnapshotLUN class
        /// </summary>
        /// <param name="snapshotLun">snapshot lun object string</param>
        /// <param name="force">The force switch parameter</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="whatif">The whatif switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public DeactivateEmcSnapshotLUN(string snapshotLun, string force=null, string silent=null, string whatif=null, string cmd = null)
        {
            snapshotLunString = snapshotLun;
            forceString = force;
            silentString = silent;
            whatIfString = whatif;
            CmdString = cmd;            
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Deactivate-EmcSnapshotLUN");

            if (snapshotLunString != null)
            {
                sb.AppendFormat(" -SnapshotLUN {0}", snapshotLunString);
            }
            if (forceString != null)
            {
                sb.Append(" -Force");
            }
            if (whatIfString != null)
            {
                sb.Append(" -WhatIf");
            }
            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            sb.Append(" -Confirm:$false");
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whethe Remove-EmcSnapshotLun succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="lunID">snapshot lun id or lun name</param>
        /// <returns>result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string lunID)
        {
            string result = RunCMD(psMachine);            

            //TBD
            //VerifyFields(psMachine);
            return result;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcFileBasedDisk : BaseClass
    {
        #region CMD fields
        private string hypervString = null;
        private string pathString = null;
        private string sizeString = null;
        private string diskTypeString = null;
        private string silentString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// NewEmcFileBasedDisk
        ///     Constructor for New-EmcFileBasedDisk class
        /// </summary>
        /// <param name="hyperv">The hypervisor object</param>
        /// <param name="path">The path for file based disk</param>
        /// <param name="size">The size for file based disk</param>
        /// <param name="diskType">The disk type for file based disk, either fixed or dynamic</param>
        /// <param name="silent">The silent switch paramter</param>
        /// <param name="cmd">Command string to test</param>
        public NewEmcFileBasedDisk(string hyperv, string path, string size, string diskType, string silent = null, string cmd = null)
        {
            hypervString = hyperv;
            pathString = path;
            sizeString = size;
            diskTypeString = diskType;
            silentString = silent;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcFileBasedDisk");

            if (hypervString != null)
            {
                sb.AppendFormat(" -Hypervisor {0}", hypervString);
            }

            if (pathString!= null)
            {
                sb.AppendFormat(" -Path {0}", pathString);
            }

            if (sizeString != null)
            {
                sb.AppendFormat(" -SizeInGB {0}", sizeString);
            }

            if (diskTypeString != null)
            {
                sb.AppendFormat("  -DiskType {0}", diskTypeString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcFileBasedDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="netFilePath">The network path for filebaseddisk</param>
        /// <returns>The result of New-EmcFileBasedDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string netFilePath)
        {
            string result = RunCMD(psMachine);

            if (! HelperAdapter.TestPath(psMachine, netFilePath))
            {
                log.LogError(string.Format("Failed to create file based disk {0}", pathString));
                PSException pe = new PSException(string.Format("Failed to create file based disk {0}", pathString));
                throw pe;
            }

            VerifyFields(psMachine, netFilePath);
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields for New-EmcFileBasedDisk
        /// </summary>
        /// <param name="psMachine">The PowerShell Machine instance</param>
        /// <param name="netFilePath">The network path for filebaseddisk</param>
        private void VerifyFields(PowershellMachine psMachine, string netFilePath)
        {
            List<string> ps = new List<string>();

            ps.Add(string.Format("(Get-Item \"{0}\").Length", netFilePath));
            string ret = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            double size = double.Parse(ret.Trim());
            

            if (diskTypeString.Equals("Fixed", StringComparison.OrdinalIgnoreCase))
            {
                double sizeInGB = Math.Round(size / 1024 / 1024 / 1024);
                log.AreEqual(sizeString, sizeInGB.ToString(), "Filed Based Disk SizeInGB: ");
                
            }

            if (diskTypeString.Equals("Dynamic", StringComparison.OrdinalIgnoreCase))
            {
                double fileSize = double.Parse(sizeString) * 1024 * 1024 * 1024;

                if ((size == 0) || size >= fileSize)
                {
                    log.LogError(string.Format("Incorrect size of file based disk {0}: expected {1}, actual {2}", pathString, fileSize, size));
                    PSException pe = new PSException(string.Format("Incorrect size of file based disk {0}: expected {1}, actual {2}", pathString, fileSize, size));
                    throw pe;
                }
            }
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;


namespace PowerShellAutomation
{
    public class GetEmcStorageGroup:BaseClass
    {
        #region CMD fields
        private string storageSystemString;
        private string initiatorIdString;
        private string silentString;
        private string poolTypeString;
        #endregion

        public GetEmcStorageGroup(string storageSystem=null, string initiatorId = null, string silent=null, string cmd = null)
        {
            storageSystemString = storageSystem;
            initiatorIdString = initiatorId;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            if (CmdString != null)
            {
                return CmdString;
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStorageGroup");
           
            if (storageSystemString != null)
            {
                sb.AppendFormat(" -StorageSystem {0}", storageSystemString);
            }
            if (initiatorIdString != null)
            {
                sb.AppendFormat(" -InitiatorId {0}", initiatorIdString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();
            string result = RunCMD(psMachine, true);

            return result;
        }

        private void VerifyFields(SortedList<string, string> storageGroup,PowershellMachine psMachine)
        {
           
        }
    }
}

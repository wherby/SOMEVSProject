﻿using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcHostVolume:BaseClass
    {
        #region CMD fields
        private string idString;
        private string hostDiskString;
        private string hostSystemString;
        private string clusterDiskString;
        private string clusterSystemString;
        private string silentString;
        private SortedList<string, string> volumeInfo;
        #endregion

        public SortedList<string, string> VolumeInfo
        {
            get
            {
                return volumeInfo;
            }
            set
            {
                volumeInfo = value;
            }
        }

        public GetEmcHostVolume(string id = null, string hostDisk = null, string hostSystem = null, string clusterDisk = null, string clusterSystem = null, string silent = null, string cmd = null)
        {
            idString = id;
            hostDiskString = hostDisk;
            hostSystemString = hostSystem;
            clusterDiskString = clusterDisk;
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Get-EmcHostVolume");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterDiskString != null)
            {
                sb.AppendFormat(" -ClusterDisk {0}", clusterDiskString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent {0}", silentString);
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getVolumeKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            VerifyFields(getVolumeKeyValueList, psMachine);

            return result;
        }

        private void VerifyFields(List<SortedList<string, string>> getVolumeKeyValueList, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            #endregion

            foreach (SortedList<string, string> keyValue in getVolumeKeyValueList)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, volumeInfo))
                {
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify host volume is got correctly");
        }
    }
}
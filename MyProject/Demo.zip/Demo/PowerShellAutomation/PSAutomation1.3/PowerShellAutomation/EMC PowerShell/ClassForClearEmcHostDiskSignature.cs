﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class ClearEmcHostDiskSignature:BaseClass
    {
        private string diskString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// ClearEmcHostDiskSignature
        ///     ClearEmcHostDiskSignature class constructor
        /// </summary>
        /// <param name="disk">Host Disk object</param>
        /// <param name="silent">silent switch parameter</param>
        /// <param name="cmd">command string to test</param>
        public ClearEmcHostDiskSignature(string disk, string silent=null, string cmd = null)
        {
            diskString = disk;
            silentString = silent;
            CmdString = cmd;
           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Clear-EmcHostDiskSignature");

            if (diskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", diskString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Clear-EmcHostDiskSignature command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="diskIdentifier">Host Disk Identifier</param>
        /// <param name="origMBRSignature">The original MBR signature of the disk</param>
        /// <param name="hostPrefix">The prefix for host system</param>
        /// <returns>Clear-EmcHostDiskSignature result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string diskIdentifier, string origMBRSignature, string hostPrefix = null)
        {
            if (hostPrefix == null)
            {
                hostPrefix = HelperAdapter.GetParameter("Host");
            }
            
            string result = RunCMD(psMachine);

            Thread.Sleep(10000);
            // update host system
            UpdateEmcSystem host = new UpdateEmcSystem(hostPrefix);
            host.RunCMD(psMachine);

            VerifyFields(psMachine, diskIdentifier, origMBRSignature);
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Clear-EmcHostDiskSignature
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="diskIdentifier">Host Disk Identifier</param>
        /// <param name="origMBRSignature">The original MBR signature of the disk</param>
        private void VerifyFields(PowershellMachine psMachine, string diskIdentifier, string origMBRSignature)
        {           

            GetEmcHostDisk hostDisk = new GetEmcHostDisk(diskIdentifier);
            string result = hostDisk.RunCMD(psMachine, true);

            SortedList<string, string> diskProperties = HelperAdapter.GenerateKeyValuePairs(result);           

            #region verification for fields
            if ( diskProperties["MbrDiskSignature"].Equals(origMBRSignature) )
            {
                log.LogError(string.Format("MbrDiskSignature of {0} is not changed, original: {1}, current: {2}", 
                    diskIdentifier, origMBRSignature, diskProperties["MbrDiskSignature"]));
                PSException pe = new PSException(string.Format("MbrDiskSignature of {0} is not changed, original: {1}, current: {2}", 
                    diskIdentifier, origMBRSignature, diskProperties["MbrDiskSignature"]));
                throw pe;
            }
            #endregion
        }
    }
}
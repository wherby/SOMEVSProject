﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcAvailablePassthroughDiskCandidate:BaseClass
    {        
        private string hypervString = null;        
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcAvailablePassthroughDiskCandidate
        ///     GetEmcAvailablePassthroughDiskCandidate class constructor
        /// </summary>
        /// <param name="hyperv">Hypervisor object</param>
        /// <param name="silent">Silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcAvailablePassthroughDiskCandidate(string hyperv, string silent=null, string cmd = null)
        {            
            hypervString = hyperv;            
            silentString = silent;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcAvailablePassthroughDiskCandidate");
            
            if (hypervString != null)
            {
                sb.AppendFormat(" -Hypervisor {0}", hypervString);
            }            

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcAvailablePassthroughDiskCandidate command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="diskResult">Newly added disk info</param>
        /// <param name="hypervPrefix">Hypervisor object</param> 
        /// <returns>Get-EmcAvailablePassthroughDiskCandidate result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string diskResult, string hypervPrefix = null)
        {
            List<string> ps = new List<string>();

            if (hypervPrefix == null)
            {
                hypervPrefix = HelperAdapter.GetParameter("Hypervisor");
            }

            ps.Add(hypervPrefix + ".AvailablePassthroughDiskCandidates");
            string ret = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;            

            string result = RunCMD(psMachine, true);

            VerifyFields(result, ret, diskResult);            

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcAvailablePassthroughDiskCandidate
        /// </summary>
        /// <param name="result">Get-EmcAvailablePassthroughDiskCandidate result string</param>
        /// <param name="expectedResult">AvailablePassthroughDiskCandidate retrieved from Hypervisor object</param> 
        /// <param name="diskResult">Newly added disk info</param>
        private void VerifyFields(string result, string expectedResult, string diskResult)
        {
            List<SortedList<string, string>> availableDisks = HelperAdapter.GenerateKeyValuePairsList(result);
            List<SortedList<string, string>> expectedAvailableDisks = HelperAdapter.GenerateKeyValuePairsList(expectedResult);
            SortedList<string, string> disk = HelperAdapter.GenerateKeyValuePairs(diskResult);

            log.AreEqual(expectedAvailableDisks.Count, availableDisks.Count, "The number of EmcAvailablePassthroughDisks: ");

            // Verify the result retrieved from hypervisor object is consistent with the result from Get-EmcAvailablePassthroughDisks
            foreach (SortedList<string, string> expectedAvailableDisk in expectedAvailableDisks)
            {
                SortedList<string, string> availableDisk = FindAvailableDisk(expectedAvailableDisk["HostDiskIdentifier"], availableDisks);
                if (availableDisk == null)
                {
                    log.LogError(string.Format("Failed to find available disk candidate: {0}", expectedAvailableDisk));
                    PSException pe = new PSException(string.Format("Failed to find available disk candidate: {0}", expectedAvailableDisk));
                    throw pe;
                }
                HelperAdapter.AssertPropertiesComparision(expectedAvailableDisk, availableDisk);
            }

            // Verify the newly added disk is listed in Available Passthrough disks
            SortedList<string, string> getAvailableDisk = FindAvailableDisk(disk["HostDiskIdentifier"], availableDisks);
            if (getAvailableDisk == null)
            {
                log.LogError(string.Format("Failed to find available disk candidate: {0}", disk));
                PSException pe = new PSException(string.Format("Failed to find available disk candidate: {0}", disk));
                throw pe;
            }
            HelperAdapter.AssertPropertiesComparision(getAvailableDisk, disk);            
                
        }

        /// <summary>
        /// FindAvailableDisk
        ///     Find the expected disk in the result of "Get-EmcAvailablePassthroughDiskCandidate"
        /// </summary>
        /// <param name="hostDiskIdentifier">Host Disk identifier</param>
        /// <param name="hostDisks">list of host disks retrieved from Get-EmcAvailablePassthroughDiskCandidate</param>
        /// <returns>Available Passthrough Host Disk properties</returns>
        private SortedList<string, string> FindAvailableDisk(string hostDiskIdentifier, List<SortedList<string, string>> hostDisks)
        {
            SortedList<string, string> availableHostDisk = null;
            foreach(SortedList<string, string> hostDisk in hostDisks)
            {
                if (hostDisk["HostDiskIdentifier"].Equals(hostDiskIdentifier))
                {
                    availableHostDisk = hostDisk;
                }
            }
            return availableHostDisk;
        }
        
    }
}
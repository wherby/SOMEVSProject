﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class GetEmcAvailableDriverLetter : BaseClass
    {
        #region CMD fields
        private string hostSystemString = null;
        private string clusterSystemString = null;
        private string silentString = null;
        #endregion
         
        public GetEmcAvailableDriverLetter(string hostSystem=null,string clusterSystem=null,string silent=null,string cmd=null)
        {
            hostSystemString=hostSystem;
            clusterSystemString=clusterSystem;
            silentString=silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcAvailableDriveLetter");
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();     
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            return result;
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;

namespace PowerShellAutomation
{
    public class RemoveEmcLun:BaseClass
    {
        #region CMD fields
        private string lunString = null;
        private string forceString;
        private string silentString;
        private string whatIfString;
        private string confirmString;
        #endregion

        public RemoveEmcLun(string lun, string force = null, string silent = null, string whatIf = null, string confirm = "Confirm", string cmd = null)
        {
            lunString = lun;
            forceString = force;
            silentString = silent;
            whatIfString = whatIf;
            confirmString = confirm;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            if (CmdString != null)
            {
                return CmdString;
            }
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcLun");
            if (lunString != null)
            {
                sb.AppendFormat(" -Lun {0}", lunString);
            }
            if (forceString != null)
            {
                sb.AppendFormat(" -Force");
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            if (whatIfString != null)
            {
                sb.AppendFormat(" -WhatIf");
            }
            sb.AppendFormat(" -Confirm:$false");
            return sb.ToString();
        }


        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string wwn = null;
            TestLog log = TestLog.GetInstance();
            string informationForLun = null;
            if (lunString != null)
            {
                List<string> ps = new List<string>();
                ps.Add(lunString);
                informationForLun = psMachine.RunScript(ps, new List<PSParam> { }).OutStr;
                if (informationForLun.IndexOf("Wwn") < 0)
                {
                    log.LogWarning("The lun is not existed");
                }
                SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(informationForLun);
                wwn = lunKeyValue["Wwn"];
            }
            GetEmcLun getLun = new GetEmcLun(wwn);

            string result = RunCMD(psMachine);
            
            string systemString= HelperAdapter.GetParameter("System");
            UpdateEmcSystem update = new UpdateEmcSystem(null, systemString);
            update.RunCMD(psMachine);

            string retriveLun = getLun.RunCMD(psMachine);
            if ((retriveLun.IndexOf("Wwn") > 0)&&(whatIfString==null))
            {
                string errorMessage = string.Format("The Lun is not removed. The full command is: {0}.", GetFullString());
                log.LogWarning(errorMessage);
                PSException pe = new PSException(errorMessage);
                throw pe;
            }

            SortedList<string ,string > lunKeyValuePairs=HelperAdapter.GenerateKeyValuePairs(informationForLun);
            VerifyFields(lunKeyValuePairs,psMachine);
            return result;
        }

        private void VerifyFields(SortedList<string, string> storagePool,PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();
            if (whatIfString != null)
            {
                return;
            }
            if (lunString != null)
            {
                GetEmcLun getLun = new GetEmcLun(lunString);
                string information = getLun.RunCMD(psMachine);
                log.AreEqual<string>(string.Empty, information.Trim(), "The lun has been removed");
            }
        }
    }
}

﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class RemoveEmcHostDiskFromCluster : BaseClass
    {
        #region CMD fields
        private string clusterDiskString = null;
        private string hostLunIdentifierString = null;
        private string clusterSystemString = null;
        private string hostDiskString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatIfString = null;
        #endregion

        public RemoveEmcHostDiskFromCluster(string clusterDisk = null, string clusterSystem = null, string hostDisk = null, string hostLunIdentifier = null, string force = null, string silent = null, string whatIf = null, string cmd = null)
        {
            clusterDiskString = clusterDisk;
            hostLunIdentifierString = hostLunIdentifier;
            clusterSystemString = clusterSystem;
            hostDiskString = hostDisk;
            forceString = force;
            silentString = silent;
            whatIfString = whatIf;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Remove-EmcHostDiskFromCluster");

            if (clusterDiskString != null)
            {
                sb.AppendFormat(" -ClsuterDisk {0}", clusterDiskString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }            
            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }
            if (hostLunIdentifierString != null)
            {
                sb.AppendFormat(" -HostLunIdentifier {0}", hostLunIdentifierString);
            }
            if (forceString != null)
            {
                sb.AppendFormat(" -Force");
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            if (whatIfString != null)
            {
                sb.AppendFormat(" -WhatIf");
            }

            sb.Append(" -Confirm:$false");

            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine, string resourceName)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, resourceName);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine, string resourceName)
        {
            TestLog log = TestLog.GetInstance();

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(null, null, HelperAdapter.GetParameter("Cluster"));
            updateSystem.RunCMD(psMachine);

            GetEmcClusterDisk disk = new GetEmcClusterDisk(resourceName);
            string result = disk.RunCMD(psMachine).Trim();

            if (result == string.Empty && whatIfString != null || result != string.Empty && whatIfString == null)
            {
                log.LogError(string.Format("Cmd error:{0}", CmdString));
                PSException pe = new PSException(string.Format("Cmd error:{0}", CmdString));
                throw pe;
            }
        }
    }
}
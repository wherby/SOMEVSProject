﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualMachineConfiguration:BaseClass
    {
        private string vmString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcVirtualMachineConfiguration
        ///     GetEmcVirtualMachineConfiguration class constructor
        /// </summary>
        /// <param name="vm">VirtualMachine object</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcVirtualMachineConfiguration(string vm, string silent=null, string cmd = null)
        {
            vmString = vm;
            silentString = silent;
            CmdString = cmd;
           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualMachineConfiguration");

            if (vmString != null)
            {
                sb.AppendFormat(" -VirtualMachine {0}", vmString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualMachineConfiguration command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="hypervVmConfiguration">All the VM configuration in the hyperv</param>
        /// <param name="hypervName">The name of Hyper-V host</param>
        /// <returns>Get-EmcVirtualMachineConfiguration result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hypervVmConfiguration, string hypervName)
        {            
            string result = RunCMD(psMachine, true);
            VerifyFields(result, hypervVmConfiguration, hypervName);       
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualMachineConfiguration
        /// </summary>
        /// <param name="result">Get-EmcVirtualMachineConfiguration result string</param>
        /// <param name="hypervVmConfiguration">All the VM configuration in the hyperv</param>
        /// <param name="hypervName">The name of Hyper-V host</param>
        private void VerifyFields(string result, string hypervVmConfiguration, string hypervName)
        {            
            List<SortedList<string, string>> vmConfigurations = HelperAdapter.GenerateKeyValuePairsList(hypervVmConfiguration);
            SortedList<string, string> getVmConfiguration = HelperAdapter.GenerateKeyValuePairs(result);

            SortedList<string, string> vmConfiguration = null;

            foreach (SortedList<string, string> vm in vmConfigurations)
            {                
                
                if (vm["Name"].Equals(getVmConfiguration["Name"]))
                {
                    vmConfiguration = vm;
                }
            }

            if (vmConfiguration == null)
            {
                log.LogError(string.Format("Failed to get the find the following VM: {0}", getVmConfiguration));
                PSException pe = new PSException(string.Format("Failed to get the find the following VM: {0}", getVmConfiguration));
                throw pe;
            }

            #region verification for fields
            HelperAdapter.AssertPropertiesComparision(getVmConfiguration, vmConfiguration);
            log.AreEqual(hypervName.ToUpper(), getVmConfiguration["HypervisorName"].ToUpper());
            #endregion
        }
    }
}

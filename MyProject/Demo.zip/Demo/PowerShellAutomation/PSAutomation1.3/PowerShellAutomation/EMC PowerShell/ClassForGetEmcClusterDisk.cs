﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class GetEmcClusterDisk : BaseClass
    {
        #region CMD fields
        private string idString = null;
        private string clusterSystemString = null;
        private string clusterGroupNameString = null;
        private string clusterSharedVolumeString = null;
        private string silentString = null;
        #endregion

        public GetEmcClusterDisk(string id = null, string clusterSystem = null, string clusterGroupName = null, string clusterSharedVolume = null, string silent = null, string cmd = null)
        {
            idString = id;
            clusterSystemString = clusterSystem;
            clusterGroupNameString = clusterGroupName;
            clusterSharedVolumeString = clusterSharedVolume;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Get-EmcClusterDisk");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", "\"" + idString + "\"");
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (clusterGroupNameString != null)
            {
                sb.AppendFormat(" -ClusterGroupName {0}", "\"" + clusterGroupNameString + "\"");
            }
            if (clusterSharedVolumeString != null)
            {
                sb.Append(" -ClsuterSharedVolume");
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> diskKeyValue)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, diskKeyValue);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine, string result, SortedList<string, string> diskKeyValue)
        {
            TestLog log = TestLog.GetInstance();

            bool diskExist = false;

            List<SortedList<string, string>> diskKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach (SortedList<string, string> keyValue in diskKeyValueList)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, diskKeyValue))
                {
                    diskExist = true;
                    break;
                }
            }

            log.AreEqual<bool>(true, diskExist, "Verify Disk Exists");
        }
    }
}
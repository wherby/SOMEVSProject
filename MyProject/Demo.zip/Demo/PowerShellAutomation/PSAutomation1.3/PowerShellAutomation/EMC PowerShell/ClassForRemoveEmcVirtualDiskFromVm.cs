﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class RemoveEmcVirtualDiskFromVm:BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        #region CMD fields
        private string vmConfigString = null;
        private string hypervString = null;
        private string scsiControllerIdString = null;
        private string scsiControllerIndexString = null;
        private string locationsString = null;
        private string silentString = null;
        private string whatIfString = null;
        private string forceString = null;
        #endregion

        private string diskIdentifier;

        public string DiskIdentifier
        {
            get
            {
                return diskIdentifier;
            }
            set
            {
                diskIdentifier = value;
            }
        }

        /// <summary>
        /// RemoveEmcVirtualDiskFromVm
        ///     RemoveEmcVirtualDiskFromVm class constructor
        /// </summary>
        /// <param name="vmConfig">Virtual Machine configuration</param>
        /// <param name="hyperv">hypervisor object</param>
        /// <param name="location">location</param>
        /// <param name="scsiControllerId">scsiControllerId</param>
        /// <param name="scsiControllerIndex">scsiControllerIndex</param>
        /// <param name="silent">Silent</param>
        /// <param name="whatIf">WhatIf</param>
        /// <param name="force">Force</param>
        /// <param name="cmd">full cmd string</param>
        public RemoveEmcVirtualDiskFromVm(string vmConfig, string hyperv, string location, string scsiControllerId = null, string scsiControllerIndex = null, string silent=null, string whatIf = null, string force = null, string cmd = null)
        {
            vmConfigString = vmConfig;
            hypervString = hyperv;
            locationsString = location;
            scsiControllerIdString = scsiControllerId;
            scsiControllerIndexString = scsiControllerIndex;
            silentString = silent;
            whatIfString = whatIf;
            forceString = force;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcVirtualDiskFromVm");

            if ( vmConfigString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", vmConfigString);
            }

            if ( hypervString != null)
            {
                sb.AppendFormat(" -Hypervisor {0}", hypervString);
            }

            if ( scsiControllerIdString != null)
            {
                sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsiControllerIdString + "\"");
            }

            if ( scsiControllerIndexString != null)
            {
                sb.AppendFormat(" -ScsiControllerIndex {0}", scsiControllerIndexString);
            }

            if ( locationsString != null)
            {
                sb.AppendFormat(" -Location {0}", locationsString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            if ( whatIfString != null)
            {
                sb.Append(" -WhatIf");
            }
            
            if ( forceString != null)
            {
                sb.Append(" -Force");
            }

            sb.Append(" -Confirm:$false");

            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Remove-EmcVirtualDiskFromVm command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        public void VerifyTheCMD(PowershellMachine psMachine)
        {
            RunCMD(psMachine);

            VerifyFields(psMachine);
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Remove-EmcVirtualDiskFromVm
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        private void VerifyFields(PowershellMachine psMachine)
        {
            string vm = HelperAdapter.GetParameter("VirtualMachine");

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(vm);
            updateSystem.RunCMD(psMachine);
            updateSystem.RunCMD(psMachine);

            GetEmcHostDisk getDisk = new GetEmcHostDisk(diskIdentifier, null, null, vm);
            string getDiskResult = getDisk.RunCMD(psMachine).Trim();

            if (getDiskResult != string.Empty && whatIfString == null || getDiskResult == string.Empty && whatIfString != null)
            {
                log.LogError(string.Format("Remove Virtual Disk {0} Failed. cmd:{1}", diskIdentifier, CmdString));
                PSException pe = new PSException(string.Format("Remove Virtual Disk {0} Failed. cmd:{1}", diskIdentifier, CmdString));
                throw pe;
            }
        }
    }
}
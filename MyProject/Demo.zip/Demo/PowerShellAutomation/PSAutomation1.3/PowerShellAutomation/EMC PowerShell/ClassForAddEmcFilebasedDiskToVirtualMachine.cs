﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcFilebasedDiskToVirtualMachine : BaseClass
    {
        #region CMD fields
        private string pathString = null;
        private string vmConfigString = null;
        private string hypervString = null;
        private string scsiControllerIdString = null;
        private string scsiControllerIndexString = null;
        private string locationString = null;
        private string silentString = null;
        #endregion

        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// AddEmcFilebasedDiskToVirtualMachine
        ///     Constructor for Add-EmcFilebasedDiskToVirtualMachine class
        /// </summary>
        /// <param name="lun">lun object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcFilebasedDiskToVirtualMachine(string path, string vmConfig, string hyperv, string location, string scsiControllerId = null, string scsiControllerIndex = null, string silent = null, string cmd = null)
        {
            pathString = path;
            vmConfigString = vmConfig;
            hypervString = hyperv;
            locationString = location;
            scsiControllerIdString = scsiControllerId;
            scsiControllerIndexString = scsiControllerIndex;
            silentString = silent;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcFilebasedDiskToVirtualMachine");

            if (pathString != null)
            {
                sb.AppendFormat(" -Path {0}", pathString);
            }

            if (vmConfigString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", vmConfigString);
            }

            if (hypervString != null)
            {
                sb.AppendFormat(" -Hypervisor {0}", hypervString);
            }
            
            if (scsiControllerIdString != null)
            {
                sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsiControllerIdString + "\"");
            }

            if (scsiControllerIndexString != null)
            {
                sb.AppendFormat("  -ScsiControllerIndex {0}", scsiControllerIndexString);
            }

            if (locationString != null)
            {
                sb.AppendFormat(" -Location {0}", locationString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcFilebasedDiskToVirtualMachine commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Add-EmcFilebasedDiskToVirtualMachine</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> scsiController)
        {
            PrefixString = "$addDisk";
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, scsiController);
            
            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, SortedList<string, string> scsiController)
        {
            string host = HelperAdapter.GetParameter("VirtualMachine");
            bool diskCreated = false;
            List<string> ps = new List<string>();

            Thread.Sleep(5000); 
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(host);
            updateSystem.RunCMD(psMachine);

            ps.Add(string.Format("{0}.Path", PrefixString));
            string path = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<string>(pathString, path, "Verify path");

            ps.Clear();
            ps.Add(string.Format("{0}.ScsiControllerIndex", PrefixString));
            string index = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<string>(scsiController["ScsiControllerIndex"], index, "Verify ScsiControllerIndex");

            ps.Clear();
            ps.Add(string.Format("{0}.HostLunIdentifier.ScsiControllerId", PrefixString));
            string scsiControllerId = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<string>(scsiController["ScsiControllerId"], scsiControllerId, "Verify ScsiControllerId");

            ps.Clear();
            ps.Add(string.Format("{0}.HostLunIdentifier", PrefixString));
            string hostLunIdentifier = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

            GetEmcHostDisk disks = new GetEmcHostDisk(null, null, null, host);
            disks.PrefixString = HelperAdapter.GetParameter("Disks");
            disks.RunCMD(psMachine, true);

            ps.Clear();
            ps.Add(disks.PrefixString + ".Count");
            int diskCount = int.Parse(psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim());

            for (int i = 0; i < diskCount; i++ )
            {
                ps.Clear();
                ps.Add(disks.PrefixString + "[" + i + "].DiskType");
                string type = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
                if (!type.Contains( "FilebasedVmDisk"))
                {
                    continue;
                }
                
                GetEmcVirtualDiskConfiguration getDiskConfig = new GetEmcVirtualDiskConfiguration(disks.PrefixString + "[" + i + "]");
                getDiskConfig.PrefixString = "$verifyDiskConfig";
                string diskConfig = getDiskConfig.RunCMD(psMachine);

                ps.Clear();
                ps.Add(getDiskConfig.PrefixString + ".HostLunIdentifier");
                string diskHostLunIdentifier = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

                if (diskHostLunIdentifier == hostLunIdentifier)
                {
                    diskCreated = true;
                    break;
                }
            }

            log.AreEqual<bool>(true, diskCreated, "Verify disk exists");
        }
    }
}
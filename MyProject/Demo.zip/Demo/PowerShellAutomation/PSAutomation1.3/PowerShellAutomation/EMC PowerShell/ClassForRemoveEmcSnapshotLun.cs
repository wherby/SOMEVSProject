﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcSnapshotLun : BaseClass
    {
        #region CMD fields
        private string snapshotLunString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatIfString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// RemoveEmcSnapshotLun
        ///    Constructor for RemoveEmcSnapshotLun class
        /// </summary>
        /// <param name="lun">snapshot lun object string</param>
        /// <param name="force">The force switch parameter</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="whatif">The whatif switch parameter</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcSnapshotLun(string lun, string force=null, string silent=null, string whatif=null, string cmd = null)
        {
            snapshotLunString = lun;
            forceString = force;
            silentString = silent;
            whatIfString = whatif;
            CmdString = cmd;            
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcSnapshotLUN");

            if (snapshotLunString != null)
            {
                sb.Append(" -SnapshotLUN " + snapshotLunString);
                //sb.AppendFormat(" -SnapshotLUN {0}", snapshotLunString);
            }
            if (forceString != null)
            {
                sb.Append(" -Force");
            }
            if (whatIfString != null)
            {
                sb.Append(" -WhatIf");
            }
            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            sb.Append(" -Confirm:$false");
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whethe Remove-EmcSnapshotLun succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="lunID">snapshot lun id or lun name</param>
        /// <returns>result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string lunID)
        {
            string result = RunCMD(psMachine);

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(null, HelperAdapter.GetParameter("System"));
            updateSystem.RunCMD(psMachine);

            VerifyFields(psMachine, lunID);
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify snapshot lun is removed successfully
        /// </summary>     
        /// <param name="psMacine">powershell machine</param>
        /// <param name="lunID">lun name or lun id</param>
        private void VerifyFields(PowershellMachine psMachine, string lunID)
        {
            string blockStorageSystem = null;
            blockStorageSystem = HelperAdapter.GetParameter("System");
            GetEmcSnapshotLun snapshotLun = new GetEmcSnapshotLun(blockStorageSystem, lunID);
            string result = snapshotLun.RunCMD(psMachine);

            //The following code is used when get-emcsnapshotlun cannot retrieve snapshotlun by specifying ID
            List<SortedList<string, string>> getSnapshotLunPropertiesList = HelperAdapter.GenerateKeyValuePairsList(result);
            SortedList<string, string> getSnapshotLunProperties = null;
            foreach (SortedList<string, string> properties in getSnapshotLunPropertiesList)
            {
                if (properties["Wwn"].Equals(lunID))
                {
                    getSnapshotLunProperties = properties;                    
                }
            }
            

            if (whatIfString != null)
            {
                //if (result.Trim() == String.Empty)
                if (getSnapshotLunProperties == null)
                {
                    log.LogError(string.Format("SnapshotLun should not be removed with WhatIf parameter."));
                    PSException pe = new PSException(string.Format("SnapshotLun should not be removed with WhatIf parameter."));
                    throw pe;
                }
            }
            else
            {
                //if (result.Trim() != String.Empty)
                if (getSnapshotLunProperties != null)
                {
                    log.LogError(string.Format("Failed to remove SnapshotLun: {0}.", result));
                    PSException pe = new PSException(string.Format("Failed to remove SnapshotLun: {0}.", result));
                    throw pe;
                }
            }
        }
    }
}
﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualMachineHypervisor:BaseClass
    {
        private string vmConfigurationString = null;
        private string vmString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcVirtualMachineHypervisor
        ///     GetEmcVirtualMachineHypervisor class constructor
        /// </summary>
        /// <param name="vmConfig">VirtualMachineConfiguration object</param>
        /// <param name="vm">VirtualMachine object</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcVirtualMachineHypervisor(string vmConfig = null, string vm = null, string silent=null, string cmd = null)
        {
            vmConfigurationString = vmConfig;
            vmString = vm;
            silentString = silent;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualMachineHypervisor");

            if (vmConfigurationString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", vmConfigurationString);
            }
            else if (vmString != null)
            {
                sb.AppendFormat(" -VirtualMachine {0}", vmString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualMachineHypervisor command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="hyperv">The string of hyperv object</param>
        /// <returns>Get-EmcVirtualMachineHypervisor result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hyperv)
        {            
            string result = RunCMD(psMachine, true);
            VerifyFields(result, hyperv);       
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualMachineHypervisor
        /// </summary>
        /// <param name="result">Get-EmcVirtualMachineHypervisor result string</param>
        /// <param name="hyperv">the string of hyperv object</param>        
        private void VerifyFields(string result, string hyperv)
        {            
            SortedList<string, string> hypervProperties = HelperAdapter.GenerateKeyValuePairs(hyperv);
            SortedList<string, string> getHypervProperties = HelperAdapter.GenerateKeyValuePairs(result);            

            #region verification for fields
            HelperAdapter.AssertPropertiesComparision(getHypervProperties, hypervProperties);
            #endregion
        }
    }
}
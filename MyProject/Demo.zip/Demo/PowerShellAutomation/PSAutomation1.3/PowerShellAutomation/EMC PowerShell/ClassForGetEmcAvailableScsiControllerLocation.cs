﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcAvailableScsiControllerLocation:BaseClass
    {
        private string vmConfigurationString = null;
        private string hypervString = null;
        private string scsiControllerIndexString = null;
        private string scsiControllerIdString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcAvailableScsiControllerLocation
        ///     GetEmcAvailableScsiControllerLocation class constructor
        /// </summary>
        /// <param name="vmConfig">VirtualMachineConfiguration object</param>
        /// <param name="vm">VirtualMachine object</param>
        /// <param name="hyperv">The hypervisor object</param>
        /// <param name="scsiControllerIndex">The index for ScsiController</param>
        /// <param name="scsiControllerId">The Id for ScsiController</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcAvailableScsiControllerLocation(string vmConfig, string hyperv, string scsiControllerIndex = null, string scsiControllerId = null,
            string silent=null, string cmd = null)
        {
            vmConfigurationString = vmConfig;
            hypervString = hyperv;
            scsiControllerIndexString = scsiControllerIndex;
            scsiControllerIdString = scsiControllerId;
            silentString = silent;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcAvailableScsiControllerLocation");

            if (vmConfigurationString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", vmConfigurationString);
            }
            if (hypervString != null)
            {
                sb.AppendFormat(" -Hypervisor {0}", hypervString);
            }
            if (scsiControllerIndexString != null)
            {
                sb.AppendFormat(" -ScsiControllerIndex {0}", scsiControllerIndexString);
            }
            else if (scsiControllerIndexString != null)
            {
                sb.AppendFormat(" -ScsiControllerId {0}", scsiControllerIdString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcAvailableScsiControllerLocation command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>Get-EmcAvailableScsiControllerLocation result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {  
            string result = RunCMD(psMachine, true);            
            VerifyFields(psMachine, result);
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///   Verify the fields of Get-EmcAvailableScsiControllerLocation
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="availableScsiControllerLocationResult">Get-EmcAvaiableScsiControllerLocation result string</param>
        private void VerifyFields(PowershellMachine psMachine, string availableScsiControllerLocationResult)
        {
            String[] availableScsiControllerLocation = availableScsiControllerLocationResult.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            
            // Get all disks on VM
            GetEmcHostDisk hd = new GetEmcHostDisk(null, null, null, HelperAdapter.GetParameter("VirtualMachine"));
            hd.PrefixString = HelperAdapter.GetParameter("Disks");
            string diskResult = hd.RunCMD(psMachine, true);

            List<SortedList<string, string>> disks = HelperAdapter.GenerateKeyValuePairsList(diskResult);

            // Get Virtual Disk Configuration for all filebaseddisk and passthrough disk
            int i = 0;
            int usedScsiControllerLocationCount = 0;
            foreach ( SortedList<string, string> disk in disks )
            {
                if (disk["DiskType"].Contains("Filebased")
                    || disk["DiskType"].Contains("Passthrough"))
                {
                    usedScsiControllerLocationCount++;
                    string hostDisk = hd.PrefixString + "[" + i.ToString() + "]";
                    GetEmcVirtualDiskConfiguration vd = new GetEmcVirtualDiskConfiguration(hostDisk);
                    vd.PrefixString = HelperAdapter.GetParameter("Disk");
                    vd.RunCMD(psMachine, true);

                    List<string> ps = new List<string>();
                    ps.Add(vd.PrefixString + ".HostLunIdentifier.ScsiAddress.Lun");
                    string location = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;

                    // Verify the scsicontrollerlocation being used doesn't occur in available scsi location list
                    for (int j = 0; j < availableScsiControllerLocation.Length; j++)
                    {
                        if (availableScsiControllerLocation[j].Trim() == location.Trim())
                        {
                            log.LogError(string.Format("Available ScsiLocation {0} is actually used by disk {1}.", location, disk["HostDiskIdentifier"]));
                            PSException pe = new PSException(string.Format("Available ScsiLocation {0} is actually used by disk {1}.", location, disk["HostDiskIdentifier"]));
                            throw pe;
                        }
                    }
                }
                i++;
            }

            // Verify the sum of available scsi controller number and used scsi controller number is 64
            if (usedScsiControllerLocationCount + availableScsiControllerLocation.Length != 64)
            {
                log.LogError(string.Format("Incorrect available ScsiController Location. Used location number: {0}, Available location number {1}.", 
                    usedScsiControllerLocationCount, availableScsiControllerLocation.Length));
                PSException pe = new PSException(string.Format("Incorrect available ScsiController Location. Used location number: {0}, Available location number {1}.", 
                    usedScsiControllerLocationCount, availableScsiControllerLocation.Length));
                throw pe;
            }
        } 
    }
}
﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcHostLunIdentifier:BaseClass
    {
        private string lunString = null;        
        private string silentString = null;
        private string clusterString = null;
        private string hostString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcHostLunIdentifier
        ///     GetEmcHostLunIdentifier class constructor
        /// </summary>
        /// <param name="lun">The lun object/param>
        /// <param name="host">The host object/param>
        /// <param name="cluster">The cluster object/param>
        /// <param name="silent">Silent siwtch paramter</param></param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcHostLunIdentifier(string lun, string host = null, string cluster = null, string silent = null, string cmd = null)
        {
            lunString = lun;
            clusterString = cluster;
            hostString = host;
            silentString = silent;
            CmdString = cmd;
           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcHostLunIdentifier");

            if (lunString != null)
            {
                sb.AppendFormat(" -Lun {0}", lunString);
            }
            if (clusterString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterString);
            }
            if (hostString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcHostLunIdentifier command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="lunId">The wwn of the lun</param>
        /// <returns>Get-EmcHostLunIdentifier result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string lunId)
        {            
            string result = RunCMD(psMachine, true);
            VerifyFields(result, lunId);       
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcHostLunIdentifier
        /// </summary>
        /// <param name="result">Get-EmcHostLunIdentifier result string</param>
        /// <param name="lunId">The wwn of the lun</param>      
        private void VerifyFields(string result, string lunId)
        {            
            SortedList<string, string> getHostLunIdentifier = HelperAdapter.GenerateKeyValuePairs(result);            

            #region verification for fields
            log.AreEqual(lunId, getHostLunIdentifier["Wwn"], "The wwn of the lun: ");   
            #endregion
        }
    }
}
﻿using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcClusterGroup:BaseClass
    {
        #region CMD fields
        private string clusterSystemString;
        private string silentString;
        #endregion

        public GetEmcClusterGroup(string clusterSystem = null,  string silent = null, string cmd = null)
        {
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcClusterGroup");


            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent {0}", silentString);
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> keyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach(SortedList<string, string> keyValue in keyValueList)
            {
                VerifyFields(psMachine, keyValue);
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, SortedList<string, string> getGroupKeyValue)
        {
            string state = null;
            string[] splitString = null;
            TestLog log = TestLog.GetInstance();

            GetEmcClusterDisk clusterDisk = new GetEmcClusterDisk(null, HelperAdapter.GetParameter("Cluster"), getGroupKeyValue["Name"]);
            string diskResult = clusterDisk.RunCMD(psMachine);

            if (diskResult.Trim() != string.Empty)
            {
                List<SortedList<string, string>> diskList = HelperAdapter.GenerateKeyValuePairsList(diskResult);
                foreach (SortedList<string, string> diskKeyValue in diskList)
                {
                    if (diskKeyValue["ClusterDiskResouceState"] == "Offline")
                    {
                        if(state == null)
                        {
                            state = "Offline";
                        }
                        else if (state == "Online")
                        {
                            state = "PartialOnline";
                        }
                    }
                    else if (diskKeyValue["ClusterDiskResouceState"] == "Online")
                    {
                        if (state == null)
                        {
                            state = "Online";
                        }
                        else if (state == "Offline")
                        {
                            state = "PartialOnline";
                        }
                    }

                    if (diskKeyValue["ClusterDiskResouceState"] == "Failed")
                    {
                        state = "Failed";
                        break;
                    }

                }

                log.AreEqual<string>(state, getGroupKeyValue["State"], "Verify State");

                if (getGroupKeyValue["ResourceNames"].Contains("..."))
                {
                    splitString = new string[] { "{", ",", "...}" };
                }
                else
                {
                    splitString = new string[] { "{", ",", "}" };
                }

                AssertEntryInList(diskList, getGroupKeyValue["ResourceNames"], splitString);
            }
                        
        }

        private void AssertEntryInList(List<SortedList<string, string>> diskList, string diskValue, string[] splitString)
        {
            string[] disks = diskValue.Split(splitString, StringSplitOptions.RemoveEmptyEntries);
            TestLog log = TestLog.GetInstance();
            bool exist = false;

            for (int i = 0; i < disks.Length; i++)
            {
                for (int j = 0; j < diskList.Count; j++)
                {
                    if (disks[i].Trim() == diskList[j]["ClusterDiskResourceName"])
                    {
                        exist = true;
                        break;
                    }
                }
                log.AreEqual<bool>(true, exist, string.Format("Verify disk {0} is in the cluster system", disks[i]));
                exist = false;
            }
        }
    }
}

﻿using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcPassthroughDiskToVirtualMachine : BaseClass
    {
        #region CMD fields
        private string diskIdString = null;
        private string diskNumberString = null;
        private string hostDiskString = null;
        private string vmConfigString = null;
        private string hypervString = null;
        private string scsiControllerIdString = null;
        private string scsiControllerIndexString = null;
        private string locationString = null;
        private string silentString = null;
        private int diskNumber = 0;
        #endregion

        public int DiskNumber
        {
            get
            {
                return diskNumber;
            }
            set
            {
                diskNumber = value;
            }
        }


        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// AddEmcPassthroughDiskToVirtualMachine
        ///     Constructor for Add-EmcPassthroughDiskToVirtualMachine class
        /// </summary>
        /// <param name="lun">lun object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcPassthroughDiskToVirtualMachine(string diskId, string diskNumber, string hostDisk, string vmConfig, string hyperv, string location, string scsiControllerId = null, string scsiControllerIndex = null, string silent = null, string cmd = null)
        {
            diskIdString = diskId;
            diskNumberString = diskNumber;
            hostDiskString = hostDisk;
            vmConfigString = vmConfig;
            hypervString = hyperv;
            locationString = location;
            scsiControllerIdString = scsiControllerId;
            scsiControllerIndexString = scsiControllerIndex;
            silentString = silent;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcPassthroughDiskToVirtualMachine");

            if (diskIdString != null)
            {
                sb.AppendFormat(" -DiskId {0}", diskIdString);
            }
            else if (diskNumberString != null)
            {
                sb.AppendFormat(" -DiskNumber {0}", diskNumberString);
            }
            else if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }

            if (vmConfigString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", vmConfigString);
            }

            if (hypervString != null)
            {
                sb.AppendFormat(" -Hypervisor {0}", hypervString);
            }
            
            if (scsiControllerIdString != null)
            {
                sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsiControllerIdString + "\"");
            }

            if (scsiControllerIndexString != null)
            {
                sb.AppendFormat("  -ScsiControllerIndex {0}", scsiControllerIndexString);
            }

            if (locationString != null)
            {
                sb.AppendFormat(" -Location {0}", locationString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcPassthroughDiskToVirtualMachine commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Add-EmcPassthroughDiskToVirtualMachine</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> scsiController)
        {
            PrefixString = "$addDisk";
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, scsiController);
            
            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, SortedList<string, string> scsiController)
        {
            string host = HelperAdapter.GetParameter("VirtualMachine");
            bool diskCreated = false;
            List<string> ps = new List<string>();

            Thread.Sleep(5000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(host);
            updateSystem.RunCMD(psMachine);

            ps.Add(string.Format("{0}.Description", PrefixString));
            string description = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<bool>(true, description.Contains("Disk " + diskNumber + " 1.00 GB"), "Verify description");
            log.AreEqual<bool>(true, description.Contains("Bus") && description.Contains("Lun") && description.Contains("Target"), "Verify description");

            ps.Clear();
            ps.Add(string.Format("{0}.DriveNumber", PrefixString));
            string driveNumber = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<string>(diskNumber.ToString(), driveNumber, "Verify driveNumber");

            ps.Clear();
            ps.Add(string.Format("{0}.ScsiControllerIndex", PrefixString));
            string index = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<string>(scsiController["ScsiControllerIndex"], index, "Verify ScsiControllerIndex");

            ps.Clear();
            ps.Add(string.Format("{0}.HostLunIdentifier.ScsiControllerId", PrefixString));
            string scsiControllerId = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            log.AreEqual<string>(scsiController["ScsiControllerId"], scsiControllerId, "Verify ScsiControllerId");

            ps.Clear();
            ps.Add(string.Format("{0}.HostLunIdentifier", PrefixString));
            string hostLunidentifier = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            SortedList<string, string> hostLunIdKeyValue = HelperAdapter.GenerateKeyValuePairs(hostLunidentifier);

            GetEmcHostDisk disks = new GetEmcHostDisk(null, null, null, host);
            disks.PrefixString = HelperAdapter.GetParameter("Disks");
            disks.RunCMD(psMachine, true);

            ps.Clear();
            ps.Add(disks.PrefixString + ".Count");
            int diskCount = int.Parse(psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim());

            for (int i = 0; i < diskCount; i++)
            {
                ps.Clear();
                ps.Add(disks.PrefixString + "[" + i + "].DiskType");
                string type = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
                if (!type.Contains( "Passthrough"))
                {
                    continue;
                }

                GetEmcVirtualDiskConfiguration getDiskConfig = new GetEmcVirtualDiskConfiguration(disks.PrefixString + "[" + i + "]");
                getDiskConfig.PrefixString = "$verifyDiskConfig";
                string diskConfig = getDiskConfig.RunCMD(psMachine);

                ps.Clear();
                ps.Add(getDiskConfig.PrefixString + ".HostLunIdentifier");
                string diskHostLunIdentifier = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

                if (diskHostLunIdentifier == hostLunidentifier)
                {
                    diskCreated = true;
                    break;
                }
            }

            log.AreEqual<bool>(true, diskCreated, "Verify disk exists");            
        }
    }
}
﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class AddEmcHostDiskToCluster : BaseClass
    {
        #region CMD fields
        private string hostLunIdentifierString = null;
        private string clusterSystemString = null;
        private string clusterGroupNameString = null;
        private string addToClusterSharedVolumeString = null;
        private string hostDiskString = null;
        private string silentString = null; 
        #endregion

        public AddEmcHostDiskToCluster(string clusterSystem, string hostLunIdentifier = null, string clusterGroupName = null, string addToClusterSharedVolume = null, string hostDisk = null, string silent = null, string cmd = null)
        {
            clusterSystemString = clusterSystem;
            hostLunIdentifierString = hostLunIdentifier;
            clusterGroupNameString = clusterGroupName;
            addToClusterSharedVolumeString = addToClusterSharedVolume;
            hostDiskString = hostDisk;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Add-EmcHostDiskToCluster");

            if (hostLunIdentifierString != null)
            {
                sb.AppendFormat(" -HostLunIdentifier {0}", hostLunIdentifierString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (clusterGroupNameString != null)
            {
                sb.AppendFormat(" -ClusterGroupName {0}", "\"" + clusterGroupNameString + "\"");
            }
            if (addToClusterSharedVolumeString != null)
            {
                sb.Append(" -AddToClusterSharedVolume");
            }
            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine, string clusterGlobalId)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, clusterGlobalId);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine, string result, string clusterGlobalId)
        {
            TestLog log = TestLog.GetInstance();
            string groupName = string.Empty;
            string isSharedVolume = "False";
            string ownerNodeName = null;

            SortedList<string, string> clusterDiskKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.AreEqual<string>(clusterGlobalId, clusterDiskKeyValue["ClusterSystemGlobalId"], "Verify Cluster System Global Id");

            if (addToClusterSharedVolumeString == null)
            {
                if (clusterGroupNameString != null)
                {
                    groupName = clusterGroupNameString;
                }
                else
                {
                    groupName = "Available Storage";
                }

                GetEmcClusterGroup getGroup = new GetEmcClusterGroup(HelperAdapter.GetParameter("Cluster"));
                string groupResult = getGroup.RunCMD(psMachine, true);
                List<SortedList<string, string>> groupList = HelperAdapter.GenerateKeyValuePairsList(groupResult);
                foreach (SortedList<string, string> group in groupList)
                {
                    if (group["Name"] == groupName)
                    {
                        ownerNodeName = group["CurrentOwnerNodeName"];
                        break;
                    }
                }
                log.AreEqual<string>(ownerNodeName, clusterDiskKeyValue["CurrentOwnerNodeName"], "Verify Current Owner Node Name");
            }
            log.AreEqual<string>(groupName, clusterDiskKeyValue["ClusterGroupName"], "Verify Cluster Group Name");

            if (addToClusterSharedVolumeString != null)
            {
                isSharedVolume = "True";
            }
            log.AreEqual<string>(isSharedVolume, clusterDiskKeyValue["IsClusterSharedVolume"], "Verify Cluster Shared Volume");

            
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcSnapshotSession : BaseClass
    {
        #region CMD fields
        private string lunString = null;
        private string snapshotLunString = null;
        private string snapshotPoolString = null;
        private string silentString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// NewEmcSnapshotSession
        ///     Constructor for New-EmcSnapshotSession class
        /// </summary>
        /// <param name="lun">The lun object string</param>
        /// <param name="cmd">Command string to test</param>
        public NewEmcSnapshotSession(string lun, string snapshotLun = null, string snapshotPool = null, string silent = null, string cmd = null)
        {
            lunString = lun;
            snapshotLunString = snapshotLun;
            snapshotPoolString = snapshotPool;
            silentString = silent;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcSnapshotSession");

            if (lunString != null)
            {
                sb.AppendFormat(" -SourceLUN {0}", lunString);
            }

            if (snapshotLunString != null)
            {
                sb.AppendFormat(" -SnapshotLUN {0}", snapshotLunString);
            }

            if (snapshotPoolString != null)
            {
                sb.AppendFormat(" -SnapshotPool {0}", snapshotPoolString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcSnapshotSession commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="lunID">lun name or lun id</param>
        /// <returns>the result of new-emcsnapshotsession</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string globalId, string lunId, string targetId, string snapshotPoolId)
        {
            string result = RunCMD(psMachine, true);
            SortedList<string, string> newSnapshotSessionProperties = HelperAdapter.GenerateKeyValuePairs(result);

            GetEmcSnapshotSession getSnapshotSession = new GetEmcSnapshotSession(newSnapshotSessionProperties["SessionId"]);
            getSnapshotSession.RunCMD(psMachine, true);

            // Verify snapshot lun is created
            if (snapshotLunString == null)
            {                
                targetId = newSnapshotSessionProperties["TargetSnapshotLunId"];
                GetEmcSnapshotLun snapshotLun = new GetEmcSnapshotLun(null, targetId);
                snapshotLun.RunCMD(psMachine, true);
            }

            VerifyFields(newSnapshotSessionProperties, globalId, lunId, targetId, snapshotPoolId);
            return result;
        }        

        /// <summary>
        /// VerifyFields
        ///     verify the fields of a snapshot session
        /// </summary>
        /// <param name="getLunProperties">snapshot lun properties retrieved from New-EmcSnapshotSession</param>
        /// <param name="lunID">lun name or lun id</param>
        private void VerifyFields(SortedList<string, string> newSessionProperties, string globalId, string lunId, string targetId, string snapshotPoolId)
        {            

            #region verification for fields 
            // Verify StorageSystemGlobalId
            log.AreEqual<string>(globalId, newSessionProperties["StorageSystemGlobalId"], "Verify StorageSystemGlobalId: ");

            // Verify SourceLunId
            log.AreEqual<string>(lunId, newSessionProperties["SourceLunId"], "Verify SourceLunId: ");

            // Verify TargetSnapshotLunId
            if (snapshotLunString != null)
            {                
                log.AreEqual<string>(targetId, newSessionProperties["TargetSnapshotLunId"], "Verify TargetSnapshotLunId: ");
            }
            
            // Verify SessionState
            log.AreEqual<string>("Normal", newSessionProperties["SessionState"], "Verify SessionState: ");

            // Verify SnapshotPoolId           
            log.AreEqual<string>(snapshotPoolId, newSessionProperties["SnapshotPoolId"], "Verify SnapshotPoolId: ");           
            #endregion            
        }
    }
}
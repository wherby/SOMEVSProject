﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcSnapshotLun : BaseClass
    {
        #region CMD fields
        private string lunString = null;
        private string snapshotPoolString = null;
        private string nameString = null;
        private string silentString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// NewEmcSnapshotLun
        ///     Constructor for New-EmcSnapshotLun class
        /// </summary>
        /// <param name="lun">Lun object string</param>
        /// <param name="snapshotPool">The snapshot pool object</param>
        /// <param name="name">The snapshot lun name</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public NewEmcSnapshotLun(string lun, string snapshotPool=null, string name=null,string silent = null, string cmd = null)
        {
            lunString = lun;
            snapshotPoolString = snapshotPool;
            nameString = name;
            silentString = silent;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcSnapshotLUN");

            if (lunString != null)
            {
                sb.AppendFormat(" -SourceLUN {0}", lunString);
            }

            if (snapshotPoolString != null)
            {
                sb.AppendFormat(" -SnapshotPool {0}", snapshotPoolString);
            }

            if (nameString != null)
            {                
                sb.AppendFormat(" -Name {0}", nameString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcSnapshotLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="lunID">The lun name or lun id</param>
        /// <param name="storageGlobalId">Storage Global Id</param>
        /// <returns>The result of new-emcsnapshotlun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string lunID, string storageGlobalId)
        {
            PrefixString = HelperAdapter.GetParameter("SnapshotLun");
            string result = RunCMD(psMachine, true);
            SortedList<string, string> newSnapshotLunProperties = HelperAdapter.GenerateKeyValuePairs(result);

            string blockStorageSystem = HelperAdapter.GetParameter("System");
            GetEmcSnapshotLun snapshotLun = new GetEmcSnapshotLun(blockStorageSystem, newSnapshotLunProperties["Wwn"]);
            string getResult = snapshotLun.RunCMD(psMachine, true);
            List<SortedList<string, string>> getSnapshotLunList = HelperAdapter.GenerateKeyValuePairsList(getResult);
            SortedList<string, string> getSnapshotLunProperties = null;
            foreach (SortedList<string, string> properties in getSnapshotLunList)
            {

                if (properties["Wwn"].Equals(newSnapshotLunProperties["Wwn"]))
                {
                    getSnapshotLunProperties = properties;
                }
            }

            if (getSnapshotLunProperties == null)
            {
                log.LogError(string.Format("Failed to find the following snapshot lun: {0}", newSnapshotLunProperties));
                PSException pe = new PSException(string.Format("Failed to find the following snapshot lun: {0}", newSnapshotLunProperties));
                throw pe;
            }                     
            
            VerifyFields(getSnapshotLunProperties, lunID, storageGlobalId);
            return result;
        }        

        /// <summary>
        /// VerifyFields
        ///     verify the source lun of a snapshot lun
        /// </summary>
        /// <param name="getLunProperties">The snapshot lun properties retrieved from Get-EmcSnapshotLun</param>        
        /// <param name="lunID">The lun name or lun id</param>
        /// <param name="storageGlobalId">Storage Global Id</param>
        private void VerifyFields(SortedList<string, string> getLunProperties, string lunID, string storageGlobalId)
        {           

            #region verification for fields
            log.AreEqual(storageGlobalId, getLunProperties["StorageSystemGlobalId"], "Verify storage global Id: ");
            log.AreEqual("~SnapshotLunGroup", getLunProperties["ArrayPoolId"], "Verify array pool Id: ");      
            
            string arrayLunIdPrefix = "SCLUN_";
            if (lunID.ToString().Length == 1)
            {
                arrayLunIdPrefix = arrayLunIdPrefix + "0" + lunID.ToString() + "_";
            }
            else
            {
                arrayLunIdPrefix = arrayLunIdPrefix + lunID.ToString() + "_";
            }
            if (! getLunProperties["ArrayLunId"].Contains(arrayLunIdPrefix) )
            {
                log.LogError(string.Format("Incorrect ArrayLunId: {0}.", getLunProperties["ArrayLunId"]));
                PSException pe = new PSException(string.Format("Incorrect ArrayLunId: {0}.", getLunProperties["ArrayLunId"]));
                throw pe;
            }
            string sourceLunID = null;
            if (nameString != null)
            {
                log.AreEqual<string>(nameString, getLunProperties["Name"], "Verify the Name of a Snapshot Lun: "); 
            }
            else 
            {
                if (!getLunProperties["Name"].Contains(arrayLunIdPrefix))
                {
                    log.LogError(string.Format("Incorrect Name: {0}.", getLunProperties["Name"]));
                    PSException pe = new PSException(string.Format("Incorrect Name: {0}.", getLunProperties["Name"]));
                    throw pe;
                }
            }

            if (HelperAdapter.GetProperty("ESIVersion").Equals("1.4"))
            {
                sourceLunID = getLunProperties["SourceLunId"];
            }
            else if (HelperAdapter.GetProperty("ESIVersion").Equals("1.3"))
            {
                sourceLunID = getLunProperties["DefaultStringForOtherProperties"].Split('=')[1];
                sourceLunID = sourceLunID.Replace(")", "");   
            }

            log.AreEqual<string>(lunID, sourceLunID, "Verify the Source Lun ID of a Snapshot Lun: "); 
            #endregion
        }
    }
}
﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class SetEmcHostDiskOnlineState:BaseClass
    {
        private string diskString = null;
        private string onlineString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// SetEmcHostDiskOnlineState
        ///     SetEmcHostDiskOnlineState class constructor
        /// </summary>
        /// <param name="disk">The disk object</param>
        /// <param name="statusFlag">The disk online/offline switch</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public SetEmcHostDiskOnlineState(string disk, string statusFlag = null, string silent = null, string cmd = null)
        {
            diskString = disk;
            onlineString = statusFlag;
            silentString = silent;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcHostDiskOnlineState");

            if (diskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", diskString);
            }
            if (onlineString.Equals("Online", StringComparison.OrdinalIgnoreCase))
            {
                sb.Append(" -Online");
            }
            else 
            {
                sb.Append(" -Offline");
            }
            
            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify SetEmcHostDiskOnlineState command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <returns>SetEmcHostDiskOnlineState result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {            
            string result = RunCMD(psMachine);

            // Update Host System
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Host"));
            updateSystem.RunCMD(psMachine);            

            // Get the disk again
            GetEmcHostDisk hostDisk = new GetEmcHostDisk(null, HelperAdapter.GetParameter("Lun"), null, HelperAdapter.GetParameter("Host"));
            hostDisk.PrefixString = HelperAdapter.GetParameter("Disk");
            result = hostDisk.RunCMD(psMachine, true);

            if (onlineString.Equals("Online", StringComparison.OrdinalIgnoreCase))
            {
                VerifyFields(result, "Online");
            }
            else
            {
                VerifyFields(result, "Offline");
            }
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of SetEmcHostDiskOnlineState
        /// </summary>
        /// <param name="result">SetEmcHostDiskOnlineState result string</param>
        /// <param name="status">The disk status</param>        
        private void VerifyFields(string result, string status)
        {            
            SortedList<string, string> getHostDiskProperties = HelperAdapter.GenerateKeyValuePairs(result);

            #region verification for fields
            log.AreEqual(status, getHostDiskProperties["Status"], "Host disk status: ");    
            #endregion
        }
    }
}
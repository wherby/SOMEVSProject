﻿using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcStorageSystem:BaseClass
    {
        #region CMD fields
        private string idString;
        private string fileString;
        private string blockString;
        private string lunString;
        private string poolString;
        private string clarStorageGroupString;
        private string silentString;
        private int getSystemCount;
        private SortedList<string, string>[] connectSystemKeyValue;
        private string globalId;
        #endregion

        public SortedList<string, string>[] ConnectSystemKeyValue
        {
            get
            {
                return connectSystemKeyValue;
            }
            set
            {
                connectSystemKeyValue = value;
            }
        }

        public int GetSystemCount
        {
            get
            {
                return getSystemCount;
            }
            set
            {
                getSystemCount = value;
            }
        }

        public string GlobalId
        {
            get
            {
                return globalId;
            }
            set
            {
                globalId = value;
            }
        }

        public GetEmcStorageSystem(string id = null, string file = null, string block = null, string lun = null, string pool = null, string clarStorageGroup = null, string silent = null, string cmd = null)
        {
            idString = id;
            fileString = file;
            blockString = block;
            lunString = lun;
            poolString = pool;
            clarStorageGroupString = clarStorageGroup;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStorageSystem");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            if (fileString != null)
            {
                sb.AppendFormat(" -{0}", fileString);
            }
            if (blockString != null)
            {
                sb.AppendFormat(" -{0}", blockString);
            }
            if (lunString != null)
            {
                sb.AppendFormat(" -Lun {0}", lunString);
            }
            if (poolString != null)
            {
                sb.AppendFormat(" -Pool {0}", poolString);
            }
            if (clarStorageGroupString != null)
            {
                sb.AppendFormat(" -ClarStorageGroup {0}", clarStorageGroupString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent {0}", silentString);
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getSystemKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            log.AreEqual<int>(getSystemCount, getSystemKeyValueList.Count, "Verify get system count");

            foreach (SortedList<string, string> keyValue in getSystemKeyValueList)
            {
                VerifyFields(keyValue, psMachine);
            }
            

            return result;
        }

        private void VerifyFields(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            List<string> excludeKeys = new List<string>();
            #endregion

            log.AreEqual<string>("StorageSystem", getSystemKeyValue["AdapterType"], "Verify Adapter Type");

            if (globalId != null)
            {
                log.AreEqual<string>(globalId, getSystemKeyValue["GlobalId"], "Verify GlobalId");
            }
            
            string result = null;
            List<SortedList<string, string>> resultList = new List<SortedList<string,string>>();
            string[] splitString = null;

            GetEmcStorageSystem system = new GetEmcStorageSystem(getSystemKeyValue["GlobalId"]);
            system.PrefixString = "$verifyStorage";
            system.RunCMD(psMachine);

            if(getSystemKeyValue.ContainsKey("LunPools") && getSystemKeyValue["LunPools"] != "{}")
            {
                excludeKeys.Add("LunPools");
                
                GetEmcStoragePool pool = new GetEmcStoragePool(null, null, system.PrefixString);
                pool.PrefixString = "$verifyPool";
                result = pool.RunCMD(psMachine);
                resultList = HelperAdapter.GenerateKeyValuePairsList(result);

                splitString = new string[]{"{[", "], [", "]}", "]...}"};
                
                string[] pools = getSystemKeyValue["LunPools"].Split(splitString, StringSplitOptions.RemoveEmptyEntries);
                log.LogInfo(pools.Length.ToString() + " LUNPOOLS:" + getSystemKeyValue["LunPools"]);
                for(int i = 0 ; i < pools.Length; i++)
                {
                    string[] nameId = pools[i].Split(new char[] { '.' }, 2, StringSplitOptions.RemoveEmptyEntries);
                    string[] name = nameId[0].Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries);
                    string[] id = nameId[1].Split(new char[] { ':' }, 2, StringSplitOptions.RemoveEmptyEntries);
                    log.AreEqual<string>(name[1].Trim(), resultList[i]["Name"], string.Format("Verify Lun Pool {0} Name", i));
                    log.AreEqual<string>(id[1].Trim(), resultList[i]["ArrayPoolId"], string.Format("Verify Lun Pool {0} Id", i));
                }
            }

            string[] keys = { "Luns", "SnapshotLuns", "Snapshots", "StorageGroups" };
            foreach (string key in keys)
            {
                if(getSystemKeyValue.ContainsKey(key) && getSystemKeyValue[key] != "{}")
                {
                    excludeKeys.Add(key);

                    splitString = new string[] { "{", ",", "}", "..." };
                    
                    if (key == "Luns")
                    {
                        GetEmcLun lun = new GetEmcLun();
                        result = lun.RunCMD(psMachine);
                    }
                    else if (key == "SnapshotLuns" || key == "Snapshots")
                    {
                         GetEmcSnapshotLun lun = new GetEmcSnapshotLun("$verifyStorage");
                         result = lun.RunCMD(psMachine);
                    }
                    else if (key == "StorageGroups")
                    {
                        GetEmcStorageGroup group = new GetEmcStorageGroup("$verifyStorage");
                        result = group.RunCMD(psMachine);
                    }

                    resultList = HelperAdapter.GenerateKeyValuePairsList(result);
                    AssertLunsInStorage(resultList, getSystemKeyValue[key], splitString, getSystemKeyValue["GlobalId"]);
                }
             }

            excludeKeys.Add("SnapshotSessions");// To be verified

            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, getSystemKeyValue, excludeKeys))
                {
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify storage system key value exists in connected storage system");
            
        }

        private void AssertLunsInStorage(List<SortedList<string, string>> resultList, string value, string[] splitString, string globalId)
        {
            string[] names = value.Split(splitString, StringSplitOptions.RemoveEmptyEntries);
            TestLog log = TestLog.GetInstance();
            bool exist = false;

            for (int i = 0; i < names.Length; i++)
            {
                for (int j = 0; j < resultList.Count; j++)
                {
                    if (names[i].Trim() == resultList[j]["Name"] && globalId == resultList[j]["StorageSystemGlobalId"])
                    {
                        exist = true;
                        break;
                    }
                }
                log.AreEqual<bool>(true, exist, string.Format("Verify {0} is in the storage system", names[i]));
                exist = false;
            }
        }
    }
}
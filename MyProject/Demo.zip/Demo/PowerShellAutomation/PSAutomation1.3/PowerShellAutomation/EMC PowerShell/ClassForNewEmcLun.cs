﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcLun : BaseClass
    {
        #region CMD fields
        private string poolString = null;
        private string nameString = null;
        private string capacityString = null;
        private string thinString = null;
        private string descriptionString = null;
        private string silentString = null;
        private string hostbusAdapterString = null;
        private string hostSystemString = null;
        private string clusterSystemString = null;
        #endregion


        public NewEmcLun(string pool, string capacity, string name = null, string thin = null, string description = null, string silent = null, 
            string hostbusAdapter=null,string hostSytem=null,string clusterSystem=null,string cmd = null)
        {
            poolString = pool;
            nameString = name;
            capacityString = capacity;
            thinString = thin;
            descriptionString = description;
            hostbusAdapterString = hostbusAdapter;
            hostbusAdapterString = hostSytem;
            clusterSystemString = clusterSystem;
            silentString = silent;        
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcLun");
            if (poolString != null)
            {
                sb.AppendFormat(" -Pool {0}", poolString);
            }
            if (nameString != null)
            {
                sb.AppendFormat(" -Name {0}", nameString);
            }
            if (capacityString != null)
            {
                sb.AppendFormat(" -Capacity {0}", capacityString);
            }
            if (thinString != null)
            {
                sb.AppendFormat(" -Thin");
            }
            if (descriptionString != null)
            {
                sb.AppendFormat(" -Description {0}", descriptionString);
            }
            if(hostbusAdapterString!=null)
            {
                sb.AppendFormat(" -HostbusAdapter {0}",hostbusAdapterString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (hostbusAdapterString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            string returnString = sb.ToString();
            return returnString;
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine,true);

            
            SortedList<string, string> newLunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            GetEmcLun getLun = new GetEmcLun(newLunKeyValue["Wwn"]);
            string resultForVerification = getLun.RunCMD(psMachine);
            SortedList<string, string> getLunKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForVerification);

            VerifyFields(getLunKeyValue,psMachine);
            return result;
        }


        private void VerifyFields(SortedList<string, string> getLunKeyValue, PowershellMachine psMachine)
        {
            #region verification for fields
            TestLog log = TestLog.GetInstance();
            if (poolString != null)
            {
                string poolInfo=psMachine.RunScript(new List<string>{poolString},new List<PSParam>{}).OutStr;
                SortedList<string, string> poolInforKeyValue = HelperAdapter.GenerateKeyValuePairs(poolInfo);
                string poolID = poolInforKeyValue["ArrayPoolId"];
                log.AreEqual<string>(poolID, getLunKeyValue["ArrayPoolId"], "Verify Pool ID");
            }
            if (nameString != null)
            {
                log.AreEqual<string>(nameString, getLunKeyValue["Name"], "Verify Name property");
            }
            if (capacityString != null)
            {
                log.AreEqual<string>(capacityString, getLunKeyValue["Size"], "Verify capacity property");
            }
            if (thinString != null)
            {
                string expectValue = "Thin";
                log.AreEqual<string>(expectValue, getLunKeyValue["ProvisioningType"], "Verify provision type property");
            }
            else
            {
                string expectValue = "Thick";
                log.AreEqual<string>(expectValue, getLunKeyValue["ProvisioningType"], "Verify provision type property");
            }
            #endregion
        }
    }
}
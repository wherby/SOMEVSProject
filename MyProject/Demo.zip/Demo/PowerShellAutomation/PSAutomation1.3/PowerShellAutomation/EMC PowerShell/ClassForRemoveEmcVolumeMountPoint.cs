﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class RemoveEmcVolumeMountPoint : BaseClass
    {
        #region CMD fields
        private string volumeString = null;
        private string hostSystemString = null;
        private string clusterSystemString = null;
        private string silentString = null;
        #endregion

        public RemoveEmcVolumeMountPoint(string volume = null, string hostSystem = null, string clusterSystem = null, string silent = null, string cmd = null)
        {
            volumeString = volume;
            hostSystemString = hostSystem;
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Remove-EmcVolumeMountPoint");

            if (volumeString != null)
            {
                sb.AppendFormat(" -Volume {0}", volumeString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            GetEmcHostVolume volume = new GetEmcHostVolume(volumeString + ".HostVolumeIdentifier", null, hostSystemString, clusterSystemString);
            string result = volume.RunCMD(psMachine, true);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.AreEqual<string>(string.Empty, keyValue["MountPath"], "Verify mount path");
        }
    }
}
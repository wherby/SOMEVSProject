﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
using System;
namespace PowerShellAutomation
{

    public class GetEmcHostDisk : BaseClass
    {
        #region CMD fields
        string idString = null;
        string lunString = null;
        string volumeString = null;
        string hostSystemString = null;
        string clusterSystemString = null;
        string silentString = null;
        #endregion

        public GetEmcHostDisk(string id=null,string lun=null, string volume=null, string hostSystem=null,
            string clusterSystem=null, string silent=null,string cmd = null)
        {
            idString = id;
            lunString = lun;
            volumeString = volume;
            hostSystemString = hostSystem;
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Get-EmcHostDisk");
            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            if (lunString != null)
            {
                sb.AppendFormat(" -Lun {0}", lunString);
            }
            if (volumeString != null)
            {
                sb.AppendFormat(" -Volume {0}", volumeString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}",clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);
            if (lunString != null)
            {
                string lunInfo = TestSetup.GetParameterValue(psMachine, null,lunString);
                SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(lunInfo);
                string wwnString = lunKeyValue["wwn"];
                bool islunInResult = result.IndexOf(wwnString, StringComparison.OrdinalIgnoreCase) > 0;
                TestLog log = TestLog.GetInstance();
                log.AreEqual<bool>(true, islunInResult, "The disk is in result");
            }
            return result;
        }
    }
}

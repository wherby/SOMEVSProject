﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class SetEmcHostDiskReadOnlyState:BaseClass
    {
        private string diskString = null;
        private string readOnlyString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// SetEmcHostDiskReadOnlyState
        ///     SetEmcHostDiskReadOnlyState class constructor
        /// </summary>
        /// <param name="disk">The disk object</param>
        /// <param name="readOnlyFlag">The disk readonly switch</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public SetEmcHostDiskReadOnlyState(string disk, string readOnlyFlag = null, string silent = null, string cmd = null)
        {
            diskString = disk;
            readOnlyString = readOnlyFlag;
            silentString = silent;
            CmdString = cmd;           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcHostDiskReadOnlyState");

            if (diskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", diskString);
            }
            if (readOnlyString.Equals("ReadOnly", StringComparison.OrdinalIgnoreCase))
            {
                sb.Append(" -ReadOnly");
            }
            else 
            {
                sb.Append(" -ReadWrite");
            }
            
            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify SetEmcHostDiskReadOnlyState command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <returns>SetEmcHostDiskReadOnlyState result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {            
            string result = RunCMD(psMachine);
            
            // Update Host System
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Host"));
            updateSystem.RunCMD(psMachine);

            // Get the disk again
            GetEmcHostDisk hostDisk = new GetEmcHostDisk(null, HelperAdapter.GetParameter("Lun"), null, HelperAdapter.GetParameter("Host"));
            hostDisk.PrefixString = HelperAdapter.GetParameter("Disk");
            result = hostDisk.RunCMD(psMachine, true);

            if (readOnlyString.Equals("ReadOnly", StringComparison.OrdinalIgnoreCase))
            {
                VerifyFields(result, "ReadOnly");
            }
            else if (readOnlyString.Equals("ReadWrite", StringComparison.OrdinalIgnoreCase))
            {
                VerifyFields(result, "ReadWrite");
            }
            else
            {
                log.LogError(string.Format("Incorrect ReadOnly state: {0}", readOnlyString));
                PSException pe = new PSException(string.Format("Incorrect ReadOnly state: {0}", readOnlyString));
                throw pe;
            }
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of SetEmcHostDiskReadOnlyState 
        /// </summary>
        /// <param name="result">SetEmcHostDiskReadOnlyState result string</param>
        /// <param name="status">The disk status</param>        
        private void VerifyFields(string result, string status)
        {            
            SortedList<string, string> getHostDiskProperties = HelperAdapter.GenerateKeyValuePairs(result);

            #region verification for fields
            if (status.Equals("ReadOnly", StringComparison.OrdinalIgnoreCase))
            {
                if (!getHostDiskProperties["Flags"].Contains(status))
                {
                    log.LogError(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    PSException pe = new PSException(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    throw pe;
                }
            }
            else if (status.Equals("ReadWrite", StringComparison.OrdinalIgnoreCase))
            {
                if (getHostDiskProperties["Flags"].Contains("ReadOnly"))
                {
                    log.LogError(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    PSException pe = new PSException(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    throw pe;
                }
            }
    
            #endregion
        }
    }
}
﻿using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{
    public class UpdateEmcSystem : BaseClass
    {
        #region CMD fields
        private string hostSystemString = null;
        private string storageSystemString = null;
        private string clusterSystemString = null;
        private string silentString = null;
        private string systemType = null;
        #endregion

        public string SystemType
        {
            get
            {
                return systemType;
            }
            set
            {
                systemType = value;
            }
        }

        public UpdateEmcSystem(string hostSystem = null, string storageSystem = null, string clusterSystem = null, string silent = null, string cmd = null)
        {
            hostSystemString = hostSystem;
            storageSystemString = storageSystem;
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }  
    
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine);            
            
            return result;
        }


        private void VerifyFields(SortedList<string, string> connectSystemKeyValue, PowershellMachine psMachine)
        {                      
                        
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Update-EmcSystem");

            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }

            if (storageSystemString != null)
            {
                sb.AppendFormat(" -StorageSystem {0}", storageSystemString);
            }

            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -clusterSystem {0}", clusterSystemString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            return sb.ToString();
        }

    }
}
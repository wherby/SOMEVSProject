﻿using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcClusterSystem:BaseClass
    {
        #region CMD fields
        private string idString;
        private string diskString;
        private string silentString;
        private int getSystemCount;
        private SortedList<string, string>[] connectSystemKeyValue;
        #endregion

        public int GetSystemCount
        {
            get
            {
                return getSystemCount;
            }
            set
            {
                getSystemCount = value;
            }
        }

        public SortedList<string, string>[] ConnectSystemKeyValue
        {
            get
            {
                return connectSystemKeyValue;
            }
            set
            {
                connectSystemKeyValue = value;
            }
        }

        public GetEmcClusterSystem(string id = null, string disk = null,  string silent = null, string cmd = null)
        {
            idString = id;
            diskString = disk;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcClusterSystem");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            if (diskString != null)
            {
                sb.AppendFormat(" -ClusterDisk {0}", diskString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent {0}", silentString);
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getSystemKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            log.AreEqual<int>(getSystemCount, getSystemKeyValueList.Count, "Verify get system count");

            foreach (SortedList<string, string> keyValue in getSystemKeyValueList )
            {
                VerifyFields(psMachine, keyValue);
            }

            return result;
        }

        private void VerifyFields( PowershellMachine psMachine, SortedList<string, string> getSystemKeyValue)
        {
      
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            #endregion

            log.AreEqual<string>("ClusterSystem", getSystemKeyValue["AdapterType"], "Verify Adapter Type");

            string[] result = new string[2];
            string[] splitString = null;
            List<string> excludeKeys = new List<string>();
            GetEmcClusterSystem system = new GetEmcClusterSystem(getSystemKeyValue["GlobalId"]);
            system.PrefixString = "$verifyCluster";
            system.RunCMD(psMachine);

            GetEmcClusterDisk disk = new GetEmcClusterDisk(null, system.PrefixString);
            disk.PrefixString = "$verifyDisk";
            result[0] = disk.RunCMD(psMachine);

            GetEmcClusterGroup group = new GetEmcClusterGroup(system.PrefixString);
            group.PrefixString = "$verifyGroup";
            result[1] = group.RunCMD(psMachine);

            string[] keys = { "ClusterDisks", "ClusterGroups"};
            string[] properties = { "ClusterDiskResourceName", "Name" };
            char[][] split2 = {new char[]{':', '.'}, new char[]{'.'}};
            char[][] split3 = {null, new char[]{':'}};

            for (int i = 0; i < keys.Length; i++)
            {
                string key = keys[i];
                if (getSystemKeyValue.ContainsKey(key) && getSystemKeyValue[key] != "{}")
                {
                    excludeKeys.Add(key);

                    if (i == 0)
                    {
                        splitString = new string[] { "{", "[", ".]", ",","...", "}" };
                    }
                    else
                    {
                        splitString = new string[] { "{", ",", "...", "}"};
                    }

                    VerifyComplexEntry(getSystemKeyValue[key], result[i], splitString, null, null, properties[i]);
                }
            }
            if (getSystemKeyValue.ContainsKey("HostBusAdapters") && getSystemKeyValue["HostBusAdapters"] != "{}")
            {
                excludeKeys.Add("HostBusAdapters");

                string[] adapters = getSystemKeyValue["HostBusAdapters"].Split(new string[] { "{[", "], [", "]}" }, StringSplitOptions.RemoveEmptyEntries);
                string path = HelperAdapter.GetProperty("SystemConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path, "Cluster");
                if (dic["Name"] != getSystemKeyValue["Name"])
                {
                    dic = HelperAdapter.Load(path, "Cluster1");
                }

                string[] nodes = getSystemKeyValue["Nodes"].Split(new string[] { "{", ",", "}" }, StringSplitOptions.RemoveEmptyEntries);
                log.AreEqual<int>(nodes.Length, adapters.Length, "Verify nodes count and adapters count");

                for (int i = 0; i < adapters.Length; i++ )
                {
                    string[] adapterInfor = adapters[i].Split(new string[] { ". HostName=", ". Id=" }, StringSplitOptions.RemoveEmptyEntries);
                    log.AreEqual<string>("IscsiHostBusAdapter", adapterInfor[0], "Verify iscsi host bus adapter");
                    log.AreEqual<string>(dic["Node" + (i + 1).ToString() + "HostName"].ToLower(), adapterInfor[1], "Verify host name");
                    log.AreEqual<string>(dic["Node" + (i + 1).ToString() + "InitiatorId"].ToLower(), adapterInfor[2], "Verify iscsi id");
                }
            }

            excludeKeys.Add("Nodes");
            excludeKeys.Add("AvailableStorageOwnerNode");
            excludeKeys.Add("IsClusterSharedVolumeEnabled");

            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, getSystemKeyValue, excludeKeys))
                {
                    equalKeyValue = true;
                    break;
                }
            }
           
            log.AreEqual<bool>(true, equalKeyValue, "Verify cluster system key value exists in connected cluster systems");
            
        }

        private void VerifyComplexEntry(string entryValue, string result, string[] split1, char[] split2 = null , char[] split3 = null, string key = null)
        {
            TestLog log = TestLog.GetInstance();

            List<SortedList<string, string>> list = HelperAdapter.GenerateKeyValuePairsList(result);

            string[] bigArray = entryValue.Split(split1, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < bigArray.Length; i++)
            {                 
                if (split2 != null)
                {
                   string[] midArray = bigArray[i].Split(split2, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < midArray.Length; j++)
                    {
                        if (split3 != null)
                        {                        
                            string[] smallArray = midArray[j].Split(split3, 2, StringSplitOptions.RemoveEmptyEntries);
                            log.AreEqual<string>(smallArray[1].Trim(), list[i][smallArray[0].Trim()], string.Format("Verify {0}", smallArray[0]));
                        }
                        else
                        {
                            log.AreEqual<string>(midArray[1].Trim(), list[i][midArray[0].Trim()], string.Format("Verify {0}", midArray[0]));
                        }
                    }                    
                }
                else
                {
                    if (key != null)
                    {
                        log.AreEqual<string>(bigArray[i].Trim(), list[i][key], string.Format("Verify {0}", key));
                    }
                }
            }
            
        }
    }
}

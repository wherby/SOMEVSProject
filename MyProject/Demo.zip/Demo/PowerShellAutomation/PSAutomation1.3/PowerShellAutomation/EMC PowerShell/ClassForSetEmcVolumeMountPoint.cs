﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class SetEmcVolumeMountPoint : BaseClass
    {
        #region CMD fields
        private string volumeString = null;
        private string hostSystemString = null;
        private string driveLetterString = null;
        private string mountPathString = null;
        private string clusterSystemString = null;
        private string silentString = null;
        private SortedList<string, string> volumeInfo = null;
        #endregion

        public SortedList<string, string> VolumeInfo
        {
            get
            {
                return volumeInfo;
            }
            set
            {
                volumeInfo = value;
            }
        }

        public SetEmcVolumeMountPoint(string volume = null, string hostSystem = null, string driveLetter = null, string mountPath = null, string clusterSystem = null, string silent = null, string cmd = null)
        {
            volumeString = volume;
            hostSystemString = hostSystem;
            driveLetterString = driveLetter;
            mountPathString = mountPath; 
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Set-EmcVolumeMountPoint");

            if (volumeString != null)
            {
                sb.AppendFormat(" -Volume {0}", volumeString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (driveLetterString != null)
            {
                sb.AppendFormat(" -DriveLetter {0}", driveLetterString);
            }
            if (mountPathString != null)
            {
                sb.AppendFormat(" -MountPath {0}", mountPathString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine)
        {
            string mountPath = null;
            TestLog log = TestLog.GetInstance();

            GetEmcHostVolume volume = new GetEmcHostVolume(volumeString + ".HostVolumeIdentifier");

            string result = volume.RunCMD(psMachine, true);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

            if (driveLetterString != null)
            {
                mountPath = driveLetterString + @":\";
            }
            else
            {
                mountPath = mountPathString + @"\";
            }

            log.AreEqual<string>(mountPath, keyValue["MountPath"], "Verify mount path");

            HelperAdapter.SortedListIsEqual(keyValue, volumeInfo, new List<string> { "MountPath"});
        }
    }
}
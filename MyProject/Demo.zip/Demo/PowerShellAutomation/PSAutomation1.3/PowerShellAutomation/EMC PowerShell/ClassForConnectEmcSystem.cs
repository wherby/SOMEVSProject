﻿using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{
    public class ConnectEmcSystem : BaseClass
    {
        #region CMD fields
        private string creationBlobString = null;
        private string silentString = null;
        private string systemType = null;
        #endregion

        public string SystemType
        {
            get
            {
                return systemType;
            }
            set
            {
                systemType = value;
            }
        }

        public ConnectEmcSystem(string creationBlob, string silent = null, string cmd = null)
        {
            creationBlobString = creationBlob;
            silentString = silent;
            CmdString = cmd;
        }  
    
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);            
            
            SortedList<string, string> connectSystemKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            VerifyFields(connectSystemKeyValue, psMachine);

            return result;
        }


        private void VerifyFields(SortedList<string, string> connectSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification for fields
            TestLog log = TestLog.GetInstance();
            string path = HelperAdapter.GetProperty("SystemConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, systemType);
            string resultForVerification = null;
            SortedList<string, string> getSystemKeyValue = new SortedList<string, string>();
            #endregion

            switch (systemType)
            {
                case "Host":
                    {
                        GetEmcHostSystem getHost = new GetEmcHostSystem(connectSystemKeyValue["GlobalId"]);
                        resultForVerification = getHost.RunCMD(psMachine);
                        getSystemKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForVerification);

                        log.AreEqual<string>("HostSystem", connectSystemKeyValue["AdapterType"], "Verify Adapter Type");
                        log.AreEqual<string>(dic["HostName"].ToLower(), connectSystemKeyValue["Name"].ToLower() + "." + connectSystemKeyValue["Domain"], "Verify host Name");
                        log.AreEqual<string>(dic["UserName"].ToLower(), connectSystemKeyValue["UserName"].ToLower(), "Verify User Name");
                        log.AreEqual<string>(dic["IPAddress"], connectSystemKeyValue["IpAddress"], "Verify IP Address");
                        log.AreEqual<string>(dic["Domain"].ToLower(), connectSystemKeyValue["Domain"].ToLower(), "Verify domain");
                        HelperAdapter.AssertPropertiesComparision(getSystemKeyValue, connectSystemKeyValue);
                        break;
                    }
                case "VNX-Block":
                    {
                        log.AreEqual<string>(dic["ManagementServiceEndpointList"], connectSystemKeyValue["ManagementServiceEndpointList"], "Verify ManagementServiceEndpointList");
                        goto case "Storage";
                    }
                case "VNX-CIFS":
                    {
                        log.AreEqual<string>(dic["IpAddress"], connectSystemKeyValue["IpAddress"], "Verify IP Address");
                        log.AreEqual<string>(dic["Port"], connectSystemKeyValue["Port"], "Verify Port");
                        log.AreEqual<string>(dic["UserName"].ToLower(), connectSystemKeyValue["UserName"].ToLower(), "Verify Username");
                        goto case "VNX";
                    }
                case "VMAX": goto case "Storage";
                case "VMAXe": goto case "Storage";
                case "CLARiion-CX4": goto case "Storage";
                case "VNX":
                    {
                        
                        goto case "Storage";
                    }
                case "Storage":
                    {
                        log.AreEqual<string>("StorageSystem", connectSystemKeyValue["AdapterType"], "Verify Adapter Type");
                        log.AreEqual<string>(dic["UserFriendlyName"].ToLower(), connectSystemKeyValue["UserFriendlyName"].ToLower(), "Verify User Friendly Name");
                        break;
                    }
                case "Cluster":
                    {
                        log.AreEqual<string>("ClusterSystem", connectSystemKeyValue["AdapterType"], "Verify Adapter Type");
                        log.AreEqual<string>(dic["FriendlyName"].ToLower(), connectSystemKeyValue["UserFriendlyName"].ToLower(), "Verify User Friendly Name");
                        log.AreEqual<string>(dic["Name"].ToLower(), connectSystemKeyValue["Name"].ToLower(), "Verify Name");
                        log.AreEqual<string>(dic["Domain"].ToLower(), connectSystemKeyValue["Domain"].ToLower(), "Verify Domain");                        
                        break;
                    }
                default:
                    {
                        PSException pe = new PSException("invalid system type.");
                        throw pe;
                    }
            }
                        
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Connect-EmcSystem");

            if (creationBlobString != null)
            {
                sb.AppendFormat(" -CreationBlob {0}", creationBlobString);
            }
            
            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }

    }
}
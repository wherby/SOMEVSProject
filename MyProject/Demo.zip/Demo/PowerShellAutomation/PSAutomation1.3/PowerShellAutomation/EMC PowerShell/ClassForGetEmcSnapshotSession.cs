﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcSnapshotSession : BaseClass
    {
        #region CMD fields
        private string sessionIDString = null;
        private string sourceIDString = null;
        private string targetIDString = null;
        private string silentString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// GetEmcSnapshotSession
        ///     Constructor for Get-EmcSnapshotSession class
        /// </summary>
        /// <param name="lun">lun object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcSnapshotSession(string sessionID = null, string sourceID = null, string targetID = null, string silent = null, string cmd = null)
        {
            sessionIDString = sessionID;
            sourceIDString = sourceID;
            targetIDString = targetID;
            silentString = silent;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSnapshotSession");

            if (sessionIDString != null)
            {
                sb.AppendFormat(" -SessionID {0}", sessionIDString);
            }

            if (sourceIDString != null)
            {
                sb.AppendFormat(" -SourceID {0}", sourceIDString);
            }

            if (targetIDString != null)
            {
                sb.AppendFormat(" -TargetID {0}", targetIDString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcSnapshotSession commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcSnapshotSession</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> newSnapshotSessionProperties)
        {
            string result = RunCMD(psMachine, true);
            VerifyFields(result, newSnapshotSessionProperties);  
            return result;
        }        

        /// <summary>
        /// VerifyFields
        ///     verify the fields of a snapshot session
        /// </summary>
        /// <param name="getLunProperties">snapshot lun properties retrieved from Get-EmcSnapshotSession</param>        
        private void VerifyFields(string result, SortedList<string, string> newSnapshotSessionProperties)
        {
            List<SortedList<string, string>> getSnapshotSessionPropertiesList = HelperAdapter.GenerateKeyValuePairsList(result);

            SortedList<string, string> getSnapshotSessionProperties = null;

            foreach (SortedList<string, string> properties in getSnapshotSessionPropertiesList)
            {

                if (properties["SessionId"].Equals(newSnapshotSessionProperties["SessionId"]))
                {
                    getSnapshotSessionProperties = properties;
                }
            }

            if (getSnapshotSessionProperties == null)
            {
                log.LogError(string.Format("Failed to get the following snapshot lun: {0}", newSnapshotSessionProperties));
                PSException pe = new PSException(string.Format("Failed to get the following snapshot lun: {0}", newSnapshotSessionProperties));
                throw pe;
            }

            #region verification for fields
            HelperAdapter.AssertPropertiesComparision(getSnapshotSessionProperties, newSnapshotSessionProperties);
            #endregion            
        }
    }
}
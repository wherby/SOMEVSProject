﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcLun:BaseClass
    {
        #region CMD fields
        private string idString;
        private string poolString;
        private string hostDiskString;
        private string volumeString;
        private string clusterDiskString;
        private string blockStorageSystemString;
        private string silentString;
        #endregion


        public GetEmcLun(string id = null, string pool = null, string hostDisk = null, string volume = null, string clusterDisk = null,
            string blockStorageSystem=null , string silent=null,string cmd=null)
        {
            idString = id;
            poolString = pool;
            hostDiskString = hostDisk;
            volumeString = volume;
            clusterDiskString = clusterDisk;
            blockStorageSystemString = blockStorageSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            if (CmdString != null)
            {
                return CmdString;
            }

            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcLun");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            if (poolString != null)
            {
                sb.AppendFormat(" -Pool {0}", poolString);
            }
            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }
            if (volumeString != null)
            {
                sb.AppendFormat(" -Volume {0}", volumeString);
            }
            if (clusterDiskString != null)
            {
                sb.AppendFormat(" -ClusterDisk {0}", clusterDiskString);
            }
            if (blockStorageSystemString != null)
            {
                sb.AppendFormat(" -BlockStorageSystem {0}", blockStorageSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine);
            if (result.Trim() == string.Empty)
            {
                string warningMSG = string.Format("There is no result for command: {0}", GetFullString());
                log.LogWarning(warningMSG);
                PSException pe = new PSException(warningMSG);
                throw pe;
            }

           string[] lunStrings = result.Split(new string[] { "\r\n\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            
           foreach (string lunString in lunStrings)
           {
               SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(lunString);

               VerifyFields(lunKeyValue);
           }

           return result;
        }

        private void VerifyFields(SortedList<string, string> lun)
        {

        }
    }
}
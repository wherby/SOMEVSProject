﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualDiskConfiguration:BaseClass
    {
        private string hostDiskString = null;
        private string silentString = null;
        private TestLog log = TestLog.GetInstance();
        private string diskConfig;

        public string DiskConfig
        {
            get
            {
                return diskConfig;
            }
            set
            {
                diskConfig = value;
            }
        }

        /// <summary>
        /// GetEmcVirtualDiskConfiguration
        ///     GetEmcVirtualDiskConfiguration class constructor
        /// </summary>
        /// <param name="vm">VirtualMachine object</param>
        /// <param name="silent">silent switch parameter</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVirtualDiskConfiguration(string hostDisk, string silent=null, string cmd = null)
        {
            hostDiskString = hostDisk;
            silentString = silent;
            CmdString = cmd;
           
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualDiskConfiguration");

            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            return sb.ToString();
        }        

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualDiskConfiguration command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="hypervVmConfiguration">All the VM configuration in that hyperv</param>
        /// <param name="hypervName">The name of Hyper-V host</param>
        /// <param name="vmName">The name of Virtual Machine</param>
        /// <returns>Get-EmcVirtualMachineConfiguration result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hypervName)
        {
            PrefixString = "$getDiskConfig";

            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, hypervName);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualDiskConfiguration
        /// </summary>
        /// <param name="result">Get-EmcVirtualDiskConfiguration result string</param>
        private void VerifyFields(PowershellMachine psMachine, string hypervName)
        {            
            string getServer = getPropertyValue(psMachine, PrefixString, "Server");
            log.AreEqual<string>(hypervName.ToLower(), getServer.ToLower(), "Verify server name");

            string getLunId = getPropertyValue(psMachine, PrefixString, "HostLunIdentifier");
            string diskLunId = getPropertyValue(psMachine, diskConfig, "HostLunIdentifier");
            log.AreEqual<string>(diskLunId, getLunId, "Verify HostLunIdentifier");

            string getScsiControllerIndex = getPropertyValue(psMachine, PrefixString, "ScsiControllerIndex");
            string diskScsiControllerIndex = getPropertyValue(psMachine, diskConfig, "ScsiControllerIndex");
            log.AreEqual<string>(diskScsiControllerIndex, getScsiControllerIndex, "Verify ScsiControllerIndex");

            if (diskConfig == HelperAdapter.GetParameter("FilebasedDiskConfiguration"))
            {
                string getPath = getPropertyValue(psMachine, PrefixString, "Path");
                string diskPath = getPropertyValue(psMachine, diskConfig, "Path");
                log.AreEqual<string>(diskPath, getPath, "Verify disk path");
            }
            else
            {
                string getDescription = getPropertyValue(psMachine, PrefixString, "Description");
                string diskDescription = getPropertyValue(psMachine, diskConfig, "Description");
                log.AreEqual<string>(diskDescription, getDescription, "Verify Disk Description");

                string getDriveNumber = getPropertyValue(psMachine, PrefixString, "DriveNumber");
                string diskDriveNumber = getPropertyValue(psMachine, diskConfig, "DriveNumber");
                log.AreEqual<string>(diskDriveNumber, getDriveNumber, "Verify Disk DriveNumber");
            }
        }

        private string getPropertyValue(PowershellMachine psMachine, string prefix, string property = null)
        {
            List<string> ps = new List<string>();

            if (property == null)
            {
                ps.Add(prefix + property);
            }
            else
            {
                ps.Add(prefix + "." + property);
            }
            string getValue = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

            return getValue;
        }
    }
}
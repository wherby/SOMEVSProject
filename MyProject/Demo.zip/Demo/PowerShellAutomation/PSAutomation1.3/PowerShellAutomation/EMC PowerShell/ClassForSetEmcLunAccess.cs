﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class SetEmcLunAccess : BaseClass
    {
        #region CMD fields
        private string lunString = null;
        private string hostSystemString = null;
        private string initiatorIdString = null;
        private string hostNameString = null;
        private string hostIpAddressString = null;
        private string clusterSystemString = null;
        private string availableString = null;
        private string silentString = null;
        #endregion

        public SetEmcLunAccess(string available = null, string lun = null, string hostSystem = null, string initiatorId = null, string hostName = null, 
            string hostIpAddress = null, string clusterSystem = null, string silent=null, string cmd = null)
        {
            lunString = lun;
            hostSystemString = hostSystem;
            initiatorIdString = initiatorId;
            hostNameString = hostName; 
            hostIpAddressString = hostIpAddress;
            clusterSystemString = clusterSystem;
            availableString = available;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcLunAccess");
            if (lunString != null)
            {
                sb.AppendFormat(" -Lun {0}", lunString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (initiatorIdString != null)
            {
                sb.AppendFormat(" -InitiatorId {0}", initiatorIdString);
            }
            if (hostNameString != null)
            {
                sb.AppendFormat(" -HostName {0}", hostNameString);
            }
            if (hostIpAddressString != null)
            {
                sb.AppendFormat(" -HostIpAddress {0}", hostIpAddressString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (availableString != null)
            {
                if (availableString == "Available")
                {
                    sb.AppendFormat(" -Available");
                }
                if (availableString == "Unavailable")
                {
                    sb.AppendFormat(" -Unavailable");
                }
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);
            

            string hostSystem = hostSystemString;
            if (initiatorIdString != null)
            {
                hostSystem = HelperAdapter.GetParameter("Host");
            }
            if (clusterSystemString == null)
            {
                UpdateEmcSystem update = new UpdateEmcSystem(hostSystem);
                update.RunCMD(psMachine);
            }
            else
            {
                UpdateEmcSystem update = new UpdateEmcSystem(null, null, clusterSystemString);
                update.RunCMD(psMachine);
            }
            FindEmcHostDisk findDisk = new FindEmcHostDisk(hostSystem, clusterSystemString, null,null , lunString);
            string resultDisk = findDisk.RunCMD(psMachine, false);
            TestLog log = TestLog.GetInstance();
            bool isEmpty=resultDisk.Trim().Equals(string.Empty);
            if (availableString == "Available")
            {
                log.AreEqual<bool>(false, isEmpty, "Disk can be find.");
            }
            else
            {
                log.AreEqual<bool>(true, isEmpty, "Disk can't be find.");
            }
            return result;
        }
    }
}
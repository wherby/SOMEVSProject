﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{
    
    public class DisconnectEmcClusterSystem : BaseClass
    {
        #region CMD fields
        private string idString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatIfString = null;
        private string systemString = null;
        #endregion


        public DisconnectEmcClusterSystem(string id = null, string system = null, string force = null, string silent = null, string whatIf = null, string cmd = null)
        {
            idString = id;
            forceString = force;
            silentString = silent;
            whatIfString = whatIf;
            systemString = system;
            CmdString = cmd;
        }  
    
        public string VerifyTheCMD(PowershellMachine psMachine, string globalId)
        {
            string result = RunCMD(psMachine);

            VerifyFields(result.Trim(), psMachine, globalId);

            return result;
        }

        private void VerifyFields(string result, PowershellMachine psMachine, string globalId)
        {
            TestLog log = TestLog.GetInstance();

            log.AreEqual(string.Empty, result, "Cmdlet output");

            GetEmcClusterSystem getCluster = new GetEmcClusterSystem();

            string resultForVerification = getCluster.RunCMD(psMachine);

            if ((whatIfString == null && resultForVerification.Trim() != string.Empty) || (whatIfString != null && resultForVerification.Trim() == string.Empty))
            {
                log.LogError(string.Format("Disconnect Cluster System {0} Failed.", globalId));
                PSException pe = new PSException(string.Format("Disconnect Cluster System {0} Failed.", globalId));
                throw pe;
            }                 
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Disconnect-EmcClusterSystem");

            if (idString != null)
            {
                sb.AppendFormat(" -Id {0}", idString);
            }

            if ( systemString != null)
            {
                sb.AppendFormat(" -System {0}", systemString);
            }

            if (forceString != null)
            {
                sb.Append(" -Force");
            }

            if (whatIfString != null)
            {
                sb.Append(" -WhatIf");
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            sb.Append(" -Confirm:$false");

            return sb.ToString();
        }

    }
}
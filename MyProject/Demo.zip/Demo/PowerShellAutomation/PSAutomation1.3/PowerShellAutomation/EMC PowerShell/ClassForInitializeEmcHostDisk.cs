﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class InitializeEmcHostDisk : BaseClass
    {
        #region CMD fields
        string partitionStyleString = null;
        string hostDiskString = null;
        string hostSystemString = null;
        string clusterSystemString = null;
        string silentString = null;
        #endregion

        public InitializeEmcHostDisk(string partitionStyle=null, string hostDisk=null,string hostSystem=null,
            string clusterSystem=null, string silent=null,string cmd = null)
        {
            partitionStyleString = partitionStyle;
            hostDiskString = hostDisk;
            hostSystemString = hostSystem;
            clusterSystemString = clusterSystem;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Initialize-EmcHostDisk");
            if (partitionStyleString != null)
            {
                sb.AppendFormat(" -PartitionStyle {0}", partitionStyleString);
            }
            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine,string lunStringV=null,string hostDiskStringV=null,string hostSystemStringV=null
            ,string clusterStringV=null)
        {
            string result = RunCMD(psMachine, false);
            TestLog log = TestLog.GetInstance();

            GetEmcHostDisk getdisk;
            if (clusterSystemString == null)
            {
                getdisk = new GetEmcHostDisk(hostDiskString + ".HostDiskIdentifier", null, null, hostSystemString);
            }
            else
            {
                string lunForCluster = HelperAdapter.GetParameter("LunC");
                getdisk = new GetEmcHostDisk(hostDiskString + ".HostDiskIdentifier",lunForCluster, null, null, clusterSystemString);
            }
            if(lunStringV!=null)
            {
                getdisk = new GetEmcHostDisk(hostDiskStringV + ".HostDiskIdentifier", lunStringV, null, hostSystemStringV,clusterStringV);
            }
            string resultDisk = getdisk.RunCMD(psMachine, true);
            SortedList<string, string> diskKeyValue = HelperAdapter.GenerateKeyValuePairs(resultDisk);
            string isInitialized = diskKeyValue["IsInitialized"];
            log.AreEqual<string>("True", isInitialized, "The disk is initialized");

            return result;
        }
    }
}

﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class FindEmcHostDisk : BaseClass
    {
        #region CMD fields
        private string hostSystemString = null;
        private string clusterSystemString = null;
        private string virtualMachineString = null;
        private string hostLunIdentifierString = null;
        private string lunString = null;
        private string vmDiskConfigString = null;
        private string silentString = null;
        #endregion

        public FindEmcHostDisk(string hostSystem=null,string clusterSystem=null, string virtualMachine=null,
            string hostLunIdentifier=null, string lun=null, string vmDiskConfig=null,string silent=null ,string cmd = null)
        {
            hostSystemString = hostSystem;
            clusterSystemString = clusterSystem;
            virtualMachineString = virtualMachine;
            hostLunIdentifierString = hostLunIdentifier;
            lunString = lun;
            vmDiskConfigString = vmDiskConfig;
            silentString = silent;
            CmdString = cmd;
        }
         
        public override string ToCMDString() 
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("Find-EmcHostDisk");
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (virtualMachineString != null)
            {
                sb.AppendFormat(" -VirtualMachine {0}", virtualMachineString);
            }
            if (hostLunIdentifierString != null)
            {
                sb.AppendFormat(" -HostLunIdentifier {0}", hostLunIdentifierString);
            }
            if (lunString != null)
            {
                sb.AppendFormat(" -Lun {0}", lunString);
            }
            if (vmDiskConfigString != null)
            {
                sb.AppendFormat(" -vmDiskConfig {0}", vmDiskConfigString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            return result;
        }
    }
}
﻿using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcSnapshotSession : BaseClass
    {
        #region CMD fields
        private string snapshotSessionString = null;
        private string removeSnapshotLUNString = null;
        private string forcestring = null;        
        private string silentString = null;
        private string whatifString = null;
        #endregion
        private TestLog log = TestLog.GetInstance();

        /// <summary>
        /// RemoveEmcSnapshotSession
        ///     Constructor for RemoveEmcSnapshotSession class
        /// </summary>
        /// <param name="lun">lun object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcSnapshotSession(string snapshotSession, string removeSnapshotLUN = null, string force = null, string silent = null, string whatif = null, string cmd = null)
        {
            snapshotSessionString = snapshotSession;
            removeSnapshotLUNString = removeSnapshotLUN;
            forcestring = force;
            silentString = silent;
            whatifString = whatif;
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcSnapshotSession");

            if (snapshotSessionString != null)
            {
                sb.AppendFormat(" -SnapshotSession {0}", snapshotSessionString);
            }

            if (removeSnapshotLUNString != null)
            {
                sb.Append(" -RemoveSnapshotLUN");
            }

            if (forcestring != null)
            {
                sb.Append(" -Force");
            }            

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }

            if (whatifString != null)
            {
                sb.Append(" -WhatIf");
            }

            sb.Append(" -Confirm:$false");
            return sb.ToString();
        }        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcSnapshotSession commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcSnapshotSession</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string snapshotSessionID, string snapshotLunID)
        {
            string result = RunCMD(psMachine);

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(null, "$storage");
            updateSystem.RunCMD(psMachine);

            VerifyFields(psMachine, snapshotSessionID, snapshotLunID);
            return result;
        }        

        /// <summary>
        /// VerifyFields
        ///     verify the fields of a snapshot session
        /// </summary>
        /// <param name="getLunProperties">snapshot lun properties retrieved from Get-EmcSnapshotSession</param>        
        private void VerifyFields(PowershellMachine psMachine, string snapshotSessionID, string snapshotLunID)
        {
            GetEmcSnapshotSession snapshotSession = new GetEmcSnapshotSession(snapshotSessionID);
            string result = snapshotSession.RunCMD(psMachine);

            if (whatifString != null)
            {
                if (result.Trim() == String.Empty)
                {
                    log.LogError(string.Format("SnapshotSession should not be removed with WhatIf parameter."));
                    PSException pe = new PSException(string.Format("SnapshotSession should not be removed with WhatIf parameter."));
                    throw pe;
                }
            }
            else
            {
                if (result.Trim() != String.Empty)
                {
                    log.LogError(string.Format("Failed to remove SnapshotSession: {0}.", result));
                    PSException pe = new PSException(string.Format("Failed to remove SnapshotSession: {0}.", result));
                    throw pe;
                }
                
                // Verrify whether snapshot lun is removed
                GetEmcSnapshotLun snapshotLun = new GetEmcSnapshotLun(null, snapshotLunID);
                result = snapshotLun.RunCMD(psMachine);
                if (removeSnapshotLUNString != null)
                {
                    if (result.Trim() != string.Empty)
                    {
                        log.LogError(string.Format("Failed to remove SnapshotLun: {0}.", result));
                        PSException pe = new PSException(string.Format("Failed to remove SnapshotLun: {0}.", result));
                        throw pe;
                    }
                }
                else
                {
                    if (result.Trim() == string.Empty)
                    {
                        log.LogError(string.Format("SnapshotLun should not be removed without RemoveSnapshotLUN parameter."));
                        PSException pe = new PSException(string.Format("SnapshotLun should not be removed without RemoveSnapshotLUN parameter."));
                        throw pe;
                    }
                }
            }            
        }
    }
}
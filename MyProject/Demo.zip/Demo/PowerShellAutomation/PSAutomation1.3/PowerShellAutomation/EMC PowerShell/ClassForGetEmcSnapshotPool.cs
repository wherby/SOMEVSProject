﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;


namespace PowerShellAutomation
{
    public class GetEmcSnapshotPool : BaseClass
    {
        #region CMD fields
        private string idString;
        private string silentString;
        #endregion

        TestLog log = TestLog.GetInstance();
        
        /// <summary>
        /// GetEmcSnapshotPool
        ///     Constructor for GetEmcSnapshotPool
        /// </summary>
        /// <param name="id">Snapshot Pool ID</param>
        /// <param name="cmd">Command string to test</param>
        public GetEmcSnapshotPool(string id = null, string silent = null, string cmd = null)
        {
            idString = id;
            silentString = silent;            
            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSnapshotPool");

            if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", idString);
            }
            
            if (silentString != null)
            {
                sb.Append(" -Silent");
            }
            
            return sb.ToString();
        } 
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcSnapshotPool succeeds
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="globalID">The storage global id</param>
        /// <param name="defaultPoolID">The default id for snapshot pool</param>
        /// <returns>Get-EmcSnapshotPool result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string globalID, string defaultPoolID)
        {           
            
            string result = RunCMD(psMachine, true);
            VerifyFields(result, globalID, defaultPoolID);            

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the  fields for Get-EmcSnapshotPool
        /// </summary>     
        /// <param name="result">Get-EmcSnapshotPool result</param>
        /// <param name="globalID">The storage global id</param>
        /// <param name="defaultPoolID">The default id for snapshot pool</param>
        private void VerifyFields(string result, string globalID, string defaultPoolID)
        {            
            SortedList<string, string> snapshotPoolProperites = null;

            List<SortedList<string, string>> snapshotPoolKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach (SortedList<string, string> KeyValue in snapshotPoolKeyValueList)
            {
                if (KeyValue["StorageSystemGlobalId"].Equals(globalID))
                {
                    snapshotPoolProperites = KeyValue;
                }
            }

            if (snapshotPoolProperites == null)
            {
                log.LogError(string.Format("Failed to get the snapshot pool of storage: {0}", globalID));
                PSException pe = new PSException(string.Format("Failed to get the snapshot pool of storage: {0}", globalID));
                throw pe;
            }
            else
            {                
                log.AreEqual(defaultPoolID, snapshotPoolProperites["PoolId"], "Verfity snapshot pool id:");

            }
        }
    }
}

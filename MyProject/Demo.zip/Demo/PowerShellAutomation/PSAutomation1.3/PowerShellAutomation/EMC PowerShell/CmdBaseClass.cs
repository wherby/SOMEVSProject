﻿using System.Collections.Generic;
using PowerShellTestTools;
using System.Text;

namespace PowerShellAutomation
{
    public class BaseClass
    {
        private string prefixString;
        private string postfixString;
        private string signString;
        public string CmdString;

        public string PrefixString
        {
            get
            {
                return prefixString;
            }
            set
            {
                prefixString = value;
            }
        }

        public string PostfixString
        {
            get
            {
                return postfixString;
            }
            set
            {
                postfixString = value;
            }
        }

        public string SignString
        {
            get
            {
                return signString;
            }
            set
            {
                signString = value;
            }
        }
        public BaseClass()
        {
            prefixString = null;
            postfixString = null;
            signString = "=";
            CmdString = null;
        }

        public virtual string GetFullString()
        {
            string fullString;
            if (CmdString == null)
            {
                fullString = ((prefixString != null) ? (prefixString + signString) : "") + ToCMDString() + " " + postfixString;
            }
            else
            {
                fullString = ((prefixString != null) ? (prefixString + signString) : "") + CmdString + " " + postfixString;
            }
            return fullString;
        }

        public virtual string ToCMDString()
        {
            return "base Class";
        }

        public string RunCMD(PowershellMachine PSMachine,bool isVerified=false)
        {
            List<string> ps = new List<string>();
            ps.Add(GetFullString());
            //if prefixstring is not null, the result for the command will not show up. so there need add command for get the command result.
            if (prefixString != null)
            {
                ps.Add(prefixString);
            }
            string result=PSMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            if (isVerified == true)
            {
                if (result.Trim() == string.Empty)
                {
                    TestLog log = TestLog.GetInstance();
                    string warningMSG = string.Format("There is no result for command: {0}", GetFullString());
                    log.LogWarning(warningMSG);
                    PSException pe = new PSException(warningMSG);
                    throw pe;
                }
            }
            return result;
        }
    }
}

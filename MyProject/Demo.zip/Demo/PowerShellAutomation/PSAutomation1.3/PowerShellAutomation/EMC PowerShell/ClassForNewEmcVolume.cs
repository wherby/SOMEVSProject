﻿using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class NewEmcVolume : BaseClass
    {
        #region CMD fields
        string hostSystemString = null;
        string clusterSystemString = null;
        string hostDiskString = null;
        string hostLunIdentifierString = null;
        string allocationUnitSizeInBytesString = null;
        string fileSystemTypeString = null;
        string labelString = null;
        string silentString = null;
        #endregion

        public NewEmcVolume(string hostSystem=null,string clusterSystem=null, string hostDisk=null, string hostLunIdentifier=null,
            string allocationUnitSizeInBytes=null,string fileSystemType=null, string label=null,string silent=null,string cmd = null)
        {
            hostSystemString = hostSystem;
            clusterSystemString = clusterSystem;
            hostDiskString = hostDisk;
            hostLunIdentifierString = hostLunIdentifier;
            allocationUnitSizeInBytesString = allocationUnitSizeInBytes;
            fileSystemTypeString = fileSystemType;
            labelString = label;
            silentString = silent;
            CmdString = cmd;
        }

        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.AppendFormat("New-EmcVolume");
            if (hostSystemString != null)
            {
                sb.AppendFormat(" -HostSystem {0}", hostSystemString);
            }
            if (clusterSystemString != null)
            {
                sb.AppendFormat(" -ClusterSystem {0}", clusterSystemString);
            }
            if (hostDiskString != null)
            {
                sb.AppendFormat(" -HostDisk {0}", hostDiskString);
            }
            if (hostLunIdentifierString != null)
            {
                sb.AppendFormat(" -HostLunIdentifier {0}", hostLunIdentifierString);
            }
            if (allocationUnitSizeInBytesString != null)
            {
                sb.AppendFormat(" -AllocationUnitSizeInBytes {0}", allocationUnitSizeInBytesString);
            }
            if (fileSystemTypeString != null)
            {
                sb.AppendFormat(" -FileSystemType {0}", fileSystemTypeString);
            }
            if (labelString != null)
            {
                sb.AppendFormat(" -Label {0}", labelString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            return sb.ToString();
        }

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            return result;
        }
    }
}

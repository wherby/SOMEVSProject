﻿      
        [TestMethod]
        public void PS_[*testName*]Test[*para*]()
        {
            string cmd = "[*cmd*]";
            [*methodName*]TestMethod(cmd);
        }
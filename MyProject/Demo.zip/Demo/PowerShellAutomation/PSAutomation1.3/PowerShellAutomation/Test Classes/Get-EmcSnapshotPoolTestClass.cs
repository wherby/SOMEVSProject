﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcSnapshotPoolTest: test class for Get-EmcSnapshotPool cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcSnapshotPoolTest
    {
        public GetEmcSnapshotPoolTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string globalID = "";
        private static string defaultPoolID = "Reserved LUN Pool";
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        
        // Use ClassInitialize to run code before running the first test in the class       
        [ClassInitialize]
        public static void ESIPSTestInit(TestContext testContext)
        {            
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);           
            string result = TestSetup.ConnectSystem(psMachine, storage);
            globalID = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];
            log.LogInfo("--------Class Initialize End--------");
        }

        
        // Use ClassCleanup to run code after all tests in a class have run       
        [ClassCleanup]
        public static void ESIPSTestCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }  
  
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcSnapshotPool instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcSnapshotPool instance</returns>  
        public GetEmcSnapshotPool ParseCmd(string cmd)
        {
            string id = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = "\"" + defaultPoolID + "\"";
                cmdString = cmdString.Replace("$ID", id);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcSnapshotPool getSnapshotPool = new GetEmcSnapshotPool(id, silent, cmdString);

            return getSnapshotPool;
        }

        /// <summary>  
        /// GetEmcSnapshotPoolTestMethod:
        ///    The method to implement Get-EmcSnapshotPool poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSnapshotPoolTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
           
            GetEmcSnapshotPool snapshotPool = ParseCmd(cmd);           

            snapshotPool.VerifyTheCMD(psMachine, globalID, defaultPoolID);
        }

        /// <summary>  
        /// GetEmcSnapshotPoolNegativeTestMethod:
        ///    The method to implement Get-EmcSnapshotPool negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSnapshotPoolNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcSnapshotPool snapshotPool = ParseCmd(cmd);

            try
            {
                snapshotPool.VerifyTheCMD(psMachine, globalID, defaultPoolID);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotPool.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result: ");

        }
    }
}

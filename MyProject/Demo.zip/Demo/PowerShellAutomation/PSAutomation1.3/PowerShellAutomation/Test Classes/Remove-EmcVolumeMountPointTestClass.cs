﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class RemoveEmcVolumeMountPointTest
    {
        public RemoveEmcVolumeMountPointTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string[] systemPrefix;
        private static string[] lunPrefix;
        private static string[] volumePrefix;

        private static string remotePath;
        private static string hostName;
        private static string clusterName;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            string[] systems = { "Host", "Cluster" };
            string name = null;

            for (int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                if (HelperAdapter.GetBlobContent(system) != null)
                {
                    string diskPrefix = HelperAdapter.GetParameter("Disk") + i;
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                        name = hostName;
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                        name = clusterName;
                    }

                    Random rn = new Random();
                    int iResult = rn.Next(0, 1);

                    if (iResult == 0)
                    {
                        string letter = TestSetup.GetRandomDriveLetter(psMachine, host, cluster);
                        SetEmcVolumeMountPoint setMountPoint = new SetEmcVolumeMountPoint(volumePrefix[i], host, letter, null, cluster);
                        setMountPoint.RunCMD(psMachine);
                    }
                    else
                    {
                        string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                        Dictionary<string, string> dic = HelperAdapter.Load(path, "Volume");
                        string random = HelperAdapter.GenerateRandomString();
                        string mountPath = dic["MountPathPrefix"] + random;
                        remotePath = string.Format(@"\\{0}\{1}", name, mountPath.Replace(":", "$") );
                        SetEmcVolumeMountPoint setMountPoint = new SetEmcVolumeMountPoint(volumePrefix[i], host, null, mountPath, cluster);
                        setMountPoint.RunCMD(psMachine);
                    }      
                }
            }

            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");

            string[] systems = { "Host", "Cluster" };

            for (int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                if (HelperAdapter.GetBlobContent(system) != null)
                {
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }

                    TestSetup.ClearVolumeEnvironment(psMachine, volumePrefix[i], host, cluster);
                }
            }
            if (remotePath != null && HelperAdapter.TestPath(psMachine, remotePath))
            {
                HelperAdapter.RemoveItem(psMachine, remotePath);
            }

            log.LogInfo("--------Test Cleanup End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);

            string[] systems = { "Host", "Cluster"};
            lunPrefix = new string[systems.Length];
            volumePrefix = new string[systems.Length];
            systemPrefix = new string[systems.Length];
            lunPrefix[0] = HelperAdapter.GetParameter("Lun");
            lunPrefix[1] = HelperAdapter.GetParameter("LunC");

            for(int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                if (HelperAdapter.GetBlobContent(system) != null)
                {
                    systemPrefix[i] = HelperAdapter.GetParameter(system);
                    volumePrefix[i] = HelperAdapter.GetParameter("Volume") + i;
                    string diskPrefix = HelperAdapter.GetParameter("Disk") + i;
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                        string result = TestSetup.ConnectSystem(psMachine, system, systemPrefix[i]);
                        SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);
                        hostName = keyValue["Name"];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                        string result = TestSetup.ConnectSystem(psMachine, system, systemPrefix[i]);
                        SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);
                        clusterName = keyValue["Name"];
                    }                        
                    
                    TestSetup.SetLunEnvironment(psMachine, true, HelperAdapter.GetParameter("Pool"), lunPrefix[i]);
                    TestSetup.SetDiskEnvironment(psMachine, diskPrefix, host, lunPrefix[i], cluster);
                    try
                    {
                        TestSetup.SetVolumeEnvironment(psMachine, diskPrefix, host, cluster, volumePrefix[i]);
                    }
                    catch
                    {
                        log.LogWarning("New-EmcVolume failed");
                    }
                }
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            string[] systems = { "Host", "Cluster" };

            for (int i = 0; i < systems.Length; i++)
            {
                if (HelperAdapter.GetBlobContent(systems[i]) != null)
                {
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    TestSetup.ClearDiskEnvironment(psMachine, host, cluster, lunPrefix[i]);
                    TestSetup.ClearLunEnvironment(psMachine, lunPrefix[i]);
                }
            }

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a SetEmcLunAccess instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>SetEmcLunAccess instance</returns>  
        public RemoveEmcVolumeMountPoint ParseCmd(string cmd)
        {
            string host = null;
            string cluster = null;
            string volume = null;
            string silent = null;
            string cmdString = cmd;

            string[] systems = { "Host", "Cluster"};

            for (int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                
                if (cmdString.IndexOf(system + "System", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    if (HelperAdapter.GetBlobContent(system) == null)
                    {
                        return null;
                    }
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    cmdString = cmdString.Replace("$" + system + "System", systemPrefix[i]);

                    if (cmdString.IndexOf("$Volume", StringComparison.OrdinalIgnoreCase) > 0)
                    {
                        volume = volumePrefix[i];
                        cmdString = cmdString.Replace("$Volume", volume);
                    }
                    
                    break;
                }               
            }
            
            RemoveEmcVolumeMountPoint mountPoint = new RemoveEmcVolumeMountPoint(volume, host, cluster, silent, cmdString);

            return mountPoint;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcVolumeMountPointTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcVolumeMountPoint mountPoint = ParseCmd(cmd);

            if (mountPoint == null)
            {
                return;
            }

            mountPoint.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcVolumeMountPointNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcVolumeMountPoint mountPoint = ParseCmd(cmd);

            if (mountPoint == null)
            {
                return;
            }
            
            try
            {
                mountPoint.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", mountPoint.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");

        }
    }

}

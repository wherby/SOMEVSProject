﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcVirtualMachineConfigurationTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcVirtualMachineConfigurationTest
    {
        public GetEmcVirtualMachineConfigurationTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string hypervName;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to Hyper-V          
            log.LogInfo("Class Initialize: Connect to Hypervisor");
            string result = TestSetup.ConnectSystem(psMachine, "Hypervisor", HelperAdapter.GetParameter("Hypervisor"));
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Contains("Hyper-V"))
            {
                log.LogError(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                PSException pe = new PSException(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                throw pe;
            }
            hypervName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];

            // Connect to VM         
            log.LogInfo("Class Initialize: Connect to Virtual Machine");
            result = TestSetup.ConnectSystem(psMachine, "VM", HelperAdapter.GetParameter("VirtualMachine"));
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Equals("Virtual Machine"))
            {
                log.LogError(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                PSException pe = new PSException(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                throw pe;
            }
            log.LogInfo("--------Class Initialize End--------");            
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcVirtualMachineConfiguration instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcVirtualMachineConfiguration instance</returns>  
        public GetEmcVirtualMachineConfiguration ParseCmd(string cmd)
        {
            string vm = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("VirtualMachine", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vm = HelperAdapter.GetParameter("VirtualMachine");
                cmdString = cmdString.Replace("$VirtualMachine", vm);                
            }         

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcVirtualMachineConfiguration vmConfiguration = new GetEmcVirtualMachineConfiguration(vm, silent, cmdString);

            return vmConfiguration;
        }

        /// <summary>
        /// getVmConfigurations
        ///     Get all VM configurations of the specified Hyper-V      
        /// </summary>
        /// <param name="prefix">The prefix of Hyper-V host</param>
        /// <returns>result string</returns>
        public string getVmConfigurations(string prefix = null)
        {
            List<string> ps = new List<string>();

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Hypervisor");
            }

            // Update Hyper-V system
            log.LogInfo("Update Hyper-V system");
            UpdateEmcSystem system = new UpdateEmcSystem(prefix);
            system.RunCMD(psMachine);

            // Get all VM configurations in the Hyper-V
            log.LogInfo("Get all VM configurations in the Hyper-V");
            ps.Add(prefix + ".VirtualMachinesConfigurations");
            string result = psMachine.RunScript(ps, new List<PSParam>(){}).OutStr;
            return result; 
        }

        /// <summary>  
        /// GetEmcVirtualMachineConfigurationTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualMachineConfigurationTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            string vmConfigurations = getVmConfigurations();

            GetEmcVirtualMachineConfiguration vmConfiguration = ParseCmd(cmd);
            
            vmConfiguration.VerifyTheCMD(psMachine, vmConfigurations, hypervName);
        }

        /// <summary>  
        /// GetEmcVirtualMachineConfigurationNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualMachineConfigurationNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            string vmConfigurations = getVmConfigurations();
            GetEmcVirtualMachineConfiguration vmConfiguration = ParseCmd(cmd);

            try
            {
                vmConfiguration.VerifyTheCMD(psMachine, vmConfigurations, hypervName);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", vmConfiguration.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

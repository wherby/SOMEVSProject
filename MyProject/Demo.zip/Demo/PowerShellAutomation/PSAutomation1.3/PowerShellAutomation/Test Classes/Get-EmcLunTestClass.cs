﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcLUNTest
    {
        public GetEmcLUNTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        /// <summary>
        /// Lun name for host Lun.
        /// </summary>
        private static string lunName;

        /// <summary>
        /// Lun name for cluster Lun.
        /// </summary>
        private static string lunNameC;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");
            log.LogInfo("--------Test Cleanup End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);

            TestSetup.SetPoolEnvironment(psMachine);
            string result=TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            lunName = lunKeyValue["Name"];
            TestSetup.SetHostEnvironment(psMachine);
            TestSetup.SetDiskEnvironment(psMachine);
            TestSetup.SetVolumeEnvironment(psMachine);
            //Set cluster Lun.
            string lunForCluster=HelperAdapter.GetParameter("LunC");
            string clusterPrefix = HelperAdapter.GetParameter("Cluster");
            string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");
            string diskPrefixForCluster = HelperAdapter.GetParameter("ClusterDisk");
            string volumePrefixForCluster = HelperAdapter.GetParameter("VolumeForCluster");
            string resultForLunC = TestSetup.SetLunEnvironment(psMachine, true, null, lunForCluster);
            SortedList<string, string> LunForClusterKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForLunC);
            lunNameC = LunForClusterKeyValue["Name"];
            TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
            TestSetup.SetDiskEnvironment(psMachine, diskFindForCluster, null, lunForCluster, clusterPrefix);
            TestSetup.SetVolumeEnvironment(psMachine, diskFindForCluster, null, clusterPrefix, volumePrefixForCluster);
            TestSetup.SetClusterDiskEnvironment(psMachine, diskFindForCluster, clusterPrefix, diskPrefixForCluster);
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            string volumePrefixForCluster=HelperAdapter.GetParameter("VolumeForCluster");
            string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");
            string diskPrefixForCluster=HelperAdapter.GetParameter("ClusterDisk");
            string clusterPrefix = HelperAdapter.GetParameter("Cluster");
            string lunForCluster=HelperAdapter.GetParameter("LunC");
            TestSetup.ClearClusterDiskEnvironment(psMachine, diskFindForCluster, clusterPrefix);
            TestSetup.ClearVolumeEnvironment(psMachine, volumePrefixForCluster, null, clusterPrefix);
            TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
            TestSetup.ClearLunEnvironment(psMachine, lunForCluster);

            TestSetup.ClearVolumeEnvironment(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcLun instance</returns>  
        public GetEmcLun ParseCmd(string cmd)
        {


            string cmdString = cmd;

            string idString = lunName;
            string idStringC = lunNameC;
            string poolString = HelperAdapter.GetParameter("Pool");
            string hostDiskString = HelperAdapter.GetParameter("Disk");
            string volumeString = HelperAdapter.GetParameter("Volume");
            string blockStorageSystemString = HelperAdapter.GetParameter("System");
            string clusterDiskString = HelperAdapter.GetParameter("ClusterDisk");
            

            string id = null;
            string pool = null;
            string hostDisk = null;
            string volume = null;
            string clusterDisk = null;
            string blockStorageSystem = null;
            string silent=null;

            if(cmdString.IndexOf("$ID",StringComparison.OrdinalIgnoreCase)>0)
            {
                if (cmdString.IndexOf("$ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    idString = idStringC;
                }
                id = idString;
                cmdString = cmdString.Replace("$ID", idString);
            }
            if(cmdString.IndexOf("$Pool",StringComparison.OrdinalIgnoreCase)>0)
            {
                pool = poolString;
                cmdString = cmdString.Replace("$Pool", poolString);
            }
            if(cmdString.IndexOf("$HostDisk",StringComparison.OrdinalIgnoreCase)>0)
            {
                hostDisk = hostDiskString;
                cmdString = cmdString.Replace("$HostDisk", hostDiskString);
            }
            if (cmdString.IndexOf("Volume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                volume = volumeString;
                cmdString = cmdString.Replace("$Volume", volumeString);
            }
            if(cmdString.IndexOf("$BlockStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                blockStorageSystem = blockStorageSystemString;
                cmdString = cmdString.Replace("$BlockStorageSystem", blockStorageSystemString);
            }
            if (cmdString.IndexOf("$ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterDisk = clusterDiskString;
                cmdString = cmdString.Replace("$ClusterDisk", clusterDiskString);
            }    
            if(cmdString.IndexOf("Silent",StringComparison.OrdinalIgnoreCase)>0)
            {
                silent = "Silent";
            }

            GetEmcLun getLun = new GetEmcLun(id,pool ,hostDisk,volume ,clusterDisk ,blockStorageSystem ,silent , cmdString);

            return getLun;
        }

        //private bool BypassTest(string cmd)
        //{
        //    bool bypass = false;
        //    if (cmd.IndexOf("Cluster", StringComparison.OrdinalIgnoreCase) > 0)
        //    {
        //        bypass = true;
        //    }
        //    return bypass;
        //}

        public void GetEmcLUNTestMethod(string cmd)
        {

            GetEmcLun rmLun = ParseCmd(cmd);
            rmLun.VerifyTheCMD(psMachine);
        }

        public void GetEmcLUNNegativeTestMethod(string cmd)
        {
            //if (BypassTest(cmd))
            //{
            //    log.LogWarning("The test is bypassed");
            //    return;
            //}
            GetEmcLun rmLun = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                rmLun.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}

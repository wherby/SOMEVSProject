﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcSnapshotLunTest: test class for Get-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcSnapshotSessionTest
    {
        public GetEmcSnapshotSessionTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;       
        private static SortedList<string, string> lunKeyValue = new SortedList<string,string>();
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            TestSetup.ConnectSystem(psMachine, "VNX-Block", "$storage");

            // Create Source LUN
            log.LogInfo("Class Initialize: Create Source LUN");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);

            // Create Snapshot Session
            log.LogInfo("Class Initialize: Create Snapshot Session");
            NewEmcSnapshotSession snapshotSession = new NewEmcSnapshotSession("$lun");
            result = snapshotSession.RunCMD(psMachine, true);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);                    
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            // Remove Snapshot Session
            log.LogInfo("Class Cleanup: Remove Snapshot Session");
            GetEmcSnapshotSession snapshotSession = new GetEmcSnapshotSession(lunKeyValue["SessionId"]);
            snapshotSession.PrefixString = "$snapshotsession";
            snapshotSession.RunCMD(psMachine, true);

            RemoveEmcSnapshotSession removeSnapshotSession = new RemoveEmcSnapshotSession("$snapshotsession", "RemoveSnapshotLUN");
            removeSnapshotSession.VerifyTheCMD(psMachine, lunKeyValue["SessionId"], lunKeyValue["TargetSnapshotLunId"]);

            // Remove Source LUN 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);  
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcSnapshotLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcSnapshotLun instance</returns>  
        public GetEmcSnapshotSession ParseCmd(string cmd)
        {
            string sessionId = null;
            string sourceId = null;
            string targetId = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("sessionid", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sessionId = lunKeyValue["SessionId"];
                cmdString = cmdString.Replace("$SessionID", sessionId);                
            }
            if (cmd.IndexOf("sourceid", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourceId = lunKeyValue["SourceLunId"];
                cmdString = cmdString.Replace("$SourceID", sourceId);                
            }
            if (cmd.IndexOf("targetid", StringComparison.OrdinalIgnoreCase) > 0)
            {
                targetId = lunKeyValue["TargetSnapshotLunId"];
                cmdString = cmdString.Replace("$TargetID", targetId);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcSnapshotSession snapshotSession = new GetEmcSnapshotSession(sessionId, sourceId, targetId, silent, cmdString);

            return snapshotSession;
        }

        /// <summary>  
        /// GetEmcSnapshotSessionTestMethod:
        ///    The method to implement Get-EmcSnapshotSession poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSnapshotSessionTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcSnapshotSession snapshotSession = ParseCmd(cmd);
            
            snapshotSession.VerifyTheCMD(psMachine, lunKeyValue);
        }

        /// <summary>  
        /// GetEmcSnapshotSessionNegativeTestMethod:
        ///    The method to implement Get-EmcSnapshotSession negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSnapshotSessionNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcSnapshotSession snapshotSession = ParseCmd(cmd);

            try
            {
                snapshotSession.VerifyTheCMD(psMachine, lunKeyValue);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotSession.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

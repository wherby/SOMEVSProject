﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcClusterDiskTest
    {
        public GetEmcClusterDiskTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string[] resourceName;

        private static string[] groupName;

        private static SortedList<string, string>[] diskKeyValue;

        private static int index;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


       [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string cluster = HelperAdapter.GetParameter("Cluster");
            string lun2 = HelperAdapter.GetParameter("Lun") + "2";
            string hostDisk2 = HelperAdapter.GetParameter("Disk") + "2";
            string clusterDisk2 = HelperAdapter.GetParameter("ClusterDisk") + "2";
            string volume2 = HelperAdapter.GetParameter("Volume") + "2";

            diskKeyValue = new SortedList<string, string>[2];
            resourceName = new string[2];
            groupName = new string[2];

            TestSetup.ConnectSystem(psMachine, "Cluster", cluster);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);            
            TestSetup.SetLunEnvironment(psMachine);
            TestSetup.SetDiskEnvironment(psMachine, null, null, null, cluster);
            try
            {
                TestSetup.SetVolumeEnvironment(psMachine, null, null, cluster);
            }
            catch
            {
                log.LogWarning("New-EmcVolume failed");
            }

            string result = TestSetup.SetClusterDiskEnvironment(psMachine);
            diskKeyValue[0] = HelperAdapter.GenerateKeyValuePairs(result);
            resourceName[0] = diskKeyValue[0]["ClusterDiskResourceName"];
            groupName[0] = diskKeyValue[0]["ClusterGroupName"];

            TestSetup.SetLunEnvironment(psMachine, true, null, lun2);
            TestSetup.SetDiskEnvironment(psMachine, hostDisk2, null, lun2, cluster);
            try
            {
                TestSetup.SetVolumeEnvironment(psMachine, hostDisk2, null, cluster, volume2);
            }
            catch
            {
                log.LogWarning("New-EmcVolume failed");
            }

            string result2 = TestSetup.SetClusterDiskEnvironment(psMachine, hostDisk2, cluster, clusterDisk2, true);
            diskKeyValue[1] = HelperAdapter.GenerateKeyValuePairs(result2);
            resourceName[1] = diskKeyValue[1]["ClusterDiskResourceName"];
            groupName[1] = diskKeyValue[1]["ClusterGroupName"];

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            string cluster = HelperAdapter.GetParameter("Cluster");
            string lun2 = HelperAdapter.GetParameter("Lun") + "2";
            string hostDisk2 = HelperAdapter.GetParameter("Disk") + "2";
            string clusterDisk2 = HelperAdapter.GetParameter("ClusterDisk") + "2";

            TestSetup.ClearClusterDiskEnvironment(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine, null, cluster);
            TestSetup.ClearLunEnvironment(psMachine);

            TestSetup.ClearClusterDiskEnvironment(psMachine, hostDisk2);
            TestSetup.ClearDiskEnvironment(psMachine, null, cluster, lun2);
            TestSetup.ClearLunEnvironment(psMachine, lun2);

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcClusterDisk instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcClusterDisk instance</returns>  
        public GetEmcClusterDisk ParseCmd(string cmd)
        {
            string cmdString = cmd;
            string clusterSystem = null;
            string id = null;
            string clusterGroupName = null;
            string clusterSharedVolume = null;
            string silent = null;

            index = 0;

            if (cmdString.IndexOf("ClusterSharedVolume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterSharedVolume = "ClusterSharedVolume";
                index = 1;
            }

            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterSystem = HelperAdapter.GetParameter("Cluster");
                cmdString = cmdString.Replace("$ClusterSystem", clusterSystem);
            }
            if (cmdString.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = resourceName[index];
                cmdString = cmdString.Replace("$ID", "\"" + id + "\"");
            }
            if (cmdString.IndexOf("$ClusterGroupName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterGroupName = groupName[index];
                cmdString = cmdString.Replace("$ClusterGroupName", "\"" + clusterGroupName + "\"");
            }
            
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            GetEmcClusterDisk getDisk = new GetEmcClusterDisk(id, clusterSystem, clusterGroupName, clusterSharedVolume, silent, cmdString);

            return getDisk;
        }

       public void GetEmcClusterDiskTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcClusterDisk getDisk = ParseCmd(cmd);

            getDisk.VerifyTheCMD(psMachine, diskKeyValue[index]);
        }


        public void GetEmcClusterDiskNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool failCMD = false;

            GetEmcClusterDisk getDisk = ParseCmd(cmd);
            
            try
            {
                getDisk.VerifyTheCMD(psMachine, diskKeyValue[index]);
            }
            catch (PSException pe)
            {
                failCMD = true;

                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}


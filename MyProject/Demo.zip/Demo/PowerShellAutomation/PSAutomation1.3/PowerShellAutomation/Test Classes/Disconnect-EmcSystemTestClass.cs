﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class DisconnectEmcSystemTest
    {
        public DisconnectEmcSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
            
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private string blobConfig;
        private string friendlyName;
        private string globalId;
        private string systemType;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class
        // [ClassInitialize()]
        // public static void MyClassInitialize(TestContext testContext) { }
        //
        // Use ClassCleanup to run code after all tests in a class have run
        // [ClassCleanup()]
        // public static void MyClassCleanup() { }
        //
        // Use TestInitialize to run code before running each test 
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            blobConfig = null;
            friendlyName = null;
            globalId = null;
            systemType = null;

            log.LogInfo("--------Test Initialize End--------");
        }

        
        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Cleanup End--------");
        }      
        

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a DisconnectEmcSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public DisconnectEmcSystem ParseCmd(string cmd)
        {            
            string id = null;
            string force = null;
            string silent = null;
            string whatIf = null;
            string system = null;
            string cmdString = cmd;

            if (cmd.IndexOf(systemType + "_FriendlyName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = friendlyName;
                cmdString = cmdString.Replace("$" + systemType + "_FriendlyName", friendlyName);
            }
            else if (cmd.IndexOf(systemType + "_GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = globalId;
                cmdString = cmdString.Replace("$" + systemType + "_GlobalId", globalId);
            }
            
            if (cmd.IndexOf(systemType + "_System", StringComparison.OrdinalIgnoreCase) > 0)
            {
                system = HelperAdapter.GetParameter("System");
                cmdString = cmdString.Replace("$" + systemType + "_System", system);
            }

            if (cmd.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }

            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatIf = "WhatIf";
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            DisconnectEmcSystem disconnectSystem = new DisconnectEmcSystem(id, system, force, silent, whatIf, cmdString);
            disconnectSystem.SystemType = systemType;

            return disconnectSystem;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisconnectEmcSystemTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (PrepareEnvironment(cmd) == false)
            {
                return;
            }

            DisconnectEmcSystem system = ParseCmd(cmd);

            system.VerifyTheCMD(psMachine, globalId);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisconnectEmcSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            if (PrepareEnvironment(cmd) == false)
            {
                return;
            }

            DisconnectEmcSystem system = ParseCmd(cmd);

            try
            {
                system.VerifyTheCMD(psMachine, globalId);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");

        }

        /// <summary>
        /// PrepareEnvironment
        ///     Connect one or more systems
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns>connection success or fail</returns>
        public bool PrepareEnvironment(string cmd)
        {
            string[] types = { "CLARiiON-CX4", "VMAX", "VMAXe", "VNX", "VNX-Block", "VNX-CIFS", "Host", "Cluster"};
            
            foreach (string type in types)
            {
                if (cmd.Contains(type + "_"))
                {
                    systemType = type;
                    break;
                }
            }
            
            foreach (string type in types)
            {
                if (systemType == type || systemType == null)
                {
                    blobConfig = HelperAdapter.GetBlobContent(type);

                    if (blobConfig == null)
                    {
                        if (systemType != null)
                        {
                            log.LogInfo(string.Format("System {0} does not prepared!", systemType));
                            return false;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    
                    ConnectEmcSystem system = new ConnectEmcSystem(blobConfig);
                    system.SystemType = type;
                    system.PrefixString = HelperAdapter.GetParameter("System");
                    string result = system.RunCMD(psMachine, true);

                    SortedList<string, string> systemKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

                    if (systemType != null)
                    {
                        globalId = systemKeyValue["GlobalId"];
                        friendlyName = systemKeyValue["UserFriendlyName"];
                    }

                    log.LogInfo(string.Format("Test Initialize: Connect to {0} Storage System {1}", systemType, systemKeyValue["GlobalId"]));
                }
            }

            return true;
        }

    }
            
}

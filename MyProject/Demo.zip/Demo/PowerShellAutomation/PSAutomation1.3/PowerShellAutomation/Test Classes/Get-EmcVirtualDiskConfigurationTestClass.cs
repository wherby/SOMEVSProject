﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcVirtualDiskConfigurationTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcVirtualDiskConfigurationTest
    {
        public GetEmcVirtualDiskConfigurationTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string hypervName;
        private static string path;
        private static string fileDiskLocation;
        private static SortedList<string, string> fileDiskScsiController;
        private static string ptDiskLocation;
        private static SortedList<string, string> ptDiskScsiController;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);

            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            string vm = HelperAdapter.GetParameter("VirtualMachine") ;
            string lun = HelperAdapter.GetParameter("Lun");
            string fileDisk = HelperAdapter.GetParameter("FilebasedDisk");
            string ptDisk = HelperAdapter.GetParameter("PassthroughDisk");
            string fileDiskConfig = HelperAdapter.GetParameter("FilebasedDiskConfiguration");
            string ptDiskConfig = HelperAdapter.GetParameter("PassthroughDiskConfiguration");

            // Connect to Hyper-V          
            log.LogInfo("Class Initialize: Connect Hyper-V System");
            string result = TestSetup.ConnectSystem(psMachine, "Hypervisor", hyperv);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Contains("Hyper-V"))
            {
                log.LogError(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                PSException pe = new PSException(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                throw pe;
            }
            hypervName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];

            // Connect to VM         
            log.LogInfo("Class Initialize: Connect Storage System");
            result = TestSetup.ConnectSystem(psMachine, "VM", vm);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Equals("Virtual Machine"))
            {
                log.LogError(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                PSException pe = new PSException(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                throw pe;
            }

            UpdateEmcSystem updateHyperv = new UpdateEmcSystem(hyperv);
            updateHyperv.RunCMD(psMachine);

            UpdateEmcSystem updateVM = new UpdateEmcSystem(vm);
            updateVM.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(vm);
            vmConfig.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            vmConfig.RunCMD(psMachine, true);

            GetEmcHostDisk getDisk = new GetEmcHostDisk(null, null, null, vm);
            string diskResult1 = getDisk.RunCMD(psMachine);
            List<SortedList<string, string>> diskKeyValue1 = HelperAdapter.GenerateKeyValuePairsList(diskResult1);

            string configPath = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(configPath, "FileBasedDisk");

            path = dic["Path"] + HelperAdapter.GenerateRandomString() + ".vhd";
            NewEmcFileBasedDisk fileBasedDisk = new NewEmcFileBasedDisk(hyperv, path, dic["SizeInGB"], dic["DiskType"]);
            fileBasedDisk.RunCMD(psMachine);

            fileDiskScsiController = TestSetup.GetRandomScsiController(psMachine);
            fileDiskLocation = TestSetup.GetRandomScsiControllerLocation(psMachine, fileDiskScsiController["ScsiControllerIndex"], fileDiskScsiController["ScsiControllerId"], hyperv);
      
            AddEmcFilebasedDiskToVirtualMachine addFileDisk = new AddEmcFilebasedDiskToVirtualMachine(path, vmConfig.PrefixString, hyperv, fileDiskLocation, fileDiskScsiController["ScsiControllerId"], fileDiskScsiController["ScsiControllerIndex"]);
            addFileDisk.PrefixString = fileDiskConfig;
            addFileDisk.RunCMD(psMachine, true);

            updateVM.RunCMD(psMachine);
            string diskResult2 = getDisk.RunCMD(psMachine, true);
            List<SortedList<string, string>> diskKeyValue2 = HelperAdapter.GenerateKeyValuePairsList(diskResult2);
            SortedList<string, string> fileDiskKeyValue = getNewAddedDisk(diskKeyValue1, diskKeyValue2, fileDisk);

            //Connect to Storage System
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            TestSetup.SetDiskEnvironment(psMachine, null, hyperv, null, null, false);

            ptDiskScsiController = TestSetup.GetRandomScsiController(psMachine);
            ptDiskLocation = TestSetup.GetRandomScsiControllerLocation(psMachine, ptDiskScsiController["ScsiControllerIndex"], ptDiskScsiController["ScsiControllerId"], hyperv);

            AddEmcPassthroughDiskToVirtualMachine addPtDisk = new AddEmcPassthroughDiskToVirtualMachine(null, null, HelperAdapter.GetParameter("Disk"), vmConfig.PrefixString, hyperv, ptDiskLocation, ptDiskScsiController["ScsiControllerId"], ptDiskScsiController["ScsiControllerIndex"]);
            addPtDisk.PrefixString = ptDiskConfig;
            addPtDisk.RunCMD(psMachine, true);

            updateVM.RunCMD(psMachine);
            string diskResult3 = getDisk.RunCMD(psMachine, true);
            List<SortedList<string, string>> diskKeyValue3 = HelperAdapter.GenerateKeyValuePairsList(diskResult3);
            SortedList<string, string> ptDiskKeyValue = getNewAddedDisk(diskKeyValue2, diskKeyValue3, ptDisk);

            log.LogInfo("--------Class Initialize End--------");

        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            string vm = HelperAdapter.GetParameter("VirtualMachine");
            string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            RemoveEmcVirtualDiskFromVm rmFileDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, hyperv, fileDiskLocation, fileDiskScsiController["ScsiControllerId"], fileDiskScsiController["ScsiControllerIndex"], null, null, "Force");
            rmFileDisk.RunCMD(psMachine);

            string fileName = path.Split(new string[] { @":\" }, StringSplitOptions.RemoveEmptyEntries)[1];
            List<string> ps = new List<string>();
            ps.Add(string.Format(@"Remove-Item -Path \\{0}\c$\{1}", hypervName, fileName));
            psMachine.RunScript(ps, new List<PSParam>());

            RemoveEmcVirtualDiskFromVm rmPtDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, hyperv, ptDiskLocation, ptDiskScsiController["ScsiControllerId"], ptDiskScsiController["ScsiControllerIndex"], null, null, "Force");
            rmPtDisk.RunCMD(psMachine);

            Thread.Sleep(5000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(vm);
            updateSystem.RunCMD(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine, hyperv);
            TestSetup.ClearLunEnvironment(psMachine);
           
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcVirtualDiskConfiguration instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcVirtualDiskConfiguration instance</returns>  
        public GetEmcVirtualDiskConfiguration ParseCmd(string cmd)
        {
            string diskConfig = null;
            string silent = null;
            string cmdString = cmd;
            string hostDisk = null;
            string fileDisk = HelperAdapter.GetParameter("FilebasedDisk");
            string ptDisk = HelperAdapter.GetParameter("PassthroughDisk");
            string fileDiskConfig = HelperAdapter.GetParameter("FilebasedDiskConfiguration");
            string ptDiskConfig = HelperAdapter.GetParameter("PassthroughDiskConfiguration");

            if (cmd.IndexOf("$FilebasedDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostDisk = fileDisk;
                diskConfig = fileDiskConfig;
                cmdString = cmdString.Replace("$FilebasedDisk", hostDisk);
            }

            if (cmd.IndexOf("$PassthroughDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostDisk = ptDisk;
                diskConfig = ptDiskConfig;
                cmdString = cmdString.Replace("$PassthroughDisk", hostDisk);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcVirtualDiskConfiguration vmConfiguration = new GetEmcVirtualDiskConfiguration(hostDisk, silent, cmdString);
            vmConfiguration.DiskConfig = diskConfig;

            return vmConfiguration;
        }

        /// <summary>
        /// getNewAdded
        ///     Get new added sortedlist     
        /// </summary>
        /// <param name="oldList">The old List</param>
        /// <param name="newList">The new List</param>
        /// <param name="diskPrefix">prefix string of new added disk</param>
        /// <returns>result SortedList</returns>
        private static SortedList<string, string> getNewAddedDisk(List<SortedList<string, string>> oldList, List<SortedList<string, string>> newList, string diskPrefix)
        {
            SortedList<string, string> newAdded = null;
            List<string> ps = new List<string>();
            bool itemFind = false;

            foreach (SortedList<string, string> newItem in newList)
            {
                foreach (SortedList<string, string> oldItem in oldList)
                {
                    if (HelperAdapter.SortedListIsEqual(oldItem, newItem))
                    {
                        itemFind = false;
                        break;
                    }
                    else
                    {
                        itemFind = true;
                    }
                }

                if (itemFind == true)
                {
                    newAdded = newItem;
                    break;
                }
            }

            if (newAdded != null)
            {
                GetEmcHostDisk getDisk = new GetEmcHostDisk(newAdded["HostDiskIdentifier"], null, null, HelperAdapter.GetParameter("VirtualMachine"));
                getDisk.PrefixString = diskPrefix;
                getDisk.RunCMD(psMachine, true);
            }
            
            return newAdded; 
        }

        /// <summary>  
        /// GetEmcVirtualDiskConfigurationTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualDiskConfigurationTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcVirtualDiskConfiguration vmConfiguration = ParseCmd(cmd);
            
            vmConfiguration.VerifyTheCMD(psMachine, hypervName);
        }

        /// <summary>  
        /// GetEmcVirtualDiskConfigurationNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualDiskConfigurationNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcVirtualDiskConfiguration vmConfiguration = ParseCmd(cmd);

            try
            {
                vmConfiguration.VerifyTheCMD(psMachine, hypervName);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", vmConfiguration.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

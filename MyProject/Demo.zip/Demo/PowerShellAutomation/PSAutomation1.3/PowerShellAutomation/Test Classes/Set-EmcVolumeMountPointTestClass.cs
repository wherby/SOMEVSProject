﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class SetEmcVolumeMountPointTest
    {
        public SetEmcVolumeMountPointTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string[] systemPrefix;
        private static string[] lunPrefix;
        private static string[] volumePrefix;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);

            string[] systems = { "Host", "Cluster"};
            lunPrefix = new string[systems.Length];
            volumePrefix = new string[systems.Length];
            systemPrefix = new string[systems.Length];

            for(int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                if (HelperAdapter.GetBlobContent(system) != null)
                {
                    systemPrefix[i] = HelperAdapter.GetParameter(system);
                    lunPrefix[i] = HelperAdapter.GetParameter("Lun") + i;                    
                    volumePrefix[i] = HelperAdapter.GetParameter("Volume") + i;
                    string diskPrefix = HelperAdapter.GetParameter("Disk") + i;
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];                        
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }                        
                    TestSetup.ConnectSystem(psMachine, system, systemPrefix[i]);
                    TestSetup.SetLunEnvironment(psMachine, true, HelperAdapter.GetParameter("Pool"), lunPrefix[i]);
                    TestSetup.SetDiskEnvironment(psMachine, diskPrefix, host, lunPrefix[i], cluster);
                    TestSetup.SetVolumeEnvironment(psMachine, diskPrefix, host, cluster, volumePrefix[i]);
                }
            }
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            string[] systems = { "Host", "Cluster" };

            for (int i = 0; i < systems.Length; i++)
            {
                if (HelperAdapter.GetBlobContent(systems[i]) != null)
                {
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    TestSetup.ClearDiskEnvironment(psMachine, host, cluster, lunPrefix[i]);
                    TestSetup.ClearLunEnvironment(psMachine, lunPrefix[i]);
                }
            }

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a SetEmcLunAccess instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>SetEmcLunAccess instance</returns>  
        public SetEmcVolumeMountPoint ParseCmd(string cmd)
        {
            string host = null;
            string cluster = null;
            string driveLetter = null;
            string mountPath = null;
            string volume = null;
            string silent = null;
            string cmdString = cmd;

            string[] systems = { "Host", "Cluster"};

            for (int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                
                if (cmdString.IndexOf(system + "System", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    if (HelperAdapter.GetBlobContent(system) == null)
                    {
                        return null;
                    }
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    cmdString = cmdString.Replace("$" + system + "System", systemPrefix[i]);

                    if (cmdString.IndexOf("$Volume", StringComparison.OrdinalIgnoreCase) > 0)
                    {
                        volume = volumePrefix[i];
                        cmdString = cmdString.Replace("$Volume", volume);
                    }
                    
                    break;
                }               
            }
            
            if (cmdString.IndexOf("$DriveLetter", StringComparison.OrdinalIgnoreCase) > 0)
            {
                GetEmcAvailableDriverLetter letter = new GetEmcAvailableDriverLetter(host, cluster);
                string result = letter.RunCMD(psMachine);
                if (result.Trim() == string.Empty)
                {
                    return null;
                }
                string[] letters = result.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                driveLetter = letters[0].Trim();
                cmdString = cmdString.Replace("$DriveLetter", driveLetter);
            }
            if (cmdString.IndexOf("$MountPath", StringComparison.OrdinalIgnoreCase) > 0)
            {
                mountPath = @"C:\ps_path_" + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$MountPath", mountPath);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            SetEmcVolumeMountPoint mountPoint = new SetEmcVolumeMountPoint(volume, host, driveLetter, mountPath, cluster, silent, cmdString);

            return mountPoint;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcVolumeMountPointTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            SetEmcVolumeMountPoint mountPoint = ParseCmd(cmd);

            if (mountPoint == null)
            {
                return;
            }

            mountPoint.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcVolumeMountPointNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            SetEmcVolumeMountPoint mountPoint = ParseCmd(cmd);

            if (mountPoint == null)
            {
                return;
            }
            
            try
            {
                mountPoint.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", mountPoint.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");

        }
    }

}

﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class RemoveEmcLunTest
    {
        public RemoveEmcLunTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string nameForLun = null;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            string result=TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            nameForLun = lunKeyValue["Name"];
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");
            string name = nameForLun;
            GetEmcLun getLun = new GetEmcLun(name);
            string result = getLun.RunCMD(psMachine);
            if (result.Trim() != string.Empty)
            {
                TestSetup.ClearLunEnvironment(psMachine);
            }
            log.LogInfo("--------Test Cleanup End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            TestSetup.SetPoolEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a RemoveEmcLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>RemoveEmcLun instance</returns>  
        public RemoveEmcLun  ParseCmd(string cmd)
        {
            string cmdString = cmd;

            string lunString = HelperAdapter.GetParameter("Lun");

             
            string lun = null;
            string force = null;
            string silent = null;
            string whatIf = null;
            string confirm = null;


            if (cmdString.IndexOf("$lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = lunString;
                cmdString = cmdString.Replace("$lun", lunString);
            }
            if (cmdString.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmdString.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent ="Silent";
            }
            if (cmdString.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatIf = "WhatIf";
            }
            if (cmdString.IndexOf("Confirm", StringComparison.OrdinalIgnoreCase) > 0)
            {
                confirm = "Confirm";
            }
            RemoveEmcLun rmLun = new RemoveEmcLun(lun, force, silent, whatIf, confirm, cmdString);

            return rmLun;
        }

        public void RemoveEmcLunTestMethod(string cmd)
        {
            RemoveEmcLun rmLun = ParseCmd(cmd);
            rmLun.VerifyTheCMD(psMachine);
        }

        public void RemoveEmcLunNegativeTestMethod(string cmd)
        {
            RemoveEmcLun rmLun = ParseCmd(cmd);
            TestLog log = TestLog.GetInstance();
            bool failCMD = false;
            try
            {
                rmLun.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}

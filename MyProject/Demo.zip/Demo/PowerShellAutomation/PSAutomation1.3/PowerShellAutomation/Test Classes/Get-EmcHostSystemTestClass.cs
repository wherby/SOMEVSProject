﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcHostSystemTest
    {
        public GetEmcHostSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string[] iPAddressConfig;
        private static string[] userNameConfig;
        private static SortedList<string, string>[] connectSystemKeyValue;
        private static string storageGlobalId;
        private static string[] hosts;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        #region Additional test attributes
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);

            string path = HelperAdapter.GetProperty("SystemConfig");

            hosts = new string[] { "Host", "Hypervisor" };

            iPAddressConfig = new string[hosts.Length];
            userNameConfig = new string[hosts.Length];
            connectSystemKeyValue = new SortedList<string, string>[hosts.Length];

            for (int i = 0; i < hosts.Length; i++ )
            {
                Dictionary<string, string> dic = HelperAdapter.Load(path, hosts[i]);

                iPAddressConfig[i] = dic["IPAddress"];
                userNameConfig[i] = dic["UserName"];

                string prefix = HelperAdapter.GetParameter(hosts[i]);
                string result = TestSetup.ConnectSystem(psMachine, hosts[i], prefix);
                connectSystemKeyValue[i] = HelperAdapter.GenerateKeyValuePairs(result);
            }

            string host = HelperAdapter.GetParameter("Host");
            string hostDisk = HelperAdapter.GetParameter("Disk");
            string volume = HelperAdapter.GetParameter("Volume");

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            string storageResult = TestSetup.ConnectSystem(psMachine, storage);
            SortedList<string, string> storageKeyValue = HelperAdapter.GenerateKeyValuePairs(storageResult);
            storageGlobalId = storageKeyValue["GlobalId"];

            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                TestSetup.SetDiskEnvironment(psMachine, hostDisk, host);
            }
            catch
            {
                TestSetup.ClearLunEnvironment(psMachine);
                throw new PSException("Setup disk environment fail!");
            }
            try
            {
                TestSetup.SetVolumeEnvironment(psMachine, hostDisk, host, null, volume);
            }
            catch
            {
                TestSetup.ClearDiskEnvironment(psMachine, host);
                TestSetup.ClearLunEnvironment(psMachine);
                throw new PSException("Setup volume environment fail!");
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            TestSetup.ClearDiskEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcHostSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public GetEmcHostSystem ParseCmd(string cmd)
        {
            string id = null;
            string hostDisk = null;
            string volume = null;
            string hostSystemType = null;
            string silent = null;
            string cmdString = cmd;
            int getSystemCount = 2;
            int index = 0;

            if (cmd.IndexOf("$VmWare", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostSystemType = "VmWare";
                cmdString = cmdString.Replace("$VmWare", hostSystemType);
                getSystemCount = 1;
                return null;
            }
            else if (cmd.IndexOf("$HyperV", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostSystemType = "HyperV";
                cmdString = cmdString.Replace("$HyperV", hostSystemType);
                getSystemCount = 1;
                index = 1;
            }

            if (cmd.IndexOf("$HostName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = connectSystemKeyValue[index]["Name"];
                cmdString = cmdString.Replace("$HostName", id);
                getSystemCount = 1;
            }
            else if (cmd.IndexOf("$IPAddress", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = iPAddressConfig[index];
                cmdString = cmdString.Replace("$IPAddress", id);
                getSystemCount = 1;
            }
            else if(cmd.IndexOf("$GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = connectSystemKeyValue[index]["GlobalId"];
                cmdString = cmdString.Replace("$GlobalId", id);
                getSystemCount = 1;
            }

            if (cmd.IndexOf("HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostDisk = HelperAdapter.GetParameter("Disk");
                cmdString = cmdString.Replace("$HostDisk", hostDisk);
                getSystemCount = 1;
            }

            if (cmd.IndexOf("Volume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                volume = HelperAdapter.GetParameter("Volume");
                cmdString = cmdString.Replace("$Volume", volume);
                getSystemCount = 1;
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcHostSystem hostSystem = new GetEmcHostSystem(id, hostDisk, volume, hostSystemType, silent, cmdString);
            hostSystem.ConnectSystemKeyValue = connectSystemKeyValue;
            hostSystem.GetSystemCount = getSystemCount;

            return hostSystem;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostSystemTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcHostSystem system = ParseCmd(cmd);

            if (system == null)
            {
                return;
            }

            system.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcHostSystem system = ParseCmd(cmd);

            if (system == null)
            {
                return;
            }

            try
            {
                system.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");
        }

    }

}

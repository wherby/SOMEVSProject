﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcVirtualMachineHypervisorTest: test class for Get-EmcVirtualMachineHypervisor cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcVirtualMachineHypervisorTest
    {
        public GetEmcVirtualMachineHypervisorTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string hyperv;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to Hyper-V          
            log.LogInfo("Class Initialize: Connect to Hypervisor");
            string result = TestSetup.ConnectSystem(psMachine, "Hypervisor", HelperAdapter.GetParameter("Hypervisor"));
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Contains("Hyper-V"))
            {
                log.LogError(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                PSException pe = new PSException(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                throw pe;
            } 
            string hypervName = lunKeyValue["Name"];

            // Connect to VM         
            log.LogInfo("Class Initialize: Connect to Virtual Machine");
            result = TestSetup.ConnectSystem(psMachine, "VM", HelperAdapter.GetParameter("VirtualMachine"));
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Equals("Virtual Machine"))
            {
                log.LogError(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                PSException pe = new PSException(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                throw pe;
            }            

            // Get VM Configuration
            UpdateEmcSystem system = new UpdateEmcSystem(HelperAdapter.GetParameter("Hypervisor"));
            system.RunCMD(psMachine);
            GetEmcHostSystem hypervHost = new GetEmcHostSystem(hypervName);
            hyperv = hypervHost.RunCMD(psMachine, true); 

            log.LogInfo("Class Initialize: Get Virtual Machine Configuration");
            GetEmcVirtualMachineConfiguration vmConfiguration = new GetEmcVirtualMachineConfiguration(HelperAdapter.GetParameter("VirtualMachine"));
            vmConfiguration.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            vmConfiguration.RunCMD(psMachine, true);
            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Initialize End--------");
            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcVirtualMachineHypervisor instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcVirtualMachineHypervisor instance</returns>  
        public GetEmcVirtualMachineHypervisor ParseCmd(string cmd)
        {
            string vmconfig = null;
            string vm = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmconfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", vmconfig);
            }                
            if (cmd.IndexOf("VirtualMachine", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vm = HelperAdapter.GetParameter("VirtualMachine");
                cmdString = cmdString.Replace("$VirtualMachine", vm);                
            }         

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcVirtualMachineHypervisor hyperv = new GetEmcVirtualMachineHypervisor(vmconfig, vm, silent, cmdString);

            return hyperv;
        }

        /// <summary>  
        /// GetEmcVirtualMachineHypervisorTestMethod:
        ///    The method to implement Get-EmcVirtualMachineHypervisor poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualMachineHypervisorTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcVirtualMachineHypervisor hypervisor = ParseCmd(cmd);
            
            hypervisor.VerifyTheCMD(psMachine, hyperv);
        }

        /// <summary>  
        /// GetEmcVirtualMachineHypervisorNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineHypervisor negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualMachineHypervisorNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcVirtualMachineHypervisor hypervisor = ParseCmd(cmd);

            try
            {
                hypervisor.VerifyTheCMD(psMachine, hyperv);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", hypervisor.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

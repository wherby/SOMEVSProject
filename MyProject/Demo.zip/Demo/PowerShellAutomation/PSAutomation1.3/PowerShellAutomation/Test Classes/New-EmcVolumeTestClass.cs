﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class NewEmcVolumeTest
    {
        public NewEmcVolumeTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;


        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        public void Initialize()
        {
            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            string result = TestSetup.SetDiskEnvironment(psMachine);
            GetEmcHostLunIdentifier getIdentifier = new GetEmcHostLunIdentifier("$lun", "$h");
            getIdentifier.PrefixString = HelperAdapter.GetParameter("LunIdentifier");
            getIdentifier.RunCMD(psMachine);
            //Set cluster Lun.
            string lunForCluster = HelperAdapter.GetParameter("LunC");
            string clusterPrefix = HelperAdapter.GetParameter("Cluster");
            string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");

            TestSetup.SetLunEnvironment(psMachine, true, null, lunForCluster);

            TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
            TestSetup.SetDiskEnvironment(psMachine, diskFindForCluster, null, lunForCluster, clusterPrefix);
            GetEmcHostLunIdentifier getIdentifierForCluster = new GetEmcHostLunIdentifier(lunForCluster, null, clusterPrefix);
            getIdentifierForCluster.PrefixString = HelperAdapter.GetParameter("LunIdentifierForCluster");
            getIdentifierForCluster.RunCMD(psMachine);
        }

        public void Clean()
        {
            string clusterPrefix = HelperAdapter.GetParameter("Cluster");
            string lunForCluster = HelperAdapter.GetParameter("LunC");
            TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
            TestSetup.ClearLunEnvironment(psMachine, lunForCluster);

            TestSetup.ClearDiskEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
        }

        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            try
            {
                Initialize();
            }
            catch (Exception ex)
            {
                TestTearDown();
            }
            log.LogInfo("--------Test Initialize End--------");
        }


        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");
             Clean();
            log.LogInfo("--------Test Cleanup End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcVolume instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcVolume instance</returns>  
        public NewEmcVolume ParseCmd(string cmd)
        {


            string cmdString = cmd;

            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Volume");
            string random = HelperAdapter.GenerateRandomString();

            string hostSystemString = HelperAdapter.GetParameter("Host");
            string hostDiskString = HelperAdapter.GetParameter("Disk");
            string clusterDiskString = HelperAdapter.GetParameter("DiskFindForCLuster");
            string allocationUnitSizeInByteString = dic["AllocationUnitSize"];
            string fileSystemTypeString = dic["FileSystem"];
            string labelString = "vol_" + random;
            string hostLunIdentifierString = HelperAdapter.GetParameter("LunIdentifier");
            string clusterLunIdentifierString = HelperAdapter.GetParameter("LunIdentifierForCluster");
            string silentString = "Silent";
            string clusterSystemString = HelperAdapter.GetParameter("Cluster");


            string hostSystem = null;
            string hostDisk = null;
            string allocationUnitSizeInByte = null;
            string fileSystemType = null;
            string label = null;
            string hostLunIdentifier = null;
            string silent = null;
            string clusterSystem = null;



            if (cmdString.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostSystem = hostSystemString;
                cmdString = cmdString.Replace("$HostSystem", hostSystemString);
            }
            if (cmdString.IndexOf("$HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    hostDisk = clusterDiskString;
                }
                hostDisk = hostDiskString;
                cmdString = cmdString.Replace("$HostDisk", hostDiskString);
            }
            if (cmdString.IndexOf("$AllocationUnitSizeInBytes", StringComparison.OrdinalIgnoreCase) > 0)
            {
                allocationUnitSizeInByte = allocationUnitSizeInByteString;
                cmdString = cmdString.Replace("$AllocationUnitSizeInBytes", allocationUnitSizeInByteString);
            }
            if (cmdString.IndexOf("$FileSystemType", StringComparison.OrdinalIgnoreCase) > 0)
            {
                fileSystemType = fileSystemTypeString;
                cmdString = cmdString.Replace("$FileSystemType", fileSystemTypeString);
            }
            if (cmdString.IndexOf("$Label", StringComparison.OrdinalIgnoreCase) > 0)
            {
                label = labelString;
                cmdString = cmdString.Replace("$Label", labelString);
            }
            if (cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    hostLunIdentifierString = clusterLunIdentifierString;
                }
                hostLunIdentifier = hostLunIdentifierString;
                cmdString = cmdString.Replace("$HostLunIdentifier", hostLunIdentifierString);
            }
            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterSystem = clusterSystemString;
                cmdString = cmdString.Replace("$ClusterSystem", clusterSystemString);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = silentString;
            }
            NewEmcVolume newVolume = new NewEmcVolume(hostSystem, clusterSystem, hostDisk, hostLunIdentifier, allocationUnitSizeInByte,
                fileSystemType, label, silent, cmdString);

            return newVolume;
        }



        public void NewEmcVolumeTestMethod(string cmd)
        {

            NewEmcVolume newVolume = ParseCmd(cmd);
            newVolume.PrefixString = "$VolumeTest";
            newVolume.VerifyTheCMD(psMachine);

        }


        public void NewEmcVolumeNegativeTestMethod(string cmd)
        {

            NewEmcVolume newVolume = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                newVolume.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }

        }
    }

}



﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcHostLunIdentifierTest: test class for Get-EmcHostLunIdentifier cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcHostLunIdentifierTest
    {
        public GetEmcHostLunIdentifierTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string lunWwn = "";        
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);   
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Connect to EMC Host system
            log.LogInfo("Class Initialize: Connect Host System");
            TestSetup.ConnectSystem(psMachine, "Host", HelperAdapter.GetParameter("Host")); 

            // Connect to EMC Cluster System
            log.LogInfo("Class Initialize: Connect Cluster System");
            TestSetup.ConnectSystem(psMachine, "Cluster", HelperAdapter.GetParameter("Cluster"));

            // Create Source LUN
            log.LogInfo("Class Initialize: Create Source LUN");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            lunWwn = HelperAdapter.GenerateKeyValuePairs(result)["Wwn"]; 
           
            // Create Host Disk
            log.LogInfo("Class Initialize: Unmask LUN to host and find the disk");
            TestSetup.SetDiskEnvironment(psMachine, null, HelperAdapter.GetParameter("Host"), null, null, false);

            // Create Cluster Disk
            log.LogInfo("Class Initialize: Unmask LUN to cluster and find the disk");
            TestSetup.SetDiskEnvironment(psMachine, null, null, null, HelperAdapter.GetParameter("Cluster"), false);
            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            // Unmask Host Disk
            log.LogInfo("Class Cleanup: Unmask LUN from host");
            TestSetup.ClearDiskEnvironment(psMachine, HelperAdapter.GetParameter("Host"));

            // Unmask Cluster Disk
            log.LogInfo("Class Cleanup: Unmask LUN from cluster");
            TestSetup.ClearDiskEnvironment(psMachine, null, HelperAdapter.GetParameter("Cluster"));

            // Remove Source LUN 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcHostLunIdentifier instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcHostLunIdentifier instance</returns>  
        public GetEmcHostLunIdentifier ParseCmd(string cmd)
        {
            string lun = null;
            string cluster = null;
            string host = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$Lun", lun);                
            }
            if (cmd.IndexOf("clustersystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                cluster = HelperAdapter.GetParameter("Cluster");
                cmdString = cmdString.Replace("$ClusterSystem", cluster);
            }
            if (cmd.IndexOf("hostsystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                host = HelperAdapter.GetParameter("Host");
                cmdString = cmdString.Replace("$HostSystem", host);
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcHostLunIdentifier hostLunIdentifier = new GetEmcHostLunIdentifier(lun, host, cluster, silent, cmdString);

            return hostLunIdentifier;
        }

        /// <summary>  
        /// GetEmcHostLunIdentifierTestMethod:
        ///    The method to implement Get-EmcHostLunIdentifier poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostLunIdentifierTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcHostLunIdentifier hostLunIdentifier = ParseCmd(cmd);

            hostLunIdentifier.VerifyTheCMD(psMachine, lunWwn);
        }

        /// <summary>  
        /// GetEmcHostLunIdentifierNegativeTestMethod:
        ///    The method to implement Get-EmcHostLunIdentifier negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostLunIdentifierNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcHostLunIdentifier hostLunIdentifier = ParseCmd(cmd);

            try
            {
                hostLunIdentifier.VerifyTheCMD(psMachine, lunWwn);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", hostLunIdentifier.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

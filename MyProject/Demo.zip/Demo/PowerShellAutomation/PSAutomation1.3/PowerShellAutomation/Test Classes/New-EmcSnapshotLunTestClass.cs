﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcSnapshotLunTest: test class for New-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcSnapshotLunTest
    {
        public NewEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;        
        private static string arrayLunID;
        private static string storageGlobalId;
        
        private string snapshotLUNID = "";        
        private bool removeFlag = false;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();            

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            string storageResult = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalId = HelperAdapter.GenerateKeyValuePairs(storageResult)["GlobalId"];

            // Get Snapshot Pool
            GetEmcSnapshotPool snapshotPool = new GetEmcSnapshotPool();
            snapshotPool.PrefixString = HelperAdapter.GetParameter("SnapshotPool");
            snapshotPool.RunCMD(psMachine, true);
           
            // Create Source LUN
            log.LogInfo("Class Initialize: Create Source LUN");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            arrayLunID = lunKeyValue["ArrayLunId"];
            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            // Remove Source LUN 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }        
        
        // Use TestCleanup to run code after each test has run
        [TestCleanup]
        public void TestTearDown()
        {            
            if (removeFlag)
            {
                log.LogInfo("--------Test Cleanup Start--------");
                log.LogInfo("Test Cleanup: Remove Snapshot LUN");
                //string blockStorageSystem = null;
                //if (HelperAdapter.GetProperty("ESIVersion").Equals("1.4"))
                //{
                //    blockStorageSystem = HelperAdapter.GetParameter("System");
                //}
                //GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(blockStorageSystem, snapshotLUNID);
                //getSnapshotLun.PrefixString = HelperAdapter.GetParameter("SnapshotLun");
                //getSnapshotLun.RunCMD(psMachine);
                if (HelperAdapter.GetProperty("ESIVersion").Equals("1.4"))
                {
                    DeactivateEmcSnapshotLUN snapshotlun = new DeactivateEmcSnapshotLUN(HelperAdapter.GetParameter("SnapshotLun"));
                    snapshotlun.RunCMD(psMachine);
                }
                RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun(HelperAdapter.GetParameter("SnapshotLun"));
                removeSnapshotLun.VerifyTheCMD(psMachine, snapshotLUNID);
                log.LogInfo("--------Test Cleanup End--------");
            }            
        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcSnapshotLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcSnapshotLun instance</returns>  
        public static NewEmcSnapshotLun ParseCmd(string cmd)
        {
            string lun = null;
            string snapshotPool = null;
            string name = null; 
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("sourcelun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$SourceLUN", lun);
            }

            if (cmd.IndexOf("snapshotpool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotPool = HelperAdapter.GetParameter("SnapshotPool");
                cmdString = cmdString.Replace("$SnapshotPool", snapshotPool);
            }

            if (cmd.IndexOf("name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = "ps_snapshotlun" + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$Name", name);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";                
            }

            NewEmcSnapshotLun snapshotLun = new NewEmcSnapshotLun(lun, snapshotPool, name, silent, cmdString);

            return snapshotLun;
        }

        /// <summary>  
        /// NewEmcSnapshotLunTestMethod:
        ///    The method to implement New-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcSnapshotLunTestMethod(string cmd)
        {           
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            
            NewEmcSnapshotLun snapshotLun = ParseCmd(cmd);
            string newSnapshotLUNResult = snapshotLun.VerifyTheCMD(psMachine, arrayLunID, storageGlobalId);
            snapshotLUNID = HelperAdapter.GenerateKeyValuePairs(newSnapshotLUNResult)["Wwn"];
            removeFlag = true;

            
        }

        /// <summary>  
        /// NewEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement New-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcSnapshotLunNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcSnapshotLun snapshotLun = ParseCmd(cmd);
            try
            {
                snapshotLun.VerifyTheCMD(psMachine, arrayLunID, storageGlobalId);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotLun.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    
    }
}

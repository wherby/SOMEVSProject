﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcHostDiskTest
    {
        public GetEmcHostDiskTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;
        
        /// <summary>
        ///The Lun identifier. 
        /// </summary>
        private static string lunID;

        /// <summary>
        /// The Lun Identifer for cluster.
        /// </summary>
        private static string lunIDForCluster;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");
            log.LogInfo("--------Test Cleanup End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            string result=TestSetup.SetDiskEnvironment(psMachine);
            SortedList<string, string> resultKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            lunID = resultKeyValue["HostDiskIdentifier"];
            TestSetup.SetVolumeEnvironment(psMachine);

            //Set cluster Environment.
            string lunForCluster = HelperAdapter.GetParameter("LunC");
            string clusterPrefix = HelperAdapter.GetParameter("Cluster");
            string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");
            TestSetup.SetLunEnvironment(psMachine, true, null, lunForCluster);
            TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
            string resultForCluster= TestSetup.SetDiskEnvironment(psMachine, diskFindForCluster, null, lunForCluster, clusterPrefix);
            SortedList<string, string> resultForClusterKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForCluster);
            lunIDForCluster = resultForClusterKeyValue["HostDiskIdentifier"];
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            string clusterPrefix = HelperAdapter.GetParameter("Cluster");
            string lunForCluster = HelperAdapter.GetParameter("LunC");
            TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
            TestSetup.ClearLunEnvironment(psMachine, lunForCluster);

            TestSetup.ClearVolumeEnvironment(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcHostDisk instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcHostDisk instance</returns>  
        public GetEmcHostDisk ParseCmd(string cmd)
        {


            string cmdString = cmd;

            string idString=lunID;
            string idStringForCluster = lunIDForCluster;
            string hostSystemString = HelperAdapter.GetParameter("Host");
            string lunString = HelperAdapter.GetParameter("Lun");
            string lunForClusterString = HelperAdapter.GetParameter("LunC");
            string volumeString = HelperAdapter.GetParameter("Volume");
            string silentString = "Silent";
            //Not implemented
            string clusterSystemString = HelperAdapter.GetParameter("Cluster");


            string hostSystem = null;
            string id = null;
            string lun = null;
            string silent = null;
            string clusterSystem = null;
            string volume = null;


            if (cmdString.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostSystem = hostSystemString;
                cmdString = cmdString.Replace("$HostSystem", hostSystemString);
            }
            if (cmdString.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    idString = idStringForCluster;
                }
                id = idString;
                cmdString = cmdString.Replace("$ID", idString);
            }
            if (cmdString.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    lunString = lunForClusterString;
                }
                lun = lunString;
                cmdString = cmdString.Replace("$Lun", lunString);
            }
            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterSystem = clusterSystemString;
                cmdString = cmdString.Replace("$ClusterSystem", clusterSystemString);
            }
            if (cmdString.IndexOf("$Volume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                volume = volumeString;
                cmdString = cmdString.Replace("$Volume", volumeString);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = silentString;
            }
            GetEmcHostDisk getDisk = new GetEmcHostDisk(id, lun, volume, hostSystem, clusterSystem, silent, cmdString);

            return getDisk;
        }



        public void GetEmcHostDiskTestMethod(string cmd)
        {
            GetEmcHostDisk getDisk = ParseCmd(cmd);
            getDisk.VerifyTheCMD(psMachine);
        }


        public void GetEmcHostDiskNegativeTestMethod(string cmd)
        {
            GetEmcHostDisk getDisk = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                getDisk.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}


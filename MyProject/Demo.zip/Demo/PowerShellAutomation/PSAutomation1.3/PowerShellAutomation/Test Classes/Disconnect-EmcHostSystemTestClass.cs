﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class DisconnectEmcHostSystemTest
    {
        public DisconnectEmcHostSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static SortedList<string, string> systemKeyValue;

        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes

        [TestInitialize()]
        public void TestInit() 
        {
            log.LogInfo("--------Test Initialize Start--------");

            string result = TestSetup.ConnectSystem(psMachine, "Host", HelperAdapter.GetParameter("Host"));

            systemKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.LogInfo("--------Test Initialize End--------");
        }
        
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Cleanup End--------");
        }        
        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }
        #endregion


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a DisconnectEmcHostSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public DisconnectEmcHostSystem ParseCmd(string cmd)
        {            
            string id = null;
            string force = null;
            string silent = null;
            string whatIf = null;
            string system = null;
            string cmdString = cmd;

            if (cmd.IndexOf("HostName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = systemKeyValue["Name"];
                cmdString = cmdString.Replace("$HostName", id);
            }
            else if (cmd.IndexOf("IPAddress", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = systemKeyValue["IpAddress"]; ;
                cmdString = cmdString.Replace("$IPAddress", id);
            }
            else if (cmd.IndexOf("GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = systemKeyValue["GlobalId"]; ;
                cmdString = cmdString.Replace("$GlobalId", id);
            }

            if (cmd.IndexOf("System", StringComparison.OrdinalIgnoreCase) > 0)
            {
                system = HelperAdapter.GetParameter("Host");
                cmdString = cmdString.Replace("$System", system);
            }

            if (cmd.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }

            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatIf = "WhatIf";
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            DisconnectEmcHostSystem hostSystem = new DisconnectEmcHostSystem(id, system, force, silent, whatIf, cmdString);

            return hostSystem;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisconnectEmcHostSystemTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            DisconnectEmcHostSystem system = ParseCmd(cmd);

            system.VerifyTheCMD(psMachine, systemKeyValue["GlobalId"]);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisconnectEmcHostSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            DisconnectEmcHostSystem system = ParseCmd(cmd);

            try
            {
                system.VerifyTheCMD(psMachine, systemKeyValue["GlobalId"]);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");
        }
        
    }
            
}

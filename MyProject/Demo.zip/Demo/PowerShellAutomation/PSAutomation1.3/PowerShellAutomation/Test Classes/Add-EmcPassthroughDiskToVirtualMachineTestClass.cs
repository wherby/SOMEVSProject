﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;
using System.Text.RegularExpressions;

namespace PowerShellAutomation
{   
    /// <summary>
    /// AddEmcPassthroughDiskToVirtualMachineTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class AddEmcPassthroughDiskToVirtualMachineTest
    {
        public AddEmcPassthroughDiskToVirtualMachineTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string> passthroughDisk;
        private static string hypervName;
        private static string location;
        private static SortedList<string, string> scsiController;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            passthroughDisk = TestSetup.GetRandomPassthroughDisk(psMachine);
            scsiController = TestSetup.GetRandomScsiController(psMachine, HelperAdapter.GetParameter("ScsiController"));
            location = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController["ScsiControllerIndex"], scsiController["ScsiControllerId"], HelperAdapter.GetParameter("Hypervisor"), vmConfig);

            log.LogInfo("--------Test Initialize End--------");        
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start---------");

            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            string vm = HelperAdapter.GetParameter("VirtualMachine");
            RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfig, hyperv, location, null, null, null, null, "Force");
            removeDisk.RunCMD(psMachine);

            log.LogInfo("--------Test Cleanup End---------");
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            string vm = HelperAdapter.GetParameter("VirtualMachine");
            string lun = HelperAdapter.GetParameter("Lun");
            
            // Connect to Hyper-V          
            log.LogInfo("Class Initialize: Connect Hyper-V System");
            string result = TestSetup.ConnectSystem(psMachine, "Hypervisor", hyperv);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Contains("Hyper-V"))
            {
                log.LogError(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                PSException pe = new PSException(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                throw pe;
            }
            hypervName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];

            // Connect to VM         
            log.LogInfo("Class Initialize: Connect Storage System");
            result = TestSetup.ConnectSystem(psMachine, "VM", vm);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!lunKeyValue["Model"].Equals("Virtual Machine"))
            {
                log.LogError(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                PSException pe = new PSException(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                throw pe;
            }

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(hyperv);
            updateSystem.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(vm);
            vmConfig.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            vmConfig.RunCMD(psMachine, true);

            //Connect to Storage System
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            SetEmcLunAccess setLunAccess = new SetEmcLunAccess("Available", lun, hyperv);
            setLunAccess.RunCMD(psMachine, false);

            FindEmcHostDisk findDisk = new FindEmcHostDisk(hyperv, null, null, null, lun);
            findDisk.PrefixString = HelperAdapter.GetParameter("Disk");
            findDisk.RunCMD(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            Thread.Sleep(5000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("VirtualMachine"));
            updateSystem.RunCMD(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine, HelperAdapter.GetParameter("Hypervisor"));
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a AddEmcPassthroughDiskToVirtualMachine instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>AddEmcPassthroughDiskToVirtualMachine instance</returns>  
        public AddEmcPassthroughDiskToVirtualMachine ParseCmd(string cmd)
        {
            string diskId = null;
            string diskNumber = null;
            string hostDisk = null;
            string vmConfig = null;
            string hyperv = null;
            string scsiControllerId = null;
            string scsiControllerIndex = null;
            string locationLocal = null;
            string silent = null;
            string cmdString = cmd;
            int number = 0;

            Regex reg = new Regex(@"\\\\\?\\PhysicalDrive(\d+)");
            GroupCollection gc = reg.Match(passthroughDisk["HostDiskIdentifier"]).Groups;
            number = int.Parse(gc[1].Value);

            if (cmd.IndexOf("$DiskId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                diskId = passthroughDisk["HostDiskIdentifier"];
                cmdString = cmdString.Replace("$DiskId", diskId);
            }
            else if (cmd.IndexOf("$DiskNumber", StringComparison.OrdinalIgnoreCase) > 0)
            {
                diskNumber = number.ToString();
                cmdString = cmdString.Replace("$DiskNumber", diskNumber);
            }
            else if (cmd.IndexOf("$HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostDisk = HelperAdapter.GetParameter("PassthroughDisk");
                cmdString = cmdString.Replace("$HostDisk", hostDisk);
            }

            if (cmd.IndexOf("$VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", vmConfig);
            }

            if (cmd.IndexOf("$Hypervisor", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hyperv = HelperAdapter.GetParameter("Hypervisor");
                cmdString = cmdString.Replace("$Hypervisor", hyperv);
            }

            if (cmd.IndexOf("$ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsiControllerId = scsiController["ScsiControllerId"];
                cmdString = cmdString.Replace("$ScsiControllerId", "\"" + scsiControllerId + "\"");
            }

            if (cmd.IndexOf("$ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsiControllerIndex = scsiController["ScsiControllerIndex"];
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsiControllerIndex);
            }

            if (cmd.IndexOf("$Location", StringComparison.OrdinalIgnoreCase) > 0)
            {
                locationLocal = location;
                cmdString = cmdString.Replace("$Location", locationLocal);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            AddEmcPassthroughDiskToVirtualMachine addDisk = new AddEmcPassthroughDiskToVirtualMachine(diskId, diskNumber, hostDisk, vmConfig, hyperv, locationLocal, scsiControllerId, scsiControllerIndex, silent, cmdString);
            addDisk.DiskNumber = number;

            return addDisk;
        }

        
        /// <summary>  
        /// AddEmcPassthroughDiskToVirtualMachineTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcPassthroughDiskToVirtualMachineTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            AddEmcPassthroughDiskToVirtualMachine addDisk = ParseCmd(cmd);

            addDisk.VerifyTheCMD(psMachine, scsiController);
        }

        /// <summary>  
        /// AddEmcPassthroughDiskToVirtualMachineNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcPassthroughDiskToVirtualMachineNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            AddEmcPassthroughDiskToVirtualMachine addDisk = ParseCmd(cmd);

            try
            {
                addDisk.VerifyTheCMD(psMachine, scsiController);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", addDisk.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcStoragePoolTest
    {
        public GetEmcStoragePoolTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string poolID=null;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Cleanup Start--------");
            log.LogInfo("--------Test Cleanup End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            string result= TestSetup.SetPoolEnvironment(psMachine);
            SortedList<string ,string> poolKeyValue= HelperAdapter.GenerateKeyValuePairs(result);
            poolID = poolKeyValue["ArrayPoolId"];
            TestSetup.SetLunEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcStoragePool instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcStoragePool instance</returns>  
        public GetEmcStoragePool ParseCmd(string cmd)
        {
            string cmdString = cmd;

            string idString = poolID;
            string lunString =HelperAdapter.GetParameter("Lun");
            string storageSystemString =HelperAdapter.GetParameter("System");
            string poolTypeString = HelperAdapter.GetParameter("PoolType", "LunConfig");

            string id = null;
            string lun = null;
            string storageSystem = null;
            string silent = null;
            string poolType = null;

            if (cmdString.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = idString;
                cmdString = cmdString.Replace("$ID", idString);
            }
            if (cmdString.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = lunString;
                cmdString = cmdString.Replace("$Lun", lunString);
            }
            if (cmdString.IndexOf("$StorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storageSystem = storageSystemString;
                cmdString = cmdString.Replace("$StorageSystem", storageSystem);
            }
            if (cmdString.IndexOf("$PoolType", StringComparison.OrdinalIgnoreCase) > 0)
            {
                poolType = poolTypeString;
                cmdString = cmdString.Replace("$PoolType", poolType);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcStoragePool getStoragePool = new GetEmcStoragePool(id, lun, storageSystem, silent,poolType, cmdString); 

            return getStoragePool;
        }

        public void GetEmcStoragePoolTestMethod(string cmd)
        {
            GetEmcStoragePool getStoragePool = ParseCmd(cmd);
            getStoragePool.VerifyTheCMD(psMachine);
        }

        public void GetEmcStoragePoolNegativeTestMethod(string cmd)
        {
            GetEmcStoragePool getStoragePool = ParseCmd(cmd);
            TestLog log = TestLog.GetInstance();
            bool failCMD = false;
            try
            {
                getStoragePool.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}


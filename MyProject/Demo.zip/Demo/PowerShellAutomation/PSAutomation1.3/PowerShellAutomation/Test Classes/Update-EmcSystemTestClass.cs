﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class UpdateEmcSystemTest
    {
        public UpdateEmcSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string[] types = { "CLARiiON-CX4", "VMAX", "VMAXe", "VNX", "VNX-Block", "VNX-CIFS", "Host", "Cluster"};
            string path = HelperAdapter.GetProperty("SystemConfig");

            foreach (string type in types)
            {
                Dictionary<string, string> dic = HelperAdapter.Load(path, type);
                if (dic.Count == 0)
                {
                    log.LogInfo(string.Format("Storage system {0} is not prepared!", type));
                    continue;
                }
                string prefix = "$" + type.Replace("-", "_") + "System";
                TestSetup.ConnectSystem(psMachine, type, prefix);
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

             
       
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a UpdateEmcSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>UpdateEmcSystem instance</returns>  
        public UpdateEmcSystem ParseCmd(string cmd)
        {
            string cmdString = cmd;
            string hostSystem = null;
            string storageSystem = null;
            string clusterSystem = null;
            string silent = null;
            string[] types = { "CLARiiON-CX4", "VMAX", "VMAXe", "VNX", "VNX-Block", "VNX-CIFS", "Host", "Cluster"};
            
            foreach (string type in types)
            {
                if (cmd.IndexOf(type + "System", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    storageSystem = "$" + type.Replace("-", "_") + "System";
                    string blobstring = HelperAdapter.GetBlobContent(type);
                    if (blobstring == null)
                    {
                        return null;
                    }
                    else
                    {
                        cmdString = cmdString.Replace("$" + type + "System", storageSystem);
                        break;
                    }
                }
            }

            //if (cmd.IndexOf("HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            //{
            //    hostSystem = "$HostSystem";
            //}

            //if (cmd.IndexOf("ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            //{
            //    hostSystem = "$ClusterSystem";
            //}

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            UpdateEmcSystem system = new UpdateEmcSystem(hostSystem, storageSystem, clusterSystem, silent, cmdString);

            return system;
        }

        
        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void UpdateEmcSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            UpdateEmcSystem system = ParseCmd(cmd);

            if (system == null)
            {
                return;
            }
            
            string result =  system.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void UpdateEmcSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            UpdateEmcSystem system = ParseCmd(cmd);

            if (system == null)
            {
                return;
            }

            try
            {
                string result = system.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case failed");

        }

    }
            
}

﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcSnapshotSessionTest: test class for New-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcSnapshotSessionTest
    {
        public RemoveEmcSnapshotSessionTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private SortedList<string, string> lunKeyValue;        
        private bool removeSnapshotLunFlag = false;
        private bool removeSnapshotSessionFlag = false;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class       
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            TestSetup.ConnectSystem(psMachine, "VNX-Block", "$storage");

            // Create Source LUN
            log.LogInfo("Class Initialize: Create Source LUN");
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
        }
       
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            // Remove Source LUN 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);  
        }     
  
        // Use TestInitialize to run code before running each test            
        [TestInitialize]
        public void TestInit()
        {
         
            // Create a snapshot session
            log.LogInfo("Test Initialize: Create Snapshot Session");
            NewEmcSnapshotSession snapshotSession = new NewEmcSnapshotSession("$lun");
            string result = snapshotSession.RunCMD(psMachine, true);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);            

            GetEmcSnapshotSession getsnapshotSession = new GetEmcSnapshotSession(lunKeyValue["SessionId"]);
            getsnapshotSession.PrefixString = "$snapshotsession";
            getsnapshotSession.RunCMD(psMachine, true);            
        }

        // Use TestCleanup to run code after each test has run        
        [TestCleanup]
        public void TestTearDown()
        {
            if (removeSnapshotSessionFlag)
            {
                log.LogInfo("Test Cleanup: Remove Snapshot Session");
                RemoveEmcSnapshotSession removeSnapshotSession = new RemoveEmcSnapshotSession("$snapshotsession", "RemoveSnapshotLUN");
                removeSnapshotSession.VerifyTheCMD(psMachine, lunKeyValue["SessionId"], lunKeyValue["TargetSnapshotLunId"]);
            }
            else if (removeSnapshotLunFlag)
            {
                log.LogInfo("Test Cleanup: Remove Snapshot LUN");
                GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(null, lunKeyValue["TargetSnapshotLunId"]);
                getSnapshotLun.PrefixString = "$snapshotlun";
                getSnapshotLun.RunCMD(psMachine);

                RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun("$snapshotlun");
                removeSnapshotLun.VerifyTheCMD(psMachine, lunKeyValue["TargetSnapshotLunId"]);
            }            
        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a RemoveEmcSnapshotSession instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>RemoveEmcSnapshotSession instance</returns>  
        public static RemoveEmcSnapshotSession ParseCmd(string cmd)
        {
            string snapshotSession = null;
            string removeSnapshotLun = null;
            string force = null;
            string silent = null;
            string whatIf = null;
            string cmdString = cmd;

            if (cmd.IndexOf("snapshotsession", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotSession = "$snapshotsession";
                cmdString = cmdString.Replace("$SnapshotSession", snapshotSession);
            }
            if (cmd.IndexOf("removesnapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                removeSnapshotLun = "RemoveSnapshotLUN";
            }
            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatIf = "WhatIf";
            }

            RemoveEmcSnapshotSession removeSnapshotSession = new RemoveEmcSnapshotSession(snapshotSession, removeSnapshotLun, force, silent, whatIf, cmdString);

            return removeSnapshotSession;
        }

        /// <summary>  
        /// RemoveEmcSnapshotSessionTestMethod:
        ///    The method to implement Remove-EmcSnapshotSession poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSnapshotSessionTestMethod(string cmd)
        {
           
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            
            // Remove snapshot Session            
            RemoveEmcSnapshotSession removesnapshotSession = ParseCmd(cmd);

            removesnapshotSession.VerifyTheCMD(psMachine, lunKeyValue["SessionId"], lunKeyValue["TargetSnapshotLunId"]);
            
            if ( cmd.Contains("WhatIf") )
            {                                
                removeSnapshotSessionFlag = true;
            }
            else if (!cmd.Contains("RemoveSnapshotLUN"))
            {
                removeSnapshotLunFlag = true;
            }            
        }

        /// <summary>  
        /// RemoveEmcSnapshotSessionNegativeTestMethod:
        ///    The method to implement Remove-EmcSnapshotSession negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSnapshotSessionNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcSnapshotSession snapshotSession = ParseCmd(cmd);

            try
            {
                snapshotSession.VerifyTheCMD(psMachine, lunKeyValue["SessionId"], lunKeyValue["TargetSnapshotLunId"]);
            }
            catch (PSException psEx)
            {
                removeSnapshotSessionFlag = true;
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotSession.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    
    }
}

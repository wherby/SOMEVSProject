﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcSnapshotSessionTest: test class for New-EmcSnapshotSession cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcSnapshotSessionTest
    {
        public NewEmcSnapshotSessionTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;        
        private static string arrayLunID;        
        private static string storageGlobalID;

        private string snapshotLunID = "";
        private string snapshotSessionID = "";
        private string snapshotPoolID = "";
        private bool removeSnapshotLunFlag = false;
        private bool removeSnapshotSessionFlag = false;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();            

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            // Disconnect all the storage system which has been connected
            DisconnectEmcStorageSystem disconnectSystem = new DisconnectEmcStorageSystem();
            disconnectSystem.RunCMD(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string result = TestSetup.ConnectSystem(psMachine, "VNX-Block", "$storage");
            storageGlobalID = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Create Source LUN
            log.LogInfo("Class Initialize: Create Source LUN");
            TestSetup.SetPoolEnvironment(psMachine);
            result = TestSetup.SetLunEnvironment(psMachine);
            arrayLunID = HelperAdapter.GenerateKeyValuePairs(result)["ArrayLunId"];
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestCleanUP()
        {
            // Remove Source LUN 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);  
        }

        // Use TestInitialize to run code before running each test         
        [TestInitialize]
        public void TestInit()
        {
            // Get Snapshot Pool for specified storage
            log.LogInfo("Test Initialize: Get Snapshot Pool");
            
            GetEmcSnapshotPool snapshotpool= new GetEmcSnapshotPool();
            snapshotpool.PrefixString = "$snapshotpool";
            string result = snapshotpool.RunCMD(psMachine, true);
            snapshotPoolID = HelperAdapter.GenerateKeyValuePairs(result)["PoolId"];
        }
        
        // Use TestCleanup to run code after each test has run
        [TestCleanup]
        public void TestTearDown()
        {
            if (removeSnapshotSessionFlag == false && removeSnapshotLunFlag == true)
            {
                log.LogInfo("Test Cleanup: Remove Snapshot LUN");
                GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(null, snapshotLunID);
                getSnapshotLun.PrefixString = "$snapshotlun";
                getSnapshotLun.RunCMD(psMachine);

                RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun("$snapshotlun");
                removeSnapshotLun.VerifyTheCMD(psMachine, snapshotLunID);
            }
            else if (removeSnapshotSessionFlag)
            {
                log.LogInfo("Test Cleanup: Remove Snapshot Session");
                GetEmcSnapshotSession getSnapshotSession = new GetEmcSnapshotSession(snapshotSessionID);
                getSnapshotSession.PrefixString = "$snapshotsession";
                getSnapshotSession.RunCMD(psMachine);

                RemoveEmcSnapshotSession removeSnapshotSession = new RemoveEmcSnapshotSession("$snapshotsession", "RemoveSnapshotLUN");
                removeSnapshotSession.VerifyTheCMD(psMachine, snapshotSessionID, snapshotLunID);

            }
        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcSnapshotSession instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcSnapshotSession instance</returns>  
        public static NewEmcSnapshotSession ParseCmd(string cmd)
        {
            string lun = null;
            string snapshotlun = null;
            string snapshotpool = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("sourcelun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = "$lun";
                cmdString = cmdString.Replace("$SourceLUN", lun);
            }

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotlun = "$snapshotlun";
                cmdString = cmdString.Replace("$SnapshotLUN", snapshotlun);
            }

            if (cmd.IndexOf("snapshotpool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotpool = "$snapshotpool";
                cmdString = cmdString.Replace("$SnapshotPool", snapshotpool);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";                
            }

            NewEmcSnapshotSession snapshotSession = new NewEmcSnapshotSession(lun, snapshotlun, snapshotpool, silent, cmdString);

            return snapshotSession;
        }

        /// <summary>  
        /// NewEmcSnapshotSessionTestMethod:
        ///    The method to implement New-EmcSnapshotSession poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcSnapshotSessionTestMethod(string cmd)
        {           
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                // Create a snapshot Lun
                log.LogInfo("Create Snapshot LUN");
                NewEmcSnapshotLun snapshotLun = new NewEmcSnapshotLun("$lun");
                string result = snapshotLun.RunCMD(psMachine, true);
                snapshotLunID = HelperAdapter.GenerateKeyValuePairs(result)["ArrayLunId"];               

                GetEmcSnapshotLun getsnapshotLun = new GetEmcSnapshotLun(null, snapshotLunID);
                getsnapshotLun.PrefixString = "$snapshotlun";
                getsnapshotLun.RunCMD(psMachine, true);
                removeSnapshotLunFlag = true;
            }
            
            NewEmcSnapshotSession snapshotSession = ParseCmd(cmd);
            string newSnapshotSessionResult = snapshotSession.VerifyTheCMD(psMachine, storageGlobalID, arrayLunID, snapshotLunID, snapshotPoolID);
            snapshotSessionID = HelperAdapter.GenerateKeyValuePairs(newSnapshotSessionResult)["SessionId"];
            snapshotLunID = HelperAdapter.GenerateKeyValuePairs(newSnapshotSessionResult)["TargetSnapshotLunId"];
            removeSnapshotSessionFlag = true;            
        }

        /// <summary>  
        /// NewEmcSnapshotSessionNegativeTestMethod:
        ///    The method to implement New-EmcSnapshotSession negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcSnapshotSessionNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                // Create a snapshot Lun
                log.LogInfo("Create Snapshot LUN");
                NewEmcSnapshotLun snapshotLun = new NewEmcSnapshotLun("$lun");
                string result = snapshotLun.RunCMD(psMachine, true);
                snapshotLunID = HelperAdapter.GenerateKeyValuePairs(result)["Wwn"];

                GetEmcSnapshotLun getsnapshotLun = new GetEmcSnapshotLun(null, snapshotLunID);
                getsnapshotLun.PrefixString = "$snapshotlun";
                getsnapshotLun.RunCMD(psMachine, true);
                removeSnapshotLunFlag = true;
            }

            NewEmcSnapshotSession snapshotSession = ParseCmd(cmd);
            try
            {
                snapshotSession.VerifyTheCMD(psMachine, storageGlobalID, arrayLunID, snapshotLunID, snapshotPoolID);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotSession.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    
    }
}

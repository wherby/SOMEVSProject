﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcSnapshotLunTest: test class for New-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcSnapshotLUNTest
    {
        public RemoveEmcSnapshotLUNTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private SortedList<string, string> lunKeyValue;
        private string snapshotLUNID = "";
        private bool removeFlag = false;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class       
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Create Source LUN
            log.LogInfo("Class Initialize: Create Source LUN");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            log.LogInfo("--------Class Initialize End--------");
        }
       
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            // Remove Source LUN 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Cleanup End--------");
        }      
  
        
        // Use TestInitialize to run code before running each test 
        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
         
            // Create a snapshot Lun
            log.LogInfo("Test Initialize: Create Snapshot LUN");
            NewEmcSnapshotLun snapshotLun = new NewEmcSnapshotLun(HelperAdapter.GetParameter("Lun"));
            snapshotLun.PrefixString = HelperAdapter.GetParameter("SnapshotLun");
            string result = snapshotLun.RunCMD(psMachine, true);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            snapshotLUNID = lunKeyValue["Wwn"];
            if (HelperAdapter.GetProperty("ESIVersion").Equals("1.4"))
            {
                DeactivateEmcSnapshotLUN snapshotlun = new DeactivateEmcSnapshotLUN(HelperAdapter.GetParameter("SnapshotLun"));
                snapshotlun.RunCMD(psMachine);
            }            
            log.LogInfo("--------Test Initialize End--------");
        }

        // Use TestCleanup to run code after each test has run       
        [TestCleanup]
        public void TestTearDown()
        {            
            if (removeFlag)
            {
                log.LogInfo("--------Test Cleanup Start--------");
                log.LogInfo("Test Cleanup: Remove Snapshot LUN");
                RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun(HelperAdapter.GetParameter("SnapshotLun"));                
                removeSnapshotLun.VerifyTheCMD(psMachine, snapshotLUNID);
                log.LogInfo("--------Test Cleanup End--------");
            }          
            
        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a RemoveEmcSnapshotLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>RemoveEmcSnapshotLun instance</returns>  
        public static RemoveEmcSnapshotLun ParseCmd(string cmd)
        {
            string lun = null;
            string force = null;
            string silent = null;
            string whatIf = null;
            string cmdString = cmd;

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = HelperAdapter.GetParameter("SnapshotLun");
                cmdString = cmdString.Replace("$SnapshotLUN", lun);
            }
            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatIf = "WhatIf";
            }

            RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun(lun, force, silent, whatIf, cmdString);

            return removeSnapshotLun;
        }

        /// <summary>  
        /// RemoveEmcSnapshotLunTestMethod:
        ///    The method to implement Remove-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSnapshotLUNTestMethod(string cmd)
        {
           
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            
            // Remove snapshot Lun            
            RemoveEmcSnapshotLun removesnapshotLun = ParseCmd(cmd);
            
            if ( cmd.Contains("WhatIf") )
            {
                removesnapshotLun.VerifyTheCMD(psMachine, snapshotLUNID);                
                removeFlag = true;
            }
            else
            {
                removesnapshotLun.VerifyTheCMD(psMachine, snapshotLUNID);
            }            

        }

        /// <summary>  
        /// RemoveEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement Remove-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSnapshotLUNNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcSnapshotLun snapshotLun = ParseCmd(cmd);

            try
            {
                snapshotLun.VerifyTheCMD(psMachine, snapshotLUNID);
            }
            catch (PSException psEx)
            {
                removeFlag = true;
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotLun.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    
    }
}

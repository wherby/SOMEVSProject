﻿using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// AddEmcFilebasedDiskToVirtualMachineTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class AddEmcFilebasedDiskToVirtualMachineTest
    {
        public AddEmcFilebasedDiskToVirtualMachineTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string path;
        private static string hypervName;
        private static string location;
        private static SortedList<string, string> scsiController;
        private static string remotePath;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            scsiController = TestSetup.GetRandomScsiController(psMachine, HelperAdapter.GetParameter("ScsiController"));

            location = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController["ScsiControllerIndex"], scsiController["ScsiControllerId"], HelperAdapter.GetParameter("Hypervisor"), vmConfig);
        
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up---------");
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfig, hyperv, location, scsiController["ScsiControllerId"], scsiController["ScsiControllerIndex"], null, null, "Force");
            removeDisk.RunCMD(psMachine);
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            
            // Connect to Hyper-V          
            log.LogInfo("Class Initialize: Connect Hyper-V System");
            string result = TestSetup.ConnectSystem(psMachine, "Hypervisor", HelperAdapter.GetParameter("Hypervisor"));
            SortedList<string, string> hypervKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!hypervKeyValue["Model"].Contains("Hyper-V"))
            {
                log.LogError(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                PSException pe = new PSException(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                throw pe;
            }
            hypervName = hypervKeyValue["Name"];

            // Connect to VM         
            log.LogInfo("Class Initialize: Connect Virtual Machine System");
            result = TestSetup.ConnectSystem(psMachine, "VM", HelperAdapter.GetParameter("VirtualMachine"));
            SortedList<string, string> vmKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!vmKeyValue["Model"].Equals("Virtual Machine"))
            {
                log.LogError(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                PSException pe = new PSException(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                throw pe;
            }

            string configPath = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(configPath, "FileBasedDisk");

            path = dic["Path"] + HelperAdapter.GenerateRandomString() + ".vhd";
            remotePath = string.Format(@"\\{0}\{1}",hypervKeyValue["Name"], path.Replace(":", "$"));

            NewEmcFileBasedDisk fileBasedDisk = new NewEmcFileBasedDisk(HelperAdapter.GetParameter("Hypervisor"), path, dic["SizeInGB"], dic["DiskType"]);
            fileBasedDisk.RunCMD(psMachine);

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Hypervisor"));
            updateSystem.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(HelperAdapter.GetParameter("VirtualMachine"));
            vmConfig.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            vmConfig.RunCMD(psMachine, true);
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            if (HelperAdapter.TestPath(psMachine, remotePath))
            {
                HelperAdapter.RemoveItem(psMachine, remotePath);
            }

            TestSetup.DisconnectSystem(psMachine);
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a AddEmcFilebasedDiskToVirtualMachine instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>AddEmcFilebasedDiskToVirtualMachine instance</returns>  
        public AddEmcFilebasedDiskToVirtualMachine ParseCmd(string cmd)
        {
            string pathLocal = null;
            string vmConfig = null;
            string hyperv = null;
            string scsiControllerId = null;
            string scsiControllerIndex = null;
            string locationLocal = null;
            string silent = null;
            string cmdString = cmd;

            if (cmd.IndexOf("$Path", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pathLocal = path;
                cmdString = cmdString.Replace("$Path", pathLocal);
            }

            if (cmd.IndexOf("$VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", vmConfig);
            }

            if (cmd.IndexOf("$Hypervisor", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hyperv = HelperAdapter.GetParameter("Hypervisor");
                cmdString = cmdString.Replace("$Hypervisor", hyperv);
            }

            if (cmd.IndexOf("$ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsiControllerId = scsiController["ScsiControllerId"];
                cmdString = cmdString.Replace("$ScsiControllerId", "\"" + scsiControllerId + "\"");
            }

            if (cmd.IndexOf("$ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsiControllerIndex = scsiController["ScsiControllerIndex"];
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsiControllerIndex);
            }

            if (cmd.IndexOf("$Location", StringComparison.OrdinalIgnoreCase) > 0)
            {
                locationLocal = location;
                cmdString = cmdString.Replace("$Location", locationLocal);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            AddEmcFilebasedDiskToVirtualMachine addDisk = new AddEmcFilebasedDiskToVirtualMachine(path, vmConfig, hyperv, locationLocal, scsiControllerId, scsiControllerIndex, silent, cmdString);

            return addDisk;
        }

        
        /// <summary>  
        /// AddEmcFilebasedDiskToVirtualMachineTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcFilebasedDiskToVirtualMachineTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            AddEmcFilebasedDiskToVirtualMachine addDisk = ParseCmd(cmd);

            addDisk.VerifyTheCMD(psMachine, scsiController);
        }

        /// <summary>  
        /// AddEmcFilebasedDiskToVirtualMachineNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcFilebasedDiskToVirtualMachineNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            AddEmcFilebasedDiskToVirtualMachine addDisk = ParseCmd(cmd);

            try
            {
                addDisk.VerifyTheCMD(psMachine, scsiController);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", addDisk.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

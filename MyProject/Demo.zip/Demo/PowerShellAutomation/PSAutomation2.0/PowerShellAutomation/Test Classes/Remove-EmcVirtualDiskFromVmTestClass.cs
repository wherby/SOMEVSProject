using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{
    public enum DiskType
    {
        FilebasedDisk,
        PassthroughDisk
    }
    /// <summary>
    /// RemoveEmcVirtualDiskFromVmTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcVirtualDiskFromVmTest
    {
        public RemoveEmcVirtualDiskFromVmTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string[] hypervisors;
        private static string[] path;
        private static string[] firstScsiFilePath;
        private static string[] fileDiskLocation;
        private static string[] firstScsiFileDiskLocation;
        private static SortedList<string, string>[] fileDiskConfig;
        private static SortedList<string, string>[] firstScsiFileDiskConfig;
        private static string[] ptDiskLocation;
        private static string[] firstScsiPtDiskLocation;
        private static SortedList<string, string>[] ptDiskConfig;
        private static SortedList<string, string>[] firstScsiPtDiskConfig;
        private static SortedList<string, string>[] fileScsiController;
        private static SortedList<string, string>[] ptScsiController;
        private static string[] hyperHost;
        private static int vmIndex;
        private static DiskType diskType;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    log.BypassTest();
                }
                string hypervisor = HelperAdapter.GetParameter(hypervisors[i]);
                string vm = HelperAdapter.GetParameter("VirtualMachine") + i;
                string fileDisk = HelperAdapter.GetParameter("FilebasedDisk") + i;
                string ptDisk = HelperAdapter.GetParameter("PassthroughDisk") + i;
                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                string hostDisk = HelperAdapter.GetParameter("Disk") + i;
                string firstScsiDisk = HelperAdapter.GetParameter("Disk") + "First" + i;
                
                UpdateEmcSystem updateVM = new UpdateEmcSystem(vm);
                updateVM.RunCMD(psMachine);

                GetEmcAvailableScsiControllerLocation getLocations = new GetEmcAvailableScsiControllerLocation(vmConfigPrefix, "0");
                string scsiLocations = getLocations.RunCMD(psMachine);
                SortedList<string, string> locations = HelperAdapter.GenerateKeyValuePairs(scsiLocations);

                if (string.IsNullOrEmpty(firstScsiFileDiskLocation[i]) || locations.ContainsKey(firstScsiFileDiskLocation[i]))
                {
                    firstScsiFileDiskLocation[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, "0", null, vmConfigPrefix);
                    string result = TestSetup.SetVirtualDiskEnvironment(psMachine, null, firstScsiFilePath[i], vmConfigPrefix, firstScsiFileDiskLocation[i], "0");
                    firstScsiFileDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);
                }

                if (fileScsiController[i] != null)
                {
                    getLocations = new GetEmcAvailableScsiControllerLocation(vmConfigPrefix, fileScsiController[i]["ScsiControllerIndex"]);
                    scsiLocations = getLocations.RunCMD(psMachine);
                    locations = HelperAdapter.GenerateKeyValuePairs(scsiLocations);
                }
                if (string.IsNullOrEmpty(fileDiskLocation[i]) || locations.ContainsKey(fileDiskLocation[i]))
                {
                    fileScsiController[i] = TestSetup.GetRandomScsiController(psMachine, null, vmConfigPrefix);
                    fileDiskLocation[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, fileScsiController[i]["ScsiControllerIndex"], null, vmConfigPrefix);
                    string result = TestSetup.SetVirtualDiskEnvironment(psMachine, null, path[i], vmConfigPrefix, fileDiskLocation[i], fileScsiController[i]["ScsiControllerIndex"]);
                    fileDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);
                }

                getLocations = new GetEmcAvailableScsiControllerLocation(vmConfigPrefix, "0");
                scsiLocations = getLocations.RunCMD(psMachine);
                locations = HelperAdapter.GenerateKeyValuePairs(scsiLocations);
                if (string.IsNullOrEmpty(firstScsiPtDiskLocation[i]) || locations.ContainsKey(firstScsiPtDiskLocation[i]))
                {
                    firstScsiPtDiskLocation[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, "0", null, vmConfigPrefix);
                    string result = TestSetup.SetVirtualDiskEnvironment(psMachine, firstScsiDisk, null, vmConfigPrefix, firstScsiPtDiskLocation[i], "0");
                    firstScsiPtDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);
                }

                if (ptScsiController[i] != null)
                {
                    getLocations = new GetEmcAvailableScsiControllerLocation(vmConfigPrefix, ptScsiController[i]["ScsiControllerIndex"]);
                    scsiLocations = getLocations.RunCMD(psMachine);
                    locations = HelperAdapter.GenerateKeyValuePairs(scsiLocations);
                }
                if (string.IsNullOrEmpty(ptDiskLocation[i]) || locations.ContainsKey(ptDiskLocation[i]))
                {
                    ptScsiController[i] = TestSetup.GetRandomScsiController(psMachine, null, vmConfigPrefix);
                    ptDiskLocation[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, ptScsiController[i]["ScsiControllerIndex"], null, vmConfigPrefix);
                    string result = TestSetup.SetVirtualDiskEnvironment(psMachine, hostDisk, null, vmConfigPrefix, ptDiskLocation[i], ptScsiController[i]["ScsiControllerIndex"] );
                    ptDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);
                }
            }

            log.LogInfo("--------Test Initialize End--------");
        }

       
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);

            hypervisors = new string[] { "HyperV", "VMWare" };
            hyperHost = new string[2] { "HyperV", "ESXHost" };
            path = new string[2];
            firstScsiFilePath = new string[2];
            fileDiskLocation = new string[2];
            fileDiskConfig = new SortedList<string, string>[2];
            firstScsiFileDiskLocation = new string[2];
            firstScsiFileDiskConfig = new SortedList<string, string>[2];
            ptDiskLocation = new string[2];
            firstScsiPtDiskLocation = new string[2];
            ptDiskConfig = new SortedList<string, string>[2];
            firstScsiPtDiskConfig = new SortedList<string, string>[2];
            ptScsiController = new SortedList<string, string>[2];
            fileScsiController = new SortedList<string, string>[2];

            //Connect to Storage System
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);
            
            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1 )
                {
                    continue;
                }
                string hypervisor = HelperAdapter.GetParameter(hypervisors[i]);
                string hostPrefix = HelperAdapter.GetParameter(hyperHost[i]);
                string vm = HelperAdapter.GetParameter("VirtualMachine") + i;
                string lun = HelperAdapter.GetParameter("Lun") + i;
                string firstScsiLun = HelperAdapter.GetParameter("Lun") + "First" + i;
                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                string hostDisk = HelperAdapter.GetParameter("Disk") + i;
                string firstScsiDisk = HelperAdapter.GetParameter("Disk") + "First" + i;

                // Connect to Hyper-V    
                string isVcenter = HelperAdapter.GetHypervisorProperties(HyperVisorType.VMWare)["IsVirtualCenter"];
                if (i == 1 && isVcenter == "true")
                {
                    Dictionary<string, string> dict = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                    TestSetup.ConnectSystem(psMachine, hypervisors[i], hypervisor, dict);
                }
                else
                {
                    TestSetup.ConnectSystem(psMachine, hypervisors[i], hypervisor);
                }

                // Connect Hyperv's VM
                HyperVisorType type = HyperVisorType.HyperV;
                if (i == 1)
                {
                    type = HyperVisorType.VMWare;
                }
                Dictionary<string, string> dic = HelperAdapter.GetHostVMs(type)[0];
                TestSetup.ConnectSystem(psMachine, "HyperVM", HelperAdapter.GetParameter("VirtualMachine") + i, dic);
                
                if (i == 1)
                {
                    string configPath = HelperAdapter.GetProperty("DiskVolumeConfig");
                    Dictionary<string, string> datastoreDic = HelperAdapter.Load(configPath, "DataStore");
                    GetEmcDataStore dataStore = new GetEmcDataStore(datastoreDic["Name"], hypervisor);
                    dataStore.PrefixString = HelperAdapter.GetParameter("DataStore");
                    dataStore.RunCMD(psMachine, true);
                }

                path[i] = TestSetup.SetFileBasedDiskEnvironment(psMachine, hypervisor, type);
                firstScsiFilePath[i] = TestSetup.SetFileBasedDiskEnvironment(psMachine, hypervisor, type);

                if (i == 1)
                {
                    GetEmcESXHost getESXHost = new GetEmcESXHost(null, hypervisor);
                    getESXHost.PrefixString = hostPrefix;
                    getESXHost.RunCMD(psMachine, true);
                }
                TestSetup.SetLunEnvironment(psMachine, true, null, lun);
                TestSetup.SetLunEnvironment(psMachine, true, null, firstScsiLun);
                TestSetup.SetDiskEnvironment(psMachine, hostDisk, hostPrefix, lun, null, false);
                TestSetup.SetDiskEnvironment(psMachine, firstScsiDisk, hostPrefix, firstScsiLun, null, false);

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(hypervisor);
                updateSystem.RunCMD(psMachine);

                TestSetup.GetVirtualMachineConfiguration(psMachine, vmConfigPrefix, vm);
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            
            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                string hypervisor = HelperAdapter.GetParameter(hypervisors[i]);
                string vm = HelperAdapter.GetParameter("VirtualMachine") + i;
                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                string lun = HelperAdapter.GetParameter("Lun") + i;
                string firstScsiLun = HelperAdapter.GetParameter("Lun") + "First" + i;

                if (!string.IsNullOrEmpty(firstScsiFileDiskLocation[i]))
                {
                    RemoveEmcVirtualDiskFromVm rmFileDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, firstScsiFileDiskLocation[i], "Force", null, "0");
                    rmFileDisk.RunCMD(psMachine);
                }
                if (!string.IsNullOrEmpty(fileDiskLocation[i]))
                {
                    RemoveEmcVirtualDiskFromVm rmFileDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, fileDiskLocation[i], "Force", null, fileScsiController[i]["ScsiControllerIndex"]);
                    rmFileDisk.RunCMD(psMachine);
                }
                if (!string.IsNullOrEmpty(firstScsiPtDiskLocation[i]))
                {
                    RemoveEmcVirtualDiskFromVm rmPtDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, firstScsiPtDiskLocation[i], "Force", null, "0");
                    rmPtDisk.RunCMD(psMachine);
                }
                if (!string.IsNullOrEmpty(ptDiskLocation[i]))
                {
                    RemoveEmcVirtualDiskFromVm rmPtDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, ptDiskLocation[i], "Force", null, ptScsiController[i]["ScsiControllerIndex"]);
                    rmPtDisk.RunCMD(psMachine);
                }

                TestSetup.ClearFileBasedDiskEnvironment(psMachine, path[i], hypervisor);
                TestSetup.ClearFileBasedDiskEnvironment(psMachine, firstScsiFilePath[i], hypervisor);

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(vm);
                updateSystem.RunCMD(psMachine);

                if (i == 1)
                {
                    GetEmcESXHost getESXHost = new GetEmcESXHost(null, hypervisor);
                    getESXHost.PrefixString = HelperAdapter.GetParameter(hyperHost[i]);
                    getESXHost.RunCMD(psMachine, true);
                }

                TestSetup.ClearDiskEnvironment(psMachine, HelperAdapter.GetParameter( hyperHost[i]), null, lun);
                TestSetup.ClearDiskEnvironment(psMachine, HelperAdapter.GetParameter(hyperHost[i]), null, firstScsiLun);
                TestSetup.ClearLunEnvironment(psMachine, lun);
                TestSetup.ClearLunEnvironment(psMachine, firstScsiLun);
            }

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a RemoveEmcVirtualDiskFromVm instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>RemoveEmcVirtualDiskFromVm instance</returns>  
        public RemoveEmcVirtualDiskFromVm ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string virtualmachineconfiguration = null;
            string location = null;
            string force = null;
            string scsicontrollerid = null;
            string scsicontrollerindex = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion
#endif
            SortedList<string, string> diskConfig = null;
            string scsiController = null;
            vmIndex = 0;

            bool firstScsi = true;

            if (cmd.IndexOf("ScsiController", StringComparison.OrdinalIgnoreCase) > 0)
            {
                firstScsi = false;
            }

            if (cmd.IndexOf("HypervVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if ( !HelperAdapter.IsHyperVSet() )
                {
                    return null;
                }
                vmIndex = 0;
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
                cmdString = cmdString.Replace("$HypervVMConfig", virtualmachineconfiguration);
            }
            else if (cmd.IndexOf("VMWareVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if ( !HelperAdapter.IsVMwareSet() )
                {
                    return null;
                }
                vmIndex = 1;
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
                cmdString = cmdString.Replace("$VMWareVMConfig", virtualmachineconfiguration);
            }

            if (cmd.IndexOf("$FileDiskLocation", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (firstScsi)
                {
                    location = firstScsiFileDiskLocation[vmIndex];
                    diskConfig = firstScsiFileDiskConfig[vmIndex];
                }
                else
                {
                    location = fileDiskLocation[vmIndex];
                    diskConfig = fileDiskConfig[vmIndex];
                }
                
                cmdString = cmdString.Replace("$FileDiskLocation", location);
                diskType = DiskType.FilebasedDisk;
                
            }
            else if (cmd.IndexOf("$PtDiskLocation", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (firstScsi)
                {
                    location = firstScsiPtDiskLocation[vmIndex];
                    diskConfig = firstScsiPtDiskConfig[vmIndex];
                }
                else
                {
                    location = ptDiskLocation[vmIndex];
                    diskConfig = ptDiskConfig[vmIndex];
                }
                
                cmdString = cmdString.Replace("$PtDiskLocation", location);
                diskType = DiskType.PassthroughDisk;
            }

            scsiController = HelperAdapter.GetParameter("ScsiController") + vmIndex;
            if (cmd.IndexOf("$ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (firstScsi)
                {
                    scsicontrollerid = GetVMFirstScsiControllerId(psMachine, HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex);
                }
                else
                {
                    if (diskType == DiskType.FilebasedDisk)
                    {
                        scsicontrollerid = fileScsiController[vmIndex]["ScsiControllerId"];
                    }
                    else
                    {
                        scsicontrollerid = ptScsiController[vmIndex]["ScsiControllerId"];
                    }
                }
                cmdString = cmdString.Replace("$ScsiControllerId", "\"" + scsicontrollerid + "\"");
            }

            if (cmd.IndexOf("$ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (firstScsi)
                {
                    scsicontrollerindex = "0";
                }
                else
                {
                    if (diskType == DiskType.FilebasedDisk)
                    {
                        scsicontrollerindex = fileScsiController[vmIndex]["ScsiControllerIndex"];
                    }
                    else
                    {
                        scsicontrollerindex = ptScsiController[vmIndex]["ScsiControllerIndex"];
                    }
                }
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsicontrollerindex);
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            if (cmd.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }

            RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(virtualmachineconfiguration, location, force, scsicontrollerid, scsicontrollerindex, silent, whatif, cmdString);
            removeDisk.DiskConfig = diskConfig;
            removeDisk.VMIndex = vmIndex;

            return removeDisk;
        }
        

        /// <summary>  
        /// RemoveEmcVirtualDiskFromVmTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcVirtualDiskFromVmTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcVirtualDiskFromVm removeDisk = ParseCmd(cmd);

            if (removeDisk == null)
            {
                return;
            }

            removeDisk.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// RemoveEmcVirtualDiskFromVmNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcVirtualDiskFromVmNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcVirtualDiskFromVm removeDisk = ParseCmd(cmd);

            if (removeDisk == null)
            {
                return;
            }

            try
            {
                removeDisk.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removeDisk.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }

        private string GetVMFirstScsiControllerId(PowershellMachine psMachine, string vmConfig)
        {
            GetEmcVirtualMachineScsiController getScsiController = new GetEmcVirtualMachineScsiController(vmConfig);
            getScsiController.PrefixString = HelperAdapter.GetParameter("ScsiController");
            getScsiController.RunCMD(psMachine, true);

            string count = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("ScsiController"), "Count");
            if (!string.IsNullOrEmpty(count))
            {
                return TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("ScsiController") + "[0]", "ScsiControllerId");
            }
            else
            {
                return TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("ScsiController"), "ScsiControllerId");
            }
        }
    }
}

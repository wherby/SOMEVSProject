using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcFileBasedDiskTest: test class for Remove-EmcFileBasedDisk cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcFileBasedDiskTest
    {
        public RemoveEmcFileBasedDiskTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string vmwareFilePath;
        private static string hypervFilePath;
        private static string esxHostIp;
        private static string esxHostPassword;
        private static string esxHostUsername;
        private static string netShare;
        private static string datastorePath;
        private static string hypervPrefix = HelperAdapter.GetParameter("HyperV");
        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string type;
        private bool removeFlag = false;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (HelperAdapter.IsVMwareSet())
            {
                if (vmwareFilePath == null)
                {
                    vmwareFilePath = TestSetup.SetFileBasedDiskEnvironment(psMachine, vmwarePrefix, HyperVisorType.VMWare);
                }
            }
            if (HelperAdapter.IsHyperVSet())
            {
                if (hypervFilePath == null)
                {
                    hypervFilePath = TestSetup.SetFileBasedDiskEnvironment(psMachine, hypervPrefix, HyperVisorType.HyperV);
                }
            }           

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("Test Cleanup: Remove File Based Disk");
            if (type != null)
            {
                if (HelperAdapter.IsHyperVSet())
                {
                    if (removeFlag && type.Equals("vhd"))
                    {
                        TestSetup.ClearFileBasedDiskEnvironment(psMachine, hypervFilePath, hypervPrefix);
                        hypervFilePath = null;
                    }
                }
                if (HelperAdapter.IsVMwareSet())
                {
                    if (removeFlag && type.Equals("vmdk"))
                    {
                        TestSetup.ClearFileBasedDiskEnvironment(psMachine, vmwareFilePath, vmwarePrefix);
                        vmwareFilePath = null;
                    }
                }
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");

            if (HelperAdapter.IsHyperVSet())
            {
                // Connect to Hyper-V host
                string result = TestSetup.ConnectSystem(psMachine, "HyperV", hypervPrefix);
                string hypervIp = HelperAdapter.GenerateKeyValuePairs(result)["IpAddress"];

                netShare = "\\\\" + hypervIp + "\\";
            }
            if (HelperAdapter.IsVMwareSet())
            {
                // Connect to vCenter or ESX Host
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                string result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
                SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);

                esxHostUsername = keyValuePairs["UserName"];
                esxHostIp = keyValuePairs["IpAddress"];

                // Get ESX Host Password from VMWare.xml
                esxHostPassword = dic["Password"];

                // Get Specified Datastore
                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                string dataStoreName = HelperAdapter.Load(path, "DataStore")["Name"];
                GetEmcDataStore getEmcDataStore = new GetEmcDataStore(dataStoreName);
                result = getEmcDataStore.RunCMD(psMachine, true);
                string dataStoreUrl = HelperAdapter.GenerateKeyValuePairs(result)["Url"];
                datastorePath = dataStoreUrl + "/";
            }
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean UP Start--------");

            if (vmwareFilePath != null)
            {
                TestSetup.ClearFileBasedDiskEnvironment(psMachine, vmwareFilePath, vmwarePrefix);
            }
            if (hypervFilePath != null)
            {
                TestSetup.ClearFileBasedDiskEnvironment(psMachine, hypervFilePath, hypervPrefix);
            }

            // Disconnect Storage and Host System
            log.LogInfo("Class Cleanup:Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean UP End--------");            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcFileBasedDisk instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcFileBasedDisk instance</returns>  
        public RemoveEmcFileBasedDisk ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hypervisor = null;
            string path = null;
            string silent = null;
            string force = null;
            string whatif = null;

            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("hypervisor", StringComparison.OrdinalIgnoreCase) > 0)
            {               
                if (cmd.Contains("$Hyperv"))
                {
                    if (HelperAdapter.IsHyperVSet())
                    {
                        hypervisor = hypervPrefix;
                        type = "vhd";
                    }
                    else
                    {
                        return null;
                    }
                }
                else if (cmd.Contains("$VMWare"))
                {
                    if (HelperAdapter.IsVMwareSet())
                    {
                        hypervisor = vmwarePrefix;
                        type = "vmdk";
                    }
                    else
                    {
                        return null;
                    }
                }
                cmdString = cmdString.Replace("$Hypervisor", hypervisor);
            }

            if (cmd.IndexOf("path", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmd.Contains("$Hyperv"))
                {
                    path = "\"" + hypervFilePath + "\"";
                    type = "vhd";
                }
                else if (cmd.Contains("$VMWare"))
                {
                    path = "\"" + vmwareFilePath + "\"";
                    type = "vmdk";
                }
                cmdString = cmdString.Replace("$Path", path);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }

            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            RemoveEmcFileBasedDisk instance = new RemoveEmcFileBasedDisk(hypervisor, path, silent,  cmdString, force, whatif);
            return instance;
        }


        /// <summary>  
        /// Remove-EmcFileBasedDisk:
        ///    The method to implement Remove-EmcFileBasedDisk poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcFileBasedDiskTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcFileBasedDisk cmdClass = ParseCmd(cmd);

            if (cmdClass != null)
            {                
                cmdClass.VerifyTheCMD(psMachine, type, netShare, datastorePath, esxHostPassword, esxHostUsername, esxHostIp);
                if (!cmd.Contains("WhatIf"))
                {
                    if (cmd.Contains("$Hyperv"))
                    {
                        hypervFilePath = null;
                    }
                    if (cmd.Contains("$VMWare"))
                    {
                        vmwareFilePath = null;
                    }
                }
                else
                {
                    removeFlag = true;
                }
            }
            else
            {
                log.LogWarning(String.Format("Skip the command {0}", cmd));
            }
        }

        /// <summary>  
        /// RemoveEmcFileBasedDiskNegativeTestMethod:
        ///    The method to implement Remove-EmcFileBasedDisk negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcFileBasedDiskNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcFileBasedDisk removeemcfilebaseddiskClass = ParseCmd(cmd);

            if (removeemcfilebaseddiskClass != null)
            {
                try
                {
                    removeemcfilebaseddiskClass.VerifyTheCMD(psMachine, type, netShare, datastorePath, esxHostPassword, esxHostUsername, esxHostIp);
                }
                catch (PSException psEx)
                {
                    log.LogTestCase(string.Format("Test with {0} failed.", removeemcfilebaseddiskClass.GetFullString()));
                    log.LogTestCase(psEx.messageDetail);
                    caseFail = true;
                    removeFlag = true;
                }
                log.AreEqual<bool>(true, caseFail, "Negative test case result:");
            }
            else
            {
                log.LogWarning(String.Format("Skip the command {0}", cmd));
            }
        }
    }
}

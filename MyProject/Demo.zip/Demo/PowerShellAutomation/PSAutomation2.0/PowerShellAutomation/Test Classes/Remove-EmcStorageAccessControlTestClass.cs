using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcStorageAccessControlTest: test class for Remove-EmcStorageAccessControl cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcStorageAccessControlTest
    {
        public RemoveEmcStorageAccessControlTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string storageGlobalID;
        private static string poolName;
        private static bool removeFlag = false;

        private static string poolPrefix = HelperAdapter.GetParameter("Pool");
        private static string accessControlPrefix = HelperAdapter.GetParameter("AccessControl");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            AddEmcStorageAccessControl addEmcStorageAccessControl = new AddEmcStorageAccessControl(
                accessControlPrefix, poolPrefix);
            addEmcStorageAccessControl.VerifyTheCMD(psMachine, storageGlobalID, poolName);
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (removeFlag)
            {
                log.LogInfo("--------Test Clean Up Start---------");
                RemoveEmcStorageAccessControl removeEmcStorageAcceccControl =
                    new RemoveEmcStorageAccessControl(accessControlPrefix, poolPrefix);

                removeEmcStorageAcceccControl.VerifyTheCMD(psMachine, storageGlobalID, poolName);
                log.LogInfo("--------Test Clean Up End---------");
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");  

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine, "All");
            string result = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalID = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Select a random pool          
            log.LogInfo("Class Initialize: Get Storage Pool");
            result = TestSetup.SetPoolEnvironment(psMachine, null, null, null, null, TestSetup.StorageSystemType);
            poolName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];
           

            // New Access Control
            log.LogInfo("Class Initialize: New Access Control");
            NewEmcStorageAccessControl accessControl = new NewEmcStorageAccessControl();
            accessControl.PrefixString = accessControlPrefix;
            accessControl.VerifyTheCMD(psMachine);

            log.LogInfo("--------Class Initialize End--------");  
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Disconnect Storage System
            log.LogInfo("Class Cleanup:Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcStorageAccessControl instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcStorageAccessControl instance</returns>  
        public RemoveEmcStorageAccessControl ParseCmd(string cmd)
        {
            #region AutoGenerate
            string accesscontrol = null;
            string pool = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("accesscontrol", StringComparison.OrdinalIgnoreCase) > 0)
            {
                accesscontrol = accessControlPrefix;
                cmdString = cmdString.Replace("$AccessControl", accesscontrol);
            }
            if (cmd.IndexOf("pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = poolPrefix;
                cmdString = cmdString.Replace("$Pool", pool);
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            
            RemoveEmcStorageAccessControl instance = new RemoveEmcStorageAccessControl(accesscontrol, pool, silent,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Remove-EmcStorageAccessControl:
        ///    The method to implement Remove-EmcStorageAccessControl poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcStorageAccessControlTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcStorageAccessControl cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, storageGlobalID, poolName);
        }

        /// <summary>  
        /// RemoveEmcStorageAccessControlNegativeTestMethod:
        ///    The method to implement Remove-EmcStorageAccessControl negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcStorageAccessControlNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcStorageAccessControl removeemcstorageaccesscontrolClass = ParseCmd(cmd);

            try
            {
                removeemcstorageaccesscontrolClass.VerifyTheCMD(psMachine, storageGlobalID, poolName);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removeemcstorageaccesscontrolClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
                removeFlag = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

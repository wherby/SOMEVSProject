using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using System.Threading;

using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RestoreEmcSnapshotLunTest: test class for Restore-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class RestoreEmcSnapshotLunTest
    {
        public RestoreEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string sourceFile = "test_orig.txt";
        private static string file = "test";
        private static string driveLetter;
        private static string hostDiskPath;
        private static string snapshotLunID;
        private static string content;

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string sourceLunPrefix = HelperAdapter.GetParameter("Lun");
        private static string hostPrefix = HelperAdapter.GetParameter("Host");

        private bool setDiskOnline = false;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            
            // Append content to the file located on host disk
            log.LogInfo("Test Initialize: Append content to the file located on Host Disk");
            Thread.Sleep(1000);

            content = TestSetup.GetPropertyValue(psMachine, "Get-Date");
            TestSetup.AddContent(psMachine, hostDiskPath, content);
            if (TestSetup.CompareFiles(psMachine, sourceFile, hostDiskPath))
            {
                log.LogError("Failed to add conetent to the Host Disk");
                PSException pe = new PSException("Failed to add conetent to the Host Disk");
                throw pe;
            }
            TestSetup.SetHostDiskOnline(psMachine, false);

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (setDiskOnline)
            {
                TestSetup.SetHostDiskOnline(psMachine, true);
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Connect to EMC Host system
            log.LogInfo("Class Initialize: Connect Host System");
            string result = TestSetup.ConnectSystem(psMachine, "Host", HelperAdapter.GetParameter("Host"));   
            string ip = HelperAdapter.GenerateKeyValuePairs(result)["IpAddress"];
           
            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            // Unmask Disk, Find and Initialize Host Disk
            log.LogInfo("Class Initialize: Unmask and Initialize Disk");
            TestSetup.SetDiskEnvironment(psMachine);

            // Create Volume and Mount to MountPoint
            log.LogInfo("Class Initialize: Create Volume and Mount to MountPoint");
            TestSetup.SetVolumeEnvironment(psMachine, null, null, null, null, MountPoint.DriveLetter);
            result = TestSetup.UpdateHostVolumeInfo(psMachine);
            hostDiskPath = HelperAdapter.GenerateNetSharePath(result, ip, file);
            
            // Copy a file to the host disk
            log.LogInfo("Class Initialize: Copy a file to the Host Disk");
            TestSetup.CreateFile(psMachine, sourceFile);
            TestSetup.CopyItem(psMachine, sourceFile, hostDiskPath);

            // Create Snapshot Lun
            log.LogInfo("Class Initialize: Create a Snapshot for the Host Disk");            
            
            Thread.Sleep(5000);
            TestSetup.SetHostDiskOnline(psMachine, false);

            // Drive letter may be changed
            result = TestSetup.UpdateHostVolumeInfo(psMachine);
            hostDiskPath = HelperAdapter.GenerateNetSharePath(result, ip, file);

            result = TestSetup.SetSnapshotLunEnvironment(psMachine, snapshotLunPrefix, sourceLunPrefix);
            if (TestSetup.StorageSystemType == "VNXe")
            {
                snapshotLunID = HelperAdapter.GenerateKeyValuePairs(result)["Name"];
            }
            else
            {
                snapshotLunID = HelperAdapter.GenerateKeyValuePairs(result)["Wwn"];
            }
            Thread.Sleep(5000);
           
            TestSetup.SetHostDiskOnline(psMachine, true);
            result = TestSetup.UpdateHostVolumeInfo(psMachine);
            driveLetter = HelperAdapter.GenerateKeyValuePairs(result)["MountPath"];
            hostDiskPath = HelperAdapter.GenerateNetSharePath(result, ip, file);
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            // Remove SnapshotLun
            TestSetup.ClearSnapshotLunEnvironment(psMachine, snapshotLunID, snapshotLunPrefix);

            // Remove File
            TestSetup.RemoveItem(psMachine, hostDiskPath);
            TestSetup.RemoveItem(psMachine, sourceFile);

            // Set Disk offline
            log.LogInfo("Class Cleanup: Set Host Disk Offline");
            TestSetup.SetHostDiskOnline(psMachine, false);

            // Mask Disk
            log.LogInfo("Class Cleanup: Mask the Lun");
            TestSetup.ClearDiskEnvironment(psMachine, HelperAdapter.GetParameter("Host"));

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Restore-EmcSnapshotLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Restore-EmcSnapshotLun instance</returns>  
        public RestoreEmcSnapshotLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string snapshotlun = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotlun = HelperAdapter.GetParameter("SnapshotLun");
                cmdString = cmdString.Replace("$SnapshotLun", snapshotlun);
            }


            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }

            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            
            RestoreEmcSnapshotLun instance = new RestoreEmcSnapshotLun(snapshotlun, force, silent, whatif,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Restore-EmcSnapshotLun:
        ///    The method to implement Restore-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RestoreEmcSnapshotLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RestoreEmcSnapshotLun cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, hostDiskPath, driveLetter, content);
            
        }

        /// <summary>  
        /// RestoreEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement Restore-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RestoreEmcSnapshotLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RestoreEmcSnapshotLun restoreemcsnapshotlunClass = ParseCmd(cmd);

            try
            {
                restoreemcsnapshotlunClass.VerifyTheCMD(psMachine, hostDiskPath, driveLetter, content);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", restoreemcsnapshotlunClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
                setDiskOnline = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

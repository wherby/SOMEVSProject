using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcStandByLunTest: test class for New-EmcStandByLun cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcStandByLunTest
    {
        public NewEmcStandByLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string resultForStandByLun;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            resultForStandByLun = null;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (resultForStandByLun != null)
            {
                TestSetup.RemoveStandbyLunEnvironment(psMachine);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            TestSetup.ConnectSystem(psMachine, "VMAX");
            TestSetup.SetPoolEnvironment(psMachine, "True", "5", "Pool", null, "VMAX");

        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a New-EmcStandByLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>New-EmcStandByLun instance</returns>  
        public NewEmcStandByLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string storagesystem = null;
            string count = null;
            string capacity = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string storagesystemString = HelperAdapter.GetParameter("System");
            string countString = HelperAdapter.GetParameter("CountForStandByLun", "LunConfig");
            string capacityString = HelperAdapter.GetParameter("CapacityForStandByLun", "LunConfig");
            if (cmd.IndexOf("$StorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagesystem = storagesystemString;
                cmd = cmd.Replace("$StorageSystem", storagesystem);
            }
            if (cmd.IndexOf("$Count", StringComparison.OrdinalIgnoreCase) > 0)
            {
                count = countString;
                cmd = cmd.Replace("$Count", count);
            }
            if (cmd.IndexOf("$Capacity", StringComparison.OrdinalIgnoreCase) > 0)
            {
                capacity = capacityString;
                cmd = cmd.Replace("$Capacity", capacity);
            }
            NewEmcStandByLun instance = new NewEmcStandByLun(storagesystem, count, capacity, silent,  cmd);
            instance.PrefixString = HelperAdapter.GetParameter("StandByLuns");
            return instance;
        }


        /// <summary>  
        /// New-EmcStandByLun:
        ///    The method to implement New-EmcStandByLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcStandByLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            NewEmcStandByLun cmdClass = ParseCmd(cmd);

            resultForStandByLun=cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// NewEmcStandByLunNegativeTestMethod:
        ///    The method to implement New-EmcStandByLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcStandByLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcStandByLun newemcstandbylunClass = ParseCmd(cmd);

            try
            {
                resultForStandByLun= newemcstandbylunClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", newemcstandbylunClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

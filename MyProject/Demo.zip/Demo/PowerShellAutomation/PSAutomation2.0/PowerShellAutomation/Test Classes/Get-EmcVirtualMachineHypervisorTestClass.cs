using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcVirtualMachineHypervisorTest: test class for Get-EmcVirtualMachineHypervisor cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcVirtualMachineHypervisorTest
    {
        public GetEmcVirtualMachineHypervisorTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string hypervPrefix = HelperAdapter.GetParameter("HyperV");
        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string xenServerPrefix = HelperAdapter.GetParameter("XenServer");
        private static string vmPrefix = HelperAdapter.GetParameter("VirtualMachine");
        private static string vmwareVMPrefix = vmPrefix + "_vmware";
        private static string hypervVMPrefix = vmPrefix + "_hyperv";
        private static string xenVMPrefix = vmPrefix + "_xen";
        private static string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
        private static string vmwareVMConfigPrefix = vmConfigPrefix + "_vmware";
        private static string hypervVMConfigPrefix = vmConfigPrefix + "_hyperv";
        private static string xenVMConfigPrefix = vmConfigPrefix + "_xen";
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to Hypervisor         
            if (HelperAdapter.IsHyperVSet())
            {
                TestSetup.ConnectSystem(psMachine, "Hyperv", hypervPrefix);
                UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(hypervPrefix);
                updateEmcSystem.RunCMD(psMachine);

                TestSetup.ConnectVirtualMachine(psMachine, HyperVisorType.HyperV, hypervVMPrefix);
                TestSetup.GetVirtualMachineConfiguration(psMachine, hypervVMConfigPrefix, hypervVMPrefix);
            }
            if (HelperAdapter.IsVMwareSet())
            {
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
                UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(vmwarePrefix);
                updateEmcSystem.RunCMD(psMachine);

                TestSetup.ConnectVirtualMachine(psMachine, HyperVisorType.VMWare, vmwareVMPrefix);
                TestSetup.GetVirtualMachineConfiguration(psMachine, vmwareVMConfigPrefix, vmwareVMPrefix);
            }
            if (HelperAdapter.IsXenSet())
            {
                TestSetup.ConnectSystem(psMachine, "XenServer", xenServerPrefix);
                UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(xenServerPrefix);
                updateEmcSystem.RunCMD(psMachine);

                TestSetup.ConnectVirtualMachine(psMachine, HyperVisorType.XenServer, xenVMPrefix);
                TestSetup.GetVirtualMachineConfiguration(psMachine, xenVMConfigPrefix, xenVMPrefix);
            }
         

            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcVirtualMachineHypervisor instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcVirtualMachineHypervisor instance</returns>  
        public GetEmcVirtualMachineHypervisor ParseCmd(string cmd)
        {
            
            #region AutoGenerate
            string virtualmachineconfiguration = null;
            string silent = null;
            string virtualmachine = null;


            string cmdString = cmd;
   
            #endregion


            if (cmd.IndexOf("$HypervVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsHyperVSet())
                {
                    virtualmachineconfiguration = hypervVMConfigPrefix;
                    cmdString = cmdString.Replace("$HypervVMConfig", virtualmachineconfiguration);
                }
                else
                {
                    log.BypassTest();
                }
            }
            if (cmd.IndexOf("$VMWareVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsVMwareSet())
                {
                    virtualmachineconfiguration = vmwareVMConfigPrefix;
                    cmdString = cmdString.Replace("$VMWareVMConfig", virtualmachineconfiguration);
                }
                else
                {
                    log.BypassTest();
                }
            }
            if (cmd.IndexOf("$XenVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsXenSet())
                {
                    virtualmachineconfiguration = xenVMConfigPrefix;
                    cmdString = cmdString.Replace("$XenVMConfig", virtualmachineconfiguration);
                }
                else
                {
                    log.BypassTest();
                }
            }

            if (cmd.IndexOf("$HypervVirtualMachine", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsHyperVSet())
                {
                    virtualmachine = hypervVMPrefix;
                    cmdString = cmdString.Replace("$HypervVirtualMachine", virtualmachine);
                }
                else
                {
                   log.BypassTest();
                }
            }
            if (cmd.IndexOf("$VMWareVirtualMachine", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsVMwareSet())
                {
                    virtualmachine = vmwareVMPrefix;
                    cmdString = cmdString.Replace("$VMWareVirtualMachine", virtualmachine);
                }
                else
                {
                    log.BypassTest();
                }
            }
            if (cmd.Contains("$XenVirtualMachine"))
            {
                if (HelperAdapter.IsXenSet())
                {
                    virtualmachine = xenVMPrefix;
                    cmdString = cmdString.Replace("$XenVirtualMachine", virtualmachine);
                }
                else
                {
                    log.BypassTest();
                }
            }    

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcVirtualMachineHypervisor hyperv = new GetEmcVirtualMachineHypervisor(virtualmachineconfiguration, silent, virtualmachine, cmdString);

            return hyperv;
        }

        /// <summary>  
        /// GetEmcVirtualMachineHypervisorTestMethod:
        ///    The method to implement Get-EmcVirtualMachineHypervisor poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualMachineHypervisorTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcVirtualMachineHypervisor hypervisor = ParseCmd(cmd);
            hypervisor.VerifyTheCMD(psMachine, hypervPrefix, vmwarePrefix, xenServerPrefix);
            
        }

        /// <summary>  
        /// GetEmcVirtualMachineHypervisorNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineHypervisor negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualMachineHypervisorNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcVirtualMachineHypervisor hypervisor = ParseCmd(cmd);
            
            try
            {
                hypervisor.VerifyTheCMD(psMachine, hypervPrefix, vmwarePrefix, xenServerPrefix);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", hypervisor.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");
           
        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class NewEmcLunTest
    {
        public NewEmcLunTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        /// <summary>
        /// The field is for wwn frield of created Lun.
        /// </summary>
        private string wwn=null;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       



        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            wwn = null;
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            if (wwn != null)
            {
                GetEmcLun getLun = new GetEmcLun(wwn);
                getLun.PrefixString = "$temp";
                getLun.RunCMD(psMachine, true);
                RemoveEmcLun rmLun = new RemoveEmcLun("$temp");
                rmLun.VerifyTheCMD(psMachine);
            }
            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            if (HelperAdapter.IsClusterSet())
            {
                string clusterSystemString = HelperAdapter.GetParameter("Cluster");
                TestSetup.ConnectSystem(psMachine, "Cluster", clusterSystemString);
            }
            TestSetup.SetHBAEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }


        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }     

       
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public static NewEmcLun ParseCmd(string cmd)
        {
            cmd = cmd.Replace("Capacity", "Capacity");
            string path = HelperAdapter.GetProperty("LunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            string thinString = "Thin";
            string descriptionString = dic["Description"];
            string silentString = "Silent";
            //Not used.
            string ApplicationHintString = HelperAdapter.GetParameter("ApplicationHint","LunConfig");

            #region AutoGenerate
            string pool = null;
            string capacity = null;
            string name = null;
            string applicationhint = null;
            string thin = null;
            string description = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion


            string nameString = HelperAdapter.GenerateName(dic["NamePrefix"]);
            string capacityString = dic["Capacity"];
            string poolString = HelperAdapter.GetParameter("Pool") ;

            string hostbusAdapterString = HelperAdapter.GetParameter("HostbusAdapter");
            string hostSystemString = HelperAdapter.GetParameter("Host");
            string clusterSystemString = HelperAdapter.GetParameter("Cluster");


            if (cmdString.IndexOf("$pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = poolString;
                cmdString = cmdString.Replace("$Pool", poolString);
            }
            if (cmdString.IndexOf("$name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = nameString;
                cmdString = cmdString.Replace("$Name", nameString);
            }
            if (cmdString.IndexOf("$Capacity", StringComparison.OrdinalIgnoreCase) > 0)
            {
                capacity = capacityString;
                cmdString = cmdString.Replace("$Capacity", capacityString);
            }
            if (cmdString.IndexOf("$ApplicationHint", StringComparison.OrdinalIgnoreCase) > 0)
            {
                applicationhint = ApplicationHintString;
                cmdString = cmdString.Replace("$ApplicationHint", applicationhint);
            }
            if (cmdString.IndexOf(("thin"), StringComparison.OrdinalIgnoreCase) > 0)
            {
                thin = thinString;
                cmdString = cmdString.Replace("$Thin", "");
                if (TestSetup.StorageSystemType == "VMAX")
                {
                    thin = null;
                    cmdString = cmdString.Replace("-Thin", "");
                }
            }
            if (cmdString.IndexOf("$description", StringComparison.OrdinalIgnoreCase) > 0)
            {
                description = descriptionString;
                cmdString = cmdString.Replace("$Description", descriptionString);
            }
            if (cmdString.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = silentString;
                cmdString = cmdString.Replace("$Silent", "");
            }

            NewEmcLun lun = new NewEmcLun(pool, capacity, name, applicationhint, thin, description, silent, cmdString);

            return lun;
        }

        public void NewEmcLunTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            NewEmcLun newLun = ParseCmd(cmd);
            string result=newLun.VerifyTheCMD(psMachine);
            SortedList<string, string> lunKeyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            wwn = lunKeyValuePairs["Wwn"];
        }

        public void NewEmcLunNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            NewEmcLun newLun = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                string result = newLun.VerifyTheCMD(psMachine);
                SortedList<string, string> lunKeyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
                wwn = lunKeyValuePairs["Wwn"];
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }


}

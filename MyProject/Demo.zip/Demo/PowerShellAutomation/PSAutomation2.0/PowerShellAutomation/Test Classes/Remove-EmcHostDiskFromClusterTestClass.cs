using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;
using System.Threading;

using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class RemoveEmcHostDiskFromClusterTest
    {
        public RemoveEmcHostDiskFromClusterTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string groupName;

        private static string[] resourceName;

        private static string[] lunPrefix;

        private static string[] diskPrefix;

        private static string[] volumePrefix;

        private static string[] lunIdPrefix;

        private static string[] clusterDiskPrefix;

        private static int index;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            string cluster = HelperAdapter.GetParameter("Cluster");
            string result = string.Empty;
            string group = null;
            string addToVolume = null;

            for (int i = 0; i < 2; i++)
            {
                if (i == 0)
                {
                    group = groupName;
                    addToVolume = null;
                }
                else
                {
                    group = null;
                    addToVolume = "AddToClusterSharedVolume";
                }

                if (resourceName[i] != string.Empty && resourceName[i] != null)
                {
                    GetEmcClusterDisk getDisk = new GetEmcClusterDisk(resourceName[i], cluster);
                    result = getDisk.RunCMD(psMachine);
                }

                if (result == string.Empty)
                {
                    AddEmcHostDiskToCluster addDisk = new AddEmcHostDiskToCluster( lunIdPrefix[i], cluster, group, null, addToVolume);
                    addDisk.PrefixString = clusterDiskPrefix[i];
                    result = addDisk.RunCMD(psMachine, true);
                }

                SortedList<string, string> clusterDisk = HelperAdapter.GenerateKeyValuePairs(result);

                resourceName[i] = clusterDisk["ClusterDiskResourceName"];
            }
            
            log.LogInfo("--------Test Initialize End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsClusterSet())
            {
                log.BypassTest();
            }

            string cluster = HelperAdapter.GetParameter("Cluster");
            lunPrefix = new string[2] {HelperAdapter.GetParameter("Lun"), HelperAdapter.GetParameter("Lun") + "1"};
            diskPrefix = new string[2] { HelperAdapter.GetParameter("Disk"), HelperAdapter.GetParameter("Disk") + "1" };
            volumePrefix = new string[2] { HelperAdapter.GetParameter("Volume"), HelperAdapter.GetParameter("Volume") + "1" };
            lunIdPrefix = new string[2] { HelperAdapter.GetParameter("LunIdentifier"), HelperAdapter.GetParameter("LunIdentifier") + "1" };
            clusterDiskPrefix = new string[2] { HelperAdapter.GetParameter("ClusterDisk"), HelperAdapter.GetParameter("ClusterDisk") + "1" };

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);

            string clusterResult = TestSetup.ConnectSystem(psMachine, "Cluster", cluster);

            for (int i = 0; i < 2; i++)
            {
                TestSetup.SetLunEnvironment(psMachine, true, null, lunPrefix[i]);

                SortedList<string, string> clusterKeyValue = HelperAdapter.GenerateKeyValuePairs(clusterResult);

                string result = TestSetup.SetDiskEnvironment(psMachine, diskPrefix[i], null, lunPrefix[i], cluster);

                try
                {
                    TestSetup.SetVolumeEnvironment(psMachine, diskPrefix[i], null, cluster, volumePrefix[i]);
                }
                catch
                {
                    log.LogWarning("New Volume Error");
                }

                GetEmcHostLunIdentifier lunId = new GetEmcHostLunIdentifier(lunPrefix[i], null, cluster);
                lunId.PrefixString = lunIdPrefix[i];
                lunId.RunCMD(psMachine, true);
            }
                
            GetEmcClusterGroup getGroup = new GetEmcClusterGroup(cluster);
            string groupResult = getGroup.RunCMD(psMachine, true);

            List<SortedList<string, string>> groupList = HelperAdapter.GenerateKeyValuePairsList(groupResult);
            groupName = groupList[0]["Name"];

            resourceName = new string[2];

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            string cluster = HelperAdapter.GetParameter("Cluster");

            for (int i = 0; i < 2; i++)
            {
                TestSetup.ClearClusterDiskEnvironment(psMachine, diskPrefix[i], cluster);
                TestSetup.ClearVolumeEnvironment(psMachine, volumePrefix[i], null, cluster);
                TestSetup.ClearDiskEnvironment(psMachine, null, cluster, lunPrefix[i]);
                TestSetup.ClearLunEnvironment(psMachine, lunPrefix[i]);
            }

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a RemoveEmcHostDiskFromCluster instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>RemoveEmcHostDiskFromCluster instance</returns>  
        public RemoveEmcHostDiskFromCluster ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string clusterdisk = null;
            string force = null;
            string silent = null;
            string whatif = null;
            string clustersystem = null;
            string hostlunidentifier = null;
            string hostdisk = null;


            string cmdString = cmd;
   
            #endregion
#endif

            Random rd = new Random();
            index = rd.Next(0, 1);

            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustersystem = HelperAdapter.GetParameter("Cluster");
                cmdString = cmdString.Replace("$ClusterSystem", clustersystem);
            }
            if (cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostlunidentifier = lunIdPrefix[index];
                cmdString = cmdString.Replace("$HostLunIdentifier", hostlunidentifier);
            }
            if (cmdString.IndexOf("$HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostdisk = diskPrefix[index];
                cmdString = cmdString.Replace("$HostDisk", hostdisk);
            }
            if (cmdString.IndexOf("$ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterdisk = clusterDiskPrefix[index];
                cmdString = cmdString.Replace("$ClusterDisk", clusterdisk);
            }
            if (cmdString.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmdString.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            RemoveEmcHostDiskFromCluster removeDisk = new RemoveEmcHostDiskFromCluster(clusterdisk, force, silent, whatif, clustersystem, hostlunidentifier, hostdisk, cmdString);

            return removeDisk;
        }

       public void RemoveEmcHostDiskFromClusterTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            RemoveEmcHostDiskFromCluster removeDisk = ParseCmd(cmd);

            removeDisk.VerifyTheCMD(psMachine, resourceName[index]);
        }


        public void RemoveEmcHostDiskFromClusterNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            bool failCMD = false;

            RemoveEmcHostDiskFromCluster removeDisk = ParseCmd(cmd);
            
            try
            {
                removeDisk.VerifyTheCMD(psMachine, resourceName[index]);
            }
            catch (PSException pe)
            {
                failCMD = true;

                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}


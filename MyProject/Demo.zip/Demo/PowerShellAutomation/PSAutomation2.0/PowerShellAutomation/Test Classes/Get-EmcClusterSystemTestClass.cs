using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcClusterSystemTest
    {
        public GetEmcClusterSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static SortedList<string, string> clusterKeyValue;
        private static string storageGlobalId;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        #region Additional test attributes
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsClusterSet())
            {
                log.BypassTest();
            }

            string cluster = HelperAdapter.GetParameter("Cluster");
            string clusterDisk = HelperAdapter.GetParameter("ClusterDisk");
            string hostDisk = HelperAdapter.GetParameter("Disk");

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            string storageResult = TestSetup.ConnectSystem(psMachine, storage);
            SortedList<string, string> storageKeyValue = HelperAdapter.GenerateKeyValuePairs(storageResult);
            storageGlobalId = storageKeyValue["GlobalId"];

            string result = TestSetup.ConnectSystem(psMachine, "Cluster", cluster);
            clusterKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            TestSetup.SetDiskEnvironment(psMachine, hostDisk, null, null, cluster);
            TestSetup.SetVolumeEnvironment(psMachine, hostDisk, null, cluster);
            TestSetup.SetClusterDiskEnvironment(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            TestSetup.ClearClusterDiskEnvironment(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine, null, HelperAdapter.GetParameter("Cluster"), null);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcClusterSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public GetEmcClusterSystem ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string id = null;
            string silent = null;
            string clusterdisk = null;


            string cmdString = cmd;
   
            #endregion
#endif

            
            if (cmd.IndexOf("ClusterName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = clusterKeyValue["Name"];
                cmdString = cmdString.Replace("$ClusterName", id);
            }
            else if (cmd.IndexOf("IPAddress", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = clusterKeyValue["IpAddress"];
                cmdString = cmdString.Replace("$IPAddress", id);
            }
            else if (cmd.IndexOf("GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = clusterKeyValue["GlobalId"];
                cmdString = cmdString.Replace("$GlobalId", id);
            }

            if (cmd.IndexOf("ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterdisk = HelperAdapter.GetParameter("ClusterDisk"); ;
                cmdString = cmdString.Replace("$ClusterDisk", clusterdisk);
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcClusterSystem clusterSystem = new GetEmcClusterSystem(id, silent, clusterdisk, cmdString);
            clusterSystem.ConnectSystemKeyValue = clusterKeyValue;

            return clusterSystem;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcClusterSystemTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            GetEmcClusterSystem system = ParseCmd(cmd);

            system.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcClusterSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            bool caseFail = false;

            GetEmcClusterSystem system = ParseCmd(cmd);

            try
            {
                system.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");
        }

    }

}

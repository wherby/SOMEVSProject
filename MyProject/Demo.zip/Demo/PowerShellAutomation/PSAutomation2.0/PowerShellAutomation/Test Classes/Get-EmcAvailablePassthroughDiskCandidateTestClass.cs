using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcAvailablePassthroughDiskCandidateTest: test class for Get-EmcAvailablePassthroughDiskCandidate cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcAvailablePassthroughDiskCandidateTest
    {
        public GetEmcAvailablePassthroughDiskCandidateTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string hypervDiskResult = null;
        private static string vmwareDiskResult = null;

        private static string hypervPrefix = HelperAdapter.GetParameter("HyperV");
        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string esxHostPrefix = HelperAdapter.GetParameter("ESXHost");
        private static string lunPrefix = HelperAdapter.GetParameter("Lun");
        private static string hypervLunPrefix = lunPrefix + "_hyperv";
        private static string vmwareLunPrefix = lunPrefix + "_vmware";
        private static string diskPrefix = HelperAdapter.GetParameter("Disk");
        private static string hypervDiskPrefix = diskPrefix + "_hyperv";
        private static string vmwareDiskPrefix = diskPrefix + "_vmware";
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            if (HelperAdapter.IsHyperVSet())
            {
                // Connect to Hyper-V          
                log.LogInfo("Class Initialize: Connect to Hypervisor");
                string result = TestSetup.ConnectSystem(psMachine, "Hyperv", hypervPrefix);

                // Create Source Lun
                log.LogInfo("Class Initialize: Create Source Lun");
                TestSetup.SetPoolEnvironment(psMachine);
                TestSetup.SetLunEnvironment(psMachine, true, null, hypervLunPrefix);

                // Unmask Disk and Find Host Disk (if a disk is initialized, the disk cannot be used as Passthrough disk)
                hypervDiskResult = TestSetup.SetDiskEnvironment(psMachine, hypervDiskPrefix, hypervPrefix, hypervLunPrefix, null, false);
                if (String.IsNullOrEmpty(hypervDiskResult))
                {
                    PSException pe = new PSException("Find-EmcHostDisk failed");
                    throw pe;
                }
                Thread.Sleep(30000);
                UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(hypervPrefix);
                updateEmcSystem.RunCMD(psMachine);
            }

            if (HelperAdapter.IsVMwareSet())
            {
                // Connect to ESX Host
                log.LogInfo("Class Initialize: Connect to ESX Host");
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                string result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);

                // Get ESX Host
                TestSetup.SetESXHostEnvironment(psMachine, esxHostPrefix, vmwarePrefix);

                // Create Source Lun
                log.LogInfo("Class Initialize: Create Source Lun");
                TestSetup.SetPoolEnvironment(psMachine);
                TestSetup.SetLunEnvironment(psMachine, true, null, vmwareLunPrefix);

                //Unmask Lun to ESX Host and Find the host disk
                log.LogInfo("Class Initialize: Unmask Lun and rescan host disk");
                vmwareDiskResult = TestSetup.SetDiskEnvironment(psMachine, vmwareDiskPrefix, esxHostPrefix, vmwareLunPrefix, null, false);
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            if (HelperAdapter.IsHyperVSet())
            {
                // Mask Disk
                log.LogInfo("Class Cleanup: Mask the Lun");
                TestSetup.ClearDiskEnvironment(psMachine, hypervPrefix, null, hypervLunPrefix);

                // Remove Source Lun 
                log.LogInfo("Class Cleanup: Remove Source Lun");
                TestSetup.ClearLunEnvironment(psMachine, hypervLunPrefix);
            }

            if (HelperAdapter.IsVMwareSet())
            {
                // Mask Disk
                log.LogInfo("Class Cleanup: Mask the Lun");
                TestSetup.ClearDiskEnvironment(psMachine, esxHostPrefix, null, vmwareLunPrefix);

                // Remove Source Lun 
                log.LogInfo("Class Cleanup: Remove Source Lun");
                TestSetup.ClearLunEnvironment(psMachine, vmwareLunPrefix);
            }

            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcAvailablePassthroughDiskCandidate instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcAvailablePassthroughDiskCandidate instance</returns>  
        public GetEmcAvailablePassthroughDiskCandidate ParseCmd(string cmd)
        {           
            #region AutoGenerate
            string hypervisor = null;
            string silent = null;
            string esxhostsystem = null;


            string cmdString = cmd;
   
            #endregion


            if (cmd.IndexOf("$Hyperv", StringComparison.OrdinalIgnoreCase) > 0 )
            {
                if (HelperAdapter.IsHyperVSet())
                {
                    hypervisor = hypervPrefix;
                    cmdString = cmdString.Replace("$Hyperv", hypervisor);
                }
                else
                {
                    log.BypassTest();
                }
            }
            if (cmd.IndexOf("$VMWare", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsVMwareSet())
                {
                    hypervisor = vmwarePrefix;
                    cmdString = cmdString.Replace("$VMWare", hypervisor);
                }
                else
                {
                    log.BypassTest();
                }
            }
            if (cmd.IndexOf("EsxHostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsVMwareSet())
                {
                    esxhostsystem = esxHostPrefix;
                    cmdString = cmdString.Replace("$EsxHostSystem", esxhostsystem);
                }
                else
                {
                    log.BypassTest();
                }
            }    
            
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcAvailablePassthroughDiskCandidate availablePassthroughDiskCandidate = new GetEmcAvailablePassthroughDiskCandidate(hypervisor, silent, esxhostsystem, cmdString);

            return availablePassthroughDiskCandidate;
        }

        /// <summary>  
        /// GetEmcAvailablePassthroughDiskCandidateTestMethod:
        ///    The method to implement Get-EmcAvailablePassthroughDiskCandidate poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcAvailablePassthroughDiskCandidateTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcAvailablePassthroughDiskCandidate availablePassthroughDiskCandidate = ParseCmd(cmd);

            availablePassthroughDiskCandidate.VerifyTheCMD(psMachine, hypervDiskResult, vmwareDiskResult);
            
        }

        /// <summary>  
        /// GetEmcAvailablePassthroughDiskCandidateNegativeTestMethod:
        ///    The method to implement Get-EmcAvailablePassthroughDiskCandidate negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcAvailablePassthroughDiskCandidateNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcAvailablePassthroughDiskCandidate availablePassthroughDiskCandidate = ParseCmd(cmd);

            try
            {
                availablePassthroughDiskCandidate.VerifyTheCMD(psMachine, hypervDiskResult, vmwareDiskResult);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", availablePassthroughDiskCandidate.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");
       
        }
    }
}

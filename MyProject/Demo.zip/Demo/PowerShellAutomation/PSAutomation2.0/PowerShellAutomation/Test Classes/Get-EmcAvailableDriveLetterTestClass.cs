using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcAvailableDriveLetterTest
    {
        public GetEmcAvailableDriveLetterTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;


        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine,systemName);
            TestSetup.SetHostEnvironment(psMachine);
            if (HelperAdapter.IsClusterSet())
            {
                //Set cluster environment.
                string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcAvailableDriveLetter instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcAvailableDriveLetter instance</returns>  
        public GetEmcAvailableDriveLetter ParseCmd(string cmd)
        {



            #region AutoGenerate
            string hostsystem = null;
            string silent = null;
            string clustersystem = null;


            string cmdString = cmd;
   
            #endregion


            string hostSystemString =HelperAdapter.GetParameter("Host");
            string silentString = "Silent";
            string clusterSystemString = HelperAdapter.GetParameter("Cluster");





            if (cmdString.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostSystemString;
                cmdString = cmdString.Replace("$HostSystem", hostSystemString);
            }
            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustersystem = clusterSystemString;
                cmdString = cmdString.Replace("$ClusterSystem", clusterSystemString);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = silentString;
            }
            GetEmcAvailableDriveLetter getDriverLetter = new GetEmcAvailableDriveLetter(hostsystem, silent, clustersystem, cmdString);

            return getDriverLetter;
        }



        public void GetEmcAvailableDriveLetterTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            GetEmcAvailableDriveLetter getDriverLetter = ParseCmd(cmd);
            getDriverLetter.VerifyTheCMD(psMachine);
        }


        public void GetEmcAvailableDriveLetterNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            GetEmcAvailableDriveLetter getDriverLetter = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                getDriverLetter.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}



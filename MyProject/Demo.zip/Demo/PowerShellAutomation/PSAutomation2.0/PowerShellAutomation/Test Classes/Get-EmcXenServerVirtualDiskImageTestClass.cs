using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcXenServerVirtualDiskImageTest: test class for Get-EmcXenServerVirtualDiskImage cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcXenServerVirtualDiskImageTest
    {
        public GetEmcXenServerVirtualDiskImageTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static bool createSR;
        private static SortedList<string, string> virtualDiskKeyValue;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();
            createSR = false;

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            
            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));

            try
            {
                string result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    updateXenServer.RunCMD(psMachine);
                    GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository("gui_testsr_sandy2", HelperAdapter.GetParameter("XenServer"), null, null);
                    sr.PrefixString = HelperAdapter.GetParameter("StorageRepository");
                    result = sr.RunCMD(psMachine, true);
                }
                else
                {
                    createSR = true;
                }
            }
            catch
            {
                TestSetup.ClearLunEnvironment(psMachine);
                TestSetup.DisconnectSystem(psMachine);
                throw new Exception("SetSREnvironment in Class init failed");
            }

            try
            {
                string result = TestSetup.SetXenServerVirtualDiskEnvironment(psMachine);
                virtualDiskKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            }
            catch
            {
                ESIPSTestClassCleanUP();
                throw new PSException("SetXenServerVirtualDiskEnvironment in class init failed");
            }

            updateXenServer.RunCMD(psMachine);

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            TestSetup.ClearXenServerVirtualDiskEnvironment(psMachine);

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcXenServerVirtualDiskImage instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcXenServerVirtualDiskImage instance</returns>  
        public GetEmcXenServerVirtualDiskImage ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string xenserver = null;
            string silent = null;
            string storagerepository = null;


            string cmdString = cmd;
   
            #endregion

            int count = -1;

            if (cmd.IndexOf("$StorageRepository", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagerepository = HelperAdapter.GetParameter("StorageRepository");
                cmdString = cmdString.Replace("$StorageRepository", storagerepository);
            }

            if (cmd.IndexOf("$XenServer", StringComparison.OrdinalIgnoreCase) > 0)
            {
                xenserver = HelperAdapter.GetParameter("XenServer");
                cmdString = cmdString.Replace("$XenServer", xenserver);
            }

            if (cmd.IndexOf("$UUID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = virtualDiskKeyValue["Uuid"];
                cmdString = cmdString.Replace("$UUID", id);
                count = 1;
            }
            else if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = virtualDiskKeyValue["Name"];
                cmdString = cmdString.Replace("$Name", id);
                count = 1;
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            GetEmcXenServerVirtualDiskImage instance = new GetEmcXenServerVirtualDiskImage(id, xenserver, silent, storagerepository,  cmdString);
            instance.VirtualDiskKeyValue = virtualDiskKeyValue;
            instance.Count = count;

            return instance;
        }


        /// <summary>  
        /// Get-EmcXenServerVirtualDiskImage:
        ///    The method to implement Get-EmcXenServerVirtualDiskImage poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerVirtualDiskImageTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            GetEmcXenServerVirtualDiskImage cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcXenServerVirtualDiskImageNegativeTestMethod:
        ///    The method to implement Get-EmcXenServerVirtualDiskImage negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerVirtualDiskImageNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            GetEmcXenServerVirtualDiskImage getxenservervirtualdiskimageClass = ParseCmd(cmd);

            try
            {
                getxenservervirtualdiskimageClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getxenservervirtualdiskimageClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

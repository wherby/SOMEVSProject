using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcAvailableScsiControllerLocationTest: test class for Get-EmcAvailableScsiControllerLocation cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcAvailableScsiControllerLocationTest
    {
        public GetEmcAvailableScsiControllerLocationTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string hypervPrefix = HelperAdapter.GetParameter("HyperV");
        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string vmPrefix = HelperAdapter.GetParameter("VirtualMachine");
        private static string vmwareVMPrefix = vmPrefix + "_vmware";
        private static string hypervVMPrefix = vmPrefix + "_hyperv";
        private static string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
        private static string vmwareVMConfigPrefix = vmConfigPrefix + "_vmware";
        private static string hypervVMConfigPrefix = vmConfigPrefix + "_hyperv";
        private static string scsiControllerPrefix = HelperAdapter.GetParameter("ScsiController");
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);

            if (HelperAdapter.IsHyperVSet())
            {
                // Connect to Hyper-V          
                log.LogInfo("Class Initialize: Connect to Hypervisor");
                TestSetup.ConnectSystem(psMachine, "Hyperv", hypervPrefix);
                UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(hypervPrefix);
                updateEmcSystem.RunCMD(psMachine);

                // Connect to VM
                TestSetup.ConnectVirtualMachine(psMachine, HyperVisorType.HyperV, hypervVMPrefix);

                log.LogInfo("Class Initialize: Get Virtual Machine Configuration");
                TestSetup.GetVirtualMachineConfiguration(psMachine, hypervVMConfigPrefix, hypervVMPrefix);
            }

            if (HelperAdapter.IsVMwareSet())
            {
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
                UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(vmwarePrefix);
                updateEmcSystem.RunCMD(psMachine);

                TestSetup.ConnectVirtualMachine(psMachine, HyperVisorType.VMWare, vmwareVMPrefix);

                // Get VM Configuration 
                TestSetup.GetVirtualMachineConfiguration(psMachine, vmwareVMConfigPrefix, vmwareVMPrefix);
            }
            log.LogInfo("--------Class Initialize Start--------");  
        }
       
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcAvailableScsiControllerLocation instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcAvailableScsiControllerLocation instance</returns>  
        public GetEmcAvailableScsiControllerLocation ParseCmd(string cmd)
        {
            #region AutoGenerate
            string virtualmachineconfiguration = null;
            string scsicontrollerindex = null;
            string silent = null;
            string scsicontrollerid = null;


            string cmdString = cmd;
   
            #endregion


            SortedList<string, string> scsiController = null;


            if (cmd.IndexOf("$HypervVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (HelperAdapter.IsHyperVSet())
                {
                    virtualmachineconfiguration = hypervVMConfigPrefix;
                    cmdString = cmdString.Replace("$HypervVMConfig", virtualmachineconfiguration);
                    scsiController = TestSetup.GetRandomScsiController(psMachine, scsiControllerPrefix, hypervVMConfigPrefix);
                }
                else
                {
                    log.BypassTest();
                }
            }
            else
            {
                if (HelperAdapter.IsVMwareSet())
                {
                    virtualmachineconfiguration = vmwareVMConfigPrefix;
                    cmdString = cmdString.Replace("$VMWareVMConfig", virtualmachineconfiguration);
                    scsiController = TestSetup.GetRandomScsiController(psMachine, scsiControllerPrefix, vmwareVMConfigPrefix);
                }
                else
                {
                    log.BypassTest();
                }
            }

            if (cmd.IndexOf("ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerindex = scsiController["ScsiControllerIndex"];
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsicontrollerindex);
            }
            if (cmd.IndexOf("ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerid = scsiController["ScsiControllerId"];
                cmdString = cmdString.Replace("$ScsiControllerId", "\"" + scsicontrollerid + "\"");
            }


            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcAvailableScsiControllerLocation scsiControllerLocation = new GetEmcAvailableScsiControllerLocation(virtualmachineconfiguration, 
                scsicontrollerindex, silent, scsicontrollerid, cmdString);

            return scsiControllerLocation;
        }

        /// <summary>  
        /// GetEmcAvailableScsiControllerLocationTestMethod:
        ///    The method to implement Get-EmcAvailableScsiControllerLocation poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcAvailableScsiControllerLocationTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcAvailableScsiControllerLocation scsiControllerLocation = ParseCmd(cmd);

            scsiControllerLocation.VerifyTheCMD(psMachine, hypervVMPrefix, vmwareVMPrefix);
           
        }

        /// <summary>  
        /// GetEmcAvailableScsiControllerLocationNegativeTestMethod:
        ///    The method to implement Get-EmcAvailableScsiControllerLocation negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcAvailableScsiControllerLocationNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcAvailableScsiControllerLocation scsiControllerLocation = ParseCmd(cmd);

            try
            {
                scsiControllerLocation.VerifyTheCMD(psMachine, hypervVMPrefix, vmwareVMPrefix);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", scsiControllerLocation.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");
           
        }
    }
}

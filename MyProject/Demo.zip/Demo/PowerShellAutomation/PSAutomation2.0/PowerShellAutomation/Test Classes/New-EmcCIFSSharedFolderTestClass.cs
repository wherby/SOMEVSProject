using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcCIFSSharedFolderTest: test class for New-EmcCIFSSharedFolder cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcCifsSharedFolderTest
    {
        public NewEmcCifsSharedFolderTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static bool isNeedDeleteFolder;
        private string folderNameString;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            isNeedDeleteFolder = false;
            folderNameString = null;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (isNeedDeleteFolder == true)
            {
                TestSetup.RemoveSharedFolderEnvironment(psMachine, null, folderNameString);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                TestSetup.SetVNXESharedFolderPoolEnvironment(psMachine);
            }
            else
            {
                TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
                TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Initialize End--------");    
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            if (TestSetup.IsStorageVNXE() == false)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a New-EmcCIFSSharedFolder instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>New-EmcCIFSSharedFolder instance</returns>  
        public NewEmcCIFSSharedFolder ParseCmd(string cmd)
        {
            #region AutoGenerate
            string pool = null;
            string name = null;
            string path = null;
            string capacity = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion
            string poolString = HelperAdapter.GetParameter("SharedFolderPool");
            string nameString = HelperAdapter.GenerateName("SF");
            string pathString = HelperAdapter.GenerateName("SFPath");
            folderNameString = pathString;
            string capacityString = HelperAdapter.GetParameter("CapacityForFileFolder", "LunConfig");

            if (cmd.IndexOf("$Pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = poolString;
                cmd = cmd.Replace("$Pool", poolString);
            }
            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = nameString;
                cmd = cmd.Replace("$Name", nameString);
            }
            if (cmd.IndexOf("$Path", StringComparison.OrdinalIgnoreCase) > 0)
            {
                path = pathString;
                cmd = cmd.Replace("$Path", pathString);
            }
            if (cmd.IndexOf("$Capacity", StringComparison.OrdinalIgnoreCase) > 0)
            {
                capacity = capacityString;
                cmd = cmd.Replace("$Capacity", capacityString);
            }
            if (cmd.IndexOf("$Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            NewEmcCIFSSharedFolder instance = new NewEmcCIFSSharedFolder(pool, name, path, capacity, silent,  cmd);
            return instance;
        }


        /// <summary>  
        /// New-EmcCifsSharedFolder:
        ///    The method to implement New-EmcCIFSSharedFolder poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcCifsSharedFolderTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            NewEmcCIFSSharedFolder cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
            isNeedDeleteFolder = true;
        }

        /// <summary>  
        /// NewEmcCIFSSharedFolderNegativeTestMethod:
        ///    The method to implement New-EmcCIFSSharedFolder negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcCifsSharedFolderNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcCIFSSharedFolder newemccifssharedfolderClass = ParseCmd(cmd);

            try
            {
                newemccifssharedfolderClass.VerifyTheCMD(psMachine);
                isNeedDeleteFolder = true;
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", newemccifssharedfolderClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

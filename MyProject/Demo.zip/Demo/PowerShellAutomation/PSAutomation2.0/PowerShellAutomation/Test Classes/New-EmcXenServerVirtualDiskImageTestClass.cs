using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcXenServerVirtualDiskImageTest: test class for New-EmcXenServerVirtualDisk cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcXenServerVirtualDiskImageTest
    {
        public NewEmcXenServerVirtualDiskImageTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static bool createSR;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string virtualDisk = HelperAdapter.GetParameter("XenServerVirtualDisk");
            string xenServer = HelperAdapter.GetParameter("XenServer");
            string diskUuid = TestSetup.GetPropertyValue(psMachine, virtualDisk, "Uuid");
            string result = null;

            if (!string.IsNullOrEmpty(diskUuid))
            {
                GetEmcXenServerVirtualDiskImage getVirtualDisk = new GetEmcXenServerVirtualDiskImage(diskUuid, xenServer);
                getVirtualDisk.PrefixString = virtualDisk;
                result = getVirtualDisk.RunCMD(psMachine);

                if (!string.IsNullOrEmpty(result))
                {
                    RemoveEmcXenServerVirtualDiskImage removeVirtualDisk = new RemoveEmcXenServerVirtualDiskImage(virtualDisk);
                    removeVirtualDisk.RunCMD(psMachine);

                    UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
                    updateXenServer.RunCMD(psMachine);
                }
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();
            createSR = false;

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                string result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                    updateXenServer.RunCMD(psMachine);
                    GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository("gui_testsr_sandy2", HelperAdapter.GetParameter("XenServer"), null, null);
                    sr.PrefixString = HelperAdapter.GetParameter("StorageRepository");
                    result = sr.RunCMD(psMachine, true);
                }
                else
                {
                    createSR = true;
                }
            }
            catch
            {
                ESIPSTestClassCleanUP();
                throw new PSException("SetSREnvironment in Class init failed");
            }

            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a New-EmcXenServerVirtualDisk instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>New-EmcXenServerVirtualDisk instance</returns>  
        public NewEmcXenServerVirtualDiskImage ParseCmd(string cmd)
        {
            #region AutoGenerate
            string storagerepository = null;
            string xenserver = null;
            string size = null;
            string name = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "XenServerVirtualDisk");

            if (cmd.IndexOf("$StorageRepository", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagerepository = HelperAdapter.GetParameter("StorageRepository");
                cmdString = cmdString.Replace("$StorageRepository", storagerepository);
            }

            if (cmd.IndexOf("$XenServer", StringComparison.OrdinalIgnoreCase) > 0)
            {
                xenserver = HelperAdapter.GetParameter("XenServer");
                cmdString = cmdString.Replace("$XenServer", xenserver);
            }

            if (cmd.IndexOf("$Size", StringComparison.OrdinalIgnoreCase) > 0)
            {
                size = dic["Size"];
                cmdString = cmdString.Replace("$Size", size);
            }

            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = dic["NamePrefix"] + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$Name", name);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            NewEmcXenServerVirtualDiskImage instance = new NewEmcXenServerVirtualDiskImage(storagerepository, xenserver, size, name, silent,  cmdString);
            return instance;
        }


        /// <summary>  
        /// New-EmcXenServerVirtualDisk:
        ///    The method to implement New-EmcXenServerVirtualDisk poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcXenServerVirtualDiskImageTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            NewEmcXenServerVirtualDiskImage cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// NewEmcXenServerVirtualDiskImageNegativeTestMethod:
        ///    The method to implement New-EmcXenServerVirtualDisk negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcXenServerVirtualDiskImageNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            NewEmcXenServerVirtualDiskImage newxenservervirtualdiskClass = ParseCmd(cmd);

            try
            {
                newxenservervirtualdiskClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", newxenservervirtualdiskClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

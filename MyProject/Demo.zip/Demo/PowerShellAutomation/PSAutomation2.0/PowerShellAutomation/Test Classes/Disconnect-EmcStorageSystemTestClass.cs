using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class DisconnectEmcStorageSystemTest
    {
        public DisconnectEmcStorageSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
            
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private string blobConfig;
        private string friendlyNameConfig;
        private string systemName;               /*storage system name*/
        private string globalId;
        private string systemType;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       

        #region Additional test attributes
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a DisconnectEmcStorageSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public DisconnectEmcStorageSystem ParseCmd(string cmd)
        {
            
            //string id = null;
            //string force = null;
            //string silent = null;
            //string whatIf = null;
            //string system = null;
            //string cmdString = cmd;
#if true
        #region AutoGenerate
            string id = null;
            string force = null;
            string silent = null;
            string whatif = null;
            string system = null;


            string cmdString = cmd;
   
            #endregion
#endif

            if (cmd.IndexOf(systemType + "_Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = systemName;
                cmdString = cmdString.Replace("$" + systemType + "_Name", systemName);
            }
            else if (cmd.IndexOf(systemType + "_FriendlyName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = friendlyNameConfig;
                cmdString = cmdString.Replace("$" + systemType + "_FriendlyName", friendlyNameConfig);
            }
            else if (cmd.IndexOf(systemType + "_GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = globalId;
                cmdString = cmdString.Replace("$" + systemType + "_GlobalId", globalId);
            }
            
            if (cmd.IndexOf(systemType + "_System", StringComparison.OrdinalIgnoreCase) > 0)
            {
                system = HelperAdapter.GetParameter("Storage");
                cmdString = cmdString.Replace("$" + systemType + "_System", system);
            }

            if (cmd.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }

            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            DisconnectEmcStorageSystem storageSystem = new DisconnectEmcStorageSystem(id, force, silent, whatif, system, cmdString);

            return storageSystem;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisconnectEmcStorageSystemTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (PrepareEnvironment(cmd) == false)
            {
                return;
            }

            DisconnectEmcStorageSystem system = ParseCmd(cmd);

            system.VerifyTheCMD(psMachine, globalId);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisconnectEmcStorageSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            if (PrepareEnvironment(cmd) == false)
            {
                return;
            }

            DisconnectEmcStorageSystem system = ParseCmd(cmd);

            try
            {
                system.VerifyTheCMD(psMachine, globalId);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");

        }

        /// <summary>
        /// PrepareEnvironment
        ///     Connect storage system with specific type
        /// </summary>
        /// <param name="cmd"></param>
        /// <returns></returns>
        public bool PrepareEnvironment(string cmd)
        {
            string[] types = { "CLARiiON-CX4", "VMAX", "VMAXe", "VNX", "VNX-Block", "VNX-CIFS", "VNXe"};

            foreach (string type in types)
            {
                if (cmd.Contains(type + "_"))
                {
                    systemType = type;
                    break;
                }
            }
            
            foreach (string type in types)
            {
                if (systemType == type || systemType == null)
                {
                    blobConfig = HelperAdapter.GetBlobContent(type);
                    if (blobConfig == null)
                    {
                        if (systemType != null)
                        {
                            return false;
                        }
                        else
                        {
                            continue;
                        }
                    }                    

                    ConnectEmcSystem system = new ConnectEmcSystem(blobConfig);
                    system.SystemType = type;
                    system.PrefixString = HelperAdapter.GetParameter("Storage");
                    string result = system.RunCMD(psMachine, true);

                    SortedList<string, string> systemKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

                    if (systemType != null)
                    {
                        globalId = systemKeyValue["GlobalId"];
                        systemName = systemKeyValue["Name"];
                        friendlyNameConfig = systemKeyValue["UserFriendlyName"];
                    }

                    log.LogInfo(string.Format("Test Initialize: Connect to {0} Storage System {1}", systemType, systemKeyValue["GlobalId"]));
                }
            }

            return true;
        }

    }
            
}

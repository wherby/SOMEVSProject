using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcSnapshotLunTest: test class for Get-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcSnapshotLunTest
    {
        public GetEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string snapshotLunID = "";
        private static string snapshotLunName = "";
        private static SortedList<string, string> lunKeyValue = new SortedList<string,string>();

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string sourceLunPrefix = HelperAdapter.GetParameter("Lun");
        private static string snapshotPoolPrefix = HelperAdapter.GetParameter("SnapshotPool");
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);  

            // Create Snapshot Lun
            log.LogInfo("Class Initialize: Create Snapshot Lun");
            result = TestSetup.SetSnapshotLunEnvironment(psMachine, snapshotLunPrefix, sourceLunPrefix);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (TestSetup.StorageSystemType == "VNXe")
            {
                snapshotLunName = lunKeyValue["Name"];
            }
            else
            {
                snapshotLunID = lunKeyValue["Wwn"];
            }
            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Remove Snapshot Lun
            log.LogInfo("Class Cleanup: Remove Snapshot Lun");
            string blockStorageSystem = HelperAdapter.GetParameter("System");
            string id;
            if (TestSetup.StorageSystemType == "VNXe")
            {
                id = snapshotLunName;
            }
            else
            {
                id = snapshotLunID;
            }
            GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(id, null, blockStorageSystem);
            getSnapshotLun.PrefixString = snapshotLunPrefix;
            getSnapshotLun.RunCMD(psMachine);

            TestSetup.ClearSnapshotLunEnvironment(psMachine, id, snapshotLunPrefix);

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcSnapshotLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcSnapshotLun instance</returns>  
        public GetEmcSnapshotLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string sourcelun = null;
            string blockstoragesystem = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion


            if (cmd.IndexOf("LunId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = snapshotLunID;
                cmdString = cmdString.Replace("$LUNId", id);                
            }
            else if (cmd.IndexOf("LunName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = snapshotLunName;
                cmdString = cmdString.Replace("$LUNName", id);                
            }

            if (cmd.IndexOf("BlockStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                blockstoragesystem = HelperAdapter.GetParameter("System");
                cmdString = cmdString.Replace("$BlockStorageSystem", blockstoragesystem);
            }

            if (cmd.IndexOf("SourceLun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourcelun = sourceLunPrefix;
                cmdString = cmdString.Replace("$SourceLun", sourcelun);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcSnapshotLun snapshotLun;

            if ((cmd.Contains("$LUNName") && TestSetup.StorageSystemType == "VMAX") || (cmd.Contains("$LUNId") && TestSetup.StorageSystemType == "VNXe"))
            {
                snapshotLun = null;
            }
            else
            {
                snapshotLun = new GetEmcSnapshotLun(id, sourcelun, blockstoragesystem, silent, cmdString);
            }

            return snapshotLun;
        }

        /// <summary>  
        /// GetEmcSnapshotLunTestMethod:
        ///    The method to implement Get-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSnapshotLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcSnapshotLun snapShotLun = ParseCmd(cmd);

            if (snapShotLun != null)
            {
                snapShotLun.VerifyTheCMD(psMachine, lunKeyValue);
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }
        }

        /// <summary>  
        /// GetEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement Get-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSnapshotLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcSnapshotLun snapshotLun = ParseCmd(cmd);

            if (snapshotLun != null)
            {
                try
                {
                    snapshotLun.VerifyTheCMD(psMachine, lunKeyValue);
                }
                catch (PSException psEx)
                {
                    log.LogTestCase(string.Format("Test with {0} failed.", snapshotLun.GetFullString()));
                    log.LogTestCase(psEx.messageDetail);
                    caseFail = true;
                }
                log.AreEqual<bool>(true, caseFail, "Negative test case result:");
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }

        }
    }
}

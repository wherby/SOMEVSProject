using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcXenServerSystemTest: test class for Get-EmcXenServerSystem cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcXenServerSystemTest
    {
        public GetEmcXenServerSystemTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string> xenServerKeyValue;
        private static bool createSR;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            string xenServer = HelperAdapter.GetParameter("XenServer");
            string result = TestSetup.ConnectSystem(psMachine, "XenServer", xenServer);
            xenServerKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            List<Dictionary<string, string>> hostsList = HelperAdapter.GetHypervisorHosts(HyperVisorType.XenServer);
            GetEmcXenServerHost hosts = new GetEmcXenServerHost(hostsList[0]["Name"], xenServer, null, null);
            hosts.PrefixString = HelperAdapter.GetParameter("XenServerHost");
            hosts.RunCMD(psMachine, true);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                    updateXenServer.RunCMD(psMachine);
                    GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository("gui_testsr_sandy2", HelperAdapter.GetParameter("XenServer"), null, null);
                    sr.PrefixString = HelperAdapter.GetParameter("StorageRepository");
                    result = sr.RunCMD(psMachine, true);
                }
                else
                {
                    createSR = true;
                }
            }
            catch
            {
                ESIPSTestClassCleanUP();
                throw new PSException("SetSREnvironment in Class init failed");
            }

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcXenServerSystem instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcXenServerSystem instance</returns>  
        public GetEmcXenServerSystem ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string silent = null;
            string xenserverhostsystem = null;
            string storagerepository = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = xenServerKeyValue["Name"];
                cmdString = cmdString.Replace("$Name", id);
            }
            else if (cmd.IndexOf("$GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = xenServerKeyValue["GlobalId"];
                cmdString = cmdString.Replace("$GlobalId", id);
            }

            if (cmd.IndexOf("$XenServerHostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                xenserverhostsystem = HelperAdapter.GetParameter("XenServerHost");
                cmdString = cmdString.Replace("$XenServerHostSystem", xenserverhostsystem);
            }

            if (cmd.IndexOf("$StorageRepository", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagerepository = HelperAdapter.GetParameter("StorageRepository");
                cmdString = cmdString.Replace("$StorageRepository", storagerepository);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            
            GetEmcXenServerSystem instance = new GetEmcXenServerSystem(id, silent, xenserverhostsystem, storagerepository,  cmdString);
            instance.XenServerKeyValue = xenServerKeyValue;
            return instance;
        }


        /// <summary>  
        /// Get-EmcXenServerSystem:
        ///    The method to implement Get-EmcXenServerSystem poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            GetEmcXenServerSystem cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcXenServerSystemNegativeTestMethod:
        ///    The method to implement Get-EmcXenServerSystem negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerSystemNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            GetEmcXenServerSystem getxenserversystemClass = ParseCmd(cmd);

            try
            {
                getxenserversystemClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getxenserversystemClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

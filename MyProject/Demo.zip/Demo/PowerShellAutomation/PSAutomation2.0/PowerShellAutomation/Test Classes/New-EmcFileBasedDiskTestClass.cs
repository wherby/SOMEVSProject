using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcFileBasedDiskTest: test class for New-EmcFileBasedDisk cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcFileBasedDiskTest
    {
        public NewEmcFileBasedDiskTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static Dictionary<string, string> fileBasedDiskConfig;
        private static string filePath;
        private static string directory;
        private static string netDirectory;
        private static string dataStorePath;
        private static string esxPath;
        private static string netFilePath;
        private static string type;
        private static string hypervIp;
        private static string esxHostIp;
        private static string esxHostPassword;
        private static string esxHostUsername;
        private static string dataStoreName;
        private static string dataStoreUrl;
        private static string hypervPrefix = HelperAdapter.GetParameter("HyperV");
        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private bool removeFlag = false;
        

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();
            
            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            
            // Connect to Hypervisor
            log.LogInfo("Class Initialize: Connect to Hypervisor");

            // Connect to Hyper-V host
            if (HelperAdapter.IsHyperVSet())
            {
                string result = TestSetup.ConnectSystem(psMachine, "HyperV", hypervPrefix);
                hypervIp = HelperAdapter.GenerateKeyValuePairs(result)["IpAddress"];

                // Generate share path for vhd disk                
                fileBasedDiskConfig = HelperAdapter.Load(path, "FileBasedDisk");
                directory = fileBasedDiskConfig["Path"];
                netDirectory = directory.Replace(":", "$");
                netDirectory = "\\\\" + hypervIp + "\\" + netDirectory;

                // Verify if the path exists
                if (!TestSetup.TestPath(psMachine, netDirectory))
                {
                    log.LogError(string.Format("{0} doesn't exist", netDirectory));
                    PSException pe = new PSException(string.Format("{0} doesn't exist", netDirectory));
                    throw pe;
                }
            }
            if (HelperAdapter.IsVMwareSet())
            {
                // Connect to vCenter or ESX Host
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                string result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
                SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);

                esxHostUsername = keyValuePairs["UserName"];
                esxHostIp = keyValuePairs["IpAddress"];

                // Get ESX Host Password from VMWare.xml
                esxHostPassword = dic["Password"];

                // Get Specified Datastore
                result = TestSetup.SetDataStoreEnvironment(psMachine);
                dataStoreUrl = HelperAdapter.GenerateKeyValuePairs(result)["Url"];
                Dictionary<string, string> dataStoreConfig = HelperAdapter.Load(path, "DataStore");
                dataStoreName = dataStoreConfig["Name"];
                dataStorePath = "[" + dataStoreName + "]" + dataStoreConfig["DataStorePath"] + "/";
                esxPath = dataStoreUrl + "/" + dataStoreConfig["DataStorePath"] + "/";

                // Verify if the path exists
                if (!TestSetup.TestPath(psMachine, esxPath, esxHostPassword, esxHostUsername, esxHostIp))
                {
                    log.LogError(string.Format("{0} doesn't exist", esxPath));
                    PSException pe = new PSException(string.Format("{0} doesn't exist", esxPath));
                    throw pe;
                }
            }

            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestCleanUP()
        {
            log.LogInfo("--------Class Clean UP Start--------");
            // Disconnect Storage and Host System
            log.LogInfo("Class Cleanup:Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean UP End--------");
        }
        
        // Use TestInitialize to run code before running each test         
        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");            
            
            log.LogInfo("--------Test Initialize End--------");
        }

        
        // Use TestCleanup to run code after each test has run
        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean UP Start--------");
            
            log.LogInfo("Test Cleanup:Remove File Based Disk");
            if (HelperAdapter.IsHyperVSet())
            {
                if (removeFlag && type.Equals("vhd"))
                {
                    TestSetup.ClearFileBasedDiskEnvironment(psMachine, filePath, hypervPrefix);
                }
            }
            if (HelperAdapter.IsVMwareSet())
            {
                if (removeFlag && type.Equals("vmdk"))
                {
                    TestSetup.ClearFileBasedDiskEnvironment(psMachine, filePath, vmwarePrefix);
                }
            }

            log.LogInfo("--------Test Clean UP End--------");

        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcFileBasedDisk instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcFileBasedDisk instance</returns>  
        public static NewEmcFileBasedDisk ParseCmd(string cmd)
        {
            
            #region AutoGenerate
            string hypervisor = null;
            string path = null;
            string size = null;
            string vhdtype = null;
            string silent = null;
            string vmdktype = null;


            string cmdString = cmd;
   
            #endregion


            string file = "ps_test_" + HelperAdapter.GenerateRandomString();

            if (cmd.IndexOf("hypervisor", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmd.Contains("VhdType"))
                {
                    hypervisor = hypervPrefix;
                    type = "vhd";
                }
                else if (cmd.Contains("VmdkType"))
                {
                    hypervisor = vmwarePrefix;
                    type = "vmdk";
                }
                else
                {
                    // when no vhdtype and vmdktype is input, randomly select hyperv or vmware test
                    Random r = new Random();
                    int i = r.Next(0, 2);
                    if (i == 0)
                    {
                        hypervisor = hypervPrefix;
                        type = "vhd";
                    }
                    else
                    {
                        hypervisor = vmwarePrefix;
                        type = "vmdk";
                    }
                }
                if ((type == "vhd" && HelperAdapter.IsHyperVSet()) || (type == "vmdk" && HelperAdapter.IsVMwareSet()))
                {
                    cmdString = cmdString.Replace("$Hypervisor", hypervisor);
                }
                else
                {
                    return null;
                }                
            }

            if (cmd.IndexOf("path", StringComparison.OrdinalIgnoreCase) > 0 && type.Equals("vhd"))
            {
                filePath = directory + file + ".vhd";
                netFilePath = netDirectory + file + ".vhd";
                path = "\"" + filePath + "\"";
                cmdString = cmdString.Replace("$Path", path);
            }

            if (cmd.IndexOf("path", StringComparison.OrdinalIgnoreCase) > 0 && type.Equals("vmdk"))
            {
                filePath = dataStorePath + file + ".vmdk";
                netFilePath = esxPath + file + ".vmdk";
                path = "\"" + filePath + "\"";
                cmdString = cmdString.Replace("$Path", path);
            }

            if (cmd.IndexOf("size", StringComparison.OrdinalIgnoreCase) > 0)
            {
                size = fileBasedDiskConfig["Size"];
                cmdString = cmdString.Replace("$Size", size);
            }

            if (cmd.IndexOf("$vhdtype", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vhdtype = HelperAdapter.GenerateRandomValue(HelperAdapter.VhdType);
                cmdString = cmdString.Replace("$VhdType", vhdtype);
            }

            if (cmd.IndexOf("$vmdktype", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmdktype = HelperAdapter.GenerateRandomValue(HelperAdapter.VmdkType);
                cmdString = cmdString.Replace("$VmdkType", vmdktype);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";                
            }

            NewEmcFileBasedDisk fileBasedDisk = new NewEmcFileBasedDisk(hypervisor, path, size, vhdtype, silent, vmdktype, cmdString);

            return fileBasedDisk;
        }

        /// <summary>  
        /// NewEmcFileBasedDiskTestMethod:
        ///    The method to implement New-EmcFileBasedDisk poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcFileBasedDiskTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            NewEmcFileBasedDisk fileBasedDisk = ParseCmd(cmd);

            if (fileBasedDisk != null)
            {
                fileBasedDisk.VerifyTheCMD(psMachine, netFilePath, esxHostPassword, esxHostUsername, esxHostIp);
                removeFlag = true;
            }
            else
            {
                log.LogWarning(String.Format("Skip the command {0}", cmd));
            }           
        }

        /// <summary>  
        /// NewEmcFileBasedDiskNegativeTestMethod:
        ///    The method to implement New-EmcFileBasedDisk negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcFileBasedDiskNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcFileBasedDisk fileBasedDisk = ParseCmd(cmd);
            if (fileBasedDisk != null)
            {
                try
                {
                    fileBasedDisk.VerifyTheCMD(psMachine, netFilePath, esxHostPassword, esxHostUsername, esxHostIp);
                }
                catch (PSException psEx)
                {
                    log.LogTestCase(string.Format("Test with {0} failed.", fileBasedDisk.GetFullString()));
                    log.LogTestCase(psEx.messageDetail);
                    caseFail = true;
                }
                log.AreEqual<bool>(true, caseFail, "Negative test case result:");
            }
            else
            {
                log.LogWarning(String.Format("Skip the command {0}", cmd));
            }  
        }
    
    }
}

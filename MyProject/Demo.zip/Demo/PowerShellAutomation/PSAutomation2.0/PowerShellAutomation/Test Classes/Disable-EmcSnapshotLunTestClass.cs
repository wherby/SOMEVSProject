using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// DisableEmcSnapshotLunTest: test class for Disable-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class DisableEmcSnapshotLunTest
    {
        public DisableEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string snapshotLunID = "";

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string sourceLunPrefix = HelperAdapter.GetParameter("Lun");
        private static string snapshotPoolPrefix = HelperAdapter.GetParameter("SnapshotPool");
        private static string hostPrefix = HelperAdapter.GetParameter("Host");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            log.LogInfo("Test Initialize: Activate Snapshot LUN");
            GetEmcSnapshotLun getEmcSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
            string result = getEmcSnapshotLun.RunCMD(psMachine, true);
            if (HelperAdapter.GenerateKeyValuePairs(result)["IsActivated"].Equals("False"))
            {
                if (TestSetup.StorageSystemType == "VNXe")
                {
                    TestSetup.SetLunAccess(psMachine, snapshotLunPrefix, hostPrefix);
                }
                TestSetup.EnableSnapshotLun(psMachine, snapshotLunPrefix, sourceLunPrefix);
            }
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {            
            log.LogInfo("--------Test Clean Up Start--------");
            if (TestSetup.StorageSystemType == "VNXe")
            {
                GetEmcSnapshotLun getEmcSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
                string result = getEmcSnapshotLun.RunCMD(psMachine, true);
                if (HelperAdapter.GenerateKeyValuePairs(result)["IsActivated"].Equals("False"))
                {
                    TestSetup.ClearDiskEnvironment(psMachine, hostPrefix, null, snapshotLunPrefix);

                }
            }
            log.LogInfo("--------Test Clean Up End--------");
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            
            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            
            // Create Snapshot Lun
            log.LogInfo("Class Initialize: Create Snapshot Lun");
            string result = TestSetup.SetSnapshotLunEnvironment(psMachine, snapshotLunPrefix, sourceLunPrefix);

            // To activate VNXe snapshot lun, the snapshot lun should be unmask to a host
            if (TestSetup.StorageSystemType == "VNXe")
            {
                TestSetup.ConnectSystem(psMachine, "Host", hostPrefix);
                TestSetup.SetLunAccess(psMachine, snapshotLunPrefix, hostPrefix);

                result = TestSetup.EnableSnapshotLun(psMachine, snapshotLunPrefix, sourceLunPrefix);                
            }
            
            SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            if (TestSetup.StorageSystemType == "VNXe")
            {
                snapshotLunID = keyValuePairs["Name"];
            }
            else
            {
                snapshotLunID = keyValuePairs["Wwn"];
            }
            string isActivatedString = keyValuePairs["IsActivated"];
            if (isActivatedString.Equals("False"))
            {
                log.LogError("The Snapshot Lun is not activated");
                PSException pe = new PSException("The Snapshot Lun is activated");
                throw pe;
            }
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            log.LogInfo("Class Cleanup: Remove Snapshot Lun");

            if (TestSetup.StorageSystemType == "VNXe")
            {
                GetEmcSnapshotLun getEmcSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
                string result = getEmcSnapshotLun.RunCMD(psMachine, true);
                if (HelperAdapter.GenerateKeyValuePairs(result)["IsActivated"].Equals("True"))
                {

                    DisableEmcSnapshotLun disableSnapshotLun = new DisableEmcSnapshotLun(snapshotLunPrefix);
                    disableSnapshotLun.VerifyTheCMD(psMachine, snapshotLunID);
                }

                TestSetup.ClearDiskEnvironment(psMachine, hostPrefix);
            }
            TestSetup.ClearSnapshotLunEnvironment(psMachine, snapshotLunID, snapshotLunPrefix);

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Disable-EmcSnapshotLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Disable-EmcSnapshotLun instance</returns>  
        public DisableEmcSnapshotLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string snapshotlun = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotlun = snapshotLunPrefix;
                cmdString = cmdString.Replace("$SnapshotLun", snapshotlun);
            }            
          
            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }
            
            DisableEmcSnapshotLun instance = new DisableEmcSnapshotLun(snapshotlun, force, silent, whatif,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Disable-EmcSnapshotLun:
        ///    The method to implement Disable-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisableEmcSnapshotLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            DisableEmcSnapshotLun cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, snapshotLunID);            
        }

        /// <summary>  
        /// DisableEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement Disable-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void DisableEmcSnapshotLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            DisableEmcSnapshotLun disableEmcSnapshotLunClass = ParseCmd(cmd);

            try
            {
                disableEmcSnapshotLunClass.VerifyTheCMD(psMachine, snapshotLunID);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", disableEmcSnapshotLunClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// ExpandEmcLunTest: test class for Expand-EmcLun cmdlet
    /// </summary>
    [TestClass]
    public partial class ExpandEmcLunTest
    {
        public ExpandEmcLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string>[] lunsKeyValue;
        private static ulong[] capacity;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            for (int i = 0; i < lunsKeyValue.Length; i++)
            {
                GetEmcLun lun = new GetEmcLun(lunsKeyValue[i]["Wwn"] );
                lun.PrefixString = HelperAdapter.GetParameter("Lun") + (i == 0 ? null : "2");
                string result = lun.RunCMD(psMachine);
                lunsKeyValue[i] = HelperAdapter.GenerateKeyValuePairs(result);
                capacity[i] = ulong.Parse(TestSetup.GetPropertyValue(psMachine, lun.PrefixString, "Capacity.Value"));
            }

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            TestSetup.SetPoolEnvironment(psMachine);

            lunsKeyValue = new SortedList<string, string>[2];
            capacity = new ulong[2];

            string result = TestSetup.SetLunEnvironment(psMachine);
            lunsKeyValue[0] = HelperAdapter.GenerateKeyValuePairs(result);

            result = TestSetup.SetLunEnvironment(psMachine, false, null, HelperAdapter.GetParameter("Lun") + "2");
            lunsKeyValue[1] = HelperAdapter.GenerateKeyValuePairs(result);

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine, HelperAdapter.GetParameter("Lun") + "2");
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Expand-EmcLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Expand-EmcLun instance</returns>  
        public ExpandEmcLun ParseCmd(string cmd, bool thinFlag = true)
        {
            #region AutoGenerate

            string lun = null;
            string newCapacity = null;
            string silent = null;
            string cmdString = cmd;
   
            #endregion
            int lunIndex = 0;
            

            if (cmd.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (thinFlag)
                {
                    lun = HelperAdapter.GetParameter("Lun");
                }
                else
                {
                    lun = HelperAdapter.GetParameter("Lun") + "2";
                    lunIndex = 1;
                }
                cmdString = cmdString.Replace("$Lun", lun);
            }

            if (cmd.IndexOf("$NewCapacity", StringComparison.OrdinalIgnoreCase) > 0)
            {
                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path, "Expand");

                ulong capacityIncrease = ulong.Parse(TestSetup.GetPropertyValue(psMachine, dic["LunIncreaseBy"]));
                newCapacity = (capacity[lunIndex] + capacityIncrease).ToString();
                cmdString = cmdString.Replace("$NewCapacity", newCapacity);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            ExpandEmcLun instance = new ExpandEmcLun(lun, newCapacity, silent,  cmdString);
            instance.LunsKeyValue = lunsKeyValue;
            instance.Capacity = capacity;

            return instance;
        }


        /// <summary>  
        /// Expand-EmcLun:
        ///    The method to implement Expand-EmcLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExpandEmcLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            ExpandEmcLun cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);

            cmdClass = ParseCmd(cmd, false);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// ExpandEmcLunNegativeTestMethod:
        ///    The method to implement Expand-EmcLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExpandEmcLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            bool caseFail = false;

            ExpandEmcLun expandemclunClass = ParseCmd(cmd);

            try
            {
                expandemclunClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", expandemclunClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcXenServerStorageRepositoryTest: test class for Remove-EmcXenServerStorageRepository cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcXenServerStorageRepositoryTest
    {
        public RemoveEmcXenServerStorageRepositoryTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            TestSetup.SetSREnvironment(psMachine);

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string sr = HelperAdapter.GetParameter("StorageRepository");
            string xenServer = HelperAdapter.GetParameter("XenServer");
            string srUuid = TestSetup.GetPropertyValue(psMachine, sr, "Uuid");
            string result = null;

            if (!string.IsNullOrEmpty(srUuid))
            {
                GetEmcXenServerStorageRepository getSR = new GetEmcXenServerStorageRepository(srUuid, xenServer);
                getSR.PrefixString = sr;
                result = getSR.RunCMD(psMachine);

                if (!string.IsNullOrEmpty(result))
                {
                    TestSetup.ClearSREnvironment(psMachine);
                }
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            string storage = TestSetup.SetStorageEnvironment(psMachine);

            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            log.LogInfo("--------Class Init End---------");

            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcXenServerStorageRepository instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcXenServerStorageRepository instance</returns>  
        public RemoveEmcXenServerStorageRepository ParseCmd(string cmd)
        {
            #region AutoGenerate
            string storagerepository = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$StorageRepository", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagerepository = HelperAdapter.GetParameter("StorageRepository");
                cmdString = cmdString.Replace("$StorageRepository", storagerepository);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            RemoveEmcXenServerStorageRepository instance = new RemoveEmcXenServerStorageRepository(storagerepository, silent, cmdString);
            instance.UUID = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("StorageRepository"), "Uuid");
            return instance;
        }


        /// <summary>  
        /// Remove-EmcXenServerStorageRepository:
        ///    The method to implement Remove-EmcXenServerStorageRepository poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcXenServerStorageRepositoryTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            RemoveEmcXenServerStorageRepository cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// RemoveEmcXenServerStorageRepositoryNegativeTestMethod:
        ///    The method to implement Remove-EmcXenServerStorageRepository negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcXenServerStorageRepositoryNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            RemoveEmcXenServerStorageRepository removexenserverstoragerepositoryClass = ParseCmd(cmd);

            try
            {
                removexenserverstoragerepositoryClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removexenserverstoragerepositoryClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcXenServerStorageRepositoryTest: test class for Get-EmcXenServerStorageRepository cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcXenServerStorageRepositoryTest
    {
        public GetEmcXenServerStorageRepositoryTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string> xenServerSR;
        private static bool createSR;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");
            // Open PowerShell Session
            psMachine = new PowershellMachine();
            createSR = false;

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            string storage = TestSetup.SetStorageEnvironment(psMachine);

            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                string result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                    updateXenServer.RunCMD(psMachine);
                    string srs = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("XenServer"), "StorageRepositories");
                    List<SortedList<string, string>> srList = HelperAdapter.GenerateKeyValuePairsList(srs);
                    Random rand = new Random();
                    int i = rand.Next(srList.Count);
                    xenServerSR = srList[i];
                }
                else
                {
                    createSR = true;
                    xenServerSR = HelperAdapter.GenerateKeyValuePairs(result);
                }
            }
            catch (Exception ex)
            {
                ESIPSTestClassCleanUP();
                throw ex;
            }
            
            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcXenServerStorageRepository instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcXenServerStorageRepository instance</returns>  
        public GetEmcXenServerStorageRepository ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string xenserver = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            int srCount = -1;// -1 represents multiple

            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = xenServerSR["Name"]; ;
                cmdString = cmdString.Replace("$Name", "\"" + id + "\"");
                srCount = 1;
            }
            else if (cmd.IndexOf("$UUID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = xenServerSR["Uuid"];
                cmdString = cmdString.Replace("$UUID", id);
                srCount = 1;
            }

            if (cmd.IndexOf("$XenServer", StringComparison.OrdinalIgnoreCase) > 0)
            {
                xenserver = HelperAdapter.GetParameter("XenServer");
                cmdString = cmdString.Replace("$XenServer", xenserver);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcXenServerStorageRepository instance = new GetEmcXenServerStorageRepository(id, xenserver, silent,  cmdString);
            instance.SRCount = srCount;
            instance.SRKeyValue = xenServerSR;

            return instance;
        }


        /// <summary>  
        /// Get-EmcXenServerStorageRepository:
        ///    The method to implement Get-EmcXenServerStorageRepository poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerStorageRepositoryTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            GetEmcXenServerStorageRepository cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcXenServerStorageRepositoryNegativeTestMethod:
        ///    The method to implement Get-EmcXenServerStorageRepository negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerStorageRepositoryNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            GetEmcXenServerStorageRepository getxenserverstoragerepositoryClass = ParseCmd(cmd);

            try
            {
                getxenserverstoragerepositoryClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getxenserverstoragerepositoryClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

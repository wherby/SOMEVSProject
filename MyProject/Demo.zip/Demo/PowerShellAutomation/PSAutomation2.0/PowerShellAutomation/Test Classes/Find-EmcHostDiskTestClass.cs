using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class FindEmcHostDiskTest
    {
        public FindEmcHostDiskTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string ptDiskLocation;

        private static SortedList<string, string> ptDiskScsiController;


        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(HelperAdapter.GetParameter("Lun"), HelperAdapter.GetParameter("Host"), null, null, "Available");
            setLunAccess.RunCMD(psMachine, false);
            GetEmcHostLunIdentifier lunIdentifier = new GetEmcHostLunIdentifier(HelperAdapter.GetParameter("Lun"));
            lunIdentifier.PrefixString = HelperAdapter.GetParameter("LunIdentifier");
            lunIdentifier.RunCMD(psMachine, true);

            if (HelperAdapter.IsHyperVSet())
            {
                CreateVMDisk(psMachine);
            }

            if (HelperAdapter.IsClusterSet())
            {
                //Set cluster Lun.
                string lunForCluster = HelperAdapter.GetParameter("LunC");
                string clusterPrefix = HelperAdapter.GetParameter("Cluster");

                TestSetup.SetLunEnvironment(psMachine, true, null, lunForCluster);

                TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
                SetEmcLunAccess setLunAccessForCluster = new SetEmcLunAccess(lunForCluster, null, null, null, "Available", null, null, null, clusterPrefix);
                setLunAccessForCluster.RunCMD(psMachine, false);
            }
            log.LogInfo("--------Class Initialize End--------");
        }

        public static void CreateVMDisk(PowershellMachine psMachine )
        {
            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            string vm = HelperAdapter.GetParameter("VirtualMachine");
            string lunForVM = HelperAdapter.GetParameter("LunForVM");
            string ptDiskConfig = HelperAdapter.GetParameter("PassthroughDiskConfiguration");
            string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            // Connect to Hyper-V          
            log.LogInfo("Class Initialize: Connect Hyper-V System");
            string result = TestSetup.ConnectSystem(psMachine, "Hyperv", hyperv);
            SortedList<string, string> hypervKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!hypervKeyValue["Model"].Contains("Hyper-V"))
            {
                log.LogError(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                PSException pe = new PSException(string.Format("This host system is not a Hyper-V. Please connect to Hyper-V."));
                throw pe;
            }


            // Connect to VM         
            log.LogInfo("Class Initialize: Connect Virtual Machine System");
            try
            {
                result = TestSetup.ConnectVirtualMachine(psMachine, HyperVisorType.HyperV, vm);
            }
            catch (Exception ex)
            {
                log.LogInfo(ex.Message);
                
                result=TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Host"));
                TestSetup.GetPropertyValue(psMachine, string.Format("{0}={1}",vm , HelperAdapter.GetParameter("Host")));
            }
            SortedList<string, string> vmKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (!vmKeyValue["Model"].Equals("Virtual Machine"))
            {
                log.LogError(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                PSException pe = new PSException(string.Format("This host system is not a Virtual Machine. Please connect to a Virtual Machine."));
                throw pe;
            }

            UpdateEmcSystem updateHyperv = new UpdateEmcSystem(hyperv);
            updateHyperv.RunCMD(psMachine);

            UpdateEmcSystem updateVM = new UpdateEmcSystem(vm);
            updateVM.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, vm);
            vmConfig.PrefixString = vmConfigPrefix;
            vmConfig.RunCMD(psMachine, true);


            //Create a lun for VM.
            TestSetup.SetLunEnvironment(psMachine,true,null,lunForVM);
            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(lunForVM, hyperv, null, null, "Available");
            setLunAccess.RunCMD(psMachine, false);

            FindEmcHostDisk findDisk = new FindEmcHostDisk(hyperv, null, null, null, lunForVM);
            findDisk.PrefixString = HelperAdapter.GetParameter("DiskForVM");
            findDisk.RunCMD(psMachine);


            updateVM.RunCMD(psMachine);

            ptDiskScsiController = TestSetup.GetRandomScsiController(psMachine);
            ptDiskLocation = TestSetup.GetRandomScsiControllerLocation(psMachine, ptDiskScsiController["ScsiControllerIndex"]);

            AddEmcPassthroughDiskToVirtualMachine addPtDisk = new AddEmcPassthroughDiskToVirtualMachine(null, vmConfigPrefix, ptDiskLocation, ptDiskScsiController["ScsiControllerId"], ptDiskScsiController["ScsiControllerIndex"], null, null, HelperAdapter.GetParameter("DiskForVM"));
            addPtDisk.PrefixString = ptDiskConfig;
            addPtDisk.RunCMD(psMachine, true);

        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            if (HelperAdapter.IsClusterSet())
            {
                string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                string lunForCluster = HelperAdapter.GetParameter("LunC");
                TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
                TestSetup.ClearLunEnvironment(psMachine, lunForCluster);
            }

            if (HelperAdapter.IsVMwareSet())
            {
                VMDiskClean(psMachine);
            }

            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(HelperAdapter.GetParameter("Lun"), HelperAdapter.GetParameter("Host"), "Unavailable");
            setLunAccess.RunCMD(psMachine, false);
            //TODO: refine the following code:
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }

        public static void VMDiskClean(PowershellMachine psMachine)
        {
            string hyperv = HelperAdapter.GetParameter("Hypervisor");
            string vm = HelperAdapter.GetParameter("VirtualMachine");
            string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            string lunForVM = HelperAdapter.GetParameter("LunForVM");

            
            RemoveEmcVirtualDiskFromVm rmPtDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, ptDiskLocation, "Force", ptDiskScsiController["ScsiControllerId"], ptDiskScsiController["ScsiControllerIndex"]);
            rmPtDisk.RunCMD(psMachine);



            UpdateEmcSystem updateSystem = new UpdateEmcSystem(vm);
            updateSystem.RunCMD(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine, hyperv, null, lunForVM);
            TestSetup.ClearLunEnvironment(psMachine, lunForVM);
        }

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a FindEmcHostDisk instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>FindEmcHostDisk instance</returns>  
        public FindEmcHostDisk ParseCmd(string cmd)
        {

            #region AutoGenerate
            string hostsystem = null;
            string hostlunidentifier = null;
            string rescancount = null;
            string silent = null;
            string lun = null;
            string clustersystem = null;
            string virtualmachine = null;
            string vmdiskconfig = null;


            string cmdString = cmd;
   
            #endregion


            string hostSystemString =HelperAdapter.GetParameter("Host");
            string hostLunIdentifierString = HelperAdapter.GetParameter("LunIdentifier");
            string lunString = HelperAdapter.GetParameter("Lun") ;
            string silentString = "Silent";
            string virtualMachineString = HelperAdapter.GetParameter("VirtualMachine");
            string vmDiskConfigString = HelperAdapter.GetParameter("PassthroughDiskConfiguration");
            string clusterSystemString = HelperAdapter.GetParameter("Cluster");
            string lunForCluster = HelperAdapter.GetParameter("LunC");

            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Disk");
            string rescanCountString = dic["RescanCount"];




            if (cmdString.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostSystemString;
                cmdString = cmdString.Replace("$HostSystem", hostSystemString);
            }
            if (cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostlunidentifier = hostLunIdentifierString;
                cmdString = cmdString.Replace("$HostLunIdentifier", hostLunIdentifierString);
            }
            if (cmdString.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    lunString = lunForCluster;
                }
                lun = lunString;
                cmdString = cmdString.Replace("$Lun", lunString);
            }
            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustersystem = clusterSystemString;
                cmdString = cmdString.Replace("$ClusterSystem", clusterSystemString);
            }
            if (cmdString.IndexOf("$VirtualMachine", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualmachine = virtualMachineString;
                cmdString = cmdString.Replace("$VirtualMachine", virtualMachineString);
            }
            if (cmdString.IndexOf("$VmDiskConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmdiskconfig = vmDiskConfigString;
                cmdString = cmdString.Replace("$VmDiskConfig", vmDiskConfigString);
            }
            if (cmdString.IndexOf("$RescanCount", StringComparison.OrdinalIgnoreCase) > 0)
            {
                rescancount = rescanCountString;
                cmdString = cmdString.Replace("$RescanCount", rescancount);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = silentString;
            }
            FindEmcHostDisk findDisk = new FindEmcHostDisk(hostsystem, hostlunidentifier, rescancount, silent, lun, clustersystem, virtualmachine, vmdiskconfig, cmdString);

            return findDisk;
        }


        public void FindEmcHostDiskTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            FindEmcHostDisk findDisk = ParseCmd(cmd);
            findDisk.VerifyTheCMD(psMachine);
        }

        public void FindEmcHostDiskNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            FindEmcHostDisk findDisk = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                findDisk.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// ImportEmcStorageAccessControlTest: test class for Import-EmcStorageAccessControl cmdlet
    /// </summary>
    [TestClass]
    public partial class ImportEmcStorageAccessControlTest
    {
        public ImportEmcStorageAccessControlTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string storageGlobalID;
        private static string poolName;
        private static string filePath;
        private static string protectionKey;
        private static string poolPrefix = HelperAdapter.GetParameter("Pool");
        private static string accessControlPrefix = HelperAdapter.GetParameter("AccessControl");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            GetEmcStorageSystem storage = new GetEmcStorageSystem();
            string result = storage.RunCMD(psMachine);
            
            if (!String.IsNullOrEmpty(result))
            {
                // Disconnect Storage System
                log.LogInfo("Class Cleanup: Disconnect Imported Storage System");
                DisconnectEmcStorageSystem disconnectEmcStorageSystem = new DisconnectEmcStorageSystem();
                disconnectEmcStorageSystem.VerifyTheCMD(psMachine, storageGlobalID);
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine, "All");
            string result = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalID = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Select a random pool          
            log.LogInfo("Class Initialize: Get Storage Pool");
            result = TestSetup.SetPoolEnvironment(psMachine, null, null, null, null, TestSetup.StorageSystemType);
            poolName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];


            // New Access Control
            log.LogInfo("Class Initialize: New Access Control");
            NewEmcStorageAccessControl accessControl = new NewEmcStorageAccessControl();
            accessControl.PrefixString = accessControlPrefix;
            accessControl.VerifyTheCMD(psMachine);

            // Add Pool to Storage Access Control
            AddEmcStorageAccessControl addEmcStorageAccessControl = new AddEmcStorageAccessControl(accessControlPrefix, poolPrefix);
            addEmcStorageAccessControl.VerifyTheCMD(psMachine, storageGlobalID, poolName);

            // Get export file name
            string path = HelperAdapter.GetProperty("StorageAccessControlConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            string fileFolder = dic["FileFolder"];
            string fileName = dic["FileNamePrefix"];
            fileName = fileName + HelperAdapter.GenerateRandomString() + ".EsiAcl";
            protectionKey = dic["ProtectionKey"];

            if (!Directory.Exists(fileFolder))
            {
                Directory.CreateDirectory(fileFolder);
            }

            filePath = fileFolder + fileName;

            // Export Storage Access Control
            ExportEmcStorageAccessControl exportEmcStorageAccessConrol = new ExportEmcStorageAccessControl(
                accessControlPrefix, filePath, protectionKey);
            exportEmcStorageAccessConrol.VerifyTheCMD(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize End--------");  
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");
            if (TestSetup.TestPath(psMachine, filePath))
            {
                TestSetup.RemoveItem(psMachine, filePath);
                if (TestSetup.TestPath(psMachine, filePath))
                {
                    log.LogError(String.Format("Failed to remove exported access control file {0}", filePath));
                    PSException pe = new PSException(String.Format("Failed to remove exported access control file {0}", filePath));
                    throw pe;
                }
            }

            log.LogInfo("--------Class Clean Up End---------");
            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Import-EmcStorageAccessControl instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Import-EmcStorageAccessControl instance</returns>  
        public ImportEmcStorageAccessControl ParseCmd(string cmd)
        {
            #region AutoGenerate
            string file = null;
            string protectionkey = null;
            string force = null;
            string listonly = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("file", StringComparison.OrdinalIgnoreCase) > 0)
            {
                file = filePath;
                cmdString = cmdString.Replace("$File", file);
            }
            if (cmd.IndexOf("protectionkey", StringComparison.OrdinalIgnoreCase) > 0)
            {
                protectionkey = protectionKey;
                cmdString = cmdString.Replace("$ProtectionKey", protectionkey);
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }
            if (cmd.IndexOf("listonly", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "ListOnly";
            }
            
            ImportEmcStorageAccessControl instance = new ImportEmcStorageAccessControl(file, protectionkey, force, listonly, silent, whatif,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Import-EmcStorageAccessControl:
        ///    The method to implement Import-EmcStorageAccessControl poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ImportEmcStorageAccessControlTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            ImportEmcStorageAccessControl cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, storageGlobalID, poolName);
            
        }

        /// <summary>  
        /// ImportEmcStorageAccessControlNegativeTestMethod:
        ///    The method to implement Import-EmcStorageAccessControl negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ImportEmcStorageAccessControlNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            ImportEmcStorageAccessControl importemcstorageaccesscontrolClass = ParseCmd(cmd);

            try
            {
                importemcstorageaccesscontrolClass.VerifyTheCMD(psMachine, storageGlobalID, poolName);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", importemcstorageaccesscontrolClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcLunTest
    {
        public GetEmcLunTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        /// <summary>
        /// Lun name for host Lun.
        /// </summary>
        private static string lunName;

        /// <summary>
        /// Lun name for cluster Lun.
        /// </summary>
        private static string lunNameC;

        /// <summary>
        /// Lun name for scsi.
        /// </summary>
        private static string lunNameScsi;


        private static string initiatorIDGet;

        private static string hostLunIDGet;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            List<string> ps = new List<string>();
            ps.Add(string.Format("Get-EmcStorageGroup -StorageSystem $storage |  where {{ $_.Name -match \"{0}\"}}" ,"aaa"));

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);

            TestSetup.SetPoolEnvironment(psMachine);
            string result=TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            lunName = lunKeyValue["Name"];
            string arrayLunID = lunKeyValue["ArrayLunId"];
            TestSetup.SetHostEnvironment(psMachine);
            TestSetup.SetDiskEnvironment(psMachine);
            TestSetup.SetVolumeEnvironment(psMachine);
            if (IsStorageClariion())
            {
                GetStorageGroupInformation(psMachine, arrayLunID);
            }

            if (HelperAdapter.IsClusterSet())
            {
                //Set cluster Lun.
                string lunForCluster = HelperAdapter.GetParameter("LunC");
                string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");
                string diskPrefixForCluster = HelperAdapter.GetParameter("ClusterDisk");
                string volumePrefixForCluster = HelperAdapter.GetParameter("VolumeForCluster");
                string resultForLunC = TestSetup.SetLunEnvironment(psMachine, true, null, lunForCluster);
                SortedList<string, string> LunForClusterKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForLunC);
                lunNameC = LunForClusterKeyValue["Name"];
                TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
                TestSetup.SetDiskEnvironment(psMachine, diskFindForCluster, null, lunForCluster, clusterPrefix);
                TestSetup.SetVolumeEnvironment(psMachine, diskFindForCluster, null, clusterPrefix, volumePrefixForCluster);
                TestSetup.SetClusterDiskEnvironment(psMachine, diskFindForCluster, clusterPrefix, diskPrefixForCluster);
            }

            if (HelperAdapter.IsVMwareSet())
            {
                //set ScsiLun
                string lunForScsi = HelperAdapter.GetParameter("LunForScsi");
                string resultForScsi=TestSetup.SetLunEnvironment(psMachine, true, null, lunForScsi);
                SortedList<string, string> LunForScsiKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForScsi);
                lunNameScsi = LunForScsiKeyValue["Name"];
                // Connect to ESX Host
                log.LogInfo("Class Initialize: Connect to ESX Host");
                string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);

                // Get ESX Host
                GetEmcESXHost getEmcESXHost = new GetEmcESXHost();
                string esxHostPrefix = HelperAdapter.GetParameter("ESXHost");
                getEmcESXHost.PrefixString = esxHostPrefix;
                result = getEmcESXHost.RunCMD(psMachine, true);


                // Get Datastore
                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                string dataStoreName = HelperAdapter.Load(path, "DataStore")["Name"];
                string datastorePrefix = HelperAdapter.GetParameter("DataStore");
                GetEmcDataStore getEmcDataStore = new GetEmcDataStore(dataStoreName);
                getEmcDataStore.PrefixString = datastorePrefix;
                getEmcDataStore.RunCMD(psMachine, true);

                //Unmask Lun to ESX Host and Find the host disk
                log.LogInfo("Class Initialize: Unmask Lun and rescan host disk");
                string diskForESX = HelperAdapter.GetParameter("DiskForVM");
                result = TestSetup.SetDiskEnvironment(psMachine, diskForESX, esxHostPrefix, lunForScsi, null, false);

                //find ScsiLun
                log.LogInfo("Find Scsi lun");
                GetEmcScsiLun getScsiLun = new GetEmcScsiLun(null, null, lunForScsi, null, esxHostPrefix);
                getScsiLun.PrefixString = HelperAdapter.GetParameter("ScsiLun");
                getScsiLun.RunCMD(psMachine);

                //Set hostLun indentifier
                GetEmcHostLunIdentifier getIdentifier = new GetEmcHostLunIdentifier(lunForScsi, esxHostPrefix);
                getIdentifier.PrefixString = HelperAdapter.GetParameter("LunIdentifier");
                getIdentifier.RunCMD(psMachine);
            }
                
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            if (HelperAdapter.IsClusterSet())
            {
                string volumePrefixForCluster = HelperAdapter.GetParameter("VolumeForCluster");
                string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");
                string diskPrefixForCluster = HelperAdapter.GetParameter("ClusterDisk");
                string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                string lunForCluster = HelperAdapter.GetParameter("LunC");
                TestSetup.ClearClusterDiskEnvironment(psMachine, diskFindForCluster, clusterPrefix);
                TestSetup.ClearVolumeEnvironment(psMachine, volumePrefixForCluster, null, clusterPrefix);
                TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
                TestSetup.ClearLunEnvironment(psMachine, lunForCluster);
            }

            if (HelperAdapter.IsVMwareSet())
            {
                string esxHostPrefix = HelperAdapter.GetParameter("ESXHost");
                string lunForScsi = HelperAdapter.GetParameter("LunForScsi");
                TestSetup.ClearDiskEnvironment(psMachine, esxHostPrefix, null, lunForScsi);
                TestSetup.ClearLunEnvironment(psMachine, lunForScsi);
            }

            TestSetup.ClearVolumeEnvironment(psMachine);
            TestSetup.ClearDiskEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);



            log.LogInfo("--------Class Clean Up End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcLun instance</returns>  
        public GetEmcLun ParseCmd(string cmd)
        {



            #region AutoGenerate
            string id = null;
            string pool = null;
            string silent = null;
            string hostdisk = null;
            string volume = null;
            string clusterdisk = null;
            string blockstoragesystem = null;
            string hostlunidentifier = null;
            string datastore = null;
            string scsilun = null;
            string clariionstoragesystem = null;
            string initiatorid = null;
            string hostlunid = null;


            string cmdString = cmd;
   
            #endregion


            string idString = lunName;
            string idStringC = lunNameC;
            string poolString = HelperAdapter.GetParameter("Pool");
            string hostDiskString = HelperAdapter.GetParameter("Disk");
            string volumeString = HelperAdapter.GetParameter("Volume");
            string blockStorageSystemString = HelperAdapter.GetParameter("System");
            string clusterDiskString = HelperAdapter.GetParameter("ClusterDisk");

            string hostLunIdentifierString = HelperAdapter.GetParameter("LunIdentifier");
            string dataStoreString = HelperAdapter.GetParameter("DataStore");
            string scsiLunString = HelperAdapter.GetParameter("ScsiLun");
            string clariionStorageSystemString = HelperAdapter.GetParameter("System");
            string initiatorIdString = initiatorIDGet;
            string hostLunIdString = hostLunIDGet;
            



            if(cmdString.IndexOf("$ID",StringComparison.OrdinalIgnoreCase)>0)
            {
                if (cmdString.IndexOf("$ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    idString = idStringC;
                }
                if ((cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)||
                   
                    (cmdString.IndexOf("$ScsiLun", StringComparison.OrdinalIgnoreCase) > 0)||
                    (cmdString.IndexOf("$ClariionStorageSystem", StringComparison.OrdinalIgnoreCase) > 0))
                {
                    idString = lunNameScsi;
                }

                if (cmdString.IndexOf("$DataStore", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    GetEmcLun getDataStoreLun = new GetEmcLun(null, null,null, null, null, null, null, null, dataStoreString);
                    getDataStoreLun.PrefixString = "$lunForDataStore";
                    getDataStoreLun.RunCMD(psMachine);
                    idString = TestSetup.GetPropertyValue(psMachine, "$lunForDataStore", "Name");
                }
                id = idString;
                cmdString = cmdString.Replace("$ID", idString);
            }
            if(cmdString.IndexOf("$Pool",StringComparison.OrdinalIgnoreCase)>0)
            {
                pool = poolString;
                cmdString = cmdString.Replace("$Pool", poolString);
            }
            if(cmdString.IndexOf("$HostDisk",StringComparison.OrdinalIgnoreCase)>0)
            {
                hostdisk = hostDiskString;
                cmdString = cmdString.Replace("$HostDisk", hostDiskString);
            }
            if (cmdString.IndexOf("Volume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                volume = volumeString;
                cmdString = cmdString.Replace("$Volume", volumeString);
            }
            if(cmdString.IndexOf("$BlockStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                blockstoragesystem = blockStorageSystemString;
                cmdString = cmdString.Replace("$BlockStorageSystem", blockStorageSystemString);
            }
            if (cmdString.IndexOf("$ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clusterdisk = clusterDiskString;
                cmdString = cmdString.Replace("$ClusterDisk", clusterDiskString);
            }
            if (cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostlunidentifier = hostLunIdentifierString;
                cmdString = cmdString.Replace("$HostLunIdentifier", hostlunidentifier);
            }
            if (cmdString.IndexOf("$DataStore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                datastore = dataStoreString;
                cmdString = cmdString.Replace("$DataStore", datastore);
                if ((TestSetup.StorageSystemType != "VNX") && (TestSetup.StorageSystemType != "VNX-Block"))
                {
                    log.BypassTest();
                }
            }
            if (cmdString.IndexOf("$ScsiLun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsilun = scsiLunString;
                cmdString = cmdString.Replace("$ScsiLun", scsilun);
            }
            if (cmdString.IndexOf("$ClariionStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clariionstoragesystem = clariionStorageSystemString;
                cmdString = cmdString.Replace("$ClariionStorageSystem", clariionstoragesystem);
            }
            if (cmdString.IndexOf("$InitiatorId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                initiatorid = initiatorIdString;
                cmdString = cmdString.Replace("$InitiatorId", initiatorid);
            }
            if (cmdString.IndexOf("$HostLunId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostlunid= hostLunIdString;
                cmdString = cmdString.Replace("$HostLunId", hostlunid);
            }   
            if(cmdString.IndexOf("Silent",StringComparison.OrdinalIgnoreCase)>0)
            {
                silent = "Silent";
            }

            GetEmcLun getLun = new GetEmcLun(id, pool, silent, hostdisk, volume, clusterdisk, blockstoragesystem, hostlunidentifier, datastore, scsilun,
                clariionstoragesystem,initiatorid,hostlunid, cmdString);

            return getLun;
        }

        //private bool BypassTest(string cmd)
        //{
        //    bool bypass = false;
        //    if (cmd.IndexOf("Cluster", StringComparison.OrdinalIgnoreCase) > 0)
        //    {
        //        bypass = true;
        //    }
        //    return bypass;
        //}

        public void GetEmcLunTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            Bypass(cmd);
            GetEmcLun rmLun = ParseCmd(cmd);
            rmLun.VerifyTheCMD(psMachine);
        }


        public void GetEmcLunNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            Bypass(cmd);
            GetEmcLun rmLun = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                rmLun.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }

        private static void GetStorageGroupInformation(PowershellMachine psMachine,string arrayLunID)
        {
            string hostString = HelperAdapter.GetParameter("Host");
            string hostName=TestSetup.GetPropertyValue(psMachine,hostString,"Name");
            List<string> ps = new List<string>();
            ps.Add(" Update-EmcSystem $system ");
            ps.Add(string.Format("$maps=Get-EmcStorageGroup -StorageSystem $system |  where {{ $_.Name -match \"{0}\"}}", hostName));
            ps.Add("$maps");
            string result=psMachine.RunScript(ps, new List<PSParam> { }).OutStr;
            SortedList<string,string> storageGroupkeyValues=HelperAdapter.GenerateKeyValuePairs(result);
            string initiatorString = storageGroupkeyValues["HbaIds"];
            string[] initiators = initiatorString.Split(new char[] { '{', ',', '}' }, StringSplitOptions.RemoveEmptyEntries);
            initiatorIDGet = initiators[0];
            string hostLun = TestSetup.GetPropertyValue(psMachine, string.Format("$maps.ArrayLunIdToHostLunIdMappings"));
            hostLunIDGet=TestSetup.GetPropertyValue(psMachine, string.Format("$maps.ArrayLunIdToHostLunIdMappings[{0}]", arrayLunID));
        }

        private static bool IsStorageClariion()
        {
            string type = TestSetup.StorageSystemType;
            string clariionTypes = "CLARiiON-CX4, VNX, VNX-Block";
            if (clariionTypes.IndexOf(type) >= 0)
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// The method is used to bypass  the test.
        /// </summary>
        /// <param name="cmd">The cmd string.</param>
        private static void Bypass(string cmd)
        {
            if (IsStorageClariion() == false)
            {
                if (cmd.IndexOf("ClariionStorageSystem", StringComparison.OrdinalIgnoreCase) >= 0)
                {
                    log.BypassTest();
                }
            }
        }
    }

}

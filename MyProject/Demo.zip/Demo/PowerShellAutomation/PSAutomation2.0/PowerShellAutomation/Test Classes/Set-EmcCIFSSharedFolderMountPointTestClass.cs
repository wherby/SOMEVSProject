using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// SetEmcCifsSharedFolderMountPointTest: test class for Set-EmcCIFSSharedFolderMountPoint cmdlet
    /// </summary>
    [TestClass]
    public partial class SetEmcCifsSharedFolderMountPointTest
    {
        public SetEmcCifsSharedFolderMountPointTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static bool isMountPointNeedRemoved;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            isMountPointNeedRemoved = false;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (isMountPointNeedRemoved == true)
            {
                TestSetup.RemoveMountPointEnvironment(psMachine);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                TestSetup.SetVNXESharedFolderPoolEnvironment(psMachine);
            }
            else
            {
                TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
                TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            }
            TestSetup.SetCIFSSharedFolderEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            TestSetup.SetHostCreadentialEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            TestSetup.RemoveSharedFolderEnvironment(psMachine);
            if (TestSetup.IsStorageVNXE() == false)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Set-EmcCIFSSharedFolderMountPoint instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Set-EmcCIFSSharedFolderMountPoint instance</returns>  
        public SetEmcCIFSSharedFolderMountPoint ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hostsystem = null;
            string driveletter = null;
            string sharedfolder = null;
            string credential = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string hostsystemString  = HelperAdapter.GetParameter("Host");
            string driveletterString = TestSetup.GetRandomDriveLetter(psMachine, hostsystemString);
            string sharedfolderString = HelperAdapter.GetParameter("SharedFolder");
            string credentialString = HelperAdapter.GetParameter("HostCredential");

            if (cmd.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostsystemString;
                cmd = cmd.Replace("$HostSystem", hostsystem);
            }
            if (cmd.IndexOf("$DriveLetter", StringComparison.OrdinalIgnoreCase) > 0)
            {
                driveletter = driveletterString;
                cmd = cmd.Replace("$DriveLetter", driveletter);
            }
            if (cmd.IndexOf("$SharedFolder", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sharedfolder = sharedfolderString;
                cmd = cmd.Replace("$SharedFolder", sharedfolder);
            }
            if (cmd.IndexOf("$Credential", StringComparison.OrdinalIgnoreCase) > 0)
            {
                credential = credentialString;
                cmd = cmd.Replace("$Credential", credential);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            SetEmcCIFSSharedFolderMountPoint instance = new SetEmcCIFSSharedFolderMountPoint(hostsystem, driveletter, sharedfolder, credential, silent,  cmd);
            instance.PrefixString = HelperAdapter.GetParameter("NetworkShareFolder");
            return instance;
        }


        /// <summary>  
        /// Set-EmcCIFSSharedFolderMountPoint:
        ///    The method to implement Set-EmcCIFSSharedFolderMountPoint poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcCifsSharedFolderMountPointTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            SetEmcCIFSSharedFolderMountPoint cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
            isMountPointNeedRemoved = true;
        }

        /// <summary>  
        /// SetEmcCifsSharedFolderMountPointNegativeTestMethod:
        ///    The method to implement Set-EmcCIFSSharedFolderMountPoint negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcCifsSharedFolderMountPointNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            SetEmcCIFSSharedFolderMountPoint setemccifssharedfoldermountpointClass = ParseCmd(cmd);

            try
            {
                setemccifssharedfoldermountpointClass.VerifyTheCMD(psMachine);
                isMountPointNeedRemoved = true;
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", setemccifssharedfoldermountpointClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// AddEmcXenServerVirtualDiskTest: test class for Add-EmcXenServerVirtualDisk cmdlet
    /// </summary>
    [TestClass]
    public partial class AddEmcXenServerVirtualDiskTest
    {
        public AddEmcXenServerVirtualDiskTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static bool createSR;
        private static SortedList<string, string> newDiskKeyValue;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            string xenServer = HelperAdapter.GetParameter("XenServer");
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            string result = TestSetup.SetXenServerVirtualDiskEnvironment(psMachine);
            newDiskKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            TestSetup.GetPropertyValue(psMachine, xenServer, "RefreshVirtualMachinesConfigurations()");

            GetEmcVirtualMachineConfiguration getVmConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine"));
            getVmConfig.PrefixString = vmConfig;
            getVmConfig.RunCMD(psMachine, true);

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string xenServer = HelperAdapter.GetParameter("XenServer");
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            TestSetup.GetPropertyValue(psMachine, xenServer, "RefreshVirtualMachinesConfigurations()");
            GetEmcVirtualMachineConfiguration getVmConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine"));
            getVmConfig.PrefixString = vmConfig;
            getVmConfig.RunCMD(psMachine, true);
            string result = TestSetup.GetPropertyValue(psMachine, vmConfig, "VmDisksConfigs");

            if (!string.IsNullOrEmpty(result))
            {
                List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(result);

                foreach (SortedList<string, string> disk in disksList)
                {
                    if (disk["Name"] == newDiskKeyValue["Name"])
                    {
                        try
                        {
                            RemoveEmcXenServerVirtualDisk removeVirtualDisk = new RemoveEmcXenServerVirtualDisk(vmConfig, disk["Location"]);
                            removeVirtualDisk.RunCMD(psMachine);
                        }
                        catch
                        {
                            log.LogWarning("Remove virtual disk failed");
                        }
                        break;
                    }
                }
            }
            TestSetup.ClearXenServerVirtualDiskEnvironment(psMachine);

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();
            createSR = false;

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));
            Dictionary<string, string> dic = HelperAdapter.GetHostVMs(HyperVisorType.XenServer)[0];
            TestSetup.ConnectSystem(psMachine, "xenVM", HelperAdapter.GetParameter("VirtualMachine"), dic);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                string result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    updateXenServer.RunCMD(psMachine);
                    GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository("gui_testsr_sandy2", HelperAdapter.GetParameter("XenServer"), null, null);
                    sr.PrefixString = HelperAdapter.GetParameter("StorageRepository");
                    result = sr.RunCMD(psMachine, true);
                }
                else
                {
                    createSR = true;
                }

            }
            catch(Exception ex)
            {
                ESIPSTestClassCleanUP();
                throw ex;
            }

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Add-EmcXenServerVirtualDisk instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Add-EmcXenServerVirtualDisk instance</returns>  
        public AddEmcXenServerVirtualDisk ParseCmd(string cmd)
        {
            #region AutoGenerate
            string virtualdisk = null;
            string virtualmachineconfiguration = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$VirtualDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualdisk = HelperAdapter.GetParameter("XenServerVirtualDisk");
                cmdString = cmdString.Replace("$VirtualDisk", virtualdisk);
            }

            if (cmd.IndexOf("$VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration");
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", virtualmachineconfiguration);
            }
            
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }


            AddEmcXenServerVirtualDisk instance = new AddEmcXenServerVirtualDisk(virtualdisk, virtualmachineconfiguration, silent,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Add-EmcXenServerVirtualDisk:
        ///    The method to implement Add-EmcXenServerVirtualDisk poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcXenServerVirtualDiskTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            AddEmcXenServerVirtualDisk cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// AddEmcXenServerVirtualDiskNegativeTestMethod:
        ///    The method to implement Add-EmcXenServerVirtualDisk negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcXenServerVirtualDiskNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            AddEmcXenServerVirtualDisk addxenservervirtualdiskClass = ParseCmd(cmd);

            try
            {
                addxenservervirtualdiskClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", addxenservervirtualdiskClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

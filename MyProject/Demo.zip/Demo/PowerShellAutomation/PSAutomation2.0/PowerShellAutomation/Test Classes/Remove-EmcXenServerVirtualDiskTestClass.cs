using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcXenServerVirtualDiskTest: test class for Remove-EmcXenServerVirtualDisk cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcXenServerVirtualDiskTest
    {
        public RemoveEmcXenServerVirtualDiskTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static bool createSR;
        private static SortedList<string, string> diskKeyValue;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string xenServer = HelperAdapter.GetParameter("XenServer");
            string virtualDisk = HelperAdapter.GetParameter("XenServerVirtualDisk");
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            TestSetup.SetXenServerVirtualDiskEnvironment(psMachine);
            TestSetup.GetPropertyValue(psMachine, xenServer, "RefreshVirtualMachinesConfigurations()");
            
            GetEmcVirtualMachineConfiguration getVmConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine"));
            getVmConfig.PrefixString = vmConfig;
            getVmConfig.RunCMD(psMachine, true);

            string disks = TestSetup.GetPropertyValue(psMachine, vmConfig, "VmDisksConfigs");
            AddEmcXenServerVirtualDisk addVirtualDisk = new AddEmcXenServerVirtualDisk(virtualDisk, vmConfig);
            addVirtualDisk.PrefixString = HelperAdapter.GetParameter("XenVMDisk");
            string result = addVirtualDisk.RunCMD(psMachine);
            diskKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            TestSetup.GetPropertyValue(psMachine, xenServer, "RefreshVirtualMachinesConfigurations()");
            getVmConfig.RunCMD(psMachine, true);

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string xenServer = HelperAdapter.GetParameter("XenServer");
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");

            TestSetup.GetPropertyValue(psMachine, xenServer, "RefreshVirtualMachinesConfigurations()");
            GetEmcVirtualMachineConfiguration getVmConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine"));
            getVmConfig.PrefixString = vmConfig;
            getVmConfig.RunCMD(psMachine, true);
            string result = TestSetup.GetPropertyValue(psMachine, vmConfig, "VmDisksConfigs");

            if (!string.IsNullOrEmpty(result))
            {
                List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(result);

                foreach (SortedList<string, string> disk in disksList)
                {
                    if (HelperAdapter.SortedListIsEqual(disk, diskKeyValue))
                    {
                        try
                        {
                            RemoveEmcXenServerVirtualDisk removeVirtualDisk = new RemoveEmcXenServerVirtualDisk(vmConfig, diskKeyValue["Location"]);
                            removeVirtualDisk.RunCMD(psMachine);
                        }
                        catch
                        {
                            log.LogWarning("Remove virtual disk failed");
                        }
                        break;
                    }
                }
            }
            TestSetup.ClearXenServerVirtualDiskEnvironment(psMachine);

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();
            createSR = false;

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));
            Dictionary<string, string> dic = HelperAdapter.GetHostVMs(HyperVisorType.XenServer)[0];
            TestSetup.ConnectSystem(psMachine, "xenVM", HelperAdapter.GetParameter("VirtualMachine"), dic);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                string result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    updateXenServer.RunCMD(psMachine);
                    GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository("gui_testsr_sandy2", HelperAdapter.GetParameter("XenServer"), null, null);
                    sr.PrefixString = HelperAdapter.GetParameter("StorageRepository");
                    result = sr.RunCMD(psMachine, true);
                }
                else
                {
                    createSR = true;
                }

                
            }
            catch (Exception ex)
            {
                ESIPSTestClassCleanUP();
                throw ex;
            }

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

        //    TestSetup.ClearXenServerVirtualDiskEnvironment(psMachine);

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcXenServerVirtualDisk instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcXenServerVirtualDisk instance</returns>  
        public RemoveEmcXenServerVirtualDisk ParseCmd(string cmd)
        {
            #region AutoGenerate
            string virtualmachineconfiguration = null;
            string location = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration");
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", virtualmachineconfiguration);
            }

            if (cmd.IndexOf("$Location", StringComparison.OrdinalIgnoreCase) > 0)
            {
                location = diskKeyValue["Location"];
                cmdString = cmdString.Replace("$Location", location);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            RemoveEmcXenServerVirtualDisk instance = new RemoveEmcXenServerVirtualDisk(virtualmachineconfiguration, location, silent,  cmdString);
            instance.DiskKeyValue = diskKeyValue;

            return instance;
        }


        /// <summary>  
        /// Remove-EmcXenServerVirtualDisk:
        ///    The method to implement Remove-EmcXenServerVirtualDisk poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcXenServerVirtualDiskTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            RemoveEmcXenServerVirtualDisk cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// RemoveEmcXenServerVirtualDiskNegativeTestMethod:
        ///    The method to implement Remove-EmcXenServerVirtualDisk negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcXenServerVirtualDiskNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            RemoveEmcXenServerVirtualDisk removexenservervirtualdiskClass = ParseCmd(cmd);

            try
            {
                removexenservervirtualdiskClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removexenservervirtualdiskClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcXenServerVirtualDiskImageTest: test class for Remove-EmcXenServerVirtualDiskImage cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcXenServerVirtualDiskImageTest
    {
        public RemoveEmcXenServerVirtualDiskImageTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static bool createSR;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            TestSetup.SetXenServerVirtualDiskEnvironment(psMachine);

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string virtualDisk = HelperAdapter.GetParameter("XenServerVirtualDisk");
            string xenServer = HelperAdapter.GetParameter("XenServer");
            string diskUuid = TestSetup.GetPropertyValue(psMachine, virtualDisk, "Uuid");
            string result = null;

            if (!string.IsNullOrEmpty(diskUuid))
            {
                GetEmcXenServerVirtualDiskImage getVirtualDisk = new GetEmcXenServerVirtualDiskImage(diskUuid, xenServer);
                getVirtualDisk.PrefixString = virtualDisk;
                result = getVirtualDisk.RunCMD(psMachine);

                if (!string.IsNullOrEmpty(result.Trim()))
                {
                    RemoveEmcXenServerVirtualDiskImage removeVirtualDisk = new RemoveEmcXenServerVirtualDiskImage(virtualDisk);
                    removeVirtualDisk.RunCMD(psMachine);

                    UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
                    updateXenServer.RunCMD(psMachine);
                }
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();
            createSR = false;

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            try
            {
                UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                string result = TestSetup.SetSREnvironment(psMachine);
                if (string.IsNullOrEmpty(result))
                {
                    createSR = false;
                    updateXenServer.RunCMD(psMachine);
                    GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository("gui_testsr_sandy2", HelperAdapter.GetParameter("XenServer"), null, null);
                    sr.PrefixString = HelperAdapter.GetParameter("StorageRepository");
                    result = sr.RunCMD(psMachine, true);
                }
                else
                {
                    createSR = true;
                }
            }
            catch
            {
                ESIPSTestClassCleanUP();
                throw new PSException("SetSREnvironment in Class init failed");
            }

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            if (createSR)
            {
                TestSetup.ClearSREnvironment(psMachine);
            }
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcXenServerVirtualDiskImage instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcXenServerVirtualDiskImage instance</returns>  
        public RemoveEmcXenServerVirtualDiskImage ParseCmd(string cmd)
        {
            #region AutoGenerate
            string virtualdiskimage = null;
            string silent = null;

            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$VirtualDiskImage", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualdiskimage = HelperAdapter.GetParameter("XenServerVirtualDisk");
                cmdString = cmdString.Replace("$VirtualDiskImage", virtualdiskimage);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            RemoveEmcXenServerVirtualDiskImage instance = new RemoveEmcXenServerVirtualDiskImage(virtualdiskimage, silent, cmdString);
            instance.Uuid = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("XenServerVirtualDisk"), "Uuid");

            return instance;
        }


        /// <summary>  
        /// Remove-EmcXenServerVirtualDiskImage:
        ///    The method to implement Remove-EmcXenServerVirtualDiskImage poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcXenServerVirtualDiskImageTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            RemoveEmcXenServerVirtualDiskImage cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// RemoveEmcXenServerVirtualDiskImageNegativeTestMethod:
        ///    The method to implement Remove-EmcXenServerVirtualDiskImage negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcXenServerVirtualDiskImageNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            RemoveEmcXenServerVirtualDiskImage removexenservervirtualdiskimageClass = ParseCmd(cmd);

            try
            {
                removexenservervirtualdiskimageClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removexenservervirtualdiskimageClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcVNXSharedFolderPoolTest: test class for Remove-EmcVNXSharedFolderPool cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcVNXSharedFolderPoolTest
    {
        public RemoveEmcVNXSharedFolderPoolTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static bool isPoolNeedremoved;
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            isPoolNeedremoved = true;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (isPoolNeedremoved == true)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            log.LogInfo("--------Class Initialize Start--------");
 
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                log.BypassTest();
            }
            TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            log.LogInfo("--------Class Cleanup End--------"); 
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcVNXSharedFolderPool instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcVNXSharedFolderPool instance</returns>  
        public RemoveEmcVNXSharedFolderPool ParseCmd(string cmd)
        {
            #region AutoGenerate
            string sharedfolderpool = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            string sharedFolderPoolString = HelperAdapter.GetParameter("SharedFolderPool");

            if (cmd.IndexOf("$SharedFolderPool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sharedfolderpool = sharedFolderPoolString;
                cmd = cmd.Replace("$SharedFolderPool", sharedFolderPoolString);
            }
            if (cmd.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "force";
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }
            RemoveEmcVNXSharedFolderPool instance = new RemoveEmcVNXSharedFolderPool(sharedfolderpool, force, silent, whatif,  cmd);
            return instance;
        }


        /// <summary>  
        /// Remove-EmcVNXSharedFolderPool:
        ///    The method to implement Remove-EmcVNXSharedFolderPool poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcVNXSharedFolderPoolTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcVNXSharedFolderPool cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) < 0)
            {
                isPoolNeedremoved = false;
            }
        }

        /// <summary>  
        /// RemoveEmcVNXSharedFolderPoolNegativeTestMethod:
        ///    The method to implement Remove-EmcVNXSharedFolderPool negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcVNXSharedFolderPoolNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcVNXSharedFolderPool removeemcvnxsharedfolderpoolClass = ParseCmd(cmd);

            try
            {
                removeemcvnxsharedfolderpoolClass.VerifyTheCMD(psMachine);
                if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    isPoolNeedremoved = false;
                }
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removeemcvnxsharedfolderpoolClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

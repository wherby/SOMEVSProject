using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcStorageGroupTest: test class for Get-EmcStorageGroup cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcStorageGroupTest
    {
        public GetEmcStorageGroupTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string storageGlobalId;
        private static string arrayLunId;
        private static string hostLunId;
        private static string hostName;        

        private static string diskPrefix = HelperAdapter.GetParameter("Disk");
        private static string hostPrefix = HelperAdapter.GetParameter("Host");

        private static string hbaId;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Initialize--------");
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine, "Block");
            string result = TestSetup.ConnectSystem(psMachine, storage);
            if ((TestSetup.StorageSystemType != "VNX") && (TestSetup.StorageSystemType != "VNX-Block") && (TestSetup.StorageSystemType != "CLARiiON-CX4"))
            {
                log.BypassTest();
            }
            storageGlobalId = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Connect to Host
            log.LogInfo("Class Initialize: Connect Host System");
            result = TestSetup.ConnectSystem(psMachine, "Host", hostPrefix);
            hostName = HelperAdapter.GenerateKeyValuePairs(result)["Name"].ToLower();

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            result = TestSetup.SetLunEnvironment(psMachine);
            arrayLunId = HelperAdapter.GenerateKeyValuePairs(result)["ArrayLunId"];

            // Unmask Disk and Find Host Disk
            result = TestSetup.SetDiskEnvironment(psMachine, diskPrefix, hostPrefix, null, null, false);
            hostLunId = TestSetup.GetPropertyValue(psMachine, diskPrefix, "HostLunIdentifier.ScsiAddress.Lun");

            hbaId = TestSetup.GetRandomInitiatorId(psMachine, hostPrefix);

            log.LogInfo("--------Class Initialize End--------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Mask Disk
            log.LogInfo("Class Cleanup: Mask the Lun");
            TestSetup.ClearDiskEnvironment(psMachine);

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcStorageGroup instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcStorageGroup instance</returns>  
        public GetEmcStorageGroup ParseCmd(string cmd)
        {
            #region AutoGenerate
            string storagesystem = null;
            string initiatorid = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("StorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagesystem = HelperAdapter.GetParameter("System");
                cmdString = cmdString.Replace("$StorageSystem", storagesystem);
            }
            if (cmd.IndexOf("InitiatorId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                initiatorid = hbaId;
                cmdString = cmdString.Replace("$InitiatorId", initiatorid);
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcStorageGroup instance = new GetEmcStorageGroup(storagesystem, initiatorid, silent, cmdString);
            return instance;
        }


        /// <summary>  
        /// Get-EmcStorageGroup:
        ///    The method to implement Get-EmcStorageGroup poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStorageGroupTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcStorageGroup cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, hostName, hbaId, storageGlobalId, arrayLunId, hostLunId);
        }

        /// <summary>  
        /// GetEmcStorageGroupNegativeTestMethod:
        ///    The method to implement Get-EmcStorageGroup negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStorageGroupNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcStorageGroup getemcstoragegroupClass = ParseCmd(cmd);

            try
            {
                getemcstoragegroupClass.VerifyTheCMD(psMachine, hostName, hbaId, storageGlobalId, arrayLunId, hostLunId);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcstoragegroupClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

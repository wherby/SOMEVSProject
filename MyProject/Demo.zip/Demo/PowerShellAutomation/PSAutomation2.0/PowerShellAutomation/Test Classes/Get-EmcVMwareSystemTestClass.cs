using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcVMwareSystemTest: test class for Get-EmcVMwareSystem cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcVMwareSystemTest
    {
        public GetEmcVMwareSystemTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string name;
        private static string ipAddress;
        private static string username;
        private static string isVirtualCenter;
        private static string vmwareSystemGlobalId;

        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string esxHostPrefix = HelperAdapter.GetParameter("ESXHost");
        private static string datastorePrefix = HelperAdapter.GetParameter("DataStore");
        private static string scsiLunPrefix = HelperAdapter.GetParameter("ScsiLun");        
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            if (!HelperAdapter.IsVMwareSet())
            {
                log.BypassTest();
            }

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");

            // Connect to vCenter or ESX Host
            log.LogInfo("Class Initialize: Connect to ESX Host");
            Dictionary<string, string> dic = HelperAdapter.Load(null, "VMware");
            name = dic["HostName"];
            ipAddress = dic["IPAddress"];
            username = dic["UserName"];
            isVirtualCenter = dic["IsVirtualCenter"];
            string result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
            vmwareSystemGlobalId = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];
            
            // Get ESX Host
            TestSetup.SetESXHostEnvironment(psMachine, esxHostPrefix, vmwarePrefix, 0);

            // Get Datastore
            TestSetup.SetDataStoreEnvironment(psMachine, datastorePrefix);
            
            //Get Scsi Lun
            TestSetup.GetScsiLunFromDataStore(psMachine, scsiLunPrefix, datastorePrefix);

            log.LogInfo("--------Class Initialize End--------");  
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
           

            // Disconnect Storage and Host System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");     
            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcVMwareSystem instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcVMwareSystem instance</returns>  
        public GetEmcVMwareSystem ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string silent = null;
            string esxhostsystem = null;
            string scsilun = null;
            string datastore = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = name;
                cmdString = cmdString.Replace("$Name", id);
            }
            else if (cmd.IndexOf("IPAddress", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = ipAddress;
                cmdString = cmdString.Replace("$IPAddress", id);
            }
            else if (cmd.IndexOf("GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = vmwareSystemGlobalId;
                cmdString = cmdString.Replace("$GlobalId", id);
            }

            if (cmd.IndexOf("ESXHostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                esxhostsystem = esxHostPrefix;
                cmdString = cmdString.Replace("$ESXHostSystem", esxhostsystem);
            }

            if (cmd.IndexOf("Datastore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                datastore = datastorePrefix;
                cmdString = cmdString.Replace("$Datastore", datastore);
            }

            if (cmd.IndexOf("ScsiLun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsilun = scsiLunPrefix;
                cmdString = cmdString.Replace("$ScsiLun", scsilun);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            GetEmcVMwareSystem instance = new GetEmcVMwareSystem(id, silent, esxhostsystem, scsilun, datastore,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Get-EmcVMwareSystem:
        ///    The method to implement Get-EmcVMwareSystem poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVMwareSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcVMwareSystem cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, vmwareSystemGlobalId, name, username, ipAddress, isVirtualCenter);
        }

        /// <summary>  
        /// GetEmcVMwareSystemNegativeTestMethod:
        ///    The method to implement Get-EmcVMwareSystem negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVMwareSystemNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcVMwareSystem getemcvmwaresystemClass = ParseCmd(cmd);

            try
            {
                getemcvmwaresystemClass.VerifyTheCMD(psMachine, vmwareSystemGlobalId, name, username, ipAddress, isVirtualCenter);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcvmwaresystemClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Text.RegularExpressions;

namespace PowerShellAutomation
{
    /// <summary>
    /// ExpandEmcFileBasedDiskTest: test class for Expand-EmcFileBasedDisk cmdlet
    /// </summary>
    [TestClass]
    public partial class ExpandEmcFileBasedDiskTest
    {
        public ExpandEmcFileBasedDiskTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string[] filePath;
        private static string[] netPath;
        private static string[] hypervisors;
        private static ulong[] currentSize;
        private static string[] locations;
        private static SortedList<string, string>[] scsiController;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (!HelperAdapter.IsVMwareSet() )
            {
                return;
            }
            //currentSize[0] = TestSetup.GetVhdFileBasedDiskSize(psMachine, netPath[0]);

            Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
            currentSize[1] = TestSetup.GetVmdkFileBasedDiskSize(psMachine, netPath[1], dic["Password"], dic["UserName"], dic["IPAddress"]);
            
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            hypervisors = new string[2] { "HyperV", "VMWare" };
            filePath = new string[hypervisors.Length];
            netPath = new string[hypervisors.Length];
            currentSize = new ulong[hypervisors.Length];
            locations = new string[hypervisors.Length];
            scsiController = new SortedList<string, string>[hypervisors.Length];

            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                // Connect to Hypervisor          
                string prefix = HelperAdapter.GetParameter(hypervisors[i]);
                string isVCenter = HelperAdapter.GetHypervisorProperties(HyperVisorType.VMWare)["IsVirtualCenter"];
                if (isVCenter == "false")
                {
                    throw new PSException("Please use vCenter Server!");
                }
                string result = TestSetup.ConnectSystem(psMachine, hypervisors[i], prefix);
                SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);

                // Connect Hyperv's VM
                HyperVisorType type = HyperVisorType.HyperV;
                if (i == 1)
                {
                    type = HyperVisorType.VMWare;
                }
                Dictionary<string, string> dic = HelperAdapter.GetHostVMs(type)[0];
                TestSetup.ConnectSystem(psMachine, "HyperVM", HelperAdapter.GetParameter("VirtualMachine") + i, dic);

                filePath[i] = TestSetup.SetFileBasedDiskEnvironment(psMachine, prefix, type);

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(prefix);
                updateSystem.RunCMD(psMachine);

                
                if (i == 0)
                {
                    string hypervIP = keyValuePairs["IpAddress"];
                    netPath[i] = "\\\\" + hypervIP + "\\" + filePath[i].Replace(":", "$");
                }
                else if (i == 1)
                {
                    string configPath = HelperAdapter.GetProperty("DiskVolumeConfig");
                    string dataStoreName = HelperAdapter.Load(configPath, "DataStore")["Name"];
                    GetEmcDataStore getEmcDataStore = new GetEmcDataStore(dataStoreName);
                    result = getEmcDataStore.RunCMD(psMachine, true);
                    string dataStoreUrl = HelperAdapter.GenerateKeyValuePairs(result)["Url"];
                    string fileName = filePath[i].Split(new char[] { '/' }, StringSplitOptions.RemoveEmptyEntries)[1];
                    netPath[i] = dataStoreUrl + HelperAdapter.Load(configPath, "DataStore")["DataStorePath"] + "/" + fileName;
                    netPath[i] = netPath[i].Replace(@"ds://", "");
                }

                string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;

                GetEmcVirtualMachineConfiguration getVMConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine") + i);
                getVMConfig.PrefixString = vmConfig;
                getVMConfig.RunCMD(psMachine, true);

                scsiController[i] = TestSetup.GetRandomScsiController(psMachine, HelperAdapter.GetParameter("ScsiController"), vmConfig);

                locations[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController[i]["ScsiControllerIndex"], null, vmConfig);

                AddEmcFilebasedDiskToVirtualMachine addDisk = new AddEmcFilebasedDiskToVirtualMachine(filePath[i], vmConfig, locations[i], null, null, null, scsiController[i]["ScsiControllerIndex"]);
                addDisk.RunCMD(psMachine, true);

                updateSystem.RunCMD(psMachine);

                getVMConfig.RunCMD(psMachine, true);
            }

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;

                RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfig, locations[i], "Force", null, scsiController[i]["ScsiControllerIndex"]);
                removeDisk.RunCMD(psMachine);

                TestSetup.ClearFileBasedDiskEnvironment(psMachine, filePath[i], HelperAdapter.GetParameter(hypervisors[i]));
            }
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Expand-EmcFileBasedDisk instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Expand-EmcFileBasedDisk instance</returns>  
        public ExpandEmcFileBasedDisk ParseCmd(string cmd)
        {
            #region AutoGenerate

            string virtualmachineconfiguration = null;
            string location = null;
            string scsicontrollerid = null;
            string scsicontrollerindex = null;
            string size = null;
            string silent = null;
            string cmdString = cmd;
   
            #endregion

            int index = 1;
            HyperVisorType type = HyperVisorType.VMWare;

            if (cmd.IndexOf("$VMwareVMConfig", StringComparison.OrdinalIgnoreCase) > 0)
            {
                index = 1;
                type = HyperVisorType.VMWare;
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration") + index;
                cmdString = cmdString.Replace("$VMwareVMConfig", virtualmachineconfiguration);
            }

            if (cmd.IndexOf("$Location", StringComparison.OrdinalIgnoreCase) > 0)
            {
                location = locations[index];
                cmdString = cmdString.Replace("$Location", location);
            }

            if (cmd.IndexOf("$ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerid = scsiController[index]["ScsiControllerId"];
                cmdString = cmdString.Replace("$ScsiControllerId", scsicontrollerid);
            }

            if (cmd.IndexOf("$ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerindex = scsiController[index]["ScsiControllerIndex"];
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsicontrollerindex);
            }

            if (cmd.IndexOf("$Size", StringComparison.OrdinalIgnoreCase) > 0)
            {
                string configPath = HelperAdapter.GetProperty("DiskVolumeConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(configPath, "Expand");
                ulong expandSize = ulong.Parse(TestSetup.GetPropertyValue(psMachine, dic["DiskExpand"]));
                size = (expandSize + currentSize[index]).ToString();
                cmdString = cmdString.Replace("$Size", size);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            ExpandEmcFileBasedDisk instance = new ExpandEmcFileBasedDisk(size, virtualmachineconfiguration, location, scsicontrollerid, scsicontrollerindex, silent, cmdString);
            instance.NetPath = netPath[index];
            instance.Type = type;
            return instance;
        }


        /// <summary>  
        /// Expand-EmcFileBasedDisk:
        ///    The method to implement Expand-EmcFileBasedDisk poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExpandEmcFileBasedDiskTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsVMwareSet())
            {
                return;
            }

            ExpandEmcFileBasedDisk cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// ExpandEmcFileBasedDiskNegativeTestMethod:
        ///    The method to implement Expand-EmcFileBasedDisk negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExpandEmcFileBasedDiskNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsVMwareSet())
            {
                return;
            }

            bool caseFail = false;

            ExpandEmcFileBasedDisk expandemcfilebaseddiskClass = ParseCmd(cmd);

            try
            {
                expandemcfilebaseddiskClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", expandemcfilebaseddiskClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

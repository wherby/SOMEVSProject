using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcScsiLunTest: test class for Get-EmcScsiLun cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcScsiLunTest
    {
        public GetEmcScsiLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string lunWwn;
        private static string lunCapacity;
        private static string vmwareSystemGlobalId;
        private static string esxHostSystemGlobalId; 
        private static string dataStoreRet;
        private static string canonicalName;
        private static string deviceName;
        private static string uuid;
        private static string dsCanonicalName;

        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string esxHostPrefix = HelperAdapter.GetParameter("ESXHost");
        private static string datastorePrefix = HelperAdapter.GetParameter("DataStore");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            if (!HelperAdapter.IsVMwareSet())
            {
                log.BypassTest();
            }

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            lunWwn = keyValuePairs["Wwn"];
            lunCapacity = keyValuePairs["Capacity"];
            
            // Connect to ESX Host
            log.LogInfo("Class Initialize: Connect to ESX Host");
            Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
            result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
            vmwareSystemGlobalId = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Get ESX Host
            result = TestSetup.SetESXHostEnvironment(psMachine, esxHostPrefix, vmwarePrefix, 0);
            esxHostSystemGlobalId = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Get Datastore
            dataStoreRet = TestSetup.SetDataStoreEnvironment(psMachine, datastorePrefix);
            keyValuePairs = HelperAdapter.GenerateKeyValuePairs(dataStoreRet);
            dsCanonicalName = keyValuePairs["CanonicalNames"].Replace("{", "").Replace("}", "");

            //Unmask Lun to ESX Host and Find the host disk
            log.LogInfo("Class Initialize: Unmask Lun and rescan host disk");
            result = TestSetup.SetDiskEnvironment(psMachine, null, esxHostPrefix, null, null, false);
            keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            canonicalName = keyValuePairs["CanonicalName"];
            deviceName = keyValuePairs["DeviceName"];
            uuid = keyValuePairs["Uuid"];

            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Mask Scsi Lun 
            log.LogInfo("Class Cleanup: Mask Lun");
            TestSetup.ClearDiskEnvironment(psMachine, esxHostPrefix, null, null, false);

            // Remove Lun
            log.LogInfo("Class Cleanup: Remove Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage and Host System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcScsiLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcScsiLun instance</returns>  
        public GetEmcScsiLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string vmwaresystem = null;
            string lun = null;
            string silent = null;
            string esxhostsystem = null;
            string datastore = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$CanonicalName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmd.Contains("Datastore"))
                {
                    id = dsCanonicalName;
                }
                else
                {
                    id = canonicalName;
                }
                cmdString = cmdString.Replace("$CanonicalName", id);
            }
            else if (cmd.IndexOf("$DeviceName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmd.Contains("Datastore"))
                {
                    id = "/vmfs/devices/disks/" + dsCanonicalName;
                }
                else
                {
                    id = deviceName;
                }
                cmdString = cmdString.Replace("$DeviceName", id);
            }
            else if (cmd.IndexOf("$UUID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmd.Contains("Datastore"))
                {
                    id = dsCanonicalName.Replace("naa.", "*") + "*";
                }
                else
                {
                    id = uuid;
                }
                cmdString = cmdString.Replace("$UUID", id);
            }

            if (cmd.IndexOf("VMwareSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmwaresystem = vmwarePrefix;
                cmdString = cmdString.Replace("$VMwareSystem", vmwaresystem);
            }

            if (cmd.IndexOf("ESXHostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                esxhostsystem = esxHostPrefix;
                cmdString = cmdString.Replace("$ESXHostSystem", esxhostsystem);
            }

            if (cmd.IndexOf("Datastore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                datastore = datastorePrefix;
                cmdString = cmdString.Replace("$Datastore", datastore);
            }

            if (cmd.IndexOf("Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$Lun", lun);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            
            GetEmcScsiLun instance = new GetEmcScsiLun(id, vmwaresystem, lun, silent, esxhostsystem, datastore, cmdString);
            return instance;
        }


        /// <summary>  
        /// Get-EmcScsiLun:
        ///    The method to implement Get-EmcScsiLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcScsiLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcScsiLun cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, vmwareSystemGlobalId, esxHostSystemGlobalId, lunWwn, lunCapacity, dataStoreRet, uuid);
        }

        /// <summary>  
        /// GetEmcScsiLunNegativeTestMethod:
        ///    The method to implement Get-EmcScsiLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcScsiLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcScsiLun getemcscsilunClass = ParseCmd(cmd);

            try
            {
                getemcscsilunClass.VerifyTheCMD(psMachine, vmwareSystemGlobalId, esxHostSystemGlobalId, lunWwn, lunCapacity, dataStoreRet, uuid);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcscsilunClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

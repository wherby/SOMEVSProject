using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;

using System.Text.RegularExpressions;
using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class ConnectEmcSystemTest
    {
        public ConnectEmcSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private string globalId;
     
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }

        [TestInitialize()]
        public void TestInit() 
        {
            log.LogInfo("--------Test Initialize Start--------");

            globalId = null;
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Initialize End--------");
        }
        
        [TestCleanup()]
        public void TestTearDown() 
        {
            log.LogInfo("--------Test Clean Up Start--------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Clean Up End--------");
        }
        
        #endregion

             
       
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a BewEmcLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public ConnectEmcSystem ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string creationblob = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion
#endif
            string path = HelperAdapter.GetProperty("SystemConfig");
            string systemType = null;

            Regex reg = new Regex(@"\$([\s\S]*?)_Blob");
            Match m = reg.Match(cmd);
            if (m.Groups.Count > 1)
            {
                systemType = m.Groups[1].Value;
                creationblob = HelperAdapter.GetBlobContent(systemType);
                if (creationblob == null)
                {
                    return null;
                }
                cmdString = cmd.Replace("$" + systemType + "_Blob", creationblob);
            }

            
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            ConnectEmcSystem system = new ConnectEmcSystem(creationblob, silent, cmdString);
            system.SystemType = systemType;

            return system;
        }

        
        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ConnectEmcSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            ConnectEmcSystem system = ParseCmd(cmd);

            if (system == null)
            {
                return;
            }
            
            string result =  system.VerifyTheCMD(psMachine);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

            globalId = keyValue["GlobalId"];
               
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ConnectEmcSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            ConnectEmcSystem system = ParseCmd(cmd);

            if (system == null)
            {
                return;
            }

            try
            {
                string result = system.VerifyTheCMD(psMachine);

                SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

                globalId = keyValue["GlobalId"];
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case failed");

        }

    }
            
}

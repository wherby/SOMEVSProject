using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class SetEmcVolumeMountPointTest
    {
        public SetEmcVolumeMountPointTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string[] systemPrefix;
        private static string[] lunPrefix;
        private static string[] volumePrefix;
        private static string remotePath;
        private static int index;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            remotePath = null;
            index = -1;

            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            
            if (index == -1)
            {
                return;
            }
            else if (index == 0)
            {
                string host = systemPrefix[index];
                TestSetup.ClearVolumeEnvironment(psMachine, volumePrefix[index], host);
            }
            else
            {
                string cluster = systemPrefix[index];
                TestSetup.ClearVolumeEnvironment(psMachine, volumePrefix[index], null, cluster);
            }
  
            if (remotePath != null && TestSetup.TestPath(psMachine, remotePath))
            {
                TestSetup.RemoveItem(psMachine, remotePath);
            }

            log.LogInfo("--------Test Clean Up End--------");
        }


        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);

            string[] systems = { "Host", "Cluster"};
            lunPrefix = new string[systems.Length];
            volumePrefix = new string[systems.Length];
            systemPrefix = new string[systems.Length];

            for(int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                if (HelperAdapter.GetBlobContent(system) != null)
                {
                    systemPrefix[i] = HelperAdapter.GetParameter(system);
                    lunPrefix[i] = HelperAdapter.GetParameter("Lun") + i;                    
                    volumePrefix[i] = HelperAdapter.GetParameter("Volume") + i;
                    string diskPrefix = HelperAdapter.GetParameter("Disk") + i;
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];                        
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }                        
                    TestSetup.ConnectSystem(psMachine, system, systemPrefix[i]);
                    TestSetup.SetLunEnvironment(psMachine, true, HelperAdapter.GetParameter("Pool"), lunPrefix[i]);
                    TestSetup.SetDiskEnvironment(psMachine, diskPrefix, host, lunPrefix[i], cluster);
                    TestSetup.SetVolumeEnvironment(psMachine, diskPrefix, host, cluster, volumePrefix[i]);
                    if (i == 1)
                    {
                        TestSetup.SetClusterDiskEnvironment(psMachine, diskPrefix);
                        GetEmcHostVolume getVolume = new GetEmcHostVolume(volumePrefix[i] + ".Label", null, null, null, null, systemPrefix[i]);
                        getVolume.PrefixString = volumePrefix[i];
                        getVolume.RunCMD(psMachine, true);
                    }
                }
            }
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            string[] systems = { "Host", "Cluster" };

            for (int i = 0; i < systems.Length; i++)
            {
                if (HelperAdapter.GetBlobContent(systems[i]) != null)
                {
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    if (i == 1)
                    {
                        TestSetup.ClearClusterDiskEnvironment(psMachine, HelperAdapter.GetParameter("Disk") + i);
                    }
                    TestSetup.ClearDiskEnvironment(psMachine, host, cluster, lunPrefix[i]);
                    TestSetup.ClearLunEnvironment(psMachine, lunPrefix[i]);
                }
            }

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a SetEmcLunAccess instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>SetEmcLunAccess instance</returns>  
        public SetEmcVolumeMountPoint ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string hostsystem = null;
            string driveletter = null;
            string volume = null;
            string silent = null;
            string mountpath = null;
            string clustersystem = null;


            string cmdString = cmd;
   
            #endregion
#endif

            string[] systems = { "Host", "Cluster"};

            for (int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                
                if (cmdString.IndexOf(system + "System", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    if (HelperAdapter.GetBlobContent(system) == null)
                    {
                        return null;
                    }
                    if (i == 0)
                    {
                        hostsystem = systemPrefix[i];
                    }
                    else
                    {
                        clustersystem = systemPrefix[i];
                    }
                    cmdString = cmdString.Replace("$" + system + "System", systemPrefix[i]);

                    if (cmdString.IndexOf("$Volume", StringComparison.OrdinalIgnoreCase) > 0)
                    {
                        volume = volumePrefix[i];
                        cmdString = cmdString.Replace("$Volume", volume);
                    }
                    index = i;
                    break;
                }               
            }
            
            if (cmdString.IndexOf("$DriveLetter", StringComparison.OrdinalIgnoreCase) > 0)
            {
                driveletter = TestSetup.GetRandomDriveLetter(psMachine, hostsystem, clustersystem);
                cmdString = cmdString.Replace("$DriveLetter", driveletter);
            }
            if (cmdString.IndexOf("$MountPath", StringComparison.OrdinalIgnoreCase) > 0)
            {
                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path, "Volume");
                mountpath = dic["MountPathPrefix"] + HelperAdapter.GenerateRandomString();
                if (clustersystem != null)
                {
                    mountpath = TestSetup.GetClusterMountPath(psMachine);
                    if (mountpath == null)
                    {
                        mountpath = TestSetup.GetRandomDriveLetter(psMachine, null, clustersystem);
                    }
                }
                
                cmdString = cmdString.Replace("$MountPath", mountpath);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            SetEmcVolumeMountPoint mountPoint = new SetEmcVolumeMountPoint(hostsystem, driveletter, volume, silent, mountpath, clustersystem, cmdString);

            return mountPoint;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcVolumeMountPointTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            SetEmcVolumeMountPoint mountPoint = ParseCmd(cmd);

            if (mountPoint == null)
            {
                return;
            }

            mountPoint.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcVolumeMountPointNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            SetEmcVolumeMountPoint mountPoint = ParseCmd(cmd);

            if (mountPoint == null)
            {
                return;
            }
            
            try
            {
                mountPoint.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", mountPoint.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");

        }
    }

}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcStoragePoolTest
    {
        public GetEmcStoragePoolTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string poolID = null;

        private static string storagePoolType="Block";

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
            log.LogInfo("--------Test Initialize End--------");
        }

        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            storagePoolType = GetPoolTypeString();
            string systemName = TestSetup.SetStorageEnvironment(psMachine, storagePoolType);
            TestSetup.ConnectSystem(psMachine, systemName);
            string result = TestSetup.SetPoolEnvironment(psMachine);
            SortedList<string, string> poolKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            poolID = poolKeyValue["ArrayPoolId"];
            TestSetup.SetLunEnvironment(psMachine);
            string  storageSystem = HelperAdapter.GetParameter("System");
            UpdateEmcSystem update = new UpdateEmcSystem(storageSystem);
            update.RunCMD(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcStoragePool instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcStoragePool instance</returns>  
        public GetEmcStoragePool ParseCmd(string cmd)
        {

            #region AutoGenerate
            string id = null;
            string lun = null;
            string silent = null;
            string storagesystem = null;
            string pooltype = null;


            string cmdString = cmd;
   
            #endregion


            string idString = poolID;
            string lunString = HelperAdapter.GetParameter("Lun");
            string storageSystemString = HelperAdapter.GetParameter("System");
            string poolTypeString = storagePoolType;


            if (cmdString.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = idString;
                cmdString = cmdString.Replace("$ID", idString);
            }
            if (cmdString.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = lunString;
                cmdString = cmdString.Replace("$Lun", lunString);
            }
            if (cmdString.IndexOf("$StorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagesystem = storageSystemString;
                cmdString = cmdString.Replace("$StorageSystem", storagesystem);
            }
            if (cmdString.IndexOf("$PoolType", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pooltype = poolTypeString;
                cmdString = cmdString.Replace("$PoolType", pooltype);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcStoragePool getStoragePool = new GetEmcStoragePool(id, lun, silent, storagesystem, pooltype, cmdString);

            return getStoragePool;
        }

        public void GetEmcStoragePoolTestMethod(string cmd)
        {
            GetEmcStoragePool getStoragePool = ParseCmd(cmd);
            getStoragePool.VerifyTheCMD(psMachine);
        }

        public void GetEmcStoragePoolNegativeTestMethod(string cmd)
        {
            GetEmcStoragePool getStoragePool = ParseCmd(cmd);
            TestLog log = TestLog.GetInstance();
            bool failCMD = false;
            try
            {
                getStoragePool.VerifyTheCMD(psMachine);
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }

        private static string GetPoolTypeString()
        {
            List<string> idList = new List<string>();
            idList.Add("Block");
           // idList.Add("File"); //File storage couldn't create lun.
            idList.Add("All");
            Random rd = new Random();
            string randomString = idList[rd.Next(idList.Count)];
            return randomString;
        }

    }

}


using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcStorageServiceNodeTest: test class for Get-EmcStorageServiceNode cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcStorageServiceNodeTest
    {
        public GetEmcStorageServiceNodeTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string>[] storageKeyValue;
        private static SortedList<string, string> poolKeyValue;
        private static SortedList<string, string> lunKeyValue;
        private static SortedList<string, string> shareFolderKeyValue;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            log.LogInfo("--------Class Init Start---------");
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            storageKeyValue = new SortedList<string, string>[2];

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Storage"));
            updateSystem.RunCMD(psMachine);

            GetEmcStorageSystem storageSystem = new GetEmcStorageSystem();
            storageSystem.PrefixString = HelperAdapter.GetParameter("Storage");
            string result = storageSystem.RunCMD(psMachine);
            storageKeyValue[0] = HelperAdapter.GenerateKeyValuePairs(result);

            result = TestSetup.SetPoolEnvironment(psMachine);
            poolKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            result = TestSetup.SetLunEnvironment(psMachine);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            
            TestSetup.ConnectSystem(psMachine, "VNX-CIFS");
            updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("System"));
            updateSystem.RunCMD(psMachine);
            result = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("System"));
            storageKeyValue[1] = HelperAdapter.GenerateKeyValuePairs(result);

            TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
            TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            result = TestSetup.SetCIFSSharedFolderEnvironment(psMachine);
            shareFolderKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            TestSetup.RemoveSharedFolderEnvironment(psMachine);
            TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcStorageServiceNode instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcStorageServiceNode instance</returns>  
        public GetEmcStorageServiceNode ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string storagesystem = null;
            string silent = null;
            string pool = null;
            string lun = null;
            string cifssharedfolder = null;


            string cmdString = cmd;
   
            #endregion

            int storageIndex = -1;

            
            if (cmd.IndexOf("$BlockStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storageIndex = 0;
                storagesystem = HelperAdapter.GetParameter("Storage");
                cmdString = cmdString.Replace("$BlockStorageSystem", storagesystem);
            }
            else if (cmd.IndexOf("$FileStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storageIndex = 1;
                storagesystem = HelperAdapter.GetParameter("System");
                cmdString = cmdString.Replace("$FileStorageSystem", storagesystem);
            }

            if (cmd.IndexOf("$Pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storageIndex = 0;
                pool = HelperAdapter.GetParameter("Pool");
                cmdString = cmdString.Replace("$Pool", pool);
            }

            if (cmd.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storageIndex = 0;
                lun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$Lun", lun);
            }

            if (cmd.IndexOf("$CifsSharedFolder", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storageIndex = 1;
                cifssharedfolder = HelperAdapter.GetParameter("SharedFolder");
                cmdString = cmdString.Replace("$CifsSharedFolder", cifssharedfolder);
            }

            if (cmd.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if(storageIndex == 0)
                {
                    id = "SP A";
                }
                else if(storageIndex == 1)
                {
                    id = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("System"), "CifsServiceNodes.ServiceNodeId");
                }
                else
                {
                    id = "SP A";
                }
                cmdString = cmdString.Replace("$ID", "\"" + id + "\"");
            }

            GetEmcStorageServiceNode instance = new GetEmcStorageServiceNode(id, storagesystem, silent, pool, lun, cifssharedfolder,  cmdString);
            instance.BlockStorageKeyValue = storageKeyValue[0];
            instance.FileStorageKeyValue = storageKeyValue[1];
            instance.PoolKeyValue = poolKeyValue;
            instance.LunKeyValue = lunKeyValue;
            instance.ShareFolderKeyValue = shareFolderKeyValue;
            instance.StorageIndex = storageIndex;

            return instance;
        }


        /// <summary>  
        /// Get-EmcStorageServiceNode:
        ///    The method to implement Get-EmcStorageServiceNode poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStorageServiceNodeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcStorageServiceNode cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcStorageServiceNodeNegativeTestMethod:
        ///    The method to implement Get-EmcStorageServiceNode negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStorageServiceNodeNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcStorageServiceNode getemcstorageservicenodeClass = ParseCmd(cmd);

            try
            {
                getemcstorageservicenodeClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcstorageservicenodeClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

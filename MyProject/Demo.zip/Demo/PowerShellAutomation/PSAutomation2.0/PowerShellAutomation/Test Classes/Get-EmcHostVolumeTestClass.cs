using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcHostVolumeTest
    {
        public GetEmcHostVolumeTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string[] systemPrefix;
        private static string[] lunPrefix;
        private static string[] volumePrefix;
        private static string[] diskPrefix;
        private static SortedList<string, string>[] volumeKeyValue;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        #region Additional test attributes
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            string[] systems = { "Host", "Cluster" };
            lunPrefix = new string[systems.Length];
            volumePrefix = new string[systems.Length];
            diskPrefix = new string[systems.Length];
            systemPrefix = new string[systems.Length];
            volumeKeyValue = new SortedList<string, string>[systems.Length];

            for (int i = 0; i < systems.Length; i++)
            {
                string system = systems[i];
                if (HelperAdapter.GetBlobContent(system) != null)
                {
                    systemPrefix[i] = HelperAdapter.GetParameter(system);
                    lunPrefix[i] = HelperAdapter.GetParameter("Lun") + i;
                    volumePrefix[i] = HelperAdapter.GetParameter("Volume") + i;
                    diskPrefix[i] = HelperAdapter.GetParameter("Disk") + i;
                    string host = null;
                    string cluster = null;
                    MountPoint mp = MountPoint.None;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                        mp = MountPoint.MountPath;
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    TestSetup.ConnectSystem(psMachine, system, systemPrefix[i]);
                    TestSetup.SetPoolEnvironment(psMachine);
                    TestSetup.SetLunEnvironment(psMachine, true, HelperAdapter.GetParameter("Pool"), lunPrefix[i]);
                    TestSetup.SetDiskEnvironment(psMachine, diskPrefix[i], host, lunPrefix[i], cluster);
                    TestSetup.SetVolumeEnvironment(psMachine, diskPrefix[i], host, cluster, volumePrefix[i], mp);                    
                    if (i == 0)
                    {
                        UpdateEmcSystem update = new UpdateEmcSystem(systemPrefix[i]);
                        update.RunCMD(psMachine);
                        GetEmcHostDisk getDisk = new GetEmcHostDisk(null, lunPrefix[i], host, null, cluster);
                        getDisk.PrefixString = diskPrefix[i];
                        getDisk.RunCMD(psMachine, true);
                    }
                    if (i == 1)
                    {
                        TestSetup.SetClusterDiskEnvironment(psMachine, diskPrefix[i], cluster);
                        string letter =  TestSetup.GetRandomDriveLetter(psMachine, null, cluster);

                        SetEmcVolumeMountPoint setMountPoint = new SetEmcVolumeMountPoint(null, letter, volumePrefix[i], null, null, cluster);
                        setMountPoint.RunCMD(psMachine);
                    }
                    
                    GetEmcHostVolume getVolume = new GetEmcHostVolume(volumePrefix[i] + ".Label", null, host, null, null, cluster);
                    getVolume.PrefixString = volumePrefix[i];
                    string result = getVolume.RunCMD(psMachine, true);
                    volumeKeyValue[i] = HelperAdapter.GenerateKeyValuePairs(result);
                }
            }

            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            string[] systems = { "Host", "Cluster" };

            for (int i = 0; i < systems.Length; i++)
            {
                if (HelperAdapter.GetBlobContent(systems[i]) != null)
                {
                    string host = null;
                    string cluster = null;
                    if (i == 0)
                    {
                        host = systemPrefix[i];
                    }
                    else
                    {
                        cluster = systemPrefix[i];
                    }
                    TestSetup.ClearDiskEnvironment(psMachine, host, cluster, lunPrefix[i]);
                    TestSetup.ClearLunEnvironment(psMachine, lunPrefix[i]);
                }
            }

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcHostVolume instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public GetEmcHostVolume ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string id = null;
            string hostdisk = null;
            string hostsystem = null;
            string silent = null;
            string clusterdisk = null;
            string clustersystem = null;


            string cmdString = cmd;
   
            #endregion
#endif
            string system = null;

            string[] systems = { "Host", "Cluster" };
            int i = 0;
            for (i = 0; i < systems.Length; i++)
            {
                system = systems[i];

                if (cmd.Contains(system + "System") || cmd.Contains(system + "Disk"))
                {
                    if (HelperAdapter.GetBlobContent(system) == null)
                    {
                        return null;
                    }
                    if (i == 0)
                    {
                        hostsystem = systemPrefix[i];
                        hostdisk = diskPrefix[i];
                    }
                    else
                    {
                        clustersystem = systemPrefix[i];
                        clusterdisk = HelperAdapter.GetParameter("ClusterDisk");
                    }
                    break;
                }
            }

            if (i == systems.Length)
            {
                i = 0;
            }

            string[] ids = { "MountPath", "HostVolumeIdentifier"};

            foreach (string item in ids)
            {
                if (cmdString.Contains(item))
                {
                    id = volumeKeyValue[i][item];
                    id = volumePrefix[i] + "." + item;
                    cmdString = cmdString.Replace("$" + item, id);
                    break;
                }
            }

            if (cmdString.IndexOf("$" + system + "System", StringComparison.OrdinalIgnoreCase) > 0)
            {                 
                cmdString = cmdString.Replace("$" + system + "System", systemPrefix[i]);
            }
            if (cmdString.IndexOf("$HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                cmdString = cmdString.Replace("$HostDisk", diskPrefix[0]);
            }
            if (cmdString.IndexOf("$ClusterDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                cmdString = cmdString.Replace("$ClusterDisk", clusterdisk);
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcHostVolume hostVolume = new GetEmcHostVolume(id, hostdisk, hostsystem, silent, clusterdisk, clustersystem, cmdString);
            hostVolume.VolumeInfo = volumeKeyValue[i];

            return hostVolume;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostVolumeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcHostVolume cmdClass = ParseCmd(cmd);

            if (cmdClass == null)
            {
                return;
            }

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostVolumeNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcHostVolume cmdClass = ParseCmd(cmd);

            if (cmdClass == null)
            {
                return;
            }

            try
            {
                cmdClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", cmdClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");
        }

    }

}

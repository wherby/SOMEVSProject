using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcXenServerStorageRepositoryTest: test class for New-XenServerStorageRepository cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcXenServerStorageRepositoryTest
    {
        public NewEmcXenServerStorageRepositoryTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string lun = HelperAdapter.GetParameter("Lun");
            string xenServer = HelperAdapter.GetParameter("XenServer");
            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(lun, xenServer, null, null, "Available");
            setLunAccess.RunCMD(psMachine);

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            string sr = HelperAdapter.GetParameter("StorageRepository");
            string xenServer = HelperAdapter.GetParameter("XenServer");
            string srUuid = TestSetup.GetPropertyValue(psMachine, sr, "Uuid");
            string result = null;

            if (!string.IsNullOrEmpty(srUuid))
            {
                UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
                updateXenServer.RunCMD(psMachine);

                GetEmcXenServerStorageRepository getSR = new GetEmcXenServerStorageRepository(srUuid, xenServer);
                getSR.PrefixString = sr;
                result = getSR.RunCMD(psMachine);

                if (!string.IsNullOrEmpty(result))
                {
                    TestSetup.ClearSREnvironment(psMachine);
                }
            }

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            string storage = TestSetup.SetStorageEnvironment(psMachine);

            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            log.LogInfo("--------Class Init End---------");

            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a New-XenServerStorageRepository instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>New-XenServerStorageRepository instance</returns>  
        public NewEmcXenServerStorageRepository ParseCmd(string cmd)
        {
            #region AutoGenerate
            string lun = null;
            string xenserver = null;
            string name = null;
            string targetport = null;
            string description = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "SR");

            if (cmd.IndexOf("$Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$Lun", lun);
            }

            if (cmd.IndexOf("$XenServer", StringComparison.OrdinalIgnoreCase) > 0)
            {
                xenserver = HelperAdapter.GetParameter("XenServer");
                cmdString = cmdString.Replace("$XenServer", xenserver);
            }

            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = dic["NamePrefix"] + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$Name", "\"" + name + "\"");
            }

            if (cmd.IndexOf("$TargetPort", StringComparison.OrdinalIgnoreCase) > 0)
            {
                TestSetup.GetRandomTargetPort(psMachine);
                targetport = HelperAdapter.GetParameter("TargetPort");
                cmdString = cmdString.Replace("$TargetPort", targetport);
            }

            if (cmd.IndexOf("$Description", StringComparison.OrdinalIgnoreCase) > 0)
            {
                description = dic["Description"] + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$Description", "\"" + description + "\"");
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            NewEmcXenServerStorageRepository instance = new NewEmcXenServerStorageRepository(lun, xenserver, name, targetport, description, silent, cmdString);
            return instance;
        }


        /// <summary>  
        /// New-XenServerStorageRepository:
        ///    The method to implement New-XenServerStorageRepository poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcXenServerStorageRepositoryTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            NewEmcXenServerStorageRepository cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// NewEmcXenServerStorageRepositoryNegativeTestMethod:
        ///    The method to implement New-XenServerStorageRepository negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcXenServerStorageRepositoryNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            NewEmcXenServerStorageRepository newxenserverstoragerepositoryClass = ParseCmd(cmd);

            try
            {
                newxenserverstoragerepositoryClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", newxenserverstoragerepositoryClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcStandbyLunTest: test class for Get-EmcStandbyLun cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcStandbyLunTest
    {
        public GetEmcStandbyLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string standbyLunResult;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);
            TestSetup.ConnectSystem(psMachine, "VMAX");
            TestSetup.SetPoolEnvironment(psMachine, "True", "5", "Pool", null, "VMAX");
            standbyLunResult= TestSetup.SetStandbyLunEnvironment(psMachine);
            
        }

        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            TestSetup.RemoveStandbyLunEnvironment(psMachine);
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcStandbyLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcStandbyLun instance</returns>  
        public GetEmcStandbyLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string storagesystem = null;
            string id = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string storagesystemString = HelperAdapter.GetParameter("System");
            List<SortedList<string, string>> lunKeyValues = HelperAdapter.GenerateKeyValuePairsList(standbyLunResult);
            string idString = lunKeyValues[0]["ArrayLunId"];

            if (cmd.IndexOf("$StorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                storagesystem = storagesystemString;
                cmd = cmd.Replace("$StorageSystem", storagesystem);
            }
            if (cmd.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = idString;
                cmd = cmd.Replace("$ID", id);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            GetEmcStandbyLun instance = new GetEmcStandbyLun(storagesystem, id, silent,  cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcStandbyLun:
        ///    The method to implement Get-EmcStandbyLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStandbyLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcStandbyLun cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcStandbyLunNegativeTestMethod:
        ///    The method to implement Get-EmcStandbyLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStandbyLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcStandbyLun getemcstandbylunClass = ParseCmd(cmd);

            try
            {
                getemcstandbylunClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcstandbylunClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }


    }
}

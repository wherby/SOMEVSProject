using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcSnapshotLunTest: test class for New-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcSnapshotLunTest
    {
        public NewEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;        
        private static string arrayLunID;
        private static string storageGlobalId;
        
        private string snapshotLunID = "";        
        private bool removeFlag = false;

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string snapshotPoolPrefix = HelperAdapter.GetParameter("SnapshotPool");
        private static string retentionPrefix = HelperAdapter.GetParameter("Timespan");

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();            

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            string storageResult = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalId = HelperAdapter.GenerateKeyValuePairs(storageResult)["GlobalId"];

            // Get Snapshot Pool
            string poolId = TestSetup.GetSnapshotPoolId(TestSetup.StorageSystemType);
            TestSetup.SetSnapshotPool(psMachine, snapshotPoolPrefix, poolId);
           
            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            arrayLunID = lunKeyValue["ArrayLunId"];

            // New Retention timespan object
            log.LogInfo("Class Initialize: New TimeSpan Object");
            TestSetup.SetRetention(psMachine, retentionPrefix);
            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }        
        
        // Use TestCleanup to run code after each test has run
        [TestCleanup]
        public void TestTearDown()
        {            
            if (removeFlag)
            {
                log.LogInfo("--------Test Clean Up Start--------");
                log.LogInfo("Test Cleanup: Remove Snapshot Lun");
                
                TestSetup.ClearSnapshotLunEnvironment(psMachine, snapshotLunID, snapshotLunPrefix);
                log.LogInfo("--------Test Clean Up End--------");
            }            
        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcSnapshotLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcSnapshotLun instance</returns>  
        public static NewEmcSnapshotLun ParseCmd(string cmd)
        {
           
            #region AutoGenerate
            string sourcelun = null;
            string snapshotpool = null;
            string name = null;
            string noactivation = null;
            string retention = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            NewEmcSnapshotLun snapshotLun;
            string storageType = TestSetup.StorageSystemType;

            if (cmd.IndexOf("sourcelun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourcelun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$SourceLun", sourcelun);
            }

            if (cmd.IndexOf("snapshotpool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotpool = snapshotPoolPrefix;
                cmdString = cmdString.Replace("$SnapshotPool", snapshotpool);
            }

            if (cmd.IndexOf("name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = "ps_snapshotlun" + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$Name", name);
            }

            if (cmd.IndexOf("NoActivation", StringComparison.OrdinalIgnoreCase) > 0)
            {
                noactivation = "NoActivation";
            }

            if (cmd.IndexOf("retention", StringComparison.OrdinalIgnoreCase) > 0)
            {
                retention = retentionPrefix;
                cmdString = cmdString.Replace("$Retention", retention);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";                
            }

            if ((storageType == "VMAX" && (!cmd.Contains("SourceLun"))) || (storageType == "VNXe" && cmd.Contains("SnapshotPool"))
                || (storageType == "VNXe" && !cmd.Contains("NoActivation")))
            {
                snapshotLun = null;
            }
            else
            {
                snapshotLun = new NewEmcSnapshotLun(sourcelun, snapshotpool, name, noactivation, retention, silent, cmdString);
            }

            return snapshotLun;
        }

        /// <summary>  
        /// NewEmcSnapshotLunTestMethod:
        ///    The method to implement New-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcSnapshotLunTestMethod(string cmd)
        {           
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            
            NewEmcSnapshotLun snapshotLun = ParseCmd(cmd);
            if (snapshotLun != null)
            {
                string newSnapshotLunResult = snapshotLun.VerifyTheCMD(psMachine, arrayLunID, storageGlobalId);
                if (TestSetup.StorageSystemType == "VNXe")
                {
                    snapshotLunID = HelperAdapter.GenerateKeyValuePairs(newSnapshotLunResult)["Name"];
                }
                else
                {
                    snapshotLunID = HelperAdapter.GenerateKeyValuePairs(newSnapshotLunResult)["Wwn"];
                }
                removeFlag = true;
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }
        }

        /// <summary>  
        /// NewEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement New-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcSnapshotLunNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcSnapshotLun snapshotLun = ParseCmd(cmd);
            if (snapshotLun != null)
            {
                try
                {
                    snapshotLun.VerifyTheCMD(psMachine, arrayLunID, storageGlobalId);
                }
                catch (PSException psEx)
                {
                    log.LogTestCase(string.Format("Test with {0} failed.", snapshotLun.GetFullString()));
                    log.LogTestCase(psEx.messageDetail);
                    caseFail = true;
                }
                log.AreEqual<bool>(true, caseFail, "Negative test case result:");
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }
        }
    
    }
}

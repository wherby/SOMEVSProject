using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{   
    /// <summary>
    /// AddEmcFilebasedDiskToVirtualMachineTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class AddEmcFilebasedDiskToVirtualMachineTest
    {
        public AddEmcFilebasedDiskToVirtualMachineTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string[] paths;
        private static string[] hypervisor;
        private static string[] locations;
        private static SortedList<string, string>[] scsiController;
        private static int vmIndex;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            for (int i = 0; i < hypervisor.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    log.BypassTest();
                }

                string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;

                scsiController[i] = TestSetup.GetRandomScsiController(psMachine, HelperAdapter.GetParameter("ScsiController"), vmConfig);

                locations[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController[i]["ScsiControllerIndex"], null, vmConfig);
            }
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsHyperVSet() && vmIndex == 0 || !HelperAdapter.IsVMwareSet() && vmIndex == 1)
            {
                return;
            }
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
            GetEmcVirtualMachineConfiguration getVMConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine") + vmIndex);
            getVMConfig.PrefixString = vmConfig;
            getVMConfig.RunCMD(psMachine, true);

            RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfig, locations[vmIndex], "Force", null, scsiController[vmIndex]["ScsiControllerIndex"]); 
                
            try
            {
                removeDisk.RunCMD(psMachine);
            }
            catch
            {
                log.LogInfo("do not need to remove virtual disk");
            }

            log.LogInfo("--------Test Clean Up End---------");
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            vmIndex = 0;
            hypervisor = new string[2] { "HyperV", "VMWare" };
            paths = new string[2];
            scsiController = new SortedList<string, string>[2];
            locations = new string[2];

            for (int i = 0; i < hypervisor.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                // Connect to Hypervisor          
                string prefix = HelperAdapter.GetParameter(hypervisor[i]);
                string isVcenter = HelperAdapter.GetHypervisorProperties(HyperVisorType.VMWare)["IsVirtualCenter"];
                if (i == 1 && isVcenter == "true")
                {
                    Dictionary<string, string> dict = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                    TestSetup.ConnectSystem(psMachine, hypervisor[i], prefix, dict);
                }
                else
                {
                    TestSetup.ConnectSystem(psMachine, hypervisor[i], prefix);
                }

                // Connect Hyperv's VM
                HyperVisorType type = HyperVisorType.HyperV;
                if (i == 1)
                {
                    type = HyperVisorType.VMWare;
                }
                Dictionary<string, string> dic = HelperAdapter.GetHostVMs(type)[0];
                TestSetup.ConnectSystem(psMachine, "HyperVM", HelperAdapter.GetParameter("VirtualMachine") + i, dic);

                paths[i] = TestSetup.SetFileBasedDiskEnvironment(psMachine, prefix, type);

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(prefix);
                updateSystem.RunCMD(psMachine);

                GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine") + i);
                vmConfig.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                vmConfig.RunCMD(psMachine, true);

                if (i == 1)
                {
                    string configPath = HelperAdapter.GetProperty("DiskVolumeConfig");
                    Dictionary<string, string> datastoreDic = HelperAdapter.Load(configPath, "DataStore");
                    GetEmcDataStore dataStore = new GetEmcDataStore(datastoreDic["Name"]);
                    dataStore.PrefixString = HelperAdapter.GetParameter("DataStore");
                    dataStore.RunCMD(psMachine, true);
                }

                updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter(hypervisor[i]));
                updateSystem.RunCMD(psMachine);

                updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("VirtualMachine") + i);
                updateSystem.RunCMD(psMachine);

            }


            log.LogInfo("--------Class Init End---------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

           
            for(int i = 0; i < hypervisor.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                TestSetup.ClearFileBasedDiskEnvironment(psMachine, paths[i], HelperAdapter.GetParameter(hypervisor[i]));
            }
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a AddEmcFilebasedDiskToVirtualMachine instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>AddEmcFilebasedDiskToVirtualMachine instance</returns>  
        public AddEmcFilebasedDiskToVirtualMachine ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string path = null;
            string virtualmachineconfiguration = null;
            string location = null;
            string persistence = null;
            string datastore = null;
            string scsicontrollerid = null;
            string scsicontrollerindex = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion
#endif

            Random rd = new Random();
            vmIndex = rd.Next(hypervisor.Length);

            int scsiIndex = -1;

            if (cmd.IndexOf("$Persistent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                persistence = "Persistent";
                cmdString = cmdString.Replace("$Persistent", persistence);
            }
            else if (cmd.IndexOf("$IndependentPersistent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                persistence = "IndependentPersistent";
                cmdString = cmdString.Replace("$IndependentPersistent", persistence);
            }
            else if (cmd.IndexOf("$IndependentNonPersistent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                persistence = "IndependentNonPersistent";
                cmdString = cmdString.Replace("$IndependentNonPersistent", persistence);
            }

            if (cmd.IndexOf("Datastore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                datastore = HelperAdapter.GetParameter("DataStore");
                cmdString = cmdString.Replace("$Datastore", datastore);
            }

            if (paths[vmIndex] == null)
            {
                return null;
            }

            if (cmd.IndexOf("$Path", StringComparison.OrdinalIgnoreCase) > 0)
            {
                path = paths[vmIndex];
                cmdString = cmdString.Replace("$Path", "\"" + path + "\"");
            }

            if (cmd.IndexOf("$VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", virtualmachineconfiguration);
            }

            if (cmd.IndexOf("$ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerid = scsiController[vmIndex]["ScsiControllerId"];
                cmdString = cmdString.Replace("$ScsiControllerId", "\"" + scsicontrollerid + "\"");
                scsiIndex = int.Parse(scsiController[vmIndex]["ScsiControllerIndex"]);
            }

            if (cmd.IndexOf("$ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerindex = scsiController[vmIndex]["ScsiControllerIndex"];
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsicontrollerindex);
                scsiIndex = int.Parse(scsiController[vmIndex]["ScsiControllerIndex"]);
            }

            if (cmd.IndexOf("$Location", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (scsiIndex == -1)
                {
                    GetEmcVirtualMachineScsiController getScsiController = new GetEmcVirtualMachineScsiController(HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex);
                    string result = getScsiController.RunCMD(psMachine, true);
                    scsiController[vmIndex]["ScsiControllerIndex"] = "0";
                    locations[vmIndex] = TestSetup.GetRandomScsiControllerLocation(psMachine, "0", null, HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex);
                    location = locations[vmIndex];
                }
                else
                {
                    location = locations[vmIndex];
                }
                cmdString = cmdString.Replace("$Location", location);
            }
            if (cmd.IndexOf("$Datastore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                datastore = HelperAdapter.GetParameter("DataStore");
                cmdString = cmdString.Replace("$Datastore", datastore);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            AddEmcFilebasedDiskToVirtualMachine addDisk = new AddEmcFilebasedDiskToVirtualMachine(path, virtualmachineconfiguration, location, persistence, datastore, scsicontrollerid, scsicontrollerindex, silent, cmdString);
            addDisk.VMIndex = vmIndex;
            addDisk.PrefixString = HelperAdapter.GetParameter("FilebasedDisk") + vmIndex;

            return addDisk;
        }

        
        /// <summary>  
        /// AddEmcFilebasedDiskToVirtualMachineTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcFilebasedDiskToVirtualMachineTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            AddEmcFilebasedDiskToVirtualMachine addDisk = ParseCmd(cmd);

            if (addDisk == null)
            {
                return;
            }

            addDisk.VerifyTheCMD(psMachine, scsiController[vmIndex]);
        }

        /// <summary>  
        /// AddEmcFilebasedDiskToVirtualMachineNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcFilebasedDiskToVirtualMachineNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            AddEmcFilebasedDiskToVirtualMachine addDisk = ParseCmd(cmd);

            if (addDisk == null)
            {
                return;
            }

            try
            {
                addDisk.VerifyTheCMD(psMachine, scsiController[vmIndex]);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", addDisk.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

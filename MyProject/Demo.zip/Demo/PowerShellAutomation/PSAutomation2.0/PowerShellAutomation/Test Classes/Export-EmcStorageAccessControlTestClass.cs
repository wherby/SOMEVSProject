using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// ExportEmcStorageAccessControlTest: test class for Export-EmcStorageAccessControl cmdlet
    /// </summary>
    [TestClass]
    public partial class ExportEmcStorageAccessControlTest
    {
        public ExportEmcStorageAccessControlTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string storageGlobalID;
        private static string poolName;
        private static string filePath;
        private static string protectionKey;

        private static string poolPrefix = HelperAdapter.GetParameter("Pool");
        private static string accessControlPrefix = HelperAdapter.GetParameter("AccessControl");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (TestSetup.TestPath(psMachine, filePath))
            {
                TestSetup.RemoveItem(psMachine, filePath);
                if (TestSetup.TestPath(psMachine, filePath))
                {
                    log.LogError(String.Format("Failed to remove exported access control file {0}", filePath));
                    PSException pe = new PSException(String.Format("Failed to remove exported access control file {0}", filePath));
                    throw pe;
                }
            }
            

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");  

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine, "All");
            string result = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalID = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            // Select a random pool          
            log.LogInfo("Class Initialize: Get Storage Pool");
            result = TestSetup.SetPoolEnvironment(psMachine, null, null, null, null, TestSetup.StorageSystemType);
            poolName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];          

            // New Access Control
            log.LogInfo("Class Initialize: New Access Control");
            NewEmcStorageAccessControl accessControl = new NewEmcStorageAccessControl();
            accessControl.PrefixString = accessControlPrefix;
            accessControl.VerifyTheCMD(psMachine);

            // Add Pool to Storage Access Control
            AddEmcStorageAccessControl addEmcStorageAccessControl = new AddEmcStorageAccessControl(accessControlPrefix, poolPrefix);
            addEmcStorageAccessControl.VerifyTheCMD(psMachine, storageGlobalID, poolName);

            // Get export file name
            string path = HelperAdapter.GetProperty("StorageAccessControlConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            string fileFolder = dic["FileFolder"];
            string fileName = dic["FileNamePrefix"];
            fileName = fileName + HelperAdapter.GenerateRandomString() + ".EsiAcl";
            protectionKey = dic["ProtectionKey"];

            if (! Directory.Exists(fileFolder))
            {
                Directory.CreateDirectory(fileFolder);
            }

            filePath = fileFolder + fileName;

            
            log.LogInfo("--------Class Initialize End--------");  
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            // Remove Storage Access Control
            log.LogInfo("--------Class Clean Up Start---------");
            RemoveEmcStorageAccessControl removeEmcStorageAcceccControl =
                new RemoveEmcStorageAccessControl(accessControlPrefix, poolPrefix);
            removeEmcStorageAcceccControl.VerifyTheCMD(psMachine, storageGlobalID, poolName);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Export-EmcStorageAccessControl instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Export-EmcStorageAccessControl instance</returns>  
        public ExportEmcStorageAccessControl ParseCmd(string cmd)
        {
            #region AutoGenerate
            string accesscontrol = null;
            string file = null;
            string protectionkey = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("accesscontrol", StringComparison.OrdinalIgnoreCase) > 0)
            {
                accesscontrol = HelperAdapter.GetParameter("AccessControl");
                cmdString = cmdString.Replace("$AccessControl", accesscontrol);
            }
            if (cmd.IndexOf("file", StringComparison.OrdinalIgnoreCase) > 0)
            {
                file = filePath;
                cmdString = cmdString.Replace("$File", file);
            }
            if (cmd.IndexOf("protectionkey", StringComparison.OrdinalIgnoreCase) > 0)
            {
                protectionkey = protectionKey;
                cmdString = cmdString.Replace("$ProtectionKey", protectionkey);
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            ExportEmcStorageAccessControl instance = new ExportEmcStorageAccessControl(accesscontrol, file, protectionkey, force, silent, whatif,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Export-EmcStorageAccessControl:
        ///    The method to implement Export-EmcStorageAccessControl poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExportEmcStorageAccessControlTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            ExportEmcStorageAccessControl cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// ExportEmcStorageAccessControlNegativeTestMethod:
        ///    The method to implement Export-EmcStorageAccessControl negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExportEmcStorageAccessControlNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            ExportEmcStorageAccessControl exportemcstorageaccesscontrolClass = ParseCmd(cmd);

            try
            {
                exportemcstorageaccesscontrolClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", exportemcstorageaccesscontrolClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcSnapshotLunTest: test class for New-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcSnapshotLunTest
    {
        public RemoveEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private SortedList<string, string> lunKeyValue;
        private string snapshotLunID = "";
        private bool removeFlag = false;

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string sourceLunPrefix = HelperAdapter.GetParameter("Lun");
        private static string snapshotPoolPrefix = HelperAdapter.GetParameter("SnapshotPool");

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class       
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            log.LogInfo("--------Class Initialize End--------");
        }
       
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }      
  
        
        // Use TestInitialize to run code before running each test 
        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");
         
            // Create a snapshot Lun
            log.LogInfo("Test Initialize: Create Snapshot Lun");

            string result = TestSetup.SetSnapshotLunEnvironment(psMachine, snapshotLunPrefix, sourceLunPrefix);
            lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (TestSetup.StorageSystemType == "VNXe")
            {
                snapshotLunID = lunKeyValue["Name"];
            }
            else
            {
                snapshotLunID = lunKeyValue["Wwn"];
            }   
            log.LogInfo("--------Test Initialize End--------");
        }

        // Use TestCleanup to run code after each test has run       
        [TestCleanup]
        public void TestTearDown()
        {            
            if (removeFlag)
            {
                log.LogInfo("--------Test Clean Up Start--------");
                log.LogInfo("Test Cleanup: Remove Snapshot Lun");
                TestSetup.ClearSnapshotLunEnvironment(psMachine, snapshotLunID, snapshotLunPrefix);
                log.LogInfo("--------Test Clean Up End--------");
            }          
            
        }
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a RemoveEmcSnapshotLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>RemoveEmcSnapshotLun instance</returns>  
        public static RemoveEmcSnapshotLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string snapshotlun = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion


            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotlun = snapshotLunPrefix;
                cmdString = cmdString.Replace("$SnapshotLun", snapshotlun);
            }
            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun(snapshotlun, force, silent, whatif, cmdString);

            return removeSnapshotLun;
        }

        /// <summary>  
        /// RemoveEmcSnapshotLunTestMethod:
        ///    The method to implement Remove-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSnapshotLunTestMethod(string cmd)
        {
           
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            
            // Remove snapshot Lun            
            RemoveEmcSnapshotLun removesnapshotLun = ParseCmd(cmd);
            
            if ( cmd.Contains("WhatIf") )
            {
                removesnapshotLun.VerifyTheCMD(psMachine, snapshotLunID);                
                removeFlag = true;
            }
            else
            {
                removesnapshotLun.VerifyTheCMD(psMachine, snapshotLunID);
            }            

        }

        /// <summary>  
        /// RemoveEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement Remove-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSnapshotLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcSnapshotLun snapshotLun = ParseCmd(cmd);

            try
            {
                snapshotLun.VerifyTheCMD(psMachine, snapshotLunID);
            }
            catch (PSException psEx)
            {
                removeFlag = true;
                log.LogTestCase(string.Format("Test with {0} failed.", snapshotLun.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    
    }
}

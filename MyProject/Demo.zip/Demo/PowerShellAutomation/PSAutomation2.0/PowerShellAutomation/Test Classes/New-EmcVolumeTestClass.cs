using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class NewEmcVolumeTest
    {
        public NewEmcVolumeTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;
       
        private static bool isHostDiskExists = false;

        private static bool isClusterDiskExists = false;


        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        public static void Initialize()
        {

            if (isHostDiskExists == false)
            {
                TestSetup.SetLunEnvironment(psMachine);

                string result = TestSetup.SetDiskEnvironment(psMachine);
                GetEmcHostLunIdentifier getIdentifier = new GetEmcHostLunIdentifier("$lun", "$h");
                getIdentifier.PrefixString = HelperAdapter.GetParameter("LunIdentifier");
                getIdentifier.RunCMD(psMachine);
                isHostDiskExists = true;
            }

            if (isClusterDiskExists == false)
            {
                if (HelperAdapter.IsClusterSet())
                {
                    //Set cluster Lun.
                    string lunForCluster = HelperAdapter.GetParameter("LunC");
                    string diskFindForCluster = HelperAdapter.GetParameter("DiskFindForCLuster");

                    TestSetup.SetLunEnvironment(psMachine, true, null, lunForCluster);
                    string clusterPrefix = HelperAdapter.GetParameter("Cluster");

                    TestSetup.SetDiskEnvironment(psMachine, diskFindForCluster, null, lunForCluster, clusterPrefix);
                    GetEmcHostLunIdentifier getIdentifierForCluster = new GetEmcHostLunIdentifier(lunForCluster, null, clusterPrefix);
                    getIdentifierForCluster.PrefixString = HelperAdapter.GetParameter("LunIdentifierForCluster");
                    getIdentifierForCluster.RunCMD(psMachine);
                    isClusterDiskExists = true;
                }
            }
        }

        public static void Clean()
        {
            if (isClusterDiskExists == false)
            {
                if (HelperAdapter.IsClusterSet())
                {
                    string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                    string lunForCluster = HelperAdapter.GetParameter("LunC");
                    TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
                    TestSetup.ClearLunEnvironment(psMachine, lunForCluster);
                }
            }
            if (isHostDiskExists == false)
            {
                TestSetup.ClearDiskEnvironment(psMachine);
                TestSetup.ClearLunEnvironment(psMachine);
            }
        }

        [TestInitialize]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            Initialize();

            log.LogInfo("--------Test Initialize End--------");
        }


        [TestCleanup]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start--------");
            Clean();
            log.LogInfo("--------Test Clean Up End--------");
        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            string systemName = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, systemName);
            TestSetup.SetPoolEnvironment(psMachine);

            TestSetup.SetHostEnvironment(psMachine);
            if (HelperAdapter.IsClusterSet())
            {
                string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                TestSetup.ConnectSystem(psMachine, "Cluster", clusterPrefix);
            }
            log.LogInfo("--------Class Initialize End--------");
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            if (isClusterDiskExists == true)
            {
                if (HelperAdapter.IsClusterSet())
                {
                    string clusterPrefix = HelperAdapter.GetParameter("Cluster");
                    string lunForCluster = HelperAdapter.GetParameter("LunC");
                    TestSetup.ClearDiskEnvironment(psMachine, null, clusterPrefix, lunForCluster);
                    TestSetup.ClearLunEnvironment(psMachine, lunForCluster);
                }
            }
            if (isHostDiskExists == true)
            {
                TestSetup.ClearDiskEnvironment(psMachine);
                TestSetup.ClearLunEnvironment(psMachine);
            }
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a NewEmcVolume instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcVolume instance</returns>  
        public NewEmcVolume ParseCmd(string cmd)
        {

             #region AutoGenerate
            string hostsystem = null;
            string hostdisk = null;
            string label = null;
            string allocationunitsizeinbytes = null;
            string filesystemtype = null;
            string silent = null;
            string hostlunidentifier = null;
            string clustersystem = null;


            string cmdString = cmd;
   
            #endregion


            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Volume");
            string random = HelperAdapter.GenerateRandomString();

            string hostSystemString = HelperAdapter.GetParameter("Host");
            string hostDiskString = HelperAdapter.GetParameter("Disk");
            string clusterDiskString = HelperAdapter.GetParameter("DiskFindForCLuster");
            string allocationUnitSizeInByteString = HelperAdapter.GenerateRandomValue(HelperAdapter.Fat32AllocationUnitSize);
            string fileSystemTypeString = HelperAdapter.GenerateRandomValue(HelperAdapter.FileSystemType);
            string labelString = "vol_" + random;
            string hostLunIdentifierString = HelperAdapter.GetParameter("LunIdentifier");
            string clusterLunIdentifierString = HelperAdapter.GetParameter("LunIdentifierForCluster");
            string silentString = "Silent";
            string clusterSystemString = HelperAdapter.GetParameter("Cluster");






            if (cmdString.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostSystemString;
                cmdString = cmdString.Replace("$HostSystem", hostSystemString);
            }
            if (cmdString.IndexOf("$HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    hostDiskString = clusterDiskString;
                }
                hostdisk = hostDiskString;
                cmdString = cmdString.Replace("$HostDisk", hostDiskString);
            }
            if (cmdString.IndexOf("$AllocationUnitSizeInBytes", StringComparison.OrdinalIgnoreCase) > 0)
            {
                allocationunitsizeinbytes = allocationUnitSizeInByteString;
                if (cmdString.IndexOf("FileSystemType", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    string lunCap = HelperAdapter.GetParameter("Capacity", "LunConfig");
                    string lunSize = TestSetup.GetPropertyValue(psMachine, lunCap);
                    int lunSizeInInt = int.Parse(lunSize);
                    int allocateInt=int.Parse(allocationUnitSizeInByteString);
                    if (lunSizeInInt / 70000 < allocateInt)
                    {
                        allocationunitsizeinbytes ="4096";
                    }
                }
                cmdString = cmdString.Replace("$AllocationUnitSizeInBytes", allocationunitsizeinbytes);

            }
            if (cmdString.IndexOf("$FileSystemType", StringComparison.OrdinalIgnoreCase) > 0)
            {
                filesystemtype = fileSystemTypeString;
                cmdString = cmdString.Replace("$FileSystemType", fileSystemTypeString);
            }
            if (cmdString.IndexOf("$Label", StringComparison.OrdinalIgnoreCase) > 0)
            {
                label = labelString;
                cmdString = cmdString.Replace("$Label", labelString);
            }
            if (cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    hostLunIdentifierString = clusterLunIdentifierString;
                }
                hostlunidentifier = hostLunIdentifierString;
                cmdString = cmdString.Replace("$HostLunIdentifier", hostLunIdentifierString);
            }
            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustersystem = clusterSystemString;
                cmdString = cmdString.Replace("$ClusterSystem", clusterSystemString);
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = silentString;
            }
            NewEmcVolume newVolume = new NewEmcVolume(hostsystem, hostdisk, label, allocationunitsizeinbytes, filesystemtype, silent, hostlunidentifier,
                clustersystem, cmdString);

            return newVolume;
        }



        public void NewEmcVolumeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            NewEmcVolume newVolume = ParseCmd(cmd);
            if (newVolume.ToCMDString().IndexOf("ClusterSystem") >= 0)
            {
                isClusterDiskExists = false;
            }
            if (newVolume.ToCMDString().IndexOf("HostSystem") >= 0)
            {
                isHostDiskExists = false;
            }
            newVolume.PrefixString = "$VolumeTest";
            newVolume.VerifyTheCMD(psMachine);
            //if (newVolume.ToCMDString().IndexOf("ClusterSystem") >= 0)
            //{
            //    isClusterDiskExists = false;
            //}
            //if (newVolume.ToCMDString().IndexOf("HostSystem") >= 0)
            //{
            //    isHostDiskExists = false;
            //}
        }


        public void NewEmcVolumeNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);
            NewEmcVolume newVolume = ParseCmd(cmd);
            bool failCMD = false;
            try
            {
                newVolume.VerifyTheCMD(psMachine);
                if (newVolume.ToCMDString().IndexOf("ClusterSystem") >= 0)
                {
                    isClusterDiskExists = false;
                }
                if (newVolume.ToCMDString().IndexOf("HostSystem") >= 0)
                {
                    isHostDiskExists = false;
                }
            }
            catch (PSException pe)
            {
                failCMD = true;
                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}



using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;


using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class GetEmcStorageSystemTest
    {
        public GetEmcStorageSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static int getSystemCount;
        private static string[] types;            
        private static SortedList<string, string>[] connectSystemKeyValue;
        private static string lunStorage;
        private static int groupIndex;
        private static SortedList<string, string> lunKeyValue;
        private static SortedList<string, string> poolKeyValue;
        private static SortedList<string, string> groupKeyValue;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        #region Additional test attributes
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);
            getSystemCount = 0;

            types = new string[] { "CLARiiON-CX4", "VMAX", "VMAXe", "VNX-Block", "VNX", "VNX-CIFS"};
            connectSystemKeyValue = new SortedList<string, string>[types.Length];
            string path = HelperAdapter.GetProperty("SystemConfig");
            bool setupPoolLun = false;

            for (int i = 0; i < types.Length; i++ )
            {
                string type = types[i];
                Dictionary<string, string> dic = HelperAdapter.Load(path, type);
                if (dic.Count == 0)
                {
                    log.LogInfo(string.Format("Storage system {0} is not prepared!", type));
                    continue;
                }
                
                string blobConfig = HelperAdapter.GetBlobContent(type);
                string prefix = "$" + type.Replace("-", "_");
                
                string result = TestSetup.ConnectSystem(psMachine, type, prefix);
                connectSystemKeyValue[i] = HelperAdapter.GenerateKeyValuePairs(result);
                
                if (setupPoolLun == false)
                {
                    string poolResult = TestSetup.SetPoolEnvironment(psMachine);
                    if (null == poolResult)
                    {
                        continue;
                    }
                    poolKeyValue = HelperAdapter.GenerateKeyValuePairs(poolResult);

                    string lunResult = TestSetup.SetLunEnvironment(psMachine);
                    lunKeyValue = HelperAdapter.GenerateKeyValuePairs(lunResult);
                    setupPoolLun = true;

                    List<string> ps = new List<string>();
                    ps.Add(HelperAdapter.GetParameter("System") + "=" + prefix);
                    psMachine.RunScript(ps, new List<PSParam>());
                    lunStorage = type;
                }
            }

            if (setupPoolLun == false)
            {
                log.LogError("no storage system is connected");
                PSException pe = new PSException("no storage system is connected");
                throw pe;
            }

            GetEmcStorageGroup getGroup = new GetEmcStorageGroup();
            getGroup.PrefixString = HelperAdapter.GetParameter("StorageGroup");
            string groupResult = getGroup.RunCMD(psMachine);

            List<SortedList<string, string>> groupList = HelperAdapter.GenerateKeyValuePairsList(groupResult);
            Random rd = new Random();
            groupIndex = rd.Next(0, groupList.Count);
            groupKeyValue = groupList[groupIndex];

            log.LogInfo("--------Class Initialize End--------");
        }
        
        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            TestSetup.DisconnectSystem(psMachine);
            TestSetup.ConnectSystem(psMachine, lunStorage, HelperAdapter.GetParameter("System"));
            TestSetup.ClearLunEnvironment(psMachine);            

            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcStorageSystem instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public GetEmcStorageSystem ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string id = null;
            string silent = null;
            string filestoragesystem = null;
            string blockstoragesystem = null;
            string lun = null;
            string pool = null;
            string clarstoragegroup = null;


            string cmdString = cmd;
   
            #endregion
#endif

            string systemType = null;
            int blockCount = 5;
            string idName = null;
            string globalId = null;

            int i = 0;

            for (i = 0; i < types.Length; i++)
            {
                string type = types[i];
                if (cmd.IndexOf(type + "_", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    if (connectSystemKeyValue[i] == null)
                    {
                        log.LogInfo(string.Format("Storage system {0} is not prepared!", type));
                        return null;
                    }
                }
                else
                {
                    continue;
                }

                if (cmd.IndexOf(type + "_Name", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    id = connectSystemKeyValue[i]["Name"];
                    cmdString = cmdString.Replace("$" + type + "_Name", id);                    
                    systemType = type;
                    idName = "Name";
                    globalId = connectSystemKeyValue[i]["GlobalId"];
                    break;
                }
                else if (cmd.IndexOf(type + "_FriendlyName", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    id = connectSystemKeyValue[i]["UserFriendlyName"];
                    cmdString = cmdString.Replace("$" + type + "_FriendlyName", id);
                    systemType = type;
                    idName = "UserFriendlyName";
                    globalId = connectSystemKeyValue[i]["GlobalId"];
                    break;
                }
                else if (cmd.IndexOf(type + "_GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    id = connectSystemKeyValue[i]["GlobalId"];
                    cmdString = cmdString.Replace("$" + type + "_GlobalId", id);
                    systemType = type;
                    idName = "GlobalId";
                    globalId = connectSystemKeyValue[i]["GlobalId"];
                    break;
                }
            }
            getSystemCount = 0;
            for (int j = 0; j < types.Length; j++)
            {
                if (connectSystemKeyValue[j] != null)
                {
                    if (id == null || connectSystemKeyValue[j][idName] == id)
                    {
                        getSystemCount++;
                    }
                }
            }
            if (getSystemCount != 1)
            {
                globalId = null;
            }
            
            if (cmd.IndexOf("FileStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                filestoragesystem = "FileStorageSystem";
                getSystemCount = 0;
                for (int j = blockCount - 1; j < types.Length; j++)
                {
                    if (connectSystemKeyValue[j] != null)
                    {
                        if (id == null || connectSystemKeyValue[j][idName] == id)
                        {
                            getSystemCount++;
                        }
                    }
                }
                if (systemType != null && systemType != "VNX" && systemType != "VNX-CIFS")
                {
                    return null;
                }
            }

            if (cmd.IndexOf("BlockStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                blockstoragesystem = "BlockStorageSystem";
                getSystemCount = 0;
                for (int j = 0; j < blockCount; j++)
                {
                    if (connectSystemKeyValue[j] != null)
                    {
                        if (id == null || connectSystemKeyValue[j][idName] == id)
                        {
                            log.LogInfo(string.Format("id:{0}, value:{1}", id, j));
                            getSystemCount++;
                        }
                    }
                }
                if ( systemType == "VNX-CIFS")
                {
                    return null;
                }
            }

            if (cmd.IndexOf("Lun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                lun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$Lun", lun);
                globalId = lunKeyValue["StorageSystemGlobalId"];
                getSystemCount = 1;
            }

            if (cmd.IndexOf("Pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = HelperAdapter.GetParameter("Pool");
                cmdString = cmdString.Replace("$Pool", pool);
                globalId = poolKeyValue["StorageSystemGlobalId"];
                getSystemCount = 1;
            }

            if (cmd.IndexOf("ClarStorageGroup", StringComparison.OrdinalIgnoreCase) > 0)
            {
                getSystemCount = 1;
                clarstoragegroup = HelperAdapter.GetParameter("StorageGroup") + "[" + groupIndex + "]";
                globalId = groupKeyValue["StorageSystemGlobalId"];
                cmdString = cmdString.Replace("$ClarStorageGroup", clarstoragegroup);
            }

            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (getSystemCount == 0)
            {
                return null;
            }

            GetEmcStorageSystem storageSystem = new GetEmcStorageSystem(id, silent, filestoragesystem, blockstoragesystem, lun, pool, clarstoragegroup, cmdString);
            storageSystem.ConnectSystemKeyValue = connectSystemKeyValue;
            storageSystem.GetSystemCount = getSystemCount;
            storageSystem.GlobalId = globalId;

            return storageSystem;
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStorageSystemTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcStorageSystem system = ParseCmd(cmd);
            if (system == null)
            {
                return;
            }

            system.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcStorageSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcStorageSystem system = ParseCmd(cmd);
            if (system == null)
            {
                return;
            }

            try
            {
                system.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case result");
        }

    }

}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// EnableEmcSnapshotLunTest: test class for Enable-EmcSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class EnableEmcSnapshotLunTest
    {
        public EnableEmcSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string snapshotLunID = "";

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string sourceLunPrefix = HelperAdapter.GetParameter("Lun");
        private static string snapshotPoolPrefix = HelperAdapter.GetParameter("SnapshotPool");
        private static string hostPrefix = HelperAdapter.GetParameter("Host");
        private static string retentionPrefix = HelperAdapter.GetParameter("Timespan");

        private bool negative = false;


        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (TestSetup.StorageSystemType == "VNXe")
            {
                TestSetup.SetLunAccess(psMachine, snapshotLunPrefix, hostPrefix);
            }

            log.LogInfo("--------Test Init End---------");
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            GetEmcSnapshotLun getEmcSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
            string result = getEmcSnapshotLun.RunCMD(psMachine, true);
            if (HelperAdapter.GenerateKeyValuePairs(result)["IsActivated"].Equals("True"))
            {

                log.LogInfo("--------Test Clean Up Start--------");
                log.LogInfo("Test Cleanup: Deactivate Snapshot Lun");
                DisableEmcSnapshotLun disableEmcSnapshotLun = new DisableEmcSnapshotLun(snapshotLunPrefix);
                disableEmcSnapshotLun.VerifyTheCMD(psMachine, snapshotLunID);
                log.LogInfo("--------Test Clean Up End--------");
            }
            if (TestSetup.StorageSystemType == "VNXe" && !negative)
            {
                TestSetup.ClearDiskEnvironment(psMachine, hostPrefix, null, snapshotLunPrefix);
            }

        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);

            // Get Snapshot Pool
            log.LogInfo("Class Initialize: Get Snapshot Pool");
            string poolId = TestSetup.GetSnapshotPoolId(TestSetup.StorageSystemType);
            TestSetup.SetSnapshotPool(psMachine, snapshotPoolPrefix, poolId);

            // Create Snapshot Lun
            log.LogInfo("Class Initialize: Create Snapshot Lun");
            if (TestSetup.StorageSystemType == "VNXe")
            {
                TestSetup.SetRetention(psMachine, retentionPrefix);
            }
            else
            {
                retentionPrefix = null;
            }
            string result = TestSetup.SetSnapshotLunEnvironment(psMachine, snapshotLunPrefix, sourceLunPrefix, snapshotPoolPrefix, true, retentionPrefix);
                
            SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            if (TestSetup.StorageSystemType == "VNXe")
            {
                snapshotLunID = keyValuePairs["Name"];
            }
            else
            {
                snapshotLunID = keyValuePairs["Wwn"];
            }
            string isActivatedString = keyValuePairs["IsActivated"];
            if (isActivatedString.Equals("True"))
            {
                log.LogError("The Snapshot Lun is activated");
                PSException pe = new PSException("The Snapshot Lun is activated");
                throw pe;
            }

            // To activate VNXe snapshot lun, the snapshot lun should be unmask to a host
            if (TestSetup.StorageSystemType == "VNXe")
            {
                TestSetup.ConnectSystem(psMachine, "Host", hostPrefix);
            }

        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            if (TestSetup.StorageSystemType == "VNXe")
            {
                TestSetup.ClearDiskEnvironment(psMachine, hostPrefix);
            }

            log.LogInfo("Test Cleanup: Remove Snapshot Lun");
            TestSetup.ClearSnapshotLunEnvironment(psMachine, snapshotLunID);

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source LUN");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Enable-EmcSnapshotLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Enable-EmcSnapshotLun instance</returns>  
        public EnableEmcSnapshotLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string snapshotlun = null;
            string sourcelun = null;
            string snapshotpool = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("snapshotlun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotlun = snapshotLunPrefix;
                cmdString = cmdString.Replace("$SnapshotLun", snapshotlun);
            }
            if (cmd.IndexOf("sourcelun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourcelun = sourceLunPrefix;
                cmdString = cmdString.Replace("$SourceLun", sourcelun);
            }
            if (cmd.IndexOf("SnapshotPool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotpool = snapshotPoolPrefix;
                cmdString = cmdString.Replace("$SnapshotPool", snapshotpool);
            }
            if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            EnableEmcSnapshotLun instance;

            if ((TestSetup.StorageSystemType == "VMAX" && (!cmd.Contains("SourceLun"))) || ((TestSetup.StorageSystemType == "VNXe") && cmd.Contains("SnapshotPool")))
            {
                instance = null;
            }
            else
            {
                instance = new EnableEmcSnapshotLun(snapshotlun, sourcelun, snapshotpool, force, silent, whatif, cmdString);
            }
            return instance;
        }


        /// <summary>  
        /// Enable-EmcSnapshotLun:
        ///    The method to implement Enable-EmcSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void EnableEmcSnapshotLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            EnableEmcSnapshotLun cmdClass = ParseCmd(cmd);

            if (cmdClass != null)
            {
                cmdClass.VerifyTheCMD(psMachine);
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }
        }

        /// <summary>  
        /// EnableEmcSnapshotLunNegativeTestMethod:
        ///    The method to implement Enable-EmcSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void EnableEmcSnapshotLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            EnableEmcSnapshotLun enableEmcSnapshotLunClass = ParseCmd(cmd);

            negative = true;

            if (enableEmcSnapshotLunClass != null)
            {
                try
                {
                    enableEmcSnapshotLunClass.VerifyTheCMD(psMachine);
                }
                catch (PSException psEx)
                {
                    log.LogTestCase(string.Format("Test with {0} failed.", enableEmcSnapshotLunClass.GetFullString()));
                    log.LogTestCase(psEx.messageDetail);
                    caseFail = true;
                }
                log.AreEqual<bool>(true, caseFail, "Negative test case result:");                
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }
        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// ExpandEmcHostVolumeTest: test class for Expand-EmcHostVolume cmdlet
    /// </summary>
    [TestClass]
    public partial class ExpandEmcHostVolumeTest
    {
        public ExpandEmcHostVolumeTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string> volumeKeyValue;
        private static ulong oldCapacity;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            try
            {
                ulong diskSize = ulong.Parse(TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Disk"), "Size.value"));
                ulong volumeSize = ulong.Parse(TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Volume"), "Size.value"));

                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path, "Expand");
                ulong volumeExpand = ulong.Parse(TestSetup.GetPropertyValue(psMachine, dic["VolumeExpand"]));

                if (diskSize <= volumeSize + volumeExpand)
                {
                    string lunOldCapacity = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Lun"), "Capacity.Value");
                    string lunExpandCapacity = TestSetup.GetPropertyValue(psMachine, dic["LunExpand"]);
                    ulong lunNewCapacity = ulong.Parse(lunOldCapacity) + ulong.Parse(lunExpandCapacity);

                    ExpandEmcLun expandLun = new ExpandEmcLun(HelperAdapter.GetParameter("Lun"), lunNewCapacity.ToString(), null, null);
                    expandLun.PrefixString = HelperAdapter.GetParameter("Lun");
                    expandLun.RunCMD(psMachine, true);
                }

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Host"));
                updateSystem.RunCMD(psMachine);

                GetEmcHostDisk getDisk = new GetEmcHostDisk(null, HelperAdapter.GetParameter("Lun"),  HelperAdapter.GetParameter("Host"));
                getDisk.PrefixString = HelperAdapter.GetParameter("Disk");
                getDisk.RunCMD(psMachine, true);

                GetEmcHostVolume vol = new GetEmcHostVolume(volumeKeyValue["HostVolumeIdentifier"], null, HelperAdapter.GetParameter("Host"));
                vol.PrefixString = HelperAdapter.GetParameter("Volume");
                string result = vol.RunCMD(psMachine, true);

                volumeKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
                oldCapacity = ulong.Parse(TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Volume"), "Size.Value"));
            }
            catch (Exception ex)
            {
                ESIPSTestClassCleanUP();
                throw ex;
            }

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            TestSetup.ConnectSystem(psMachine, "Host", HelperAdapter.GetParameter("Host"));
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            string result = TestSetup.SetDiskEnvironment(psMachine);
            if (string.IsNullOrEmpty(result))
            {
                TestSetup.ClearLunEnvironment(psMachine);
                throw new PSException("SetDiskEnvironment failed");
            }
            result = TestSetup.SetVolumeEnvironment(psMachine);
            if (string.IsNullOrEmpty(result))
            {
                TestSetup.ClearDiskEnvironment(psMachine);
                TestSetup.ClearLunEnvironment(psMachine);
                throw new PSException("SetVolumeEnvironment failed");
            }
            volumeKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            TestSetup.ClearDiskEnvironment(psMachine);
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Expand-EmcHostVolume instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Expand-EmcHostVolume instance</returns>  
        public ExpandEmcHostVolume ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hostsystem = null;
            string volume = null;
            string capacity = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = HelperAdapter.GetParameter("Host");
                cmdString = cmdString.Replace("$HostSystem", hostsystem);
            }

            if (cmd.IndexOf("$Volume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                volume = HelperAdapter.GetParameter("Volume");
                cmdString = cmdString.Replace("$Volume", volume);
            }

            if (cmd.IndexOf("$CapacityToAdd", StringComparison.OrdinalIgnoreCase) > 0)
            {
                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path, "Expand");

                capacity = dic["VolumeExpand"];
                cmdString = cmdString.Replace("$CapacityToAdd", capacity);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            ExpandEmcHostVolume instance = new ExpandEmcHostVolume(hostsystem, volume, capacity, silent, cmdString);
            instance.VolumeKeyValue = volumeKeyValue;
            instance.OldCapacity = oldCapacity;

            return instance;
        }


        /// <summary>  
        /// Expand-EmcHostVolume:
        ///    The method to implement Expand-EmcHostVolume poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExpandEmcHostVolumeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            ExpandEmcHostVolume cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// ExpandEmcHostVolumeNegativeTestMethod:
        ///    The method to implement Expand-EmcHostVolume negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ExpandEmcHostVolumeNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (TestSetup.StorageSystemType.ToLower() == "vnxe" || TestSetup.StorageSystemType.ToLower().Contains("vmax"))
            {
                return;
            }

            bool caseFail = false;

            ExpandEmcHostVolume expandemchostvolumeClass = ParseCmd(cmd);

            try
            {
                expandemchostvolumeClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", expandemchostvolumeClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

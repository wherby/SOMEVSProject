using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcHostBusAdapterTest: test class for Get-EmcHostBusAdapter cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcHostBusAdapterTest
    {
        public GetEmcHostBusAdapterTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            TestSetup.SetHostEnvironment(psMachine);
            if (HelperAdapter.IsClusterSet())
            {
                TestSetup.SetClusterEnvironment(psMachine);
            }
            RefreshHBAForcluster(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcHostBusAdapter instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcHostBusAdapter instance</returns>  
        public GetEmcHostBusAdapter ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hostsystem = null;
            string silent = null;
            string clustersystem = null;
   
            #endregion

            string hostsystemString = HelperAdapter.GetParameter("Host");
            string clustersystemString = HelperAdapter.GetParameter("Cluster");

            if (cmd.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostsystemString;
                cmd = cmd.Replace("$HostSystem", hostsystem);
            }
            if (cmd.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustersystem = clustersystemString;
                cmd = cmd.Replace("$ClusterSystem", clustersystem);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            GetEmcHostBusAdapter instance = new GetEmcHostBusAdapter(hostsystem, silent, clustersystem, cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcHostBusAdapter:
        ///    The method to implement Get-EmcHostBusAdapter poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostBusAdapterTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcHostBusAdapter cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcHostBusAdapterNegativeTestMethod:
        ///    The method to implement Get-EmcHostBusAdapter negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcHostBusAdapterNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcHostBusAdapter getemchostbusadapterClass = ParseCmd(cmd);

            try
            {
                getemchostbusadapterClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemchostbusadapterClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }

        /// <summary>
        /// The method is used to refresh hostbusadapter for cluster.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        private static void RefreshHBAForcluster(PowershellMachine psMachine)
        {
            string cluster = HelperAdapter.GetParameter("Cluster");
            string refreshCluster = string.Format("{0}.RefreshHostBusAdapters()", cluster);
            TestSetup.GetPropertyValue(psMachine, refreshCluster);
        }
    }
}

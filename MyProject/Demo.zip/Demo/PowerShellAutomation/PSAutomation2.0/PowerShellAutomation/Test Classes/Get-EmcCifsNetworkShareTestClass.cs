using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcCifsNetworkShareTest: test class for Get-EmcCifsNetworkShare cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcCifsNetworkShareTest
    {
        public GetEmcCifsNetworkShareTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string networkFolderResult=null;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
 
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");



            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                TestSetup.SetVNXESharedFolderPoolEnvironment(psMachine);
            }
            else
            {
                TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
                TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            }
            TestSetup.SetCIFSSharedFolderEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            TestSetup.SetHostCreadentialEnvironment(psMachine);
            networkFolderResult= TestSetup.SetMountPointEnvironment(psMachine);

            log.LogInfo("--------Class Init End---------");        
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            TestSetup.RemoveMountPointEnvironment(psMachine);
            TestSetup.RemoveSharedFolderEnvironment(psMachine);
            if (TestSetup.IsStorageVNXE() == false)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Clean Up End---------");  
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcCifsNetworkShare instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcCifsNetworkShare instance</returns>  
        public GetEmcCifsNetworkShare ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hostsystem = null;
            string id = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string hostsystemString = HelperAdapter.GetParameter("Host");
            string idString = GetPathString(networkFolderResult);

            if (cmd.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostsystemString;
                cmd = cmd.Replace("$HostSystem", hostsystem);
            }
            if (cmd.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = idString;
                cmd = cmd.Replace("$ID", id);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            GetEmcCifsNetworkShare instance = new GetEmcCifsNetworkShare(hostsystem, id, silent,  cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcCifsNetworkShare:
        ///    The method to implement Get-EmcCifsNetworkShare poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcCifsNetworkShareTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcCifsNetworkShare cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcCifsNetworkShareNegativeTestMethod:
        ///    The method to implement Get-EmcCifsNetworkShare negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcCifsNetworkShareNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcCifsNetworkShare getemccifsnetworkshareClass = ParseCmd(cmd);

            try
            {
                getemccifsnetworkshareClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemccifsnetworkshareClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }

        private static string GetPathString(string result)
        {
            SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            List<string> idList = new List<string>();
            idList.Add(keyValuePairs["LocalPath"]);
            idList.Add(keyValuePairs["RemotePath"]);
            Random rd = new Random();
            string randomString = idList[rd.Next(idList.Count)];
            return string.Format("\"{0}\"", randomString);
        }
    }
}

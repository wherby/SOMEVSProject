using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcXenServerHostTest: test class for Get-EmcXenServerHost cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcXenServerHostTest
    {
        public GetEmcXenServerHostTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string> xenServer;
        private static List<Dictionary<string, string>> hosts;
        private static List<SortedList<string, string>> hostList;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");



            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Init Start---------");
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsXenSet())
            {
                log.BypassTest();
            }

            string result = TestSetup.ConnectSystem(psMachine, "XenServer", HelperAdapter.GetParameter("XenServer"));

            xenServer = HelperAdapter.GenerateKeyValuePairs(result);

            hosts = HelperAdapter.GetHypervisorHosts(HyperVisorType.XenServer);

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(HelperAdapter.GetParameter("XenServer"));
            updateXenServer.RunCMD(psMachine);

            string hostsResult = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("XenServer"), "XenServerHosts");
            hostList = HelperAdapter.GenerateKeyValuePairsList(hostsResult);
            
            log.LogInfo("--------Class Init End---------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcXenServerHost instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcXenServerHost instance</returns>  
        public GetEmcXenServerHost ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string xenserver = null;
            string silent = null;

            string cmdString = cmd;
   
            #endregion

            string globalId = null;
            string uuid = null;
            int hostIndex = 0;//Get random index
            int hostCount = hostList.Count;

            
            foreach (SortedList<string, string> host in hostList)
            {
                if (host["Name"] == hosts[hostIndex]["Name"])
                {
                    uuid = host["Uuid"];
                    globalId = host["GlobalId"];
                    break;
                }
            }

            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = hosts[hostIndex]["Name"];
                cmdString = cmdString.Replace("$Name", id);
                hostCount = 1;
            }
            else if (cmd.IndexOf("$UUID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = uuid;
                cmdString = cmdString.Replace("$UUID", id);
                hostCount = 1;
            }
            else if (cmd.IndexOf("$GlobalId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = globalId;
                cmdString = cmdString.Replace("$GlobalId", id);
                hostCount = 1;
            }

            if (cmd.IndexOf("$XenServer", StringComparison.OrdinalIgnoreCase) > 0)
            {
                xenserver = HelperAdapter.GetParameter("XenServer");
                cmdString = cmdString.Replace("$XenServer", xenserver);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            GetEmcXenServerHost instance = new GetEmcXenServerHost(id, xenserver, silent,  cmdString);

            instance.HostsKeyValue = hosts;
            if (hostCount == hosts.Count)
            {
                instance.HostIndex = -1;
            }
            else
            {
                instance.HostIndex = hostIndex;
            }

            return instance;
        }


        /// <summary>  
        /// Get-EmcXenServerHost:
        ///    The method to implement Get-EmcXenServerHost poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerHostTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            GetEmcXenServerHost cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcXenServerHostNegativeTestMethod:
        ///    The method to implement Get-EmcXenServerHost negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcXenServerHostNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsXenSet())
            {
                return;
            }

            bool caseFail = false;

            GetEmcXenServerHost getxenserverhostClass = ParseCmd(cmd);

            try
            {
                getxenserverhostClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getxenserverhostClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcCifsSharedFolderMountPointTest: test class for Remove-EmcCifsSharedFolderMountPoint cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcCifsSharedFolderMountPointTest
    {
        public RemoveEmcCifsSharedFolderMountPointTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static bool isMountPointNeedRemoved;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            TestSetup.SetMountPointEnvironment(psMachine);
            isMountPointNeedRemoved = true;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (isMountPointNeedRemoved == true)
            {
                TestSetup.RemoveMountPointEnvironment(psMachine);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                TestSetup.SetVNXESharedFolderPoolEnvironment(psMachine);
            }
            else
            {
                TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
                TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            }
            TestSetup.SetCIFSSharedFolderEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            TestSetup.SetHostCreadentialEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            TestSetup.RemoveSharedFolderEnvironment(psMachine);
            if (TestSetup.IsStorageVNXE() == false)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcCifsSharedFolderMountPoint instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcCifsSharedFolderMountPoint instance</returns>  
        public RemoveEmcCIFSSharedFolderMountPoint ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hostsystem = null;
            string sharedfolder = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string hostsystemString = HelperAdapter.GetParameter("Host");
            string sharedfolderString = HelperAdapter.GetParameter("NetworkShareFolder");

            if (cmd.IndexOf("$HostSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostsystem = hostsystemString;
                cmd = cmd.Replace("$HostSystem", hostsystem);
            }
            if (cmd.IndexOf("$SharedFolder", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sharedfolder = sharedfolderString;
                cmd = cmd.Replace("$SharedFolder", sharedfolder);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            RemoveEmcCIFSSharedFolderMountPoint instance = new RemoveEmcCIFSSharedFolderMountPoint(hostsystem, sharedfolder, silent,  cmd);
            return instance;
        }


        /// <summary>  
        /// Remove-EmcCIFSSharedFolderMountPoint:
        ///    The method to implement Remove-EmcCIFSSharedFolderMountPoint poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcCifsSharedFolderMountPointTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcCIFSSharedFolderMountPoint cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
            isMountPointNeedRemoved = false;
        }

        /// <summary>  
        /// RemoveEmcCIFSSharedFolderMountPointNegativeTestMethod:
        ///    The method to implement Remove-EmcCIFSSharedFolderMountPoint negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcCifsSharedFolderMountPointNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcCIFSSharedFolderMountPoint removeemccifssharedfoldermountpointClass = ParseCmd(cmd);

            try
            {
                removeemccifssharedfoldermountpointClass.VerifyTheCMD(psMachine);
                isMountPointNeedRemoved = false;
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removeemccifssharedfoldermountpointClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

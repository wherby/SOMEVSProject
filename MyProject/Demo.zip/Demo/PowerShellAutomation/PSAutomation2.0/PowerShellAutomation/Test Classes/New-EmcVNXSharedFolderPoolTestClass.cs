using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcVNXSharedFolderPoolTest: test class for New-EmcVNXSharedFolderPool cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcVNXSharedFolderPoolTest
    {
        public NewEmcVNXSharedFolderPoolTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string folderPoolName;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            folderPoolName = null;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if (folderPoolName != null)
            {
                GetEmcStoragePool getPool = new GetEmcStoragePool(folderPoolName);
                getPool.PrefixString = HelperAdapter.GetParameter("SharedFolderPool");
                getPool.VerifyTheCMD(psMachine);
                RemoveEmcVNXSharedFolderPool removePool = new RemoveEmcVNXSharedFolderPool(HelperAdapter.GetParameter("SharedFolderPool"), "force");
                removePool.VerifyTheCMD(psMachine);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                log.BypassTest();
            }
            TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a New-EmcVNXSharedFolderPool instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>New-EmcVNXSharedFolderPool instance</returns>  
        public NewEmcVNXSharedFolderPool ParseCmd(string cmd)
        {
            #region AutoGenerate
            string pool = null;
            string name = null;
            string path = null;
            string capacity = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            string poolString = HelperAdapter.GetParameter("FileStoragePool");
            string nameString = HelperAdapter.GenerateName("SFP");
            string pathString = HelperAdapter.GenerateName("SFPPath");
            string capacityString = HelperAdapter.GetParameter("CapacityForFilePool", "LunConfig");
            capacityString = TestSetup.GetPropertyValue(psMachine, capacityString);

            if (cmd.IndexOf("$Pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = poolString;
                cmd = cmd.Replace("$Pool", poolString);
            }
            if (cmd.IndexOf("$Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                name = nameString;
                cmd = cmd.Replace("$Name", nameString);
            }
            if (cmd.IndexOf("$Capacity", StringComparison.OrdinalIgnoreCase) > 0)
            {
                capacity = capacityString;
                cmd = cmd.Replace("$Capacity", capacityString);
            }
            if (cmd.IndexOf("$Path", StringComparison.OrdinalIgnoreCase) > 0)
            {
                path = pathString;
                cmd = cmd.Replace("$Path", path);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            NewEmcVNXSharedFolderPool instance = new NewEmcVNXSharedFolderPool(pool, name,path, capacity, silent,  cmd);
            return instance;
        }


        /// <summary>  
        /// New-EmcVNXSharedFolderPool:
        ///    The method to implement New-EmcVNXSharedFolderPool poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcVNXSharedFolderPoolTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            NewEmcVNXSharedFolderPool cmdClass = ParseCmd(cmd);

            string result=cmdClass.VerifyTheCMD(psMachine);

            SortedList<string, string> lunKeyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            folderPoolName = lunKeyValuePairs["Name"];
        }

        /// <summary>  
        /// NewEmcVNXSharedFolderPoolNegativeTestMethod:
        ///    The method to implement New-EmcVNXSharedFolderPool negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcVNXSharedFolderPoolNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcVNXSharedFolderPool newemcvnxsharedfolderpoolClass = ParseCmd(cmd);

            try
            {
                string result= newemcvnxsharedfolderpoolClass.VerifyTheCMD(psMachine);
                SortedList<string, string> lunKeyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
                folderPoolName = lunKeyValuePairs["Name"];
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", newemcvnxsharedfolderpoolClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

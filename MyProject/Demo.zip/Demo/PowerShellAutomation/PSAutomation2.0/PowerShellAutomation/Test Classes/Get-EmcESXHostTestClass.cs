using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcESXHostTest: test class for Get-EmcESXHost cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcESXHostTest
    {
        public GetEmcESXHostTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string vmwareSystemGlobalId;
        private static string name;
        private static string uuid;
        private static string ipAddress;
        private static string managementServerIp;

        private static string vmwarePrefix = HelperAdapter.GetParameter("VMWare");
        private static string vmwarePrefix2 = vmwarePrefix + "2";
        private static string esxHostPrefix = HelperAdapter.GetParameter("ESXHost");
        private static string datastorePrefix = HelperAdapter.GetParameter("DataStore");
        private static string scsiLunPrefix = HelperAdapter.GetParameter("ScsiLun");
        private static string vmPrefix = HelperAdapter.GetParameter("VirtualMachine");
        private static string vmConfigurationPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            if (!HelperAdapter.IsVMwareSet())
            {
                log.BypassTest();
            }

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");

            // Connect to ESX Host1
            log.LogInfo("Class Initialize: Connect to ESX Host");
            Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
            name = dic["HostName"];
            ipAddress = dic["IPAddress"];
            managementServerIp = dic["ManagementServerIp"];
            string result = TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix, dic);
            vmwareSystemGlobalId = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            result = TestSetup.SetESXHostEnvironment(psMachine, esxHostPrefix, vmwarePrefix);
            uuid = HelperAdapter.GenerateKeyValuePairs(result)["Uuid"];

            UpdateEmcSystem updateEmcSystem = new UpdateEmcSystem(vmwarePrefix);
            updateEmcSystem.RunCMD(psMachine);

            try
            {
                // Connect to ESX Host2
                dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[1];
                TestSetup.ConnectSystem(psMachine, "VMware", vmwarePrefix2, dic);
            }
            catch
            {
                log.LogWarning("Failed to connect to the second ESX host");
            }

            // Connect to VM
            dic = HelperAdapter.GetHostVMs(HyperVisorType.VMWare, 0)[0];
            TestSetup.ConnectSystem(psMachine, "VMware", vmPrefix, dic);
            GetEmcVirtualMachineConfiguration getEmcVirtualMachineConfiguration = new GetEmcVirtualMachineConfiguration(null, vmPrefix);
            getEmcVirtualMachineConfiguration.PrefixString = vmConfigurationPrefix;
            getEmcVirtualMachineConfiguration.RunCMD(psMachine, true);

            // Get Datastore
            TestSetup.SetDataStoreEnvironment(psMachine, datastorePrefix);
            
            //Get Scsi Lun
            TestSetup.GetScsiLunFromDataStore(psMachine, scsiLunPrefix, datastorePrefix);
            
            log.LogInfo("--------Class Initialize End--------");            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");
            
            // Disconnect Storage and Host System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcESXHost instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcESXHost instance</returns>  
        public GetEmcESXHost ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string vmwaresystem = null;
            string silent = null;
            string scsilun = null;
            string datastore = null;
            string virtualmachineconfiguration = null;
            

            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = name;
                cmdString = cmdString.Replace("$Name", id);
            }
            else if (cmd.IndexOf("$UUID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = uuid;
                cmdString = cmdString.Replace("$UUID", id);
            }            

            if (cmd.IndexOf("VMwareSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmwaresystem = vmwarePrefix;
                cmdString = cmdString.Replace("$VMwareSystem", vmwaresystem);
            }

           
            if (cmd.IndexOf("Datastore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                datastore = datastorePrefix;
                cmdString = cmdString.Replace("$Datastore", datastore);
            }

            if (cmd.IndexOf("ScsiLun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsilun = scsiLunPrefix;
                cmdString = cmdString.Replace("$ScsiLun", scsilun);
            }

            if (cmd.IndexOf("VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualmachineconfiguration = vmConfigurationPrefix;
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", virtualmachineconfiguration);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            GetEmcESXHost instance = new GetEmcESXHost(id, vmwaresystem, silent, scsilun, datastore, virtualmachineconfiguration,  cmdString);
            return instance;
        }


        /// <summary>  
        /// Get-EmcESXHost:
        ///    The method to implement Get-EmcESXHost poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcESXHostTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcESXHost cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, name, vmwareSystemGlobalId, uuid, ipAddress, managementServerIp);
        }

        /// <summary>  
        /// GetEmcESXHostNegativeTestMethod:
        ///    The method to implement Get-EmcESXHost negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcESXHostNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcESXHost getemcesxhostClass = ParseCmd(cmd);

            try
            {
                getemcesxhostClass.VerifyTheCMD(psMachine, name, vmwareSystemGlobalId, uuid, ipAddress, managementServerIp);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcesxhostClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcSharedFolderTest: test class for Get-EmcSharedFolder cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcSharedFolderTest
    {
        public GetEmcSharedFolderTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;

        private static string folderResult;
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                TestSetup.SetVNXESharedFolderPoolEnvironment(psMachine);
            }
            else
            {
                TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
                TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            }
            folderResult=TestSetup.SetCIFSSharedFolderEnvironment(psMachine);
            TestSetup.SetHostEnvironment(psMachine);
            TestSetup.SetHostCreadentialEnvironment(psMachine);
            TestSetup.SetMountPointEnvironment(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");

            TestSetup.RemoveMountPointEnvironment(psMachine);
            TestSetup.RemoveSharedFolderEnvironment(psMachine);
            if (TestSetup.IsStorageVNXE()==false)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcSharedFolder instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcSharedFolder instance</returns>  
        public GetEmcSharedFolder ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string cifsstoragesystem = null;
            string silent = null;
            string pool = null;
            string networkshare = null;


            string cmdString = cmd;
   
            #endregion

            string idString = GetIDString(folderResult);
            string cifsstoragesystemString = HelperAdapter.GetParameter("System");
            string poolString = HelperAdapter.GetParameter("SharedFolderPool");
            string networkshareString = HelperAdapter.GetParameter("NetworkShareFolder");

            if (cmd.IndexOf("$ID", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = idString;
                cmd = cmd.Replace("$ID", idString);
            }
            if (cmd.IndexOf("$CifsStorageSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                cifsstoragesystem = cifsstoragesystemString;
                cmd = cmd.Replace("$CifsStorageSystem", cifsstoragesystemString);
            }
            if (cmd.IndexOf("$Pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = poolString;
                cmd = cmd.Replace("$Pool", poolString);
            }
            if (cmd.IndexOf("$NetworkShare", StringComparison.OrdinalIgnoreCase) > 0)
            {
                networkshare = networkshareString;
                cmd = cmd.Replace("$NetworkShare", networkshareString);
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            
            GetEmcSharedFolder instance = new GetEmcSharedFolder(id, cifsstoragesystem, silent, pool, networkshare,  cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcSharedFolder:
        ///    The method to implement Get-EmcSharedFolder poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSharedFolderTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcSharedFolder cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcSharedFolderNegativeTestMethod:
        ///    The method to implement Get-EmcSharedFolder negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSharedFolderNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcSharedFolder getemcsharedfolderClass = ParseCmd(cmd);

            try
            {
                getemcsharedfolderClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcsharedfolderClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }

        private static string GetIDString(string result)
        {
            SortedList<string, string> keyValuePairs = HelperAdapter.GenerateKeyValuePairs(result);
            List<string> idList = new List<string>();
            idList.Add(keyValuePairs["ArrayPoolId"]);
            idList.Add(keyValuePairs["ArraySharedFolderId"]);
            idList.Add(keyValuePairs["Name"]);
            Random rd=new Random();
            string randomString = idList[rd.Next(idList.Count)];
            return string.Format("\"{0}\"", randomString);
        }
    }
}

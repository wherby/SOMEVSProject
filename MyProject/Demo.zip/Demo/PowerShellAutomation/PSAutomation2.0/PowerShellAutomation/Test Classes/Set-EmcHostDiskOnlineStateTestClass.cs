using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{   
    /// <summary>
    /// SetEmcHostDiskOnlineStateTest: test class for SetEmcHostDiskOnlineState cmdlet
    /// </summary>
    [TestClass]
    public partial class SetEmcHostDiskOnlineStateTest
    {
        public SetEmcHostDiskOnlineStateTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string origStatus;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);

            TestSetup.DisconnectSystem(psMachine);   
            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);

            // Connect to EMC Host system
            log.LogInfo("Class Initialize: Connect Host System");
            TestSetup.ConnectSystem(psMachine, "Host", HelperAdapter.GetParameter("Host"));                        

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
                       
            // Unmask Disk and Find Host Disk
            string result = TestSetup.SetDiskEnvironment(psMachine);
            origStatus = HelperAdapter.GenerateKeyValuePairs(result)["Status"];
            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            // Mask Disk
            log.LogInfo("Class Cleanup: Mask the Lun");
            TestSetup.ClearDiskEnvironment(psMachine);
            
            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect System
            log.LogInfo("Class Cleanup: Disconnect System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a SetEmcHostDiskOnlineState instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>SetEmcHostDiskOnlineState instance</returns>  
        public SetEmcHostDiskOnlineState ParseCmd(string cmd)
        {
            #region AutoGenerate
            string hostdisk = null;
            string online = null;
            string silent = null;
            string offline = null;


            string cmdString = cmd;
   
            #endregion


            if (cmd.IndexOf("HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostdisk = HelperAdapter.GetParameter("Disk");
                cmdString = cmdString.Replace("$HostDisk", hostdisk);                
            }
            if (cmd.IndexOf("-Online", StringComparison.OrdinalIgnoreCase) > 0)
            {
                online = "Online";                
            }
            if (cmd.IndexOf("Offline", StringComparison.OrdinalIgnoreCase) > 0)
            {
                offline = "Offline";
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            SetEmcHostDiskOnlineState hostDiskOnlineState = new SetEmcHostDiskOnlineState(hostdisk, online, silent, offline, cmdString);

            return hostDiskOnlineState;
        }

        /// <summary>  
        /// SetEmcHostDiskOnlineStateTestMethod:
        ///    The method to implement Set-EmcHostDiskOnlineState poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcHostDiskOnlineStateTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            SetEmcHostDiskOnlineState hostDiskOnlineState = ParseCmd(cmd);

            hostDiskOnlineState.VerifyTheCMD(psMachine);

            // Recover the online status
            if (origStatus.ToLower() == "online")
            {
                hostDiskOnlineState = new SetEmcHostDiskOnlineState(HelperAdapter.GetParameter("Disk"), origStatus);
            }
            else
            {
                hostDiskOnlineState = new SetEmcHostDiskOnlineState(HelperAdapter.GetParameter("Disk"), null, null, origStatus);
            }


            hostDiskOnlineState.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// SetEmcHostDiskOnlineStateNegativeTestMethod:
        ///    The method to implement Set-EmcHostDiskOnlineState negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcHostDiskOnlineStateNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            SetEmcHostDiskOnlineState hostDiskOnlineState = ParseCmd(cmd);

            try
            {
                hostDiskOnlineState.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", hostDiskOnlineState.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// NewEmcCandidateSnapshotLunTest: test class for New-EmcCandidateSnapshotLun cmdlet
    /// </summary>
    [TestClass]
    public partial class NewEmcCandidateSnapshotLunTest
    {
        public NewEmcCandidateSnapshotLunTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string sourceLunID = "";
        private static string sourceLunCapacity = "";
        private static string storageGlobalID = "";
        private List<string> snapshotLunIDs = new List<string>();
        private static bool removeFlag = false;

        private static string snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
        private static string snapshotPoolPrefix = HelperAdapter.GetParameter("SnapshotPool");
        private static string retentionPrefix = HelperAdapter.GetParameter("Timespan");
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            if (removeFlag)
            {
                log.LogInfo("--------Test Clean Up Start---------");
                log.LogInfo("Test Cleanup: Remove Snapshot Lun");
                foreach (string snapshotLunID in snapshotLunIDs)
                {
                    GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
                    getSnapshotLun.PrefixString = snapshotLunPrefix;
                    getSnapshotLun.RunCMD(psMachine, true);
                    RemoveEmcSnapshotLun removeSnapshotLun = new RemoveEmcSnapshotLun(snapshotLunPrefix);
                    removeSnapshotLun.RunCMD(psMachine);
                }

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("System"));
                updateSystem.RunCMD(psMachine);
                foreach (string snapshotLunID in snapshotLunIDs)
                {
                    GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
                    string getSnapshotLunResult = getSnapshotLun.RunCMD(psMachine);
                    if (!String.IsNullOrEmpty(getSnapshotLunResult.Trim()))
                    {
                        log.LogError(String.Format("The snapshot lun is not deleted: {0}", getSnapshotLunResult));
                        PSException pe = new PSException(String.Format("The snapshot lun is not deleted: {0}", getSnapshotLunResult));
                        throw pe;
                    }
                }

                log.LogInfo("--------Test Clean Up End---------");
            }
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            string storageResult = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalID = HelperAdapter.GenerateKeyValuePairs(storageResult)["GlobalId"];

            // Get Snapshot Pool
            string poolId = TestSetup.GetSnapshotPoolId(TestSetup.StorageSystemType);
            TestSetup.SetSnapshotPool(psMachine, snapshotPoolPrefix, poolId);

            // Create Source Lun
            log.LogInfo("Class Initialize: Create Source Lun");
            TestSetup.SetPoolEnvironment(psMachine);
            string result = TestSetup.SetLunEnvironment(psMachine);
            SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            sourceLunID = lunKeyValue["ArrayLunId"];
            sourceLunCapacity = lunKeyValue["Capacity"];
            
            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            // Remove Source Lun 
            log.LogInfo("Class Cleanup: Remove Source Lun");
            TestSetup.ClearLunEnvironment(psMachine);

            // Disconnect Storage System
            log.LogInfo("Class Cleanup: Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");            
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a New-EmcCandidateSnapshotLun instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>New-EmcCandidateSnapshotLun instance</returns>  
        public NewEmcCandidateSnapshotLun ParseCmd(string cmd)
        {
            #region AutoGenerate
            string sourcelun = null;
            string count = null;
            string snapshotpool = null;
            string namehint = null;
            string silent = null;

            string cmdString = cmd;   
            #endregion

            NewEmcCandidateSnapshotLun instance = null;

            string path = HelperAdapter.GetProperty("SnapshotLunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            
            if (cmd.IndexOf("sourcelun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourcelun = HelperAdapter.GetParameter("Lun");
                cmdString = cmdString.Replace("$SourceLun", sourcelun);
            }

            if (cmd.IndexOf("count", StringComparison.OrdinalIgnoreCase) > 0)
            {
                count = dic["Count"];
                cmdString = cmdString.Replace("$Count", count);
            }

            if (cmd.IndexOf("snapshotpool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                snapshotpool = HelperAdapter.GetParameter("SnapshotPool");
                cmdString = cmdString.Replace("$SnapshotPool", snapshotpool);
            }

            if (cmd.IndexOf("namehint", StringComparison.OrdinalIgnoreCase) > 0)
            {
                namehint = "ps_snapshotluns_" + HelperAdapter.GenerateRandomString();
                cmdString = cmdString.Replace("$NameHint", namehint);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (TestSetup.StorageSystemType == "VNXe" && !cmd.Contains("SnapshotPool"))
            {
                instance = null;
            }
            else
            {
                instance = new NewEmcCandidateSnapshotLun(sourcelun, count, snapshotpool, namehint, silent,  cmdString);
            }

            return instance;
        }


        /// <summary>  
        /// New-EmcCandidateSnapshotLun:
        ///    The method to implement New-EmcCandidateSnapshotLun poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcCandidateSnapshotLunTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            NewEmcCandidateSnapshotLun cmdClass = ParseCmd(cmd);

            if (cmdClass != null)
            {
                string result = cmdClass.VerifyTheCMD(psMachine, sourceLunID, storageGlobalID, sourceLunCapacity);
                List<SortedList<string, string>> candidateSnapshotLuns = HelperAdapter.GenerateKeyValuePairsList(result);
                foreach (SortedList<string, string> candidate in candidateSnapshotLuns)
                {
                    if (TestSetup.StorageSystemType == "VNXe")
                    {
                        snapshotLunIDs.Add(candidate["Name"]);
                    }
                    else
                    {
                        snapshotLunIDs.Add(candidate["Wwn"]);
                    }
                }
                removeFlag = true;
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }
        }

        /// <summary>  
        /// NewEmcCandidateSnapshotLunNegativeTestMethod:
        ///    The method to implement New-EmcCandidateSnapshotLun negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void NewEmcCandidateSnapshotLunNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            NewEmcCandidateSnapshotLun newemccandidatesnapshotlunClass = ParseCmd(cmd);

            if (newemccandidatesnapshotlunClass != null)
            {
                try
                {
                    newemccandidatesnapshotlunClass.VerifyTheCMD(psMachine, sourceLunID, storageGlobalID, sourceLunCapacity);
                }
                catch (PSException psEx)
                {
                    log.LogTestCase(string.Format("Test with {0} failed.", newemccandidatesnapshotlunClass.GetFullString()));
                    log.LogTestCase(psEx.messageDetail);
                    caseFail = true;
                }
                log.AreEqual<bool>(true, caseFail, "Negative test case result:");
            }
            else
            {
                log.LogWarning(String.Format("Skip the command for {0}: {1}", TestSetup.StorageSystemType, cmd));
            }

        }
    }
}

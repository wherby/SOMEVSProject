using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcCIFSSharedFolderTest: test class for Remove-EmcCIFSSharedFolder cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcCifsSharedFolderTest
    {
        public RemoveEmcCifsSharedFolderTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        
        private static bool isFolderNeedRemove;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            TestSetup.SetCIFSSharedFolderEnvironment(psMachine);
            isFolderNeedRemove=true;
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            if(isFolderNeedRemove==true)
            {
                TestSetup.RemoveSharedFolderEnvironment(psMachine);
            }
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
        
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");


            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            string systemName = TestSetup.SetStorageEnvironment(psMachine, "File");
            TestSetup.ConnectSystem(psMachine, systemName);
            if (TestSetup.IsStorageVNXE())
            {
                TestSetup.SetVNXESharedFolderPoolEnvironment(psMachine);
            }
            else
            {
                TestSetup.SetVNXFileStoragePoolEnvironment(psMachine);
                TestSetup.SetVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Initialize End--------");
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Cleanup Start--------");
            if (TestSetup.IsStorageVNXE() == false)
            {
                TestSetup.RemoveVNXSharedFolderPoolEnvironment(psMachine);
            }
            log.LogInfo("--------Class Cleanup End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcCIFSSharedFolder instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcCIFSSharedFolder instance</returns>  
        public RemoveEmcCIFSSharedFolder ParseCmd(string cmd)
        {
            #region AutoGenerate
            string sharedfolder = null;
            string force = null;
            string silent = null;
            string whatif = null;


            string cmdString = cmd;
   
            #endregion

            string sharedfolderString = HelperAdapter.GetParameter("SharedFolder");

            if (cmd.IndexOf("$SharedFolder", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sharedfolder = sharedfolderString;
                cmd = cmd.Replace("$SharedFolder", sharedfolderString);
            }
            if (cmd.IndexOf("Force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }
            
            RemoveEmcCIFSSharedFolder instance = new RemoveEmcCIFSSharedFolder(sharedfolder, force, silent, whatif,  cmd);
            return instance;
        }


        /// <summary>  
        /// Remove-EmcCIFSSharedFolder:
        ///    The method to implement Remove-EmcCIFSSharedFolder poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcCifsSharedFolderTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            RemoveEmcCIFSSharedFolder cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
            if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) <0)
            {
                isFolderNeedRemove = false;
            }
        }

        /// <summary>  
        /// RemoveEmcCIFSSharedFolderNegativeTestMethod:
        ///    The method to implement Remove-EmcCIFSSharedFolder negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcCifsSharedFolderNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            RemoveEmcCIFSSharedFolder removeemccifssharedfolderClass = ParseCmd(cmd);

            try
            {
                removeemccifssharedfolderClass.VerifyTheCMD(psMachine);
                if (cmd.IndexOf("WhatIf", StringComparison.OrdinalIgnoreCase) < 0)
                {
                    isFolderNeedRemove = false;
                }
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removeemccifssharedfolderClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

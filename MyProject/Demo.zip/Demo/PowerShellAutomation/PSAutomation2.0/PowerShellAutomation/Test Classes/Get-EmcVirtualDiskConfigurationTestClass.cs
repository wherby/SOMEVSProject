using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{   
    /// <summary>
    /// GetEmcVirtualDiskConfigurationTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcVirtualDiskConfigurationTest
    {
        public GetEmcVirtualDiskConfigurationTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string[] path;
        private static SortedList<string, string>[] fileDiskConfig;
        private static SortedList<string, string>[] ptDiskConfig;
        private static string[] hypervisors;
        private static string[] hyperHosts;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            
            string scsiController = null;
            string location = null;
            string result = null;

            hypervisors = new string[3] { "HyperV", "VMWare", "XenServer"};
            hyperHosts = new string[3] { "HyperV", "ESXHost", "XenServer" };
            fileDiskConfig = new SortedList<string, string>[hypervisors.Length];
            ptDiskConfig = new SortedList<string, string>[hypervisors.Length];
            path = new string[hypervisors.Length];

            //Connect to Storage System
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage, HelperAdapter.GetParameter("Storage"));
            TestSetup.SetPoolEnvironment(psMachine);

            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1 || !HelperAdapter.IsXenSet() && i == 2)
                {
                    continue;
                }
                string vmPrefix = HelperAdapter.GetParameter("VirtualMachine") + i;
                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                string lun = HelperAdapter.GetParameter("Lun") + i;
                string fileHostDisk = HelperAdapter.GetParameter("FilebasedDisk") + i;
                string ptHostDisk = HelperAdapter.GetParameter("PassthroughDisk") + i;

                string fileDiskConfigPrefix = HelperAdapter.GetParameter("FilebasedDiskConfiguration") + i;
                string ptDiskConfigPrefix = HelperAdapter.GetParameter("PassthroughDiskConfiguration") + i;

                // Connect to Hypervisor          
                string prefix = HelperAdapter.GetParameter(hypervisors[i]);
                string hostPrefix = HelperAdapter.GetParameter(hyperHosts[i]);
                string isVcenter = HelperAdapter.GetHypervisorProperties(HyperVisorType.VMWare)["IsVirtualCenter"];
                if (i == 1 && isVcenter == "true")
                {
                    Dictionary<string, string> dict = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                    TestSetup.ConnectSystem(psMachine, hypervisors[i], prefix, dict);
                }
                else
                {
                    TestSetup.ConnectSystem(psMachine, hypervisors[i], prefix);
                }                

                // Connect Hyperv's VM
                HyperVisorType type = HyperVisorType.HyperV;
                if (i == 1)
                {
                    type = HyperVisorType.VMWare;
                }
                else if (i == 2)
                {
                    type = HyperVisorType.XenServer;
                }

                Dictionary<string, string> dic = HelperAdapter.GetHostVMs(type)[0];
                TestSetup.ConnectSystem(psMachine, "HyperVM", vmPrefix, dic);
                
                UpdateEmcSystem updateSystem = new UpdateEmcSystem(prefix);
                updateSystem.RunCMD(psMachine);

                GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, vmPrefix);
                vmConfig.PrefixString = vmConfigPrefix;
                vmConfig.RunCMD(psMachine, true);

                TestSetup.SetLunEnvironment(psMachine, true, null, lun);
                FindEmcHostDisk newDisk = null;
                if (i != 2)
                {
                    path[i] = TestSetup.SetFileBasedDiskEnvironment(psMachine, prefix, type);
                    scsiController = TestSetup.GetRandomScsiController(psMachine, null, vmConfigPrefix)["ScsiControllerIndex"];
                    location = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController, null, vmConfigPrefix);

                    AddEmcFilebasedDiskToVirtualMachine addFileDisk = new AddEmcFilebasedDiskToVirtualMachine(path[i], vmConfig.PrefixString, location, null, null, null, scsiController);
                    addFileDisk.PrefixString = fileDiskConfigPrefix;
                    result = addFileDisk.RunCMD(psMachine, true);
                    fileDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);

                    newDisk = new FindEmcHostDisk(null, null, null, null, null, null, vmPrefix, fileDiskConfigPrefix);
                    newDisk.PrefixString = fileHostDisk;
                    newDisk.RunCMD(psMachine, true);

                    if (i == 1)
                    {
                        Dictionary<string, string> dict = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                        GetEmcESXHost esxHost = new GetEmcESXHost(dict["IPAddress"], prefix);
                        esxHost.PrefixString = hostPrefix;
                        esxHost.RunCMD(psMachine, true);
                    }
                    TestSetup.SetDiskEnvironment(psMachine, null, hostPrefix, lun, null, false);

                    scsiController = TestSetup.GetRandomScsiController(psMachine, null, vmConfigPrefix)["ScsiControllerIndex"];
                    location = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController, null, vmConfigPrefix);

                    AddEmcPassthroughDiskToVirtualMachine addPtDisk = null;
                    if (i == 0)
                    {
                        addPtDisk = new AddEmcPassthroughDiskToVirtualMachine(null,  vmConfig.PrefixString, location, null, scsiController, null, null, HelperAdapter.GetParameter("Disk"));
                    }
                    else
                    {
                        addPtDisk = new AddEmcPassthroughDiskToVirtualMachine(null, vmConfig.PrefixString, location, null, scsiController, null, null, null, HelperAdapter.GetParameter("Disk"));
                    }
                    addPtDisk.PrefixString = ptDiskConfigPrefix;
                    result = addPtDisk.RunCMD(psMachine, true);
                    ptDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);

                    newDisk = new FindEmcHostDisk(null, null, null, null, null, null, vmPrefix, ptDiskConfigPrefix);
                    newDisk.PrefixString = ptHostDisk;
                    newDisk.RunCMD(psMachine, true);
                }
                else
                {
                    TestSetup.SetSREnvironment(psMachine, lun);
                    TestSetup.SetXenServerVirtualDiskEnvironment(psMachine);

                    AddEmcXenServerVirtualDisk addVirtualDisk = new AddEmcXenServerVirtualDisk(HelperAdapter.GetParameter("XenServerVirtualDisk"), vmConfigPrefix);
                    addVirtualDisk.PrefixString = fileDiskConfigPrefix;
                    result = addVirtualDisk.RunCMD(psMachine);
                    fileDiskConfig[i] = HelperAdapter.GenerateKeyValuePairs(result);

                    newDisk = new FindEmcHostDisk(null, null, null, null, null, null, vmPrefix, fileDiskConfigPrefix);
                    newDisk.PrefixString = fileHostDisk;
                    newDisk.RunCMD(psMachine, true);
                }
                updateSystem.RunCMD(psMachine);
                updateSystem = new UpdateEmcSystem(vmPrefix);
                updateSystem.RunCMD(psMachine);
            }

            log.LogInfo("--------Class Initialize End--------");

        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            for (int i = 0; i < hypervisors.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1 || !HelperAdapter.IsXenSet() && i == 2)
                {
                    continue;
                }
                string prefix = HelperAdapter.GetParameter(hypervisors[i]);
                string hostPrefix = HelperAdapter.GetParameter(hyperHosts[i]);
                string vmPrefix = HelperAdapter.GetParameter("VirtualMachine") + i;
                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                string lun = HelperAdapter.GetParameter("Lun") + i;
                GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, vmPrefix);
                vmConfig.PrefixString = vmConfigPrefix;
                vmConfig.RunCMD(psMachine, true);

                if (i != 2)
                {
                    RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, fileDiskConfig[i]["Location"], "Force", null, fileDiskConfig[i]["ScsiControllerIndex"]);
                    removeDisk.RunCMD(psMachine);
                    TestSetup.ClearFileBasedDiskEnvironment(psMachine, path[i], prefix);

                    removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfigPrefix, ptDiskConfig[i]["Location"], "Force", null, ptDiskConfig[i]["ScsiControllerIndex"]);
                    removeDisk.RunCMD(psMachine);
                    if (i == 1)
                    {
                        Dictionary<string, string> dict = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                        GetEmcESXHost esxHost = new GetEmcESXHost(dict["IPAddress"], prefix);
                        esxHost.PrefixString = hostPrefix;
                        esxHost.RunCMD(psMachine, true);
                    }
                    TestSetup.ClearDiskEnvironment(psMachine, hostPrefix, null, lun);
                }
                else
                {
                    RemoveEmcXenServerVirtualDisk removeDisk = new RemoveEmcXenServerVirtualDisk(vmConfigPrefix, fileDiskConfig[i]["Location"]);
                    removeDisk.RunCMD(psMachine);
                    TestSetup.ClearXenServerVirtualDiskEnvironment(psMachine);
                    TestSetup.ClearSREnvironment(psMachine, null, lun);
                }
                TestSetup.ClearLunEnvironment(psMachine, lun);
            }
            
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a GetEmcVirtualDiskConfiguration instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>GetEmcVirtualDiskConfiguration instance</returns>  
        public GetEmcVirtualDiskConfiguration ParseCmd(string cmd)
        {
            SortedList<string, string> diskConfig = null;
#if true
        #region AutoGenerate
            string hostdisk = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion
#endif
            
            for (int i = 0; i < hypervisors.Length; i++)
            {
                string fileHostDisk = HelperAdapter.GetParameter("FilebasedDisk") + i;
                string ptHostDisk = HelperAdapter.GetParameter("PassthroughDisk") + i;

                if (cmd.IndexOf("$" + hypervisors[i], StringComparison.OrdinalIgnoreCase) > 0)
                {
                    if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1 || !HelperAdapter.IsXenSet() && i == 2)
                    {
                        log.BypassTest();
                    }
                }
                if (cmd.IndexOf("$" + hypervisors[i] + "FilebasedDisk", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    hostdisk = fileHostDisk;
                    diskConfig = fileDiskConfig[i];
                    cmdString = cmdString.Replace("$" + hypervisors[i] + "FilebasedDisk", hostdisk);
                }

                if (cmd.IndexOf("$" + hypervisors[i] + "PassthroughDisk", StringComparison.OrdinalIgnoreCase) > 0 )
                {
                    if (i == 2)
                    {
                        log.BypassTest();
                    }
                    hostdisk = ptHostDisk;
                    diskConfig = ptDiskConfig[i];
                    cmdString = cmdString.Replace("$" + hypervisors[i] + "PassthroughDisk", hostdisk);
                }
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            GetEmcVirtualDiskConfiguration vmConfiguration = new GetEmcVirtualDiskConfiguration(hostdisk, silent, cmdString);
            vmConfiguration.DiskConfig = diskConfig;

            return vmConfiguration;
        }

        /// <summary>
        /// getNewAdded
        ///     Get new added sortedlist     
        /// </summary>
        /// <param name="oldList">The old List</param>
        /// <param name="newList">The new List</param>
        /// <param name="diskPrefix">prefix string of new added disk</param>
        /// <returns>result SortedList</returns>
        private static SortedList<string, string> getNewAddedDisk(List<SortedList<string, string>> oldList, List<SortedList<string, string>> newList, string diskPrefix)
        {
            SortedList<string, string> newAdded = null;
            List<string> ps = new List<string>();
            bool itemFind = false;

            foreach (SortedList<string, string> newItem in newList)
            {
                foreach (SortedList<string, string> oldItem in oldList)
                {
                    if (HelperAdapter.SortedListIsEqual(oldItem, newItem))
                    {
                        itemFind = false;
                        break;
                    }
                    else
                    {
                        itemFind = true;
                    }
                }

                if (itemFind == true)
                {
                    newAdded = newItem;
                    break;
                }
            }

            if (newAdded != null)
            {
                GetEmcHostDisk getDisk = new GetEmcHostDisk(newAdded["HostDiskIdentifier"], null, HelperAdapter.GetParameter("VirtualMachine"));
                getDisk.PrefixString = diskPrefix;
                getDisk.RunCMD(psMachine, true);
            }
            
            return newAdded; 
        }

        /// <summary>  
        /// GetEmcVirtualDiskConfigurationTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualDiskConfigurationTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcVirtualDiskConfiguration vmConfiguration = ParseCmd(cmd);

            if (vmConfiguration == null)
            {
                return;
            }
            
            vmConfiguration.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcVirtualDiskConfigurationNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcVirtualDiskConfigurationNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcVirtualDiskConfiguration vmConfiguration = ParseCmd(cmd);

            if (vmConfiguration == null)
            {
                return;
            }

            try
            {
                vmConfiguration.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", vmConfiguration.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

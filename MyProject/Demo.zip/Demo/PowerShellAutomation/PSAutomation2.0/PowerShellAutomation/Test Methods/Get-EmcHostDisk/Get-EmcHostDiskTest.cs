using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcHostDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest1()
        {
            string cmd = "Get-EmcHostDisk";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest2()
        {
            string cmd = "Get-EmcHostDisk -ID $ID";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest3()
        {
            string cmd = "Get-EmcHostDisk $ID";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest4()
        {
            string cmd = "Get-EmcHostDisk -Lun $Lun";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest5()
        {
            string cmd = "Get-EmcHostDisk -HostSystem $HostSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest6()
        {
            string cmd = "Get-EmcHostDisk -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest7()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Lun $Lun";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest8()
        {
            string cmd = "Get-EmcHostDisk $ID -Lun $Lun";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest9()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -HostSystem $HostSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest10()
        {
            string cmd = "Get-EmcHostDisk $ID -HostSystem $HostSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest11()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest12()
        {
            string cmd = "Get-EmcHostDisk $ID -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest13()
        {
            string cmd = "Get-EmcHostDisk -Lun $Lun -HostSystem $HostSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest14()
        {
            string cmd = "Get-EmcHostDisk -Lun $Lun -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest15()
        {
            string cmd = "Get-EmcHostDisk -HostSystem $HostSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest16()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Lun $Lun -HostSystem $HostSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest17()
        {
            string cmd = "Get-EmcHostDisk $ID -Lun $Lun -HostSystem $HostSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest18()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Lun $Lun -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest19()
        {
            string cmd = "Get-EmcHostDisk $ID -Lun $Lun -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest20()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -HostSystem $HostSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest21()
        {
            string cmd = "Get-EmcHostDisk $ID -HostSystem $HostSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest22()
        {
            string cmd = "Get-EmcHostDisk -Lun $Lun -HostSystem $HostSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest23()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Lun $Lun -HostSystem $HostSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest24()
        {
            string cmd = "Get-EmcHostDisk $ID -Lun $Lun -HostSystem $HostSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest25()
        {
            string cmd = "Get-EmcHostDisk -ClusterSystem $ClusterSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest26()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -ClusterSystem $ClusterSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest27()
        {
            string cmd = "Get-EmcHostDisk $ID -ClusterSystem $ClusterSystem";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest28()
        {
            string cmd = "Get-EmcHostDisk -ClusterSystem $ClusterSystem -Lun $Lun";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest29()
        {
            string cmd = "Get-EmcHostDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest30()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -ClusterSystem $ClusterSystem -Lun $Lun";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest31()
        {
            string cmd = "Get-EmcHostDisk $ID -ClusterSystem $ClusterSystem -Lun $Lun";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest32()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest33()
        {
            string cmd = "Get-EmcHostDisk $ID -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest34()
        {
            string cmd = "Get-EmcHostDisk -ClusterSystem $ClusterSystem -Lun $Lun -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest35()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -ClusterSystem $ClusterSystem -Lun $Lun -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest36()
        {
            string cmd = "Get-EmcHostDisk $ID -ClusterSystem $ClusterSystem -Lun $Lun -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest37()
        {
            string cmd = "Get-EmcHostDisk -Volume $Volume";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest38()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Volume $Volume";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest39()
        {
            string cmd = "Get-EmcHostDisk $ID -Volume $Volume";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest40()
        {
            string cmd = "Get-EmcHostDisk -Volume $Volume -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest41()
        {
            string cmd = "Get-EmcHostDisk -ID $ID -Volume $Volume -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostDiskTest42()
        {
            string cmd = "Get-EmcHostDisk $ID -Volume $Volume -Silent";
            GetEmcHostDiskTestMethod(cmd);
        }
        
    }
}

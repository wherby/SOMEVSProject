using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcVolumeMountPointTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcVolumeMountPointTest1()
        {
            string cmd = "Remove-EmcVolumeMountPoint -Volume $Volume -HostSystem $HostSystem";
            RemoveEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVolumeMountPointTest2()
        {
            string cmd = "Remove-EmcVolumeMountPoint -Volume $Volume -HostSystem $HostSystem -Silent";
            RemoveEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVolumeMountPointTest3()
        {
            string cmd = "Remove-EmcVolumeMountPoint -Volume $Volume -ClusterSystem $ClusterSystem";
            RemoveEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVolumeMountPointTest4()
        {
            string cmd = "Remove-EmcVolumeMountPoint -Volume $Volume -ClusterSystem $ClusterSystem -Silent";
            RemoveEmcVolumeMountPointTestMethod(cmd);
        }
        
    }
}

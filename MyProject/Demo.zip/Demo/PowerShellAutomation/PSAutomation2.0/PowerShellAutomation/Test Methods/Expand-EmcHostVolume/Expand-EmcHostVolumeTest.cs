using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ExpandEmcHostVolumeTest
    {
        
        
      
        [TestMethod]
        public void PS_ExpandEmcHostVolumeTest1()
        {
            string cmd = "Expand-EmcHostVolume -HostSystem $HostSystem -Volume $Volume";
            ExpandEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcHostVolumeTest2()
        {
            string cmd = "Expand-EmcHostVolume -HostSystem $HostSystem -Volume $Volume -CapacityToAdd $CapacityToAdd";
            ExpandEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcHostVolumeTest3()
        {
            string cmd = "Expand-EmcHostVolume -HostSystem $HostSystem -Volume $Volume -Silent";
            ExpandEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcHostVolumeTest4()
        {
            string cmd = "Expand-EmcHostVolume -HostSystem $HostSystem -Volume $Volume -CapacityToAdd $CapacityToAdd -Silent";
            ExpandEmcHostVolumeTestMethod(cmd);
        }
        
    }
}

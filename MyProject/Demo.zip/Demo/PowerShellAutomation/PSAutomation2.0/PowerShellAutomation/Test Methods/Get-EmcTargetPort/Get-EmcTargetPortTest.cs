using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcTargetPortTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest1()
        {
            string cmd = "Get-EmcTargetPort";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest2()
        {
            string cmd = "Get-EmcTargetPort -ID $ID";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest3()
        {
            string cmd = "Get-EmcTargetPort $ID";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest4()
        {
            string cmd = "Get-EmcTargetPort -BlockStorageSystem $BlockStorageSystem";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest5()
        {
            string cmd = "Get-EmcTargetPort -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest6()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest7()
        {
            string cmd = "Get-EmcTargetPort $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest8()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest9()
        {
            string cmd = "Get-EmcTargetPort $ID -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest10()
        {
            string cmd = "Get-EmcTargetPort -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest11()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest12()
        {
            string cmd = "Get-EmcTargetPort $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest13()
        {
            string cmd = "Get-EmcTargetPort -Pool $Pool";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest14()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -Pool $Pool";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest15()
        {
            string cmd = "Get-EmcTargetPort $ID -Pool $Pool";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest16()
        {
            string cmd = "Get-EmcTargetPort -Pool $Pool -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest17()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -Pool $Pool -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest18()
        {
            string cmd = "Get-EmcTargetPort $ID -Pool $Pool -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest19()
        {
            string cmd = "Get-EmcTargetPort -Lun $Lun";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest20()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -Lun $Lun";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest21()
        {
            string cmd = "Get-EmcTargetPort $ID -Lun $Lun";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest22()
        {
            string cmd = "Get-EmcTargetPort -Lun $Lun -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest23()
        {
            string cmd = "Get-EmcTargetPort -ID $ID -Lun $Lun -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcTargetPortTest24()
        {
            string cmd = "Get-EmcTargetPort $ID -Lun $Lun -Silent";
            GetEmcTargetPortTestMethod(cmd);
        }
        
    }
}

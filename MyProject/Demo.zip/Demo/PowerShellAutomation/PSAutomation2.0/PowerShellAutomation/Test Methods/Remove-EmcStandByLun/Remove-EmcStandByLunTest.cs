using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcStandByLunTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcStandByLunTest1()
        {
            string cmd = "Remove-EmcStandByLun -StandByLuns $StandByLuns -Confirm:$false";
            RemoveEmcStandByLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcStandByLunTest2()
        {
            string cmd = "Remove-EmcStandByLun -StandByLuns $StandByLuns -Confirm:$false -Silent";
            RemoveEmcStandByLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcStandByLunTest3()
        {
            string cmd = "Remove-EmcStandByLun -StandByLuns $StandByLuns -Confirm:$false -WhatIf";
            RemoveEmcStandByLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcStandByLunTest4()
        {
            string cmd = "Remove-EmcStandByLun -StandByLuns $StandByLuns -Confirm:$false -Silent -WhatIf";
            RemoveEmcStandByLunTestMethod(cmd);
        }
        
    }
}

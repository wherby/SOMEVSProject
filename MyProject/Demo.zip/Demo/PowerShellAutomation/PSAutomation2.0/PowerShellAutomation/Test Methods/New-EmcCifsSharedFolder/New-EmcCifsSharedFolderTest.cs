using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcCifsSharedFolderTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcCifsSharedFolderTest1()
        {
            string cmd = "New-EmcCifsSharedFolder -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity";
            NewEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCifsSharedFolderTest2()
        {
            string cmd = "New-EmcCifsSharedFolder -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity -ServiceNode $ServiceNode";
            NewEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCifsSharedFolderTest3()
        {
            string cmd = "New-EmcCifsSharedFolder -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity -Silent";
            NewEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCifsSharedFolderTest4()
        {
            string cmd = "New-EmcCifsSharedFolder -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity -ServiceNode $ServiceNode -Silent";
            NewEmcCifsSharedFolderTestMethod(cmd);
        }
        
    }
}

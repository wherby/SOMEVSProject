using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcVNXFileStoragePoolTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest1()
        {
            string cmd = "Get-EmcVNXFileStoragePool";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest2()
        {
            string cmd = "Get-EmcVNXFileStoragePool -ID $ID";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest3()
        {
            string cmd = "Get-EmcVNXFileStoragePool $ID";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest4()
        {
            string cmd = "Get-EmcVNXFileStoragePool -StorageSystem $StorageSystem";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest5()
        {
            string cmd = "Get-EmcVNXFileStoragePool -Silent";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest6()
        {
            string cmd = "Get-EmcVNXFileStoragePool -ID $ID -StorageSystem $StorageSystem";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest7()
        {
            string cmd = "Get-EmcVNXFileStoragePool $ID -StorageSystem $StorageSystem";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest8()
        {
            string cmd = "Get-EmcVNXFileStoragePool -ID $ID -Silent";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest9()
        {
            string cmd = "Get-EmcVNXFileStoragePool $ID -Silent";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest10()
        {
            string cmd = "Get-EmcVNXFileStoragePool -StorageSystem $StorageSystem -Silent";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest11()
        {
            string cmd = "Get-EmcVNXFileStoragePool -ID $ID -StorageSystem $StorageSystem -Silent";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVNXFileStoragePoolTest12()
        {
            string cmd = "Get-EmcVNXFileStoragePool $ID -StorageSystem $StorageSystem -Silent";
            GetEmcVNXFileStoragePoolTestMethod(cmd);
        }
        
    }
}

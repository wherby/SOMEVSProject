using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class AddEmcFilebasedDiskToVirtualMachineTest
    {
        
        
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest1()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest2()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest3()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest4()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest5()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest6()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest7()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest8()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest9()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest10()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest11()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest12()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest13()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest14()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest15()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest16()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest17()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest18()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest19()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest20()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest21()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest22()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest23()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest24()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest25()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest26()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest27()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest28()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest29()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest30()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest31()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest32()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest33()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest34()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest35()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest36()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest37()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest38()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest39()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest40()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest41()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest42()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest43()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest44()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest45()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest46()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest47()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest48()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest49()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest50()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest51()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest52()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest53()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest54()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest55()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest56()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest57()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest58()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest59()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest60()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest61()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest62()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest63()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcFilebasedDiskToVirtualMachineTest64()
        {
            string cmd = "Add-EmcFilebasedDiskToVirtualMachine -Path $Path -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcFilebasedDiskToVirtualMachineTestMethod(cmd);
        }
        
    }
}

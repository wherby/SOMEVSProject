using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcCifsNetworkShareTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcCifsNetworkShareTest1()
        {
            string cmd = "Get-EmcCifsNetworkShare -HostSystem $HostSystem";
            GetEmcCifsNetworkShareTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcCifsNetworkShareTest2()
        {
            string cmd = "Get-EmcCifsNetworkShare -ID $ID -HostSystem $HostSystem";
            GetEmcCifsNetworkShareTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcCifsNetworkShareTest3()
        {
            string cmd = "Get-EmcCifsNetworkShare $ID -HostSystem $HostSystem";
            GetEmcCifsNetworkShareTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcCifsNetworkShareTest4()
        {
            string cmd = "Get-EmcCifsNetworkShare -HostSystem $HostSystem -Silent";
            GetEmcCifsNetworkShareTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcCifsNetworkShareTest5()
        {
            string cmd = "Get-EmcCifsNetworkShare -ID $ID -HostSystem $HostSystem -Silent";
            GetEmcCifsNetworkShareTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcCifsNetworkShareTest6()
        {
            string cmd = "Get-EmcCifsNetworkShare $ID -HostSystem $HostSystem -Silent";
            GetEmcCifsNetworkShareTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RestoreEmcSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest1()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest2()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest3()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest4()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest5()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest6()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest7()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest8()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest9()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest10()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest11()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest12()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest13()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest14()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest15()
        {
            string cmd = "Restore-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RestoreEmcSnapshotLunTest16()
        {
            string cmd = "Restore-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            RestoreEmcSnapshotLunTestMethod(cmd);
        }
        
    }
}

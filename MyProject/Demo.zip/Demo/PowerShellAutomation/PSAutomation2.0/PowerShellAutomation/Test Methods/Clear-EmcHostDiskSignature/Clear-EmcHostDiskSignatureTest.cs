using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ClearEmcHostDiskSignatureTest
    {
        
        
      
        [TestMethod]
        public void PS_ClearEmcHostDiskSignatureTest1()
        {
            string cmd = "Clear-EmcHostDiskSignature -HostDisk $HostDisk";
            ClearEmcHostDiskSignatureTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ClearEmcHostDiskSignatureTest2()
        {
            string cmd = "Clear-EmcHostDiskSignature -HostDisk $HostDisk -Silent";
            ClearEmcHostDiskSignatureTestMethod(cmd);
        }
        
    }
}

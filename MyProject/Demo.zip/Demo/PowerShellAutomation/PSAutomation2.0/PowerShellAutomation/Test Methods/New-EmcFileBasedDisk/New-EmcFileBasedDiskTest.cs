using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcFileBasedDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcFileBasedDiskTest1()
        {
            string cmd = "New-EmcFileBasedDisk -Hypervisor $Hypervisor -Path $Path -Size $Size";
            NewEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcFileBasedDiskTest2()
        {
            string cmd = "New-EmcFileBasedDisk -Hypervisor $Hypervisor -Path $Path -Size $Size -VhdType $VhdType";
            NewEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcFileBasedDiskTest3()
        {
            string cmd = "New-EmcFileBasedDisk -Hypervisor $Hypervisor -Path $Path -Size $Size -Silent";
            NewEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcFileBasedDiskTest4()
        {
            string cmd = "New-EmcFileBasedDisk -Hypervisor $Hypervisor -Path $Path -Size $Size -VhdType $VhdType -Silent";
            NewEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcFileBasedDiskTest5()
        {
            string cmd = "New-EmcFileBasedDisk -Hypervisor $Hypervisor -Path $Path -Size $Size -VmdkType $VmdkType";
            NewEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcFileBasedDiskTest6()
        {
            string cmd = "New-EmcFileBasedDisk -Hypervisor $Hypervisor -Path $Path -Size $Size -VmdkType $VmdkType -Silent";
            NewEmcFileBasedDiskTestMethod(cmd);
        }
        
    }
}

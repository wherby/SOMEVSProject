using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcVirtualDiskConfigurationTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest1()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $HyperVFilebasedDisk";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest2()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $HyperVPassthroughDisk";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest3()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $VMWareFilebasedDisk";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest4()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $VMWarePassthroughDisk";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest5()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $XenServerFilebasedDisk";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest6()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $XenServerPassthroughDisk";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest7()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $HyperVFilebasedDisk -Silent";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest8()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $HyperVPassthroughDisk -Silent";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest9()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $VMWareFilebasedDisk -Silent";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest10()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $VMWarePassthroughDisk -Silent";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest11()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $XenServerFilebasedDisk -Silent";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualDiskConfigurationTest12()
        {
            string cmd = "Get-EmcVirtualDiskConfiguration -HostDisk $XenServerPassthroughDisk -Silent";
            GetEmcVirtualDiskConfigurationTestMethod(cmd);
        }
        
    }
}

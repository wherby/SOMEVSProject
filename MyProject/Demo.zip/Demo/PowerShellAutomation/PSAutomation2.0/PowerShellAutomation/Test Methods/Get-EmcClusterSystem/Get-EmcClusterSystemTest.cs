using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcClusterSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest1()
        {
            string cmd = "Get-EmcClusterSystem";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest2()
        {
            string cmd = "Get-EmcClusterSystem -ID $ClusterName";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest3()
        {
            string cmd = "Get-EmcClusterSystem $ClusterName";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest4()
        {
            string cmd = "Get-EmcClusterSystem -ID $IPAddress";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest5()
        {
            string cmd = "Get-EmcClusterSystem $IPAddress";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest6()
        {
            string cmd = "Get-EmcClusterSystem -ID $GlobalId";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest7()
        {
            string cmd = "Get-EmcClusterSystem $GlobalId";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest8()
        {
            string cmd = "Get-EmcClusterSystem -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest9()
        {
            string cmd = "Get-EmcClusterSystem -ID $ClusterName -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest10()
        {
            string cmd = "Get-EmcClusterSystem $ClusterName -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest11()
        {
            string cmd = "Get-EmcClusterSystem -ID $IPAddress -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest12()
        {
            string cmd = "Get-EmcClusterSystem $IPAddress -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest13()
        {
            string cmd = "Get-EmcClusterSystem -ID $GlobalId -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest14()
        {
            string cmd = "Get-EmcClusterSystem $GlobalId -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest15()
        {
            string cmd = "Get-EmcClusterSystem -ClusterDisk $ClusterDisk";
            GetEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterSystemTest16()
        {
            string cmd = "Get-EmcClusterSystem -ClusterDisk $ClusterDisk -Silent";
            GetEmcClusterSystemTestMethod(cmd);
        }
        
    }
}

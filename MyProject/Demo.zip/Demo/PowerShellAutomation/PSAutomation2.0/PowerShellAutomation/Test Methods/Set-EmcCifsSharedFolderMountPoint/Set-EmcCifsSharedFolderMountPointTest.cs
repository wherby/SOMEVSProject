using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class SetEmcCifsSharedFolderMountPointTest
    {
        
        
      
        [TestMethod]
        public void PS_SetEmcCifsSharedFolderMountPointTest1()
        {
            string cmd = "Set-EmcCifsSharedFolderMountPoint -HostSystem $HostSystem -DriveLetter $DriveLetter -SharedFolder $SharedFolder";
            SetEmcCifsSharedFolderMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcCifsSharedFolderMountPointTest2()
        {
            string cmd = "Set-EmcCifsSharedFolderMountPoint -HostSystem $HostSystem -DriveLetter $DriveLetter -SharedFolder $SharedFolder -Silent";
            SetEmcCifsSharedFolderMountPointTestMethod(cmd);
        }
        
    }
}

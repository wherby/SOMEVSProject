using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class InitializeEmcHostDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest1()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -HostSystem $HostSystem";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest2()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -HostSystem $HostSystem -PartitionStyle $PartitionStyle";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest3()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -HostSystem $HostSystem -Silent";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest4()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -HostSystem $HostSystem -PartitionStyle $PartitionStyle -Silent";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest5()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -ClusterSystem $ClusterSystem";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest6()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -ClusterSystem $ClusterSystem -PartitionStyle $PartitionStyle";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest7()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -ClusterSystem $ClusterSystem -Silent";
            InitializeEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_InitializeEmcHostDiskTest8()
        {
            string cmd = "Initialize-EmcHostDisk -HostDisk $HostDisk -ClusterSystem $ClusterSystem -PartitionStyle $PartitionStyle -Silent";
            InitializeEmcHostDiskTestMethod(cmd);
        }
        
    }
}

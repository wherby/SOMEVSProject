using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcVirtualDiskFromVmTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest1()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest2()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest3()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest4()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest5()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest6()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest7()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest8()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest9()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest10()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest11()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest12()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest13()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest14()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest15()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest16()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest17()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest18()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest19()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest20()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest21()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest22()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest23()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest24()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest25()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest26()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest27()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest28()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest29()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest30()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest31()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest32()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest33()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest34()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest35()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest36()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest37()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest38()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest39()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest40()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest41()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest42()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest43()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest44()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest45()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest46()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest47()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest48()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest49()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest50()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest51()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest52()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest53()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest54()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest55()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest56()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest57()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest58()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest59()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest60()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest61()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest62()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest63()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest64()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest65()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest66()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest67()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest68()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest69()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest70()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest71()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest72()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest73()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest74()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest75()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest76()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest77()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest78()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest79()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest80()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest81()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest82()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest83()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest84()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest85()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest86()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest87()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest88()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest89()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest90()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest91()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest92()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest93()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest94()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest95()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest96()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest97()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest98()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest99()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest100()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest101()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest102()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest103()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest104()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest105()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest106()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest107()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest108()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest109()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest110()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest111()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest112()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest113()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest114()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest115()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest116()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest117()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest118()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest119()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest120()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest121()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest122()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest123()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest124()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest125()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest126()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $FileDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest127()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $HypervVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVirtualDiskFromVmTest128()
        {
            string cmd = "Remove-EmcVirtualDiskFromVm -VirtualMachineConfiguration $VMWareVMConfig -Location $PtDiskLocation -Confirm:$false -Force -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent -WhatIf";
            RemoveEmcVirtualDiskFromVmTestMethod(cmd);
        }
        
    }
}

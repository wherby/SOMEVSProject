using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcXenServerVirtualDiskImageTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcXenServerVirtualDiskImageTest1()
        {
            string cmd = "New-EmcXenServerVirtualDiskImage -StorageRepository $StorageRepository -XenServer $XenServer -Size $Size -Name $Name";
            NewEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcXenServerVirtualDiskImageTest2()
        {
            string cmd = "New-EmcXenServerVirtualDiskImage -StorageRepository $StorageRepository -XenServer $XenServer -Size $Size -Name $Name -Silent";
            NewEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
        
    }
}

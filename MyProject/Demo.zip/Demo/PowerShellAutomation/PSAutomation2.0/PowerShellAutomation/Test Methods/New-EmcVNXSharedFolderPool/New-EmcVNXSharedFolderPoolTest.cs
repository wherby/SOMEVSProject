using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcVNXSharedFolderPoolTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcVNXSharedFolderPoolTest1()
        {
            string cmd = "New-EmcVNXSharedFolderPool -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity";
            NewEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVNXSharedFolderPoolTest2()
        {
            string cmd = "New-EmcVNXSharedFolderPool -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity -ServiceNode $ServiceNode";
            NewEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVNXSharedFolderPoolTest3()
        {
            string cmd = "New-EmcVNXSharedFolderPool -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity -Silent";
            NewEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVNXSharedFolderPoolTest4()
        {
            string cmd = "New-EmcVNXSharedFolderPool -Pool $Pool -Name $Name -Path $Path -Capacity $Capacity -ServiceNode $ServiceNode -Silent";
            NewEmcVNXSharedFolderPoolTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcStorageGroupTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest1()
        {
            string cmd = "Get-EmcStorageGroup";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest2()
        {
            string cmd = "Get-EmcStorageGroup -StorageSystem $StorageSystem";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest3()
        {
            string cmd = "Get-EmcStorageGroup -InitiatorId $InitiatorId";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest4()
        {
            string cmd = "Get-EmcStorageGroup -Silent";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest5()
        {
            string cmd = "Get-EmcStorageGroup -StorageSystem $StorageSystem -InitiatorId $InitiatorId";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest6()
        {
            string cmd = "Get-EmcStorageGroup -StorageSystem $StorageSystem -Silent";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest7()
        {
            string cmd = "Get-EmcStorageGroup -InitiatorId $InitiatorId -Silent";
            GetEmcStorageGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageGroupTest8()
        {
            string cmd = "Get-EmcStorageGroup -StorageSystem $StorageSystem -InitiatorId $InitiatorId -Silent";
            GetEmcStorageGroupTestMethod(cmd);
        }
        
    }
}

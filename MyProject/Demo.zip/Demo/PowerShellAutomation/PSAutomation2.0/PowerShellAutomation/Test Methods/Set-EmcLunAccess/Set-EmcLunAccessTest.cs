using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class SetEmcLunAccessTest
    {
        
        
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest1()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -HostSystem $HostSystem -Unavailable";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest2()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -HostSystem $HostSystem -Unavailable -Silent";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest3()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -HostSystem $HostSystem -Available";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest4()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -HostSystem $HostSystem -Available -Silent";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest5()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -InitiatorId $InitiatorId -HostName $HostName -HostIpAddress $HostIpAddress -Available";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest6()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -InitiatorId $InitiatorId -HostName $HostName -HostIpAddress $HostIpAddress -Available -Silent";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest7()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -InitiatorId $InitiatorId -HostName $HostName -HostIpAddress $HostIpAddress -Unavailable";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest8()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -InitiatorId $InitiatorId -HostName $HostName -HostIpAddress $HostIpAddress -Unavailable -Silent";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest9()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -ClusterSystem $ClusterSystem -Unavailable";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest10()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -ClusterSystem $ClusterSystem -Unavailable -Silent";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest11()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -ClusterSystem $ClusterSystem -Available";
            SetEmcLunAccessTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcLunAccessTest12()
        {
            string cmd = "Set-EmcLunAccess -Lun $Lun -ClusterSystem $ClusterSystem -Available -Silent";
            SetEmcLunAccessTestMethod(cmd);
        }
        
    }
}

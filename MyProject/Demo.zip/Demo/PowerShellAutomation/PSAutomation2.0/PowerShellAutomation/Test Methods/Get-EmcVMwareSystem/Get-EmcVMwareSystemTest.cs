using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcVMwareSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest1()
        {
            string cmd = "Get-EmcVMwareSystem";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest2()
        {
            string cmd = "Get-EmcVMwareSystem -ID $Name";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest3()
        {
            string cmd = "Get-EmcVMwareSystem $Name";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest4()
        {
            string cmd = "Get-EmcVMwareSystem -ID $IPAddress";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest5()
        {
            string cmd = "Get-EmcVMwareSystem $IPAddress";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest6()
        {
            string cmd = "Get-EmcVMwareSystem -ID $GlobalId";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest7()
        {
            string cmd = "Get-EmcVMwareSystem $GlobalId";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest8()
        {
            string cmd = "Get-EmcVMwareSystem -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest9()
        {
            string cmd = "Get-EmcVMwareSystem -ID $Name -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest10()
        {
            string cmd = "Get-EmcVMwareSystem $Name -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest11()
        {
            string cmd = "Get-EmcVMwareSystem -ID $IPAddress -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest12()
        {
            string cmd = "Get-EmcVMwareSystem $IPAddress -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest13()
        {
            string cmd = "Get-EmcVMwareSystem -ID $GlobalId -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest14()
        {
            string cmd = "Get-EmcVMwareSystem $GlobalId -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest15()
        {
            string cmd = "Get-EmcVMwareSystem -ESXHostSystem $ESXHostSystem";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest16()
        {
            string cmd = "Get-EmcVMwareSystem -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest17()
        {
            string cmd = "Get-EmcVMwareSystem -ScsiLun $ScsiLun";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest18()
        {
            string cmd = "Get-EmcVMwareSystem -ScsiLun $ScsiLun -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest19()
        {
            string cmd = "Get-EmcVMwareSystem -Datastore $Datastore";
            GetEmcVMwareSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVMwareSystemTest20()
        {
            string cmd = "Get-EmcVMwareSystem -Datastore $Datastore -Silent";
            GetEmcVMwareSystemTestMethod(cmd);
        }
        
    }
}

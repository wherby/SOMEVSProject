using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcStorageAccessControlTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcStorageAccessControlTest1()
        {
            string cmd = "New-EmcStorageAccessControl";
            NewEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcStorageAccessControlTest2()
        {
            string cmd = "New-EmcStorageAccessControl -Silent";
            NewEmcStorageAccessControlTestMethod(cmd);
        }
        
    }
}

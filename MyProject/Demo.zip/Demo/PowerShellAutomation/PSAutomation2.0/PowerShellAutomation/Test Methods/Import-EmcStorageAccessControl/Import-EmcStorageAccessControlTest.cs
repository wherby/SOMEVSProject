using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ImportEmcStorageAccessControlTest
    {
        
        
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest1()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest2()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest3()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -ListOnly";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest4()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Silent";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest5()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest6()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -ListOnly";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest7()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -Silent";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest8()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest9()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -ListOnly -Silent";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest10()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -ListOnly -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest11()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Silent -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest12()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -ListOnly -Silent";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest13()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -ListOnly -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest14()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -Silent -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest15()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -ListOnly -Silent -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ImportEmcStorageAccessControlTest16()
        {
            string cmd = "Import-EmcStorageAccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -ListOnly -Silent -WhatIf";
            ImportEmcStorageAccessControlTestMethod(cmd);
        }
        
    }
}

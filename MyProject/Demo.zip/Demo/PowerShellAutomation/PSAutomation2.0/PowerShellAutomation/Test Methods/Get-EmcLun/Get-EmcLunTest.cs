using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcLunTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcLunTest1()
        {
            string cmd = "Get-EmcLun";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest2()
        {
            string cmd = "Get-EmcLun -ID $ID";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest3()
        {
            string cmd = "Get-EmcLun $ID";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest4()
        {
            string cmd = "Get-EmcLun -Pool $Pool";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest5()
        {
            string cmd = "Get-EmcLun -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest6()
        {
            string cmd = "Get-EmcLun -ID $ID -Pool $Pool";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest7()
        {
            string cmd = "Get-EmcLun $ID -Pool $Pool";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest8()
        {
            string cmd = "Get-EmcLun -ID $ID -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest9()
        {
            string cmd = "Get-EmcLun $ID -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest10()
        {
            string cmd = "Get-EmcLun -Pool $Pool -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest11()
        {
            string cmd = "Get-EmcLun -ID $ID -Pool $Pool -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest12()
        {
            string cmd = "Get-EmcLun $ID -Pool $Pool -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest13()
        {
            string cmd = "Get-EmcLun -HostDisk $HostDisk";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest14()
        {
            string cmd = "Get-EmcLun -ID $ID -HostDisk $HostDisk";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest15()
        {
            string cmd = "Get-EmcLun $ID -HostDisk $HostDisk";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest16()
        {
            string cmd = "Get-EmcLun -HostDisk $HostDisk -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest17()
        {
            string cmd = "Get-EmcLun -ID $ID -HostDisk $HostDisk -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest18()
        {
            string cmd = "Get-EmcLun $ID -HostDisk $HostDisk -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest19()
        {
            string cmd = "Get-EmcLun -Volume $Volume";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest20()
        {
            string cmd = "Get-EmcLun -ID $ID -Volume $Volume";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest21()
        {
            string cmd = "Get-EmcLun $ID -Volume $Volume";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest22()
        {
            string cmd = "Get-EmcLun -Volume $Volume -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest23()
        {
            string cmd = "Get-EmcLun -ID $ID -Volume $Volume -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest24()
        {
            string cmd = "Get-EmcLun $ID -Volume $Volume -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest25()
        {
            string cmd = "Get-EmcLun -ClusterDisk $ClusterDisk";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest26()
        {
            string cmd = "Get-EmcLun -ID $ID -ClusterDisk $ClusterDisk";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest27()
        {
            string cmd = "Get-EmcLun $ID -ClusterDisk $ClusterDisk";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest28()
        {
            string cmd = "Get-EmcLun -ClusterDisk $ClusterDisk -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest29()
        {
            string cmd = "Get-EmcLun -ID $ID -ClusterDisk $ClusterDisk -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest30()
        {
            string cmd = "Get-EmcLun $ID -ClusterDisk $ClusterDisk -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest31()
        {
            string cmd = "Get-EmcLun -BlockStorageSystem $BlockStorageSystem";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest32()
        {
            string cmd = "Get-EmcLun -ID $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest33()
        {
            string cmd = "Get-EmcLun $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest34()
        {
            string cmd = "Get-EmcLun -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest35()
        {
            string cmd = "Get-EmcLun -ID $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest36()
        {
            string cmd = "Get-EmcLun $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest37()
        {
            string cmd = "Get-EmcLun -HostLunIdentifier $HostLunIdentifier";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest38()
        {
            string cmd = "Get-EmcLun -ID $ID -HostLunIdentifier $HostLunIdentifier";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest39()
        {
            string cmd = "Get-EmcLun $ID -HostLunIdentifier $HostLunIdentifier";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest40()
        {
            string cmd = "Get-EmcLun -HostLunIdentifier $HostLunIdentifier -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest41()
        {
            string cmd = "Get-EmcLun -ID $ID -HostLunIdentifier $HostLunIdentifier -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest42()
        {
            string cmd = "Get-EmcLun $ID -HostLunIdentifier $HostLunIdentifier -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest43()
        {
            string cmd = "Get-EmcLun -DataStore $DataStore";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest44()
        {
            string cmd = "Get-EmcLun -ID $ID -DataStore $DataStore";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest45()
        {
            string cmd = "Get-EmcLun $ID -DataStore $DataStore";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest46()
        {
            string cmd = "Get-EmcLun -DataStore $DataStore -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest47()
        {
            string cmd = "Get-EmcLun -ID $ID -DataStore $DataStore -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest48()
        {
            string cmd = "Get-EmcLun $ID -DataStore $DataStore -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest49()
        {
            string cmd = "Get-EmcLun -ScsiLun $ScsiLun";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest50()
        {
            string cmd = "Get-EmcLun -ID $ID -ScsiLun $ScsiLun";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest51()
        {
            string cmd = "Get-EmcLun $ID -ScsiLun $ScsiLun";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest52()
        {
            string cmd = "Get-EmcLun -ScsiLun $ScsiLun -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest53()
        {
            string cmd = "Get-EmcLun -ID $ID -ScsiLun $ScsiLun -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest54()
        {
            string cmd = "Get-EmcLun $ID -ScsiLun $ScsiLun -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest55()
        {
            string cmd = "Get-EmcLun -ClariionStorageSystem $ClariionStorageSystem -InitiatorId $InitiatorId -HostLunId $HostLunId";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest56()
        {
            string cmd = "Get-EmcLun -ID $ID -ClariionStorageSystem $ClariionStorageSystem -InitiatorId $InitiatorId -HostLunId $HostLunId";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest57()
        {
            string cmd = "Get-EmcLun $ID -ClariionStorageSystem $ClariionStorageSystem -InitiatorId $InitiatorId -HostLunId $HostLunId";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest58()
        {
            string cmd = "Get-EmcLun -ClariionStorageSystem $ClariionStorageSystem -InitiatorId $InitiatorId -HostLunId $HostLunId -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest59()
        {
            string cmd = "Get-EmcLun -ID $ID -ClariionStorageSystem $ClariionStorageSystem -InitiatorId $InitiatorId -HostLunId $HostLunId -Silent";
            GetEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcLunTest60()
        {
            string cmd = "Get-EmcLun $ID -ClariionStorageSystem $ClariionStorageSystem -InitiatorId $InitiatorId -HostLunId $HostLunId -Silent";
            GetEmcLunTestMethod(cmd);
        }
        
    }
}

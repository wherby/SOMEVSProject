using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest1()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest2()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest3()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest4()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest5()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest6()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest7()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest8()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest9()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest10()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest11()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest12()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest13()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest14()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest15()
        {
            string cmd = "Remove-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcSnapshotLunTest16()
        {
            string cmd = "Remove-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcSnapshotLunTestMethod(cmd);
        }
        
    }
}

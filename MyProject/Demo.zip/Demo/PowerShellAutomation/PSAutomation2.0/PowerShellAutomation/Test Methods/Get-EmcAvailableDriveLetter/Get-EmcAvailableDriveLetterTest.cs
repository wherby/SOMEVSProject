using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcAvailableDriveLetterTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest1()
        {
            string cmd = "Get-EmcAvailableDriveLetter -HostSystem $HostSystem";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest2()
        {
            string cmd = "Get-EmcAvailableDriveLetter $HostSystem";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest3()
        {
            string cmd = "Get-EmcAvailableDriveLetter -HostSystem $HostSystem -Silent";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest4()
        {
            string cmd = "Get-EmcAvailableDriveLetter $HostSystem -Silent";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest5()
        {
            string cmd = "Get-EmcAvailableDriveLetter -ClusterSystem $ClusterSystem";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest6()
        {
            string cmd = "Get-EmcAvailableDriveLetter $ClusterSystem";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest7()
        {
            string cmd = "Get-EmcAvailableDriveLetter -ClusterSystem $ClusterSystem -Silent";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableDriveLetterTest8()
        {
            string cmd = "Get-EmcAvailableDriveLetter $ClusterSystem -Silent";
            GetEmcAvailableDriveLetterTestMethod(cmd);
        }
        
    }
}

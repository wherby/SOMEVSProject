using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ExportEmcStorageAccessControlTest
    {
        
        
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest1()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest2()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest3()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Silent";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest4()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -WhatIf";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest5()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -Silent";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest6()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -WhatIf";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest7()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Silent -WhatIf";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExportEmcStorageAccessControlTest8()
        {
            string cmd = "Export-EmcStorageAccessControl -AccessControl $AccessControl -File $File -ProtectionKey $ProtectionKey -Confirm:$false -Force -Silent -WhatIf";
            ExportEmcStorageAccessControlTestMethod(cmd);
        }
        
    }
}

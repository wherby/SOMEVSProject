using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class AddEmcXenServerVirtualDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_AddEmcXenServerVirtualDiskTest1()
        {
            string cmd = "Add-EmcXenServerVirtualDisk -VirtualDisk $VirtualDisk -VirtualMachineConfiguration $VirtualMachineConfiguration";
            AddEmcXenServerVirtualDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcXenServerVirtualDiskTest2()
        {
            string cmd = "Add-EmcXenServerVirtualDisk -VirtualDisk $VirtualDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Silent";
            AddEmcXenServerVirtualDiskTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcStorageAccessControlTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcStorageAccessControlTest1()
        {
            string cmd = "Remove-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool";
            RemoveEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcStorageAccessControlTest2()
        {
            string cmd = "Remove-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool -Silent";
            RemoveEmcStorageAccessControlTestMethod(cmd);
        }
        
    }
}

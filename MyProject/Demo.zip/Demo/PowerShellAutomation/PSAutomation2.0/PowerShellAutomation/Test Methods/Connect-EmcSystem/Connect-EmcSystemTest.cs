using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ConnectEmcSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest1()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $CLARiiON-CX4_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest2()
        {
            string cmd = "Connect-EmcSystem $CLARiiON-CX4_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest3()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VMAX_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest4()
        {
            string cmd = "Connect-EmcSystem $VMAX_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest5()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VMAXe_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest6()
        {
            string cmd = "Connect-EmcSystem $VMAXe_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest7()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VNX_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest8()
        {
            string cmd = "Connect-EmcSystem $VNX_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest9()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VNX-Block_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest10()
        {
            string cmd = "Connect-EmcSystem $VNX-Block_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest11()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VNX-CIFS_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest12()
        {
            string cmd = "Connect-EmcSystem $VNX-CIFS_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest13()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $Host_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest14()
        {
            string cmd = "Connect-EmcSystem $Host_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest15()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $Cluster_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest16()
        {
            string cmd = "Connect-EmcSystem $Cluster_Blob";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest17()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $CLARiiON-CX4_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest18()
        {
            string cmd = "Connect-EmcSystem $CLARiiON-CX4_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest19()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VMAX_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest20()
        {
            string cmd = "Connect-EmcSystem $VMAX_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest21()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VMAXe_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest22()
        {
            string cmd = "Connect-EmcSystem $VMAXe_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest23()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VNX_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest24()
        {
            string cmd = "Connect-EmcSystem $VNX_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest25()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VNX-Block_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest26()
        {
            string cmd = "Connect-EmcSystem $VNX-Block_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest27()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $VNX-CIFS_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest28()
        {
            string cmd = "Connect-EmcSystem $VNX-CIFS_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest29()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $Host_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest30()
        {
            string cmd = "Connect-EmcSystem $Host_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest31()
        {
            string cmd = "Connect-EmcSystem -CreationBlob $Cluster_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ConnectEmcSystemTest32()
        {
            string cmd = "Connect-EmcSystem $Cluster_Blob -Silent";
            ConnectEmcSystemTestMethod(cmd);
        }
        
    }
}

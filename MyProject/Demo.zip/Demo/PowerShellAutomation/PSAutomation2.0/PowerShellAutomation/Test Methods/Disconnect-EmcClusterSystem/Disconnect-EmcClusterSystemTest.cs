using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class DisconnectEmcClusterSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest1()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest2()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest3()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest4()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest5()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest6()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest7()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -Force";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest8()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -Force";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest9()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest10()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest11()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest12()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest13()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest14()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest15()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest16()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -Force -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest17()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -Force -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest18()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -Force -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest19()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -Force -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest20()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest21()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest22()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest23()
        {
            string cmd = "Disconnect-EmcClusterSystem -Id $Id -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest24()
        {
            string cmd = "Disconnect-EmcClusterSystem $Id -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest25()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -System $System";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest26()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -System $System";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest27()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -System $System -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest28()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -System $System -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest29()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -System $System -Silent";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest30()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -System $System -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest31()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -System $System -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcClusterSystemTest32()
        {
            string cmd = "Disconnect-EmcClusterSystem -Confirm:$false -Force -System $System -Silent -WhatIf";
            DisconnectEmcClusterSystemTestMethod(cmd);
        }
        
    }
}

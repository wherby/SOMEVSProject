using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcStorageSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest1()
        {
            string cmd = "Get-EmcStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest2()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest3()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest4()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest5()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest6()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest7()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest8()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest9()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest10()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest11()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest12()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest13()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest14()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest15()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest16()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest17()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest18()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest19()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest20()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest21()
        {
            string cmd = "Get-EmcStorageSystem $VNX_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest22()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest23()
        {
            string cmd = "Get-EmcStorageSystem $VNX_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest24()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest25()
        {
            string cmd = "Get-EmcStorageSystem $VNX_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest26()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest27()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest28()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest29()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest30()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest31()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest32()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest33()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_Name";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest34()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest35()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_FriendlyName";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest36()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest37()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_GlobalId";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest38()
        {
            string cmd = "Get-EmcStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest39()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest40()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest41()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest42()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest43()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest44()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest45()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest46()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest47()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest48()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest49()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest50()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest51()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest52()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest53()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest54()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest55()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest56()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest57()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest58()
        {
            string cmd = "Get-EmcStorageSystem $VNX_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest59()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest60()
        {
            string cmd = "Get-EmcStorageSystem $VNX_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest61()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest62()
        {
            string cmd = "Get-EmcStorageSystem $VNX_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest63()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest64()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest65()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest66()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest67()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest68()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest69()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest70()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_Name -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest71()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest72()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_FriendlyName -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest73()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest74()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_GlobalId -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest75()
        {
            string cmd = "Get-EmcStorageSystem -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest76()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest77()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest78()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest79()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest80()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest81()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest82()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest83()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest84()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest85()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest86()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest87()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest88()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest89()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest90()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest91()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest92()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest93()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest94()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest95()
        {
            string cmd = "Get-EmcStorageSystem $VNX_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest96()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest97()
        {
            string cmd = "Get-EmcStorageSystem $VNX_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest98()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest99()
        {
            string cmd = "Get-EmcStorageSystem $VNX_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest100()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest101()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest102()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest103()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest104()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest105()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest106()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest107()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_Name -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest108()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest109()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_FriendlyName -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest110()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest111()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_GlobalId -FileStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest112()
        {
            string cmd = "Get-EmcStorageSystem -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest113()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest114()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest115()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest116()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest117()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest118()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest119()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest120()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest121()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest122()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest123()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest124()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest125()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest126()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest127()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest128()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest129()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest130()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest131()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest132()
        {
            string cmd = "Get-EmcStorageSystem $VNX_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest133()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest134()
        {
            string cmd = "Get-EmcStorageSystem $VNX_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest135()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest136()
        {
            string cmd = "Get-EmcStorageSystem $VNX_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest137()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest138()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest139()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest140()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest141()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest142()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest143()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest144()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_Name -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest145()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest146()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_FriendlyName -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest147()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest148()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_GlobalId -FileStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest149()
        {
            string cmd = "Get-EmcStorageSystem -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest150()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest151()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest152()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest153()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest154()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest155()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest156()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest157()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest158()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest159()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest160()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest161()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest162()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest163()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest164()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest165()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest166()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest167()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest168()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest169()
        {
            string cmd = "Get-EmcStorageSystem $VNX_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest170()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest171()
        {
            string cmd = "Get-EmcStorageSystem $VNX_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest172()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest173()
        {
            string cmd = "Get-EmcStorageSystem $VNX_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest174()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest175()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest176()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest177()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest178()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest179()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest180()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest181()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_Name -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest182()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest183()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_FriendlyName -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest184()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest185()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_GlobalId -BlockStorageSystem";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest186()
        {
            string cmd = "Get-EmcStorageSystem -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest187()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest188()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest189()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest190()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest191()
        {
            string cmd = "Get-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest192()
        {
            string cmd = "Get-EmcStorageSystem $CLARiiON-CX4_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest193()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest194()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest195()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest196()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest197()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAX_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest198()
        {
            string cmd = "Get-EmcStorageSystem $VMAX_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest199()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest200()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest201()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest202()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest203()
        {
            string cmd = "Get-EmcStorageSystem -Id $VMAXe_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest204()
        {
            string cmd = "Get-EmcStorageSystem $VMAXe_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest205()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest206()
        {
            string cmd = "Get-EmcStorageSystem $VNX_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest207()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest208()
        {
            string cmd = "Get-EmcStorageSystem $VNX_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest209()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest210()
        {
            string cmd = "Get-EmcStorageSystem $VNX_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest211()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest212()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest213()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest214()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest215()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-Block_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest216()
        {
            string cmd = "Get-EmcStorageSystem $VNX-Block_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest217()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest218()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_Name -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest219()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest220()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_FriendlyName -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest221()
        {
            string cmd = "Get-EmcStorageSystem -Id $VNX-CIFS_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest222()
        {
            string cmd = "Get-EmcStorageSystem $VNX-CIFS_GlobalId -BlockStorageSystem -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest223()
        {
            string cmd = "Get-EmcStorageSystem -Lun $Lun";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest224()
        {
            string cmd = "Get-EmcStorageSystem -Lun $Lun -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest225()
        {
            string cmd = "Get-EmcStorageSystem -Pool $Pool";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest226()
        {
            string cmd = "Get-EmcStorageSystem -Pool $Pool -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest227()
        {
            string cmd = "Get-EmcStorageSystem -ClarStorageGroup $ClarStorageGroup";
            GetEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageSystemTest228()
        {
            string cmd = "Get-EmcStorageSystem -ClarStorageGroup $ClarStorageGroup -Silent";
            GetEmcStorageSystemTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcStorageServiceNodeTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest1()
        {
            string cmd = "Get-EmcStorageServiceNode";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest2()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest3()
        {
            string cmd = "Get-EmcStorageServiceNode $ID";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest4()
        {
            string cmd = "Get-EmcStorageServiceNode -StorageSystem $BlockStorageSystem";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest5()
        {
            string cmd = "Get-EmcStorageServiceNode -StorageSystem $FileStorageSystem";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest6()
        {
            string cmd = "Get-EmcStorageServiceNode -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest7()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -StorageSystem $BlockStorageSystem";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest8()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -StorageSystem $BlockStorageSystem";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest9()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -StorageSystem $FileStorageSystem";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest10()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -StorageSystem $FileStorageSystem";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest11()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest12()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest13()
        {
            string cmd = "Get-EmcStorageServiceNode -StorageSystem $BlockStorageSystem -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest14()
        {
            string cmd = "Get-EmcStorageServiceNode -StorageSystem $FileStorageSystem -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest15()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -StorageSystem $BlockStorageSystem -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest16()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -StorageSystem $BlockStorageSystem -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest17()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -StorageSystem $FileStorageSystem -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest18()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -StorageSystem $FileStorageSystem -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest19()
        {
            string cmd = "Get-EmcStorageServiceNode -Pool $Pool";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest20()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -Pool $Pool";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest21()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -Pool $Pool";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest22()
        {
            string cmd = "Get-EmcStorageServiceNode -Pool $Pool -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest23()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -Pool $Pool -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest24()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -Pool $Pool -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest25()
        {
            string cmd = "Get-EmcStorageServiceNode -Lun $Lun";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest26()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -Lun $Lun";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest27()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -Lun $Lun";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest28()
        {
            string cmd = "Get-EmcStorageServiceNode -Lun $Lun -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest29()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -Lun $Lun -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest30()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -Lun $Lun -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest31()
        {
            string cmd = "Get-EmcStorageServiceNode -CifsSharedFolder $CifsSharedFolder";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest32()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -CifsSharedFolder $CifsSharedFolder";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest33()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -CifsSharedFolder $CifsSharedFolder";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest34()
        {
            string cmd = "Get-EmcStorageServiceNode -CifsSharedFolder $CifsSharedFolder -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest35()
        {
            string cmd = "Get-EmcStorageServiceNode -ID $ID -CifsSharedFolder $CifsSharedFolder -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStorageServiceNodeTest36()
        {
            string cmd = "Get-EmcStorageServiceNode $ID -CifsSharedFolder $CifsSharedFolder -Silent";
            GetEmcStorageServiceNodeTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class DisconnectEmcSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest1()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest2()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest3()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest4()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest5()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest6()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest7()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest8()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest9()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest10()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest11()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest12()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest13()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest14()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest15()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest16()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest17()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest18()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest19()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest20()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest21()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest22()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest23()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest24()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest25()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest26()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest27()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest28()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest29()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest30()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest31()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest32()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest33()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest34()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest35()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest36()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest37()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest38()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest39()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest40()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest41()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest42()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest43()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest44()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest45()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest46()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest47()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest48()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest49()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest50()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest51()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest52()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest53()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest54()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest55()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest56()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest57()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest58()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest59()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest60()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest61()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest62()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest63()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest64()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest65()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest66()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest67()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest68()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -Force";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest69()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest70()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest71()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest72()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest73()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest74()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest75()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest76()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest77()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest78()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest79()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest80()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest81()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest82()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest83()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest84()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest85()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest86()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest87()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest88()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest89()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest90()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest91()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest92()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest93()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest94()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest95()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest96()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest97()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest98()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest99()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest100()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest101()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest102()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest103()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest104()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest105()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest106()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest107()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest108()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest109()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest110()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest111()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest112()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest113()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest114()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest115()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest116()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest117()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest118()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest119()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest120()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest121()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest122()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest123()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest124()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest125()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest126()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest127()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest128()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest129()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest130()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest131()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest132()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest133()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest134()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest135()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest136()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest137()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest138()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest139()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest140()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest141()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest142()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest143()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest144()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest145()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest146()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest147()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest148()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest149()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest150()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest151()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest152()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest153()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest154()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest155()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest156()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest157()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest158()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest159()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest160()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest161()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest162()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest163()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest164()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest165()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest166()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest167()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest168()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest169()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest170()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest171()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest172()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest173()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest174()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest175()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest176()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest177()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest178()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest179()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest180()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest181()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest182()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest183()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest184()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest185()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest186()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest187()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest188()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest189()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest190()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest191()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest192()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest193()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest194()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest195()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest196()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest197()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest198()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest199()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest200()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest201()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest202()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest203()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest204()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest205()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest206()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest207()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest208()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest209()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest210()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest211()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest212()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest213()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest214()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest215()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest216()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest217()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest218()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest219()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest220()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest221()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest222()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest223()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest224()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest225()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest226()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest227()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest228()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest229()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest230()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest231()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest232()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest233()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest234()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest235()
        {
            string cmd = "Disconnect-EmcSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest236()
        {
            string cmd = "Disconnect-EmcSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest237()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest238()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest239()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest240()
        {
            string cmd = "Disconnect-EmcSystem $VMAX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest241()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest242()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest243()
        {
            string cmd = "Disconnect-EmcSystem -Id $VMAXe_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest244()
        {
            string cmd = "Disconnect-EmcSystem $VMAXe_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest245()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest246()
        {
            string cmd = "Disconnect-EmcSystem $VNX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest247()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest248()
        {
            string cmd = "Disconnect-EmcSystem $VNX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest249()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest250()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest251()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest252()
        {
            string cmd = "Disconnect-EmcSystem $VNX-Block_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest253()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest254()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest255()
        {
            string cmd = "Disconnect-EmcSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest256()
        {
            string cmd = "Disconnect-EmcSystem $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest257()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest258()
        {
            string cmd = "Disconnect-EmcSystem $Host_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest259()
        {
            string cmd = "Disconnect-EmcSystem -Id $Host_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest260()
        {
            string cmd = "Disconnect-EmcSystem $Host_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest261()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest262()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest263()
        {
            string cmd = "Disconnect-EmcSystem -Id $Cluster_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest264()
        {
            string cmd = "Disconnect-EmcSystem $Cluster_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest265()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $CLARiiON-CX4_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest266()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAX_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest267()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAXe_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest268()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest269()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-Block_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest270()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-CIFS_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest271()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Host_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest272()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Cluster_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest273()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $CLARiiON-CX4_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest274()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAX_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest275()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAXe_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest276()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest277()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-Block_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest278()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-CIFS_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest279()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Host_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest280()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Cluster_System";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest281()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $CLARiiON-CX4_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest282()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAX_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest283()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAXe_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest284()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest285()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-Block_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest286()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-CIFS_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest287()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Host_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest288()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Cluster_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest289()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $CLARiiON-CX4_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest290()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAX_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest291()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAXe_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest292()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest293()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-Block_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest294()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-CIFS_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest295()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Host_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest296()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Cluster_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest297()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $CLARiiON-CX4_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest298()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAX_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest299()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAXe_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest300()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest301()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-Block_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest302()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-CIFS_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest303()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Host_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest304()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Cluster_System -Silent";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest305()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $CLARiiON-CX4_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest306()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAX_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest307()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAXe_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest308()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest309()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-Block_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest310()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-CIFS_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest311()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Host_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest312()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Cluster_System -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest313()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $CLARiiON-CX4_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest314()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAX_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest315()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VMAXe_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest316()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest317()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-Block_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest318()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $VNX-CIFS_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest319()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Host_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest320()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -System $Cluster_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest321()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $CLARiiON-CX4_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest322()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAX_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest323()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VMAXe_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest324()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest325()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-Block_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest326()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $VNX-CIFS_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest327()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Host_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcSystemTest328()
        {
            string cmd = "Disconnect-EmcSystem -Confirm:$false -Force -System $Cluster_System -Silent -WhatIf";
            DisconnectEmcSystemTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class SetEmcVolumeMountPointTest
    {
        
        
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest1()
        {
            string cmd = "Set-EmcVolumeMountPoint -HostSystem $HostSystem -DriveLetter $DriveLetter -Volume $Volume";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest2()
        {
            string cmd = "Set-EmcVolumeMountPoint -HostSystem $HostSystem -DriveLetter $DriveLetter -Volume $Volume -Silent";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest3()
        {
            string cmd = "Set-EmcVolumeMountPoint -HostSystem $HostSystem -MountPath $MountPath -Volume $Volume";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest4()
        {
            string cmd = "Set-EmcVolumeMountPoint -HostSystem $HostSystem -MountPath $MountPath -Volume $Volume -Silent";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest5()
        {
            string cmd = "Set-EmcVolumeMountPoint -ClusterSystem $ClusterSystem -MountPath $MountPath -Volume $Volume";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest6()
        {
            string cmd = "Set-EmcVolumeMountPoint -ClusterSystem $ClusterSystem -MountPath $MountPath -Volume $Volume -Silent";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest7()
        {
            string cmd = "Set-EmcVolumeMountPoint -ClusterSystem $ClusterSystem -DriveLetter $DriveLetter -Volume $Volume";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcVolumeMountPointTest8()
        {
            string cmd = "Set-EmcVolumeMountPoint -ClusterSystem $ClusterSystem -DriveLetter $DriveLetter -Volume $Volume -Silent";
            SetEmcVolumeMountPointTestMethod(cmd);
        }
        
    }
}

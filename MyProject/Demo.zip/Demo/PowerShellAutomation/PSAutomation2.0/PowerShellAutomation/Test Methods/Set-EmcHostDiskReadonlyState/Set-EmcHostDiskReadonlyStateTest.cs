using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class SetEmcHostDiskReadonlyStateTest
    {
        
        
      
        [TestMethod]
        public void PS_SetEmcHostDiskReadonlyStateTest1()
        {
            string cmd = "Set-EmcHostDiskReadonlyState -HostDisk $HostDisk -Readonly";
            SetEmcHostDiskReadonlyStateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcHostDiskReadonlyStateTest2()
        {
            string cmd = "Set-EmcHostDiskReadonlyState -HostDisk $HostDisk -Readonly -Silent";
            SetEmcHostDiskReadonlyStateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcHostDiskReadonlyStateTest3()
        {
            string cmd = "Set-EmcHostDiskReadonlyState -HostDisk $HostDisk -ReadWrite";
            SetEmcHostDiskReadonlyStateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcHostDiskReadonlyStateTest4()
        {
            string cmd = "Set-EmcHostDiskReadonlyState -HostDisk $HostDisk -ReadWrite -Silent";
            SetEmcHostDiskReadonlyStateTestMethod(cmd);
        }
        
    }
}

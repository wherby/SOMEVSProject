using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class AddEmcStorageAccessControlTest
    {
        
        
      
        [TestMethod]
        public void PS_AddEmcStorageAccessControlTest1()
        {
            string cmd = "Add-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool";
            AddEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcStorageAccessControlTest2()
        {
            string cmd = "Add-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool -FullControl";
            AddEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcStorageAccessControlTest3()
        {
            string cmd = "Add-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool -Silent";
            AddEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcStorageAccessControlTest4()
        {
            string cmd = "Add-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool -FullControl -Silent";
            AddEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcStorageAccessControlTest5()
        {
            string cmd = "Add-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool -ViewOnly";
            AddEmcStorageAccessControlTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcStorageAccessControlTest6()
        {
            string cmd = "Add-EmcStorageAccessControl -AccessControl $AccessControl -Pool $Pool -ViewOnly -Silent";
            AddEmcStorageAccessControlTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class FindEmcHostDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest1()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest2()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -RescanCount $RescanCount";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest3()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest4()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -RescanCount $RescanCount -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest5()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -Lun $Lun";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest6()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -Lun $Lun -RescanCount $RescanCount";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest7()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -Lun $Lun -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest8()
        {
            string cmd = "Find-EmcHostDisk -HostSystem $HostSystem -Lun $Lun -RescanCount $RescanCount -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest9()
        {
            string cmd = "Find-EmcHostDisk -ClusterSystem $ClusterSystem -Lun $Lun";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest10()
        {
            string cmd = "Find-EmcHostDisk -ClusterSystem $ClusterSystem -Lun $Lun -RescanCount $RescanCount";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest11()
        {
            string cmd = "Find-EmcHostDisk -ClusterSystem $ClusterSystem -Lun $Lun -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest12()
        {
            string cmd = "Find-EmcHostDisk -ClusterSystem $ClusterSystem -Lun $Lun -RescanCount $RescanCount -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest13()
        {
            string cmd = "Find-EmcHostDisk -VirtualMachine $VirtualMachine -VmDiskConfig $VmDiskConfig";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest14()
        {
            string cmd = "Find-EmcHostDisk -VirtualMachine $VirtualMachine -VmDiskConfig $VmDiskConfig -RescanCount $RescanCount";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest15()
        {
            string cmd = "Find-EmcHostDisk -VirtualMachine $VirtualMachine -VmDiskConfig $VmDiskConfig -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_FindEmcHostDiskTest16()
        {
            string cmd = "Find-EmcHostDisk -VirtualMachine $VirtualMachine -VmDiskConfig $VmDiskConfig -RescanCount $RescanCount -Silent";
            FindEmcHostDiskTestMethod(cmd);
        }
        
    }
}

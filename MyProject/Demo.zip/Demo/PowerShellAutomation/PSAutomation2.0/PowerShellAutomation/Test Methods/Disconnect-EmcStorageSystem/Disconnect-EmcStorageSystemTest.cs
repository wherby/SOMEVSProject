using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class DisconnectEmcStorageSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest1()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest2()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest3()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest4()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest5()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest6()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest7()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest8()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest9()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest10()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest11()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest12()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest13()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest14()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest15()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest16()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest17()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest18()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest19()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest20()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest21()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest22()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest23()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest24()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest25()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest26()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest27()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest28()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest29()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest30()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest31()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest32()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest33()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest34()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest35()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest36()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest37()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest38()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest39()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest40()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest41()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest42()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest43()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest44()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest45()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest46()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest47()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest48()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest49()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest50()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest51()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest52()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest53()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest54()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest55()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest56()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest57()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest58()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest59()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest60()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest61()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest62()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest63()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest64()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest65()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest66()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest67()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest68()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest69()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest70()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest71()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest72()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest73()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest74()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest75()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest76()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -Force";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest77()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest78()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest79()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest80()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest81()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest82()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest83()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest84()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest85()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest86()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest87()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest88()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest89()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest90()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest91()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest92()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest93()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest94()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest95()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest96()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest97()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest98()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest99()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest100()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest101()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest102()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest103()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest104()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest105()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest106()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest107()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest108()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest109()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest110()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest111()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest112()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest113()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest114()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest115()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest116()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest117()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest118()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest119()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest120()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest121()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest122()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest123()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest124()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest125()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest126()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest127()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest128()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest129()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest130()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest131()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest132()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest133()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest134()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest135()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest136()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest137()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest138()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest139()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest140()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest141()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest142()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest143()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest144()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest145()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest146()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest147()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest148()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest149()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest150()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest151()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest152()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest153()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest154()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest155()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest156()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest157()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest158()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest159()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest160()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest161()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest162()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest163()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest164()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest165()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest166()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest167()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest168()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest169()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest170()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest171()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest172()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest173()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest174()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest175()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest176()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest177()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest178()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest179()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest180()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest181()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest182()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest183()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest184()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest185()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest186()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest187()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest188()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest189()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest190()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest191()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest192()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest193()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest194()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest195()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest196()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest197()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest198()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest199()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest200()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest201()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest202()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest203()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest204()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest205()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest206()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest207()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest208()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest209()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest210()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest211()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest212()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest213()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest214()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest215()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest216()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest217()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest218()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest219()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest220()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest221()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest222()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest223()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest224()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest225()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest226()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest227()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest228()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest229()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest230()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest231()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest232()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest233()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest234()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest235()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest236()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest237()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest238()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest239()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest240()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest241()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest242()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest243()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest244()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest245()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest246()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest247()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest248()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest249()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest250()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest251()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest252()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest253()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest254()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest255()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest256()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest257()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest258()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest259()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest260()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest261()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest262()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest263()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest264()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest265()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest266()
        {
            string cmd = "Disconnect-EmcStorageSystem $CLARiiON-CX4_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest267()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest268()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest269()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest270()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest271()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest272()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest273()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest274()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest275()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest276()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest277()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VMAXe_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest278()
        {
            string cmd = "Disconnect-EmcStorageSystem $VMAXe_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest279()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest280()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest281()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest282()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest283()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest284()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest285()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest286()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest287()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest288()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest289()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-Block_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest290()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-Block_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest291()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest292()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_Name -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest293()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest294()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_FriendlyName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest295()
        {
            string cmd = "Disconnect-EmcStorageSystem -Id $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest296()
        {
            string cmd = "Disconnect-EmcStorageSystem $VNX-CIFS_GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest297()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $CLARiiON-CX4_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest298()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAX_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest299()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAXe_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest300()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest301()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-Block_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest302()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-CIFS_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest303()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $CLARiiON-CX4_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest304()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAX_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest305()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAXe_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest306()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest307()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-Block_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest308()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-CIFS_System";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest309()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $CLARiiON-CX4_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest310()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAX_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest311()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAXe_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest312()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest313()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-Block_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest314()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-CIFS_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest315()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $CLARiiON-CX4_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest316()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAX_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest317()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAXe_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest318()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest319()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-Block_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest320()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-CIFS_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest321()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $CLARiiON-CX4_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest322()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAX_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest323()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAXe_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest324()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest325()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-Block_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest326()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-CIFS_System -Silent";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest327()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $CLARiiON-CX4_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest328()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAX_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest329()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAXe_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest330()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest331()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-Block_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest332()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-CIFS_System -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest333()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $CLARiiON-CX4_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest334()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAX_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest335()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VMAXe_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest336()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest337()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-Block_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest338()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -System $VNX-CIFS_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest339()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $CLARiiON-CX4_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest340()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAX_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest341()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VMAXe_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest342()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest343()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-Block_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcStorageSystemTest344()
        {
            string cmd = "Disconnect-EmcStorageSystem -Confirm:$false -Force -System $VNX-CIFS_System -Silent -WhatIf";
            DisconnectEmcStorageSystemTestMethod(cmd);
        }
        
    }
}

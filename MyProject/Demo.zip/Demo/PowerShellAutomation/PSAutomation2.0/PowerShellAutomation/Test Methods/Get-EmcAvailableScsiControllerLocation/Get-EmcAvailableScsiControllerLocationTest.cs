using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcAvailableScsiControllerLocationTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest1()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $HypervVMConfig -ScsiControllerIndex $ScsiControllerIndex";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest2()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $VMWareVMConfig -ScsiControllerIndex $ScsiControllerIndex";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest3()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $HypervVMConfig -ScsiControllerIndex $ScsiControllerIndex -Silent";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest4()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $VMWareVMConfig -ScsiControllerIndex $ScsiControllerIndex -Silent";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest5()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $HypervVMConfig -ScsiControllerId $ScsiControllerId";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest6()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $VMWareVMConfig -ScsiControllerId $ScsiControllerId";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest7()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $HypervVMConfig -ScsiControllerId $ScsiControllerId -Silent";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailableScsiControllerLocationTest8()
        {
            string cmd = "Get-EmcAvailableScsiControllerLocation -VirtualMachineConfiguration $VMWareVMConfig -ScsiControllerId $ScsiControllerId -Silent";
            GetEmcAvailableScsiControllerLocationTestMethod(cmd);
        }
        
    }
}

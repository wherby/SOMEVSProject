using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcXenServerSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest1()
        {
            string cmd = "Get-EmcXenServerSystem";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest2()
        {
            string cmd = "Get-EmcXenServerSystem -ID $Name";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest3()
        {
            string cmd = "Get-EmcXenServerSystem $Name";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest4()
        {
            string cmd = "Get-EmcXenServerSystem -ID $GlobalId";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest5()
        {
            string cmd = "Get-EmcXenServerSystem $GlobalId";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest6()
        {
            string cmd = "Get-EmcXenServerSystem -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest7()
        {
            string cmd = "Get-EmcXenServerSystem -ID $Name -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest8()
        {
            string cmd = "Get-EmcXenServerSystem $Name -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest9()
        {
            string cmd = "Get-EmcXenServerSystem -ID $GlobalId -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest10()
        {
            string cmd = "Get-EmcXenServerSystem $GlobalId -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest11()
        {
            string cmd = "Get-EmcXenServerSystem -XenServerHostSystem $XenServerHostSystem";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest12()
        {
            string cmd = "Get-EmcXenServerSystem -XenServerHostSystem $XenServerHostSystem -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest13()
        {
            string cmd = "Get-EmcXenServerSystem -StorageRepository $StorageRepository";
            GetEmcXenServerSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerSystemTest14()
        {
            string cmd = "Get-EmcXenServerSystem -StorageRepository $StorageRepository -Silent";
            GetEmcXenServerSystemTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcHostBusAdapterTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest1()
        {
            string cmd = "Get-EmcHostBusAdapter -HostSystem $HostSystem";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest2()
        {
            string cmd = "Get-EmcHostBusAdapter $HostSystem";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest3()
        {
            string cmd = "Get-EmcHostBusAdapter -HostSystem $HostSystem -Silent";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest4()
        {
            string cmd = "Get-EmcHostBusAdapter $HostSystem -Silent";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest5()
        {
            string cmd = "Get-EmcHostBusAdapter -ClusterSystem $ClusterSystem";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest6()
        {
            string cmd = "Get-EmcHostBusAdapter $ClusterSystem";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest7()
        {
            string cmd = "Get-EmcHostBusAdapter -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostBusAdapterTest8()
        {
            string cmd = "Get-EmcHostBusAdapter $ClusterSystem -Silent";
            GetEmcHostBusAdapterTestMethod(cmd);
        }
        
    }
}

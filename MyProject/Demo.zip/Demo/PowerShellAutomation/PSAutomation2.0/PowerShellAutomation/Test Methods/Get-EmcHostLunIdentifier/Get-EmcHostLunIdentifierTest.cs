using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcHostLunIdentifierTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest1()
        {
            string cmd = "Get-EmcHostLunIdentifier -Lun $Lun";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest2()
        {
            string cmd = "Get-EmcHostLunIdentifier $Lun";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest3()
        {
            string cmd = "Get-EmcHostLunIdentifier -Lun $Lun -Silent";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest4()
        {
            string cmd = "Get-EmcHostLunIdentifier $Lun -Silent";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest5()
        {
            string cmd = "Get-EmcHostLunIdentifier -Lun $Lun -HostSystem $HostSystem";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest6()
        {
            string cmd = "Get-EmcHostLunIdentifier $Lun -HostSystem $HostSystem";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest7()
        {
            string cmd = "Get-EmcHostLunIdentifier -Lun $Lun -HostSystem $HostSystem -Silent";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest8()
        {
            string cmd = "Get-EmcHostLunIdentifier $Lun -HostSystem $HostSystem -Silent";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest9()
        {
            string cmd = "Get-EmcHostLunIdentifier -Lun $Lun -ClusterSystem $ClusterSystem";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest10()
        {
            string cmd = "Get-EmcHostLunIdentifier $Lun -ClusterSystem $ClusterSystem";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest11()
        {
            string cmd = "Get-EmcHostLunIdentifier -Lun $Lun -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostLunIdentifierTest12()
        {
            string cmd = "Get-EmcHostLunIdentifier $Lun -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostLunIdentifierTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcXenServerVirtualDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcXenServerVirtualDiskTest1()
        {
            string cmd = "Remove-EmcXenServerVirtualDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location";
            RemoveEmcXenServerVirtualDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcXenServerVirtualDiskTest2()
        {
            string cmd = "Remove-EmcXenServerVirtualDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Silent";
            RemoveEmcXenServerVirtualDiskTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest1()
        {
            string cmd = "Get-EmcSnapshotLun";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest2()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest3()
        {
            string cmd = "Get-EmcSnapshotLun $ID";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest4()
        {
            string cmd = "Get-EmcSnapshotLun -SourceLun $SourceLun";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest5()
        {
            string cmd = "Get-EmcSnapshotLun -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest6()
        {
            string cmd = "Get-EmcSnapshotLun -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest7()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -SourceLun $SourceLun";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest8()
        {
            string cmd = "Get-EmcSnapshotLun $ID -SourceLun $SourceLun";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest9()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest10()
        {
            string cmd = "Get-EmcSnapshotLun $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest11()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest12()
        {
            string cmd = "Get-EmcSnapshotLun $ID -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest13()
        {
            string cmd = "Get-EmcSnapshotLun -SourceLun $SourceLun -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest14()
        {
            string cmd = "Get-EmcSnapshotLun -SourceLun $SourceLun -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest15()
        {
            string cmd = "Get-EmcSnapshotLun -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest16()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -SourceLun $SourceLun -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest17()
        {
            string cmd = "Get-EmcSnapshotLun $ID -SourceLun $SourceLun -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest18()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -SourceLun $SourceLun -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest19()
        {
            string cmd = "Get-EmcSnapshotLun $ID -SourceLun $SourceLun -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest20()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest21()
        {
            string cmd = "Get-EmcSnapshotLun $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest22()
        {
            string cmd = "Get-EmcSnapshotLun -SourceLun $SourceLun -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest23()
        {
            string cmd = "Get-EmcSnapshotLun -ID $ID -SourceLun $SourceLun -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotLunTest24()
        {
            string cmd = "Get-EmcSnapshotLun $ID -SourceLun $SourceLun -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotLunTestMethod(cmd);
        }
        
    }
}

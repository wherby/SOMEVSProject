using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class DisableEmcSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest1()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest2()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest3()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest4()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest5()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest6()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest7()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest8()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest9()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest10()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest11()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest12()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest13()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest14()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest15()
        {
            string cmd = "Disable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisableEmcSnapshotLunTest16()
        {
            string cmd = "Disable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            DisableEmcSnapshotLunTestMethod(cmd);
        }
        
    }
}

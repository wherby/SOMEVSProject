using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcFileBasedDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest1()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest2()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest3()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -Force";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest4()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -Force";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest5()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -Silent";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest6()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -Silent";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest7()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest8()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest9()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -Force -Silent";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest10()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -Force -Silent";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest11()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -Force -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest12()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -Force -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest13()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -Silent -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest14()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -Silent -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest15()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $Hyperv -Path $Path -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcFileBasedDiskTest16()
        {
            string cmd = "Remove-EmcFileBasedDisk -Hypervisor $VMWare -Path $Path -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcFileBasedDiskTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcXenServerHostTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest1()
        {
            string cmd = "Get-EmcXenServerHost";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest2()
        {
            string cmd = "Get-EmcXenServerHost -ID $Name";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest3()
        {
            string cmd = "Get-EmcXenServerHost $Name";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest4()
        {
            string cmd = "Get-EmcXenServerHost -ID $GlobalId";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest5()
        {
            string cmd = "Get-EmcXenServerHost $GlobalId";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest6()
        {
            string cmd = "Get-EmcXenServerHost -ID $UUID";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest7()
        {
            string cmd = "Get-EmcXenServerHost $UUID";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest8()
        {
            string cmd = "Get-EmcXenServerHost -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest9()
        {
            string cmd = "Get-EmcXenServerHost -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest10()
        {
            string cmd = "Get-EmcXenServerHost -ID $Name -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest11()
        {
            string cmd = "Get-EmcXenServerHost $Name -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest12()
        {
            string cmd = "Get-EmcXenServerHost -ID $GlobalId -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest13()
        {
            string cmd = "Get-EmcXenServerHost $GlobalId -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest14()
        {
            string cmd = "Get-EmcXenServerHost -ID $UUID -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest15()
        {
            string cmd = "Get-EmcXenServerHost $UUID -XenServer $XenServer";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest16()
        {
            string cmd = "Get-EmcXenServerHost -ID $Name -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest17()
        {
            string cmd = "Get-EmcXenServerHost $Name -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest18()
        {
            string cmd = "Get-EmcXenServerHost -ID $GlobalId -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest19()
        {
            string cmd = "Get-EmcXenServerHost $GlobalId -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest20()
        {
            string cmd = "Get-EmcXenServerHost -ID $UUID -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest21()
        {
            string cmd = "Get-EmcXenServerHost $UUID -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest22()
        {
            string cmd = "Get-EmcXenServerHost -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest23()
        {
            string cmd = "Get-EmcXenServerHost -ID $Name -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest24()
        {
            string cmd = "Get-EmcXenServerHost $Name -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest25()
        {
            string cmd = "Get-EmcXenServerHost -ID $GlobalId -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest26()
        {
            string cmd = "Get-EmcXenServerHost $GlobalId -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest27()
        {
            string cmd = "Get-EmcXenServerHost -ID $UUID -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerHostTest28()
        {
            string cmd = "Get-EmcXenServerHost $UUID -XenServer $XenServer -Silent";
            GetEmcXenServerHostTestMethod(cmd);
        }
        
    }
}

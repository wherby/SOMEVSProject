using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcStandbyLunTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcStandbyLunTest1()
        {
            string cmd = "Get-EmcStandbyLun -StorageSystem $StorageSystem";
            GetEmcStandbyLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStandbyLunTest2()
        {
            string cmd = "Get-EmcStandbyLun -ID $ID -StorageSystem $StorageSystem";
            GetEmcStandbyLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStandbyLunTest3()
        {
            string cmd = "Get-EmcStandbyLun $ID -StorageSystem $StorageSystem";
            GetEmcStandbyLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStandbyLunTest4()
        {
            string cmd = "Get-EmcStandbyLun -StorageSystem $StorageSystem -Silent";
            GetEmcStandbyLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStandbyLunTest5()
        {
            string cmd = "Get-EmcStandbyLun -ID $ID -StorageSystem $StorageSystem -Silent";
            GetEmcStandbyLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStandbyLunTest6()
        {
            string cmd = "Get-EmcStandbyLun $ID -StorageSystem $StorageSystem -Silent";
            GetEmcStandbyLunTestMethod(cmd);
        }
        
    }
}

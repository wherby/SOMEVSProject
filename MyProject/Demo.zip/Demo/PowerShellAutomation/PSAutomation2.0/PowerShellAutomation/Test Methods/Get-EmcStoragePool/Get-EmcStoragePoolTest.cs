using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcStoragePoolTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest1()
        {
            string cmd = "Get-EmcStoragePool";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest2()
        {
            string cmd = "Get-EmcStoragePool -ID $ID";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest3()
        {
            string cmd = "Get-EmcStoragePool $ID";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest4()
        {
            string cmd = "Get-EmcStoragePool -Lun $Lun";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest5()
        {
            string cmd = "Get-EmcStoragePool -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest6()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -Lun $Lun";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest7()
        {
            string cmd = "Get-EmcStoragePool $ID -Lun $Lun";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest8()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest9()
        {
            string cmd = "Get-EmcStoragePool $ID -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest10()
        {
            string cmd = "Get-EmcStoragePool -Lun $Lun -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest11()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -Lun $Lun -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest12()
        {
            string cmd = "Get-EmcStoragePool $ID -Lun $Lun -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest13()
        {
            string cmd = "Get-EmcStoragePool -StorageSystem $StorageSystem";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest14()
        {
            string cmd = "Get-EmcStoragePool -PoolType $PoolType";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest15()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -StorageSystem $StorageSystem";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest16()
        {
            string cmd = "Get-EmcStoragePool $ID -StorageSystem $StorageSystem";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest17()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -PoolType $PoolType";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest18()
        {
            string cmd = "Get-EmcStoragePool $ID -PoolType $PoolType";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest19()
        {
            string cmd = "Get-EmcStoragePool -StorageSystem $StorageSystem -PoolType $PoolType";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest20()
        {
            string cmd = "Get-EmcStoragePool -StorageSystem $StorageSystem -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest21()
        {
            string cmd = "Get-EmcStoragePool -PoolType $PoolType -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest22()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -StorageSystem $StorageSystem -PoolType $PoolType";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest23()
        {
            string cmd = "Get-EmcStoragePool $ID -StorageSystem $StorageSystem -PoolType $PoolType";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest24()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -StorageSystem $StorageSystem -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest25()
        {
            string cmd = "Get-EmcStoragePool $ID -StorageSystem $StorageSystem -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest26()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -PoolType $PoolType -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest27()
        {
            string cmd = "Get-EmcStoragePool $ID -PoolType $PoolType -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest28()
        {
            string cmd = "Get-EmcStoragePool -StorageSystem $StorageSystem -PoolType $PoolType -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest29()
        {
            string cmd = "Get-EmcStoragePool -ID $ID -StorageSystem $StorageSystem -PoolType $PoolType -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcStoragePoolTest30()
        {
            string cmd = "Get-EmcStoragePool $ID -StorageSystem $StorageSystem -PoolType $PoolType -Silent";
            GetEmcStoragePoolTestMethod(cmd);
        }
        
    }
}

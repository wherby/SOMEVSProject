using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcVirtualMachineHypervisorTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest1()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachineConfiguration $HypervVMConfig";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest2()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $HypervVMConfig";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest3()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachineConfiguration $VMWareVMConfig";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest4()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $VMWareVMConfig";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest5()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachineConfiguration $XenVMConfig";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest6()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $XenVMConfig";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest7()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachineConfiguration $HypervVMConfig -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest8()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $HypervVMConfig -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest9()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachineConfiguration $VMWareVMConfig -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest10()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $VMWareVMConfig -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest11()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachineConfiguration $XenVMConfig -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest12()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $XenVMConfig -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest13()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachine $HypervVirtualMachine";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest14()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $HypervVirtualMachine";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest15()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachine $VMWareVirtualMachine";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest16()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $VMWareVirtualMachine";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest17()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachine $XenVirtualMachine";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest18()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $XenVirtualMachine";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest19()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachine $HypervVirtualMachine -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest20()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $HypervVirtualMachine -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest21()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachine $VMWareVirtualMachine -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest22()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $VMWareVirtualMachine -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest23()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor -VirtualMachine $XenVirtualMachine -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineHypervisorTest24()
        {
            string cmd = "Get-EmcVirtualMachineHypervisor $XenVirtualMachine -Silent";
            GetEmcVirtualMachineHypervisorTestMethod(cmd);
        }
        
    }
}

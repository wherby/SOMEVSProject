using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class UpdateEmcSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest1()
        {
            string cmd = "Update-EmcSystem -EmcSystem $CLARiiON-CX4System";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest2()
        {
            string cmd = "Update-EmcSystem $CLARiiON-CX4System";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest3()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VMAXSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest4()
        {
            string cmd = "Update-EmcSystem $VMAXSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest5()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VMAXeSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest6()
        {
            string cmd = "Update-EmcSystem $VMAXeSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest7()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VNXSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest8()
        {
            string cmd = "Update-EmcSystem $VNXSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest9()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VNX-BlockSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest10()
        {
            string cmd = "Update-EmcSystem $VNX-BlockSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest11()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VNX-CIFSSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest12()
        {
            string cmd = "Update-EmcSystem $VNX-CIFSSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest13()
        {
            string cmd = "Update-EmcSystem -EmcSystem $HostSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest14()
        {
            string cmd = "Update-EmcSystem $HostSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest15()
        {
            string cmd = "Update-EmcSystem -EmcSystem $ClusterSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest16()
        {
            string cmd = "Update-EmcSystem $ClusterSystem";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest17()
        {
            string cmd = "Update-EmcSystem -EmcSystem $CLARiiON-CX4System -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest18()
        {
            string cmd = "Update-EmcSystem $CLARiiON-CX4System -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest19()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VMAXSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest20()
        {
            string cmd = "Update-EmcSystem $VMAXSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest21()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VMAXeSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest22()
        {
            string cmd = "Update-EmcSystem $VMAXeSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest23()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VNXSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest24()
        {
            string cmd = "Update-EmcSystem $VNXSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest25()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VNX-BlockSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest26()
        {
            string cmd = "Update-EmcSystem $VNX-BlockSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest27()
        {
            string cmd = "Update-EmcSystem -EmcSystem $VNX-CIFSSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest28()
        {
            string cmd = "Update-EmcSystem $VNX-CIFSSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest29()
        {
            string cmd = "Update-EmcSystem -EmcSystem $HostSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest30()
        {
            string cmd = "Update-EmcSystem $HostSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest31()
        {
            string cmd = "Update-EmcSystem -EmcSystem $ClusterSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_UpdateEmcSystemTest32()
        {
            string cmd = "Update-EmcSystem $ClusterSystem -Silent";
            UpdateEmcSystemTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class EnableEmcSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest1()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest2()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest3()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest4()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest5()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest6()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest7()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest8()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest9()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest10()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest11()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest12()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest13()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest14()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest15()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest16()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest17()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest18()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest19()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest20()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest21()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest22()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest23()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest24()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest25()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest26()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest27()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest28()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest29()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest30()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest31()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest32()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest33()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest34()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest35()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest36()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest37()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest38()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest39()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest40()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest41()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest42()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest43()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest44()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest45()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest46()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest47()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest48()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest49()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest50()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest51()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest52()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest53()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest54()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force -Silent";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest55()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest56()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest57()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest58()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest59()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest60()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest61()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest62()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SnapshotPool $SnapshotPool -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest63()
        {
            string cmd = "Enable-EmcSnapshotLun -SnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_EnableEmcSnapshotLunTest64()
        {
            string cmd = "Enable-EmcSnapshotLun $SnapshotLun -Confirm:$false -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Force -Silent -WhatIf";
            EnableEmcSnapshotLunTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class DisconnectEmcHostSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest1()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest2()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest3()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest4()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest5()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest6()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest7()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest8()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest9()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest10()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest11()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest12()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest13()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest14()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest15()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest16()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -Force";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest17()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest18()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest19()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest20()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest21()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest22()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest23()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest24()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest25()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest26()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest27()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest28()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest29()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest30()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest31()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest32()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest33()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest34()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest35()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest36()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest37()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -Force -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest38()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest39()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest40()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest41()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest42()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest43()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -Force -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest44()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest45()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest46()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest47()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest48()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest49()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest50()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest51()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $HostName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest52()
        {
            string cmd = "Disconnect-EmcHostSystem $HostName -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest53()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $IPAddress -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest54()
        {
            string cmd = "Disconnect-EmcHostSystem $IPAddress -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest55()
        {
            string cmd = "Disconnect-EmcHostSystem -Id $GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest56()
        {
            string cmd = "Disconnect-EmcHostSystem $GlobalId -Confirm:$false -Force -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest57()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -System $System";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest58()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -System $System";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest59()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -System $System -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest60()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -System $System -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest61()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -System $System -Silent";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest62()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -System $System -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest63()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -System $System -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_DisconnectEmcHostSystemTest64()
        {
            string cmd = "Disconnect-EmcHostSystem -Confirm:$false -Force -System $System -Silent -WhatIf";
            DisconnectEmcHostSystemTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ExpandEmcLunTest
    {
        
        
      
        [TestMethod]
        public void PS_ExpandEmcLunTest1()
        {
            string cmd = "Expand-EmcLun -Lun $Lun -NewCapacity $NewCapacity";
            ExpandEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcLunTest2()
        {
            string cmd = "Expand-EmcLun -Lun $Lun -NewCapacity $NewCapacity -Silent";
            ExpandEmcLunTestMethod(cmd);
        }
        
    }
}

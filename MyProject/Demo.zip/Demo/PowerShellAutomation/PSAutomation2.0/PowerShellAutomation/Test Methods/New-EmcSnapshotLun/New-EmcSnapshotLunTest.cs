using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest1()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest2()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest3()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest4()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -NoActivation";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest5()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest6()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest7()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest8()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -NoActivation";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest9()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest10()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest11()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -NoActivation";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest12()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest13()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest14()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -NoActivation -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest15()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -NoActivation -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest16()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest17()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -NoActivation";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest18()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest19()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest20()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -NoActivation -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest21()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -NoActivation -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest22()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest23()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -NoActivation -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest24()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -NoActivation -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest25()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest26()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -NoActivation -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest27()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -NoActivation -Retention $Retention";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest28()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -NoActivation -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest29()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest30()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -NoActivation -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest31()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -Name $Name -NoActivation -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcSnapshotLunTest32()
        {
            string cmd = "New-EmcSnapshotLun -SourceLun $SourceLun -SnapshotPool $SnapshotPool -Name $Name -NoActivation -Retention $Retention -Silent";
            NewEmcSnapshotLunTestMethod(cmd);
        }
        
    }
}

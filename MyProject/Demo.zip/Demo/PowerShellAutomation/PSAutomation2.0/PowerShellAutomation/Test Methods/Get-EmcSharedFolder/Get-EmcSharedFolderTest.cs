using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcSharedFolderTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest1()
        {
            string cmd = "Get-EmcSharedFolder";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest2()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest3()
        {
            string cmd = "Get-EmcSharedFolder $ID";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest4()
        {
            string cmd = "Get-EmcSharedFolder -CifsStorageSystem $CifsStorageSystem";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest5()
        {
            string cmd = "Get-EmcSharedFolder -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest6()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -CifsStorageSystem $CifsStorageSystem";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest7()
        {
            string cmd = "Get-EmcSharedFolder $ID -CifsStorageSystem $CifsStorageSystem";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest8()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest9()
        {
            string cmd = "Get-EmcSharedFolder $ID -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest10()
        {
            string cmd = "Get-EmcSharedFolder -CifsStorageSystem $CifsStorageSystem -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest11()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -CifsStorageSystem $CifsStorageSystem -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest12()
        {
            string cmd = "Get-EmcSharedFolder $ID -CifsStorageSystem $CifsStorageSystem -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest13()
        {
            string cmd = "Get-EmcSharedFolder -Pool $Pool";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest14()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -Pool $Pool";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest15()
        {
            string cmd = "Get-EmcSharedFolder $ID -Pool $Pool";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest16()
        {
            string cmd = "Get-EmcSharedFolder -Pool $Pool -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest17()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -Pool $Pool -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest18()
        {
            string cmd = "Get-EmcSharedFolder $ID -Pool $Pool -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest19()
        {
            string cmd = "Get-EmcSharedFolder -NetworkShare $NetworkShare";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest20()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -NetworkShare $NetworkShare";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest21()
        {
            string cmd = "Get-EmcSharedFolder $ID -NetworkShare $NetworkShare";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest22()
        {
            string cmd = "Get-EmcSharedFolder -NetworkShare $NetworkShare -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest23()
        {
            string cmd = "Get-EmcSharedFolder -ID $ID -NetworkShare $NetworkShare -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSharedFolderTest24()
        {
            string cmd = "Get-EmcSharedFolder $ID -NetworkShare $NetworkShare -Silent";
            GetEmcSharedFolderTestMethod(cmd);
        }
        
    }
}

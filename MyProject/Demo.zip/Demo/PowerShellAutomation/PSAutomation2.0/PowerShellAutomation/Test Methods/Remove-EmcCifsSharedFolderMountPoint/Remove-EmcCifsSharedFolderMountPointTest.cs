using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcCifsSharedFolderMountPointTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderMountPointTest1()
        {
            string cmd = "Remove-EmcCifsSharedFolderMountPoint -HostSystem $HostSystem -SharedFolder $SharedFolder";
            RemoveEmcCifsSharedFolderMountPointTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderMountPointTest2()
        {
            string cmd = "Remove-EmcCifsSharedFolderMountPoint -HostSystem $HostSystem -SharedFolder $SharedFolder -Silent";
            RemoveEmcCifsSharedFolderMountPointTestMethod(cmd);
        }
        
    }
}

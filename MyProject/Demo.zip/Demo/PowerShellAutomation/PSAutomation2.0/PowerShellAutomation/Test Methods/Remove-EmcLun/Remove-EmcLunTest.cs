using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcLunTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcLunTest1()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest2()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest3()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -Force";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest4()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -Force";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest5()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -Silent";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest6()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -Silent";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest7()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest8()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest9()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -Force -Silent";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest10()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -Force -Silent";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest11()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -Force -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest12()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -Force -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest13()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -Silent -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest14()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -Silent -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest15()
        {
            string cmd = "Remove-EmcLun -Lun $Lun -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcLunTest16()
        {
            string cmd = "Remove-EmcLun $Lun -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcLunTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcDataStoreTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest1()
        {
            string cmd = "Get-EmcDataStore";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest2()
        {
            string cmd = "Get-EmcDataStore -ID $Name";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest3()
        {
            string cmd = "Get-EmcDataStore $Name";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest4()
        {
            string cmd = "Get-EmcDataStore -ID $UUID";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest5()
        {
            string cmd = "Get-EmcDataStore $UUID";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest6()
        {
            string cmd = "Get-EmcDataStore -VMwareSystem $VMwareSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest7()
        {
            string cmd = "Get-EmcDataStore -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest8()
        {
            string cmd = "Get-EmcDataStore -ID $Name -VMwareSystem $VMwareSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest9()
        {
            string cmd = "Get-EmcDataStore $Name -VMwareSystem $VMwareSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest10()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -VMwareSystem $VMwareSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest11()
        {
            string cmd = "Get-EmcDataStore $UUID -VMwareSystem $VMwareSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest12()
        {
            string cmd = "Get-EmcDataStore -ID $Name -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest13()
        {
            string cmd = "Get-EmcDataStore $Name -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest14()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest15()
        {
            string cmd = "Get-EmcDataStore $UUID -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest16()
        {
            string cmd = "Get-EmcDataStore -VMwareSystem $VMwareSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest17()
        {
            string cmd = "Get-EmcDataStore -ID $Name -VMwareSystem $VMwareSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest18()
        {
            string cmd = "Get-EmcDataStore $Name -VMwareSystem $VMwareSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest19()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -VMwareSystem $VMwareSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest20()
        {
            string cmd = "Get-EmcDataStore $UUID -VMwareSystem $VMwareSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest21()
        {
            string cmd = "Get-EmcDataStore -ESXHostSystem $ESXHostSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest22()
        {
            string cmd = "Get-EmcDataStore -ID $Name -ESXHostSystem $ESXHostSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest23()
        {
            string cmd = "Get-EmcDataStore $Name -ESXHostSystem $ESXHostSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest24()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -ESXHostSystem $ESXHostSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest25()
        {
            string cmd = "Get-EmcDataStore $UUID -ESXHostSystem $ESXHostSystem";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest26()
        {
            string cmd = "Get-EmcDataStore -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest27()
        {
            string cmd = "Get-EmcDataStore -ID $Name -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest28()
        {
            string cmd = "Get-EmcDataStore $Name -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest29()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest30()
        {
            string cmd = "Get-EmcDataStore $UUID -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest31()
        {
            string cmd = "Get-EmcDataStore -ScsiLun $ScsiLun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest32()
        {
            string cmd = "Get-EmcDataStore -ID $Name -ScsiLun $ScsiLun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest33()
        {
            string cmd = "Get-EmcDataStore $Name -ScsiLun $ScsiLun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest34()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -ScsiLun $ScsiLun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest35()
        {
            string cmd = "Get-EmcDataStore $UUID -ScsiLun $ScsiLun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest36()
        {
            string cmd = "Get-EmcDataStore -ScsiLun $ScsiLun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest37()
        {
            string cmd = "Get-EmcDataStore -ID $Name -ScsiLun $ScsiLun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest38()
        {
            string cmd = "Get-EmcDataStore $Name -ScsiLun $ScsiLun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest39()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -ScsiLun $ScsiLun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest40()
        {
            string cmd = "Get-EmcDataStore $UUID -ScsiLun $ScsiLun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest41()
        {
            string cmd = "Get-EmcDataStore -Lun $Lun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest42()
        {
            string cmd = "Get-EmcDataStore -ID $Name -Lun $Lun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest43()
        {
            string cmd = "Get-EmcDataStore $Name -Lun $Lun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest44()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -Lun $Lun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest45()
        {
            string cmd = "Get-EmcDataStore $UUID -Lun $Lun";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest46()
        {
            string cmd = "Get-EmcDataStore -Lun $Lun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest47()
        {
            string cmd = "Get-EmcDataStore -ID $Name -Lun $Lun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest48()
        {
            string cmd = "Get-EmcDataStore $Name -Lun $Lun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest49()
        {
            string cmd = "Get-EmcDataStore -ID $UUID -Lun $Lun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcDataStoreTest50()
        {
            string cmd = "Get-EmcDataStore $UUID -Lun $Lun -Silent";
            GetEmcDataStoreTestMethod(cmd);
        }
        
    }
}

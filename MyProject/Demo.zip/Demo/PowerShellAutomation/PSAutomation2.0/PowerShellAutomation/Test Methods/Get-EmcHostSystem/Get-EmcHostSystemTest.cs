using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcHostSystemTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest1()
        {
            string cmd = "Get-EmcHostSystem";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest2()
        {
            string cmd = "Get-EmcHostSystem -Id $HostName";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest3()
        {
            string cmd = "Get-EmcHostSystem $HostName";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest4()
        {
            string cmd = "Get-EmcHostSystem -Id $IPAddress";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest5()
        {
            string cmd = "Get-EmcHostSystem $IPAddress";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest6()
        {
            string cmd = "Get-EmcHostSystem -Id $GlobalId";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest7()
        {
            string cmd = "Get-EmcHostSystem $GlobalId";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest8()
        {
            string cmd = "Get-EmcHostSystem -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest9()
        {
            string cmd = "Get-EmcHostSystem -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest10()
        {
            string cmd = "Get-EmcHostSystem -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest11()
        {
            string cmd = "Get-EmcHostSystem -Id $HostName -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest12()
        {
            string cmd = "Get-EmcHostSystem $HostName -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest13()
        {
            string cmd = "Get-EmcHostSystem -Id $IPAddress -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest14()
        {
            string cmd = "Get-EmcHostSystem $IPAddress -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest15()
        {
            string cmd = "Get-EmcHostSystem -Id $GlobalId -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest16()
        {
            string cmd = "Get-EmcHostSystem $GlobalId -HostSystemType $VmWare";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest17()
        {
            string cmd = "Get-EmcHostSystem -Id $HostName -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest18()
        {
            string cmd = "Get-EmcHostSystem $HostName -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest19()
        {
            string cmd = "Get-EmcHostSystem -Id $IPAddress -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest20()
        {
            string cmd = "Get-EmcHostSystem $IPAddress -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest21()
        {
            string cmd = "Get-EmcHostSystem -Id $GlobalId -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest22()
        {
            string cmd = "Get-EmcHostSystem $GlobalId -HostSystemType $HyperV";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest23()
        {
            string cmd = "Get-EmcHostSystem -Id $HostName -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest24()
        {
            string cmd = "Get-EmcHostSystem $HostName -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest25()
        {
            string cmd = "Get-EmcHostSystem -Id $IPAddress -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest26()
        {
            string cmd = "Get-EmcHostSystem $IPAddress -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest27()
        {
            string cmd = "Get-EmcHostSystem -Id $GlobalId -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest28()
        {
            string cmd = "Get-EmcHostSystem $GlobalId -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest29()
        {
            string cmd = "Get-EmcHostSystem -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest30()
        {
            string cmd = "Get-EmcHostSystem -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest31()
        {
            string cmd = "Get-EmcHostSystem -Id $HostName -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest32()
        {
            string cmd = "Get-EmcHostSystem $HostName -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest33()
        {
            string cmd = "Get-EmcHostSystem -Id $IPAddress -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest34()
        {
            string cmd = "Get-EmcHostSystem $IPAddress -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest35()
        {
            string cmd = "Get-EmcHostSystem -Id $GlobalId -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest36()
        {
            string cmd = "Get-EmcHostSystem $GlobalId -HostSystemType $VmWare -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest37()
        {
            string cmd = "Get-EmcHostSystem -Id $HostName -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest38()
        {
            string cmd = "Get-EmcHostSystem $HostName -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest39()
        {
            string cmd = "Get-EmcHostSystem -Id $IPAddress -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest40()
        {
            string cmd = "Get-EmcHostSystem $IPAddress -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest41()
        {
            string cmd = "Get-EmcHostSystem -Id $GlobalId -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest42()
        {
            string cmd = "Get-EmcHostSystem $GlobalId -HostSystemType $HyperV -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest43()
        {
            string cmd = "Get-EmcHostSystem -HostDisk $HostDisk";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest44()
        {
            string cmd = "Get-EmcHostSystem -HostDisk $HostDisk -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest45()
        {
            string cmd = "Get-EmcHostSystem -Volume $Volume";
            GetEmcHostSystemTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostSystemTest46()
        {
            string cmd = "Get-EmcHostSystem -Volume $Volume -Silent";
            GetEmcHostSystemTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcClusterDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest1()
        {
            string cmd = "Get-EmcClusterDisk";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest2()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest3()
        {
            string cmd = "Get-EmcClusterDisk $ID";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest4()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSystem $ClusterSystem";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest5()
        {
            string cmd = "Get-EmcClusterDisk -ClusterGroupName $ClusterGroupName";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest6()
        {
            string cmd = "Get-EmcClusterDisk -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest7()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSystem $ClusterSystem";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest8()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSystem $ClusterSystem";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest9()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterGroupName $ClusterGroupName";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest10()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterGroupName $ClusterGroupName";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest11()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest12()
        {
            string cmd = "Get-EmcClusterDisk $ID -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest13()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest14()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest15()
        {
            string cmd = "Get-EmcClusterDisk -ClusterGroupName $ClusterGroupName -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest16()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest17()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest18()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSystem $ClusterSystem -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest19()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSystem $ClusterSystem -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest20()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterGroupName $ClusterGroupName -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest21()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterGroupName $ClusterGroupName -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest22()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest23()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest24()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest25()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSharedVolume";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest26()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSharedVolume";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest27()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSharedVolume";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest28()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSystem $ClusterSystem -ClusterSharedVolume";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest29()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSharedVolume -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest30()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSystem $ClusterSystem -ClusterSharedVolume";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest31()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSystem $ClusterSystem -ClusterSharedVolume";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest32()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSharedVolume -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest33()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSharedVolume -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest34()
        {
            string cmd = "Get-EmcClusterDisk -ClusterSystem $ClusterSystem -ClusterSharedVolume -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest35()
        {
            string cmd = "Get-EmcClusterDisk -ID $ID -ClusterSystem $ClusterSystem -ClusterSharedVolume -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterDiskTest36()
        {
            string cmd = "Get-EmcClusterDisk $ID -ClusterSystem $ClusterSystem -ClusterSharedVolume -Silent";
            GetEmcClusterDiskTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcVNXSharedFolderPoolTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest1()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest2()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest3()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -Force";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest4()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -Force";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest5()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -Silent";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest6()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -Silent";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest7()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest8()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest9()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -Force -Silent";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest10()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -Force -Silent";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest11()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -Force -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest12()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -Force -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest13()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -Silent -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest14()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -Silent -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest15()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool -SharedFolderPool $SharedFolderPool -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcVNXSharedFolderPoolTest16()
        {
            string cmd = "Remove-EmcVNXSharedFolderPool $SharedFolderPool -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcVNXSharedFolderPoolTestMethod(cmd);
        }
        
    }
}

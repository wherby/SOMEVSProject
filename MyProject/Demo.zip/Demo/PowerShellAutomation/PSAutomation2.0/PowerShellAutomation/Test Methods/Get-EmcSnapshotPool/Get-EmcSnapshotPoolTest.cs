using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcSnapshotPoolTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest1()
        {
            string cmd = "Get-EmcSnapshotPool";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest2()
        {
            string cmd = "Get-EmcSnapshotPool -ID $ID";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest3()
        {
            string cmd = "Get-EmcSnapshotPool $ID";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest4()
        {
            string cmd = "Get-EmcSnapshotPool -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest5()
        {
            string cmd = "Get-EmcSnapshotPool -Silent";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest6()
        {
            string cmd = "Get-EmcSnapshotPool -ID $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest7()
        {
            string cmd = "Get-EmcSnapshotPool $ID -BlockStorageSystem $BlockStorageSystem";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest8()
        {
            string cmd = "Get-EmcSnapshotPool -ID $ID -Silent";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest9()
        {
            string cmd = "Get-EmcSnapshotPool $ID -Silent";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest10()
        {
            string cmd = "Get-EmcSnapshotPool -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest11()
        {
            string cmd = "Get-EmcSnapshotPool -ID $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcSnapshotPoolTest12()
        {
            string cmd = "Get-EmcSnapshotPool $ID -BlockStorageSystem $BlockStorageSystem -Silent";
            GetEmcSnapshotPoolTestMethod(cmd);
        }
        
    }
}

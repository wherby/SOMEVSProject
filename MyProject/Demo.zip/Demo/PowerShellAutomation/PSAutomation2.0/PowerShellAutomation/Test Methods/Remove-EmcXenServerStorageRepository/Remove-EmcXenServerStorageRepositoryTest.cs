using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcXenServerStorageRepositoryTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcXenServerStorageRepositoryTest1()
        {
            string cmd = "Remove-EmcXenServerStorageRepository -StorageRepository $StorageRepository";
            RemoveEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcXenServerStorageRepositoryTest2()
        {
            string cmd = "Remove-EmcXenServerStorageRepository -StorageRepository $StorageRepository -Silent";
            RemoveEmcXenServerStorageRepositoryTestMethod(cmd);
        }
        
    }
}

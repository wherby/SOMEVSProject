using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcAvailablePassthroughDiskCandidateTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest1()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate -Hypervisor $Hyperv";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest2()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate $Hyperv";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest3()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate -Hypervisor $VMWare";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest4()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate $VMWare";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest5()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate -Hypervisor $Hyperv -Silent";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest6()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate $Hyperv -Silent";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest7()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate -Hypervisor $VMWare -Silent";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest8()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate $VMWare -Silent";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest9()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate -EsxHostSystem $EsxHostSystem";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest10()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate $EsxHostSystem";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest11()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate -EsxHostSystem $EsxHostSystem -Silent";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcAvailablePassthroughDiskCandidateTest12()
        {
            string cmd = "Get-EmcAvailablePassthroughDiskCandidate $EsxHostSystem -Silent";
            GetEmcAvailablePassthroughDiskCandidateTestMethod(cmd);
        }
        
    }
}

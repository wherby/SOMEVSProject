using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcXenServerVirtualDiskImageTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcXenServerVirtualDiskImageTest1()
        {
            string cmd = "Remove-EmcXenServerVirtualDiskImage -VirtualDiskImage $VirtualDiskImage";
            RemoveEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcXenServerVirtualDiskImageTest2()
        {
            string cmd = "Remove-EmcXenServerVirtualDiskImage -VirtualDiskImage $VirtualDiskImage -Silent";
            RemoveEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
        
    }
}

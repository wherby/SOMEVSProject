using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcCandidateSnapshotLunTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest1()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest2()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -SnapshotPool $SnapshotPool";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest3()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -NameHint $NameHint";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest4()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -Silent";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest5()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -SnapshotPool $SnapshotPool -NameHint $NameHint";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest6()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -SnapshotPool $SnapshotPool -Silent";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest7()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -NameHint $NameHint -Silent";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcCandidateSnapshotLunTest8()
        {
            string cmd = "New-EmcCandidateSnapshotLun -SourceLun $SourceLun -Count $Count -SnapshotPool $SnapshotPool -NameHint $NameHint -Silent";
            NewEmcCandidateSnapshotLunTestMethod(cmd);
        }
        
    }
}

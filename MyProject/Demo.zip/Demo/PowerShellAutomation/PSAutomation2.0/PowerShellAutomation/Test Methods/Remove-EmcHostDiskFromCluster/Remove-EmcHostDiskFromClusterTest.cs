using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcHostDiskFromClusterTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest1()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest2()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -Force";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest3()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -Silent";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest4()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest5()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -Force -Silent";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest6()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -Force -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest7()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -Silent -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest8()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterDisk $ClusterDisk -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest9()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest10()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -Force";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest11()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -Silent";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest12()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest13()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -Force -Silent";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest14()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -Force -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest15()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -Silent -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest16()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest17()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest18()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -Force";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest19()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -Silent";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest20()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest21()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -Force -Silent";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest22()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -Force -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest23()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -Silent -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcHostDiskFromClusterTest24()
        {
            string cmd = "Remove-EmcHostDiskFromCluster -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcHostDiskFromClusterTestMethod(cmd);
        }
        
    }
}

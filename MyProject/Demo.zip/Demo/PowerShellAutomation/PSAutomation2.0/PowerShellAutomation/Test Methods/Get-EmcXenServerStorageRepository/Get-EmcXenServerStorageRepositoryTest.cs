using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcXenServerStorageRepositoryTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest1()
        {
            string cmd = "Get-EmcXenServerStorageRepository";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest2()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $Name";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest3()
        {
            string cmd = "Get-EmcXenServerStorageRepository $Name";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest4()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $UUID";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest5()
        {
            string cmd = "Get-EmcXenServerStorageRepository $UUID";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest6()
        {
            string cmd = "Get-EmcXenServerStorageRepository -XenServer $XenServer";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest7()
        {
            string cmd = "Get-EmcXenServerStorageRepository -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest8()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $Name -XenServer $XenServer";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest9()
        {
            string cmd = "Get-EmcXenServerStorageRepository $Name -XenServer $XenServer";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest10()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $UUID -XenServer $XenServer";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest11()
        {
            string cmd = "Get-EmcXenServerStorageRepository $UUID -XenServer $XenServer";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest12()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $Name -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest13()
        {
            string cmd = "Get-EmcXenServerStorageRepository $Name -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest14()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $UUID -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest15()
        {
            string cmd = "Get-EmcXenServerStorageRepository $UUID -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest16()
        {
            string cmd = "Get-EmcXenServerStorageRepository -XenServer $XenServer -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest17()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $Name -XenServer $XenServer -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest18()
        {
            string cmd = "Get-EmcXenServerStorageRepository $Name -XenServer $XenServer -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest19()
        {
            string cmd = "Get-EmcXenServerStorageRepository -ID $UUID -XenServer $XenServer -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerStorageRepositoryTest20()
        {
            string cmd = "Get-EmcXenServerStorageRepository $UUID -XenServer $XenServer -Silent";
            GetEmcXenServerStorageRepositoryTestMethod(cmd);
        }
        
    }
}

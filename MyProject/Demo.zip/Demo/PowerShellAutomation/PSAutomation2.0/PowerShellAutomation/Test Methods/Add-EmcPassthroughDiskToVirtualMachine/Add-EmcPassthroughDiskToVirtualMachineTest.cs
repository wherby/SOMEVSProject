using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class AddEmcPassthroughDiskToVirtualMachineTest
    {
        
        
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest1()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest2()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest3()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest4()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest5()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest6()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest7()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest8()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskId $DiskId -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest9()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest10()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest11()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest12()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest13()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest14()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest15()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest16()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -DiskNumber $DiskNumber -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest17()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest18()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest19()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest20()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest21()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest22()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest23()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest24()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -HostDisk $HostDisk -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest25()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest26()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest27()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest28()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest29()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest30()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest31()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest32()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest33()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest34()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest35()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest36()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest37()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest38()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest39()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest40()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest41()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest42()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest43()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest44()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest45()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest46()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest47()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest48()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest49()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest50()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest51()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest52()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest53()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest54()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest55()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest56()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest57()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest58()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest59()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest60()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest61()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest62()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest63()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest64()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest65()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest66()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest67()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest68()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest69()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest70()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest71()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest72()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest73()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest74()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest75()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest76()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest77()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest78()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest79()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest80()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest81()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest82()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest83()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest84()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest85()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest86()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest87()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest88()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest89()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest90()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest91()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest92()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest93()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest94()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest95()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest96()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest97()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest98()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest99()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest100()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest101()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest102()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest103()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest104()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest105()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest106()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest107()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest108()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest109()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest110()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest111()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest112()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest113()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest114()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest115()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest116()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest117()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest118()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest119()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest120()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest121()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest122()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest123()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest124()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest125()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest126()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest127()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest128()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest129()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest130()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest131()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest132()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest133()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest134()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest135()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest136()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest137()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest138()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest139()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest140()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest141()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest142()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest143()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest144()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest145()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest146()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest147()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest148()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest149()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest150()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest151()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest152()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest153()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest154()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest155()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest156()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest157()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest158()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest159()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest160()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest161()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest162()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest163()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest164()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest165()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest166()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest167()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest168()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest169()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest170()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest171()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest172()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest173()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest174()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest175()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest176()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest177()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest178()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest179()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest180()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest181()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest182()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest183()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest184()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest185()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest186()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest187()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest188()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest189()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest190()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest191()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest192()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest193()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest194()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest195()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest196()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest197()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest198()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest199()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest200()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest201()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest202()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest203()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest204()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest205()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest206()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest207()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest208()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest209()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest210()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest211()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest212()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest213()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Physical -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest214()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $Persistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest215()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcPassthroughDiskToVirtualMachineTest216()
        {
            string cmd = "Add-EmcPassthroughDiskToVirtualMachine -ScsiLun $ScsiLun -VirtualMachineConfiguration $VirtualMachineConfiguration -Location $Location -Persistence $IndependentNonPersistent -Compatibility $Virtual -Datastore $Datastore -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            AddEmcPassthroughDiskToVirtualMachineTestMethod(cmd);
        }
        
    }
}

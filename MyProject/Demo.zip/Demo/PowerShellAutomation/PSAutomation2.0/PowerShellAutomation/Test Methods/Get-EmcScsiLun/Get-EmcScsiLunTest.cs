using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcScsiLunTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest1()
        {
            string cmd = "Get-EmcScsiLun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest2()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest3()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest4()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest5()
        {
            string cmd = "Get-EmcScsiLun $DeviceName";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest6()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest7()
        {
            string cmd = "Get-EmcScsiLun $UUID";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest8()
        {
            string cmd = "Get-EmcScsiLun -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest9()
        {
            string cmd = "Get-EmcScsiLun -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest10()
        {
            string cmd = "Get-EmcScsiLun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest11()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest12()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest13()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest14()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest15()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest16()
        {
            string cmd = "Get-EmcScsiLun $UUID -VMwareSystem $VMwareSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest17()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest18()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest19()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest20()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest21()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest22()
        {
            string cmd = "Get-EmcScsiLun $UUID -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest23()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest24()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest25()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest26()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest27()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest28()
        {
            string cmd = "Get-EmcScsiLun $UUID -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest29()
        {
            string cmd = "Get-EmcScsiLun -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest30()
        {
            string cmd = "Get-EmcScsiLun -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest31()
        {
            string cmd = "Get-EmcScsiLun -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest32()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest33()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest34()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest35()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest36()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest37()
        {
            string cmd = "Get-EmcScsiLun $UUID -VMwareSystem $VMwareSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest38()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest39()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest40()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest41()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest42()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest43()
        {
            string cmd = "Get-EmcScsiLun $UUID -VMwareSystem $VMwareSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest44()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest45()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest46()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest47()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest48()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest49()
        {
            string cmd = "Get-EmcScsiLun $UUID -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest50()
        {
            string cmd = "Get-EmcScsiLun -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest51()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest52()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest53()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest54()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest55()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest56()
        {
            string cmd = "Get-EmcScsiLun $UUID -VMwareSystem $VMwareSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest57()
        {
            string cmd = "Get-EmcScsiLun -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest58()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest59()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest60()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest61()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest62()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest63()
        {
            string cmd = "Get-EmcScsiLun $UUID -ESXHostSystem $ESXHostSystem";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest64()
        {
            string cmd = "Get-EmcScsiLun -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest65()
        {
            string cmd = "Get-EmcScsiLun -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest66()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest67()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest68()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest69()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest70()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest71()
        {
            string cmd = "Get-EmcScsiLun $UUID -ESXHostSystem $ESXHostSystem -Lun $Lun";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest72()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest73()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest74()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest75()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest76()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest77()
        {
            string cmd = "Get-EmcScsiLun $UUID -ESXHostSystem $ESXHostSystem -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest78()
        {
            string cmd = "Get-EmcScsiLun -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest79()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest80()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest81()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest82()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest83()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest84()
        {
            string cmd = "Get-EmcScsiLun $UUID -ESXHostSystem $ESXHostSystem -Lun $Lun -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest85()
        {
            string cmd = "Get-EmcScsiLun -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest86()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest87()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest88()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest89()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest90()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest91()
        {
            string cmd = "Get-EmcScsiLun $UUID -Datastore $Datastore";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest92()
        {
            string cmd = "Get-EmcScsiLun -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest93()
        {
            string cmd = "Get-EmcScsiLun -ID $CanonicalName -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest94()
        {
            string cmd = "Get-EmcScsiLun $CanonicalName -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest95()
        {
            string cmd = "Get-EmcScsiLun -ID $DeviceName -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest96()
        {
            string cmd = "Get-EmcScsiLun $DeviceName -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest97()
        {
            string cmd = "Get-EmcScsiLun -ID $UUID -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcScsiLunTest98()
        {
            string cmd = "Get-EmcScsiLun $UUID -Datastore $Datastore -Silent";
            GetEmcScsiLunTestMethod(cmd);
        }
        
    }
}

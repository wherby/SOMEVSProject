using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcVirtualMachineScsiControllerTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest1()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachineConfiguration $HypervVMConfig";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest2()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $HypervVMConfig";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest3()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachineConfiguration $VMWareVMConfig";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest4()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $VMWareVMConfig";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest5()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachineConfiguration $HypervVMConfig -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest6()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $HypervVMConfig -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest7()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachineConfiguration $VMWareVMConfig -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest8()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $VMWareVMConfig -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest9()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachine $HypervVirtualMachine";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest10()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $HypervVirtualMachine";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest11()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachine $VMWareVirtualMachine";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest12()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $VMWareVirtualMachine";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest13()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachine $HypervVirtualMachine -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest14()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $HypervVirtualMachine -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest15()
        {
            string cmd = "Get-EmcVirtualMachineScsiController -VirtualMachine $VMWareVirtualMachine -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineScsiControllerTest16()
        {
            string cmd = "Get-EmcVirtualMachineScsiController $VMWareVirtualMachine -Silent";
            GetEmcVirtualMachineScsiControllerTestMethod(cmd);
        }
        
    }
}

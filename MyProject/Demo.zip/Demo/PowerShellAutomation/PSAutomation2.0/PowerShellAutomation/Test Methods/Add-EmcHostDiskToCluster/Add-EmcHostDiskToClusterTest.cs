using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class AddEmcHostDiskToClusterTest
    {
        
        
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest1()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostLunIdentifier $HostLunIdentifier -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest2()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostLunIdentifier $HostLunIdentifier -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName -Silent";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest3()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostLunIdentifier $HostLunIdentifier -ClusterSystem $ClusterSystem -AddToClusterSharedVolume";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest4()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostLunIdentifier $HostLunIdentifier -ClusterSystem $ClusterSystem -AddToClusterSharedVolume -Silent";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest5()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostDisk $HostDisk -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest6()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostDisk $HostDisk -ClusterSystem $ClusterSystem -ClusterGroupName $ClusterGroupName -Silent";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest7()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostDisk $HostDisk -ClusterSystem $ClusterSystem -AddToClusterSharedVolume";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_AddEmcHostDiskToClusterTest8()
        {
            string cmd = "Add-EmcHostDiskToCluster -HostDisk $HostDisk -ClusterSystem $ClusterSystem -AddToClusterSharedVolume -Silent";
            AddEmcHostDiskToClusterTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcStandByLunTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcStandByLunTest1()
        {
            string cmd = "New-EmcStandByLun -StorageSystem $StorageSystem -Count $Count -Capacity $Capacity";
            NewEmcStandByLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcStandByLunTest2()
        {
            string cmd = "New-EmcStandByLun -StorageSystem $StorageSystem -Count $Count -Capacity $Capacity -Silent";
            NewEmcStandByLunTestMethod(cmd);
        }
        
    }
}

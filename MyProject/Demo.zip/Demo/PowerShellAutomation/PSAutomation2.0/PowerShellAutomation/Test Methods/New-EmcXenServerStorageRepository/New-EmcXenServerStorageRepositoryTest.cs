using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcXenServerStorageRepositoryTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcXenServerStorageRepositoryTest1()
        {
            string cmd = "New-EmcXenServerStorageRepository -Lun $Lun -XenServer $XenServer -Name $Name -TargetPort $TargetPort";
            NewEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcXenServerStorageRepositoryTest2()
        {
            string cmd = "New-EmcXenServerStorageRepository -Lun $Lun -XenServer $XenServer -Name $Name -TargetPort $TargetPort -Description $Description";
            NewEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcXenServerStorageRepositoryTest3()
        {
            string cmd = "New-EmcXenServerStorageRepository -Lun $Lun -XenServer $XenServer -Name $Name -TargetPort $TargetPort -Silent";
            NewEmcXenServerStorageRepositoryTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcXenServerStorageRepositoryTest4()
        {
            string cmd = "New-EmcXenServerStorageRepository -Lun $Lun -XenServer $XenServer -Name $Name -TargetPort $TargetPort -Description $Description -Silent";
            NewEmcXenServerStorageRepositoryTestMethod(cmd);
        }
        
    }
}

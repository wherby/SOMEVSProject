using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcClusterGroupTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcClusterGroupTest1()
        {
            string cmd = "Get-EmcClusterGroup -ClusterSystem $ClusterSystem";
            GetEmcClusterGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterGroupTest2()
        {
            string cmd = "Get-EmcClusterGroup $ClusterSystem";
            GetEmcClusterGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterGroupTest3()
        {
            string cmd = "Get-EmcClusterGroup -ClusterSystem $ClusterSystem -Silent";
            GetEmcClusterGroupTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcClusterGroupTest4()
        {
            string cmd = "Get-EmcClusterGroup $ClusterSystem -Silent";
            GetEmcClusterGroupTestMethod(cmd);
        }
        
    }
}

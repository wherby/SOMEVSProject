using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcESXHostTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcESXHostTest1()
        {
            string cmd = "Get-EmcESXHost";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest2()
        {
            string cmd = "Get-EmcESXHost -ID $Name";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest3()
        {
            string cmd = "Get-EmcESXHost $Name";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest4()
        {
            string cmd = "Get-EmcESXHost -ID $UUID";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest5()
        {
            string cmd = "Get-EmcESXHost $UUID";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest6()
        {
            string cmd = "Get-EmcESXHost -VMwareSystem $VMwareSystem";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest7()
        {
            string cmd = "Get-EmcESXHost -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest8()
        {
            string cmd = "Get-EmcESXHost -ID $Name -VMwareSystem $VMwareSystem";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest9()
        {
            string cmd = "Get-EmcESXHost $Name -VMwareSystem $VMwareSystem";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest10()
        {
            string cmd = "Get-EmcESXHost -ID $UUID -VMwareSystem $VMwareSystem";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest11()
        {
            string cmd = "Get-EmcESXHost $UUID -VMwareSystem $VMwareSystem";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest12()
        {
            string cmd = "Get-EmcESXHost -ID $Name -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest13()
        {
            string cmd = "Get-EmcESXHost $Name -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest14()
        {
            string cmd = "Get-EmcESXHost -ID $UUID -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest15()
        {
            string cmd = "Get-EmcESXHost $UUID -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest16()
        {
            string cmd = "Get-EmcESXHost -VMwareSystem $VMwareSystem -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest17()
        {
            string cmd = "Get-EmcESXHost -ID $Name -VMwareSystem $VMwareSystem -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest18()
        {
            string cmd = "Get-EmcESXHost $Name -VMwareSystem $VMwareSystem -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest19()
        {
            string cmd = "Get-EmcESXHost -ID $UUID -VMwareSystem $VMwareSystem -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest20()
        {
            string cmd = "Get-EmcESXHost $UUID -VMwareSystem $VMwareSystem -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest21()
        {
            string cmd = "Get-EmcESXHost -ScsiLun $ScsiLun";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest22()
        {
            string cmd = "Get-EmcESXHost -ScsiLun $ScsiLun -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest23()
        {
            string cmd = "Get-EmcESXHost -Datastore $Datastore";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest24()
        {
            string cmd = "Get-EmcESXHost -Datastore $Datastore -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest25()
        {
            string cmd = "Get-EmcESXHost -VirtualMachineConfiguration $VirtualMachineConfiguration";
            GetEmcESXHostTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcESXHostTest26()
        {
            string cmd = "Get-EmcESXHost -VirtualMachineConfiguration $VirtualMachineConfiguration -Silent";
            GetEmcESXHostTestMethod(cmd);
        }
        
    }
}

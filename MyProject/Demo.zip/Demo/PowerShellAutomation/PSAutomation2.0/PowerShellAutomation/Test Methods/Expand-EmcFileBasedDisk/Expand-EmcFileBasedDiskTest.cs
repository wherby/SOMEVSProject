using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class ExpandEmcFileBasedDiskTest
    {
        
        
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest1()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest2()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -ScsiControllerId $ScsiControllerId";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest3()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -ScsiControllerIndex $ScsiControllerIndex";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest4()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -Silent";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest5()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest6()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -ScsiControllerId $ScsiControllerId -Silent";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest7()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -ScsiControllerIndex $ScsiControllerIndex -Silent";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_ExpandEmcFileBasedDiskTest8()
        {
            string cmd = "Expand-EmcFileBasedDisk -Size $Size -VirtualMachineConfiguration $VMwareVMConfig -Location $Location -ScsiControllerId $ScsiControllerId -ScsiControllerIndex $ScsiControllerIndex -Silent";
            ExpandEmcFileBasedDiskTestMethod(cmd);
        }
        
    }
}

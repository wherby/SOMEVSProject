using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcHostVolumeTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest1()
        {
            string cmd = "Get-EmcHostVolume";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest2()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest3()
        {
            string cmd = "Get-EmcHostVolume $MountPath";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest4()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest5()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest6()
        {
            string cmd = "Get-EmcHostVolume -HostDisk $HostDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest7()
        {
            string cmd = "Get-EmcHostVolume -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest8()
        {
            string cmd = "Get-EmcHostVolume -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest9()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -HostDisk $HostDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest10()
        {
            string cmd = "Get-EmcHostVolume $MountPath -HostDisk $HostDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest11()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -HostDisk $HostDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest12()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -HostDisk $HostDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest13()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest14()
        {
            string cmd = "Get-EmcHostVolume $MountPath -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest15()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest16()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest17()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest18()
        {
            string cmd = "Get-EmcHostVolume $MountPath -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest19()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest20()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest21()
        {
            string cmd = "Get-EmcHostVolume -HostDisk $HostDisk -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest22()
        {
            string cmd = "Get-EmcHostVolume -HostDisk $HostDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest23()
        {
            string cmd = "Get-EmcHostVolume -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest24()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -HostDisk $HostDisk -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest25()
        {
            string cmd = "Get-EmcHostVolume $MountPath -HostDisk $HostDisk -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest26()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -HostDisk $HostDisk -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest27()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -HostDisk $HostDisk -HostSystem $HostSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest28()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -HostDisk $HostDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest29()
        {
            string cmd = "Get-EmcHostVolume $MountPath -HostDisk $HostDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest30()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -HostDisk $HostDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest31()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -HostDisk $HostDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest32()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest33()
        {
            string cmd = "Get-EmcHostVolume $MountPath -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest34()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest35()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest36()
        {
            string cmd = "Get-EmcHostVolume -HostDisk $HostDisk -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest37()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -HostDisk $HostDisk -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest38()
        {
            string cmd = "Get-EmcHostVolume $MountPath -HostDisk $HostDisk -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest39()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -HostDisk $HostDisk -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest40()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -HostDisk $HostDisk -HostSystem $HostSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest41()
        {
            string cmd = "Get-EmcHostVolume -ClusterDisk $ClusterDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest42()
        {
            string cmd = "Get-EmcHostVolume -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest43()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -ClusterDisk $ClusterDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest44()
        {
            string cmd = "Get-EmcHostVolume $MountPath -ClusterDisk $ClusterDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest45()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -ClusterDisk $ClusterDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest46()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -ClusterDisk $ClusterDisk";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest47()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest48()
        {
            string cmd = "Get-EmcHostVolume $MountPath -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest49()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest50()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest51()
        {
            string cmd = "Get-EmcHostVolume -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest52()
        {
            string cmd = "Get-EmcHostVolume -ClusterDisk $ClusterDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest53()
        {
            string cmd = "Get-EmcHostVolume -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest54()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest55()
        {
            string cmd = "Get-EmcHostVolume $MountPath -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest56()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest57()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest58()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -ClusterDisk $ClusterDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest59()
        {
            string cmd = "Get-EmcHostVolume $MountPath -ClusterDisk $ClusterDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest60()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -ClusterDisk $ClusterDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest61()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -ClusterDisk $ClusterDisk -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest62()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest63()
        {
            string cmd = "Get-EmcHostVolume $MountPath -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest64()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest65()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest66()
        {
            string cmd = "Get-EmcHostVolume -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest67()
        {
            string cmd = "Get-EmcHostVolume -ID $MountPath -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest68()
        {
            string cmd = "Get-EmcHostVolume $MountPath -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest69()
        {
            string cmd = "Get-EmcHostVolume -ID $HostVolumeIdentifier -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcHostVolumeTest70()
        {
            string cmd = "Get-EmcHostVolume $HostVolumeIdentifier -ClusterDisk $ClusterDisk -ClusterSystem $ClusterSystem -Silent";
            GetEmcHostVolumeTestMethod(cmd);
        }
        
    }
}

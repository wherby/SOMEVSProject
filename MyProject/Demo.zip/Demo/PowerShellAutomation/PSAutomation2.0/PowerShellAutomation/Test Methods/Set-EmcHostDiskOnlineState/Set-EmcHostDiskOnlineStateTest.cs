using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class SetEmcHostDiskOnlineStateTest
    {
        
        
      
        [TestMethod]
        public void PS_SetEmcHostDiskOnlineStateTest1()
        {
            string cmd = "Set-EmcHostDiskOnlineState -HostDisk $HostDisk -Online";
            SetEmcHostDiskOnlineStateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcHostDiskOnlineStateTest2()
        {
            string cmd = "Set-EmcHostDiskOnlineState -HostDisk $HostDisk -Online -Silent";
            SetEmcHostDiskOnlineStateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcHostDiskOnlineStateTest3()
        {
            string cmd = "Set-EmcHostDiskOnlineState -HostDisk $HostDisk -Offline";
            SetEmcHostDiskOnlineStateTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_SetEmcHostDiskOnlineStateTest4()
        {
            string cmd = "Set-EmcHostDiskOnlineState -HostDisk $HostDisk -Offline -Silent";
            SetEmcHostDiskOnlineStateTestMethod(cmd);
        }
        
    }
}

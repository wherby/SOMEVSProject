using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcVirtualMachineConfigurationTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest1()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest2()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest3()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -VirtualMachine $HypervVM";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest4()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $HypervVM";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest5()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -VirtualMachine $XenServerVM";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest6()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $XenServerVM";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest7()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -VirtualMachine $VMWareVM";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest8()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $VMWareVM";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest9()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -VirtualMachine $HypervVM -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest10()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $HypervVM -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest11()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -VirtualMachine $XenServerVM -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest12()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $XenServerVM -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest13()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -VirtualMachine $VMWareVM -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest14()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $VMWareVM -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest15()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Hypervisor $Hyperv";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest16()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $Hyperv";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest17()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Hypervisor $XenServer";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest18()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $XenServer";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest19()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Hypervisor $VMWare";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest20()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $VMWare";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest21()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Hypervisor $Hyperv -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest22()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $Hyperv -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest23()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Hypervisor $XenServer -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest24()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $XenServer -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest25()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration -Hypervisor $VMWare -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcVirtualMachineConfigurationTest26()
        {
            string cmd = "Get-EmcVirtualMachineConfiguration $VMWare -Silent";
            GetEmcVirtualMachineConfigurationTestMethod(cmd);
        }
        
    }
}

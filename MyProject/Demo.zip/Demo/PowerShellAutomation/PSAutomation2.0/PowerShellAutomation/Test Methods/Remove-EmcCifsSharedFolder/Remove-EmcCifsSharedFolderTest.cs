using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class RemoveEmcCifsSharedFolderTest
    {
        
        
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest1()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest2()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest3()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -Force";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest4()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -Force";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest5()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -Silent";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest6()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -Silent";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest7()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest8()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest9()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -Force -Silent";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest10()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -Force -Silent";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest11()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -Force -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest12()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -Force -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest13()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -Silent -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest14()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -Silent -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest15()
        {
            string cmd = "Remove-EmcCifsSharedFolder -SharedFolder $SharedFolder -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_RemoveEmcCifsSharedFolderTest16()
        {
            string cmd = "Remove-EmcCifsSharedFolder $SharedFolder -Confirm:$false -Force -Silent -WhatIf";
            RemoveEmcCifsSharedFolderTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class GetEmcXenServerVirtualDiskImageTest
    {
        
        
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest1()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest2()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $Name";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest3()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $Name";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest4()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $UUID";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest5()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $UUID";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest6()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -XenServer $XenServer";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest7()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest8()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $Name -XenServer $XenServer";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest9()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $Name -XenServer $XenServer";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest10()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $UUID -XenServer $XenServer";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest11()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $UUID -XenServer $XenServer";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest12()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $Name -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest13()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $Name -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest14()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $UUID -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest15()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $UUID -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest16()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -XenServer $XenServer -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest17()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $Name -XenServer $XenServer -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest18()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $Name -XenServer $XenServer -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest19()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -ID $UUID -XenServer $XenServer -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest20()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage $UUID -XenServer $XenServer -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest21()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -StorageRepository $StorageRepository";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_GetEmcXenServerVirtualDiskImageTest22()
        {
            string cmd = "Get-EmcXenServerVirtualDiskImage -StorageRepository $StorageRepository -Silent";
            GetEmcXenServerVirtualDiskImageTestMethod(cmd);
        }
        
    }
}

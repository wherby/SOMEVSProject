using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcLunTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcLunTest1()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest2()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest3()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest4()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Thin";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest5()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest6()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest7()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest8()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Thin";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest9()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest10()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest11()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Thin";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest12()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest13()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest14()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Thin -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest15()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Thin -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest16()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest17()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Thin";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest18()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest19()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest20()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Thin -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest21()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Thin -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest22()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest23()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Thin -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest24()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Thin -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest25()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest26()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Thin -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest27()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Thin -Description $Description";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest28()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Thin -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest29()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest30()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -Thin -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest31()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -ApplicationHint $ApplicationHint -Thin -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcLunTest32()
        {
            string cmd = "New-EmcLun -Pool $Pool -Capacity $Capacity -Name $Name -ApplicationHint $ApplicationHint -Thin -Description $Description -Silent";
            NewEmcLunTestMethod(cmd);
        }
        
    }
}

using System;
using System.Collections.Generic;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;


namespace PowerShellAutomation
{
   
    public partial class NewEmcVolumeTest
    {
        
        
      
        [TestMethod]
        public void PS_NewEmcVolumeTest1()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest2()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest3()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest4()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest5()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest6()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest7()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest8()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest9()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest10()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest11()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest12()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest13()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest14()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest15()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest16()
        {
            string cmd = "New-EmcVolume -HostSystem $HostSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest17()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest18()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest19()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest20()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest21()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest22()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest23()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest24()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostDisk $HostDisk -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest25()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest26()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest27()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest28()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest29()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest30()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest31()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
      
        [TestMethod]
        public void PS_NewEmcVolumeTest32()
        {
            string cmd = "New-EmcVolume -ClusterSystem $ClusterSystem -HostLunIdentifier $HostLunIdentifier -Label $Label -AllocationUnitSizeInBytes $AllocationUnitSizeInBytes -FileSystemType $FileSystemType -Silent";
            NewEmcVolumeTestMethod(cmd);
        }
        
    }
}

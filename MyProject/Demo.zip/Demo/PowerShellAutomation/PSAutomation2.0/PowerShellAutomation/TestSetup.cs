﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    public enum MountPoint
    {
        None,
        DriveLetter,
        MountPath
    }    

    public class TestSetup
    {

        private static string storageSystemType;

        private static bool isPoolThin = true;

        public static string StorageSystemType
        {
            get
            {
                return storageSystemType;
            }
        }

        # region Import ESIPSToolKit
        public static int InitForEMCStorage(PowershellMachine psMachine)
        {
            Runspace runspace = psMachine.GetRunspace();
            TestLog log = TestLog.GetInstance();
            //create a pipeline
            Pipeline pipeline = runspace.CreatePipeline();

            pipeline.Commands.AddScript("$error.clear()");
            log.LogInfo("Set Execution Policy to RemoteSigned");
            pipeline.Commands.AddScript("Set-ExecutionPolicy RemoteSigned");
            log.LogInfo("Add-PSSnapin Module");
            pipeline.Commands.AddScript("Add-PSSnapin ESIPSToolKit");
            
            pipeline.Invoke();
            
            // Fetch the error output of PowerShell
            Pipeline pipeline2 = runspace.CreatePipeline();
            string scr = "if($error.count -gt 0){$error}";
            pipeline2.Commands.AddScript(scr);

            Collection<PSObject> errors = pipeline2.Invoke();

            if (errors.Count > 0)
            {
                foreach (PSObject err in errors)
                {
                    log.LogError(err.ToString());
                }

                log.LogInfo("Failed to import ESIPSToolKit Module");
                return 1;
            }
           
            return 0;
        }
        # endregion 


        # region Set Storage Environment: Storage, Pool, Lun
        /// <summary>
        /// SetStorageEnvironment
        ///     Select an available storage system at random
        /// </summary>
        /// <param name="psMachine">PowerShell Machine instance</param>
        /// <param name="type">Block/File/All</param>
        /// <returns>storage system name</returns>
        public static string SetStorageEnvironment(PowershellMachine psMachine, string type = "Block")
        {
            TestLog log = TestLog.GetInstance();
            string path = HelperAdapter.GetProperty("SystemConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Storage");
            string storageValue = null;

            if (dic.TryGetValue(type, out storageValue) == false)
            {
                log.LogWarning("Can not find value of" + type + " in Storage");
                PSException pe = new PSException("Can not find value of" + type + " in Storage");
                throw pe;
            }
            else
            {
                string[] storages = storageValue.Split(new char[]{',', ' '}, StringSplitOptions.RemoveEmptyEntries);
                List<int> rdList = new List<int>();
                while (true)
                {
                    Random rn = new Random();
                    int iResult;
                    iResult = rn.Next(0, storages.Length);
                    if( rdList.Contains(iResult))
                    {
                        continue;
                    }
                    string blob = HelperAdapter.GetBlobContent(storages[iResult]);
                    if (blob != null)
                    {
                        return storages[iResult];
                    }
                    else
                    {
                        rdList.Add(iResult);
                        if (rdList.Count == storages.Length)
                        {
                            log.LogWarning("All storages of " + type + " are unavailable");
                            PSException pe = new PSException("All storages of " + type + " are unavailable");
                            throw pe;
                        }
                    }
                }
            }
        }

        private static string GetPoolType()
        {
            string thin;
            if (storageSystemType == "VMAX")
            {
                thin = "true";
                isPoolThin = true;
            }
            else
            {
                thin = HelperAdapter.GenerateRandomValue(HelperAdapter.ThinOrThick);
                if (thin == "true")
                {
                    isPoolThin = true;
                }
                else
                {
                    isPoolThin = false;
                }
            }
            return thin;
        }

        /// <summary>
        /// Return the storage is vnxe or not.
        /// </summary>
        /// <returns>Return the storage is vnxe or not.</returns>
        public static bool IsStorageVNXE()
        {
            if (storageSystemType.ToUpper() == "VNXE")
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// The method is to initialize $pool parameter with selected pool from storagepools.
        /// </summary>
        /// <param name="psMachine">PowerShell Machine instance.</param>
        /// <param name="thin">The type of a pool.</param>
        /// <param name="capacity">The minimun capacity of a pool</param>
        /// <param name="poolType">The type of a pool: "RaidGroup", "Pool", "MetaLuns" and "SnapshotLuns" </param>
        /// <returns> The pool information.</returns>
        public static string SetPoolEnvironment(PowershellMachine psMachine, string thin="True",string capacity="5", string poolType="Pool", string prefix = null,string storageType=null)
        {
            //this method is invoked to set isPoolThin value for PoolFilter is not enabled.
            GetPoolType();
            string arrayPoolIDOrName;
            string path = HelperAdapter.GetProperty("LunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            string filter = dic["PoolFilter"];
            
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Pool");
            }

            if (storageType == null)
            {
                storageType = storageSystemType;
            }

            if (filter.Equals("true", StringComparison.OrdinalIgnoreCase))
            {
                SortedList<string, string> poolFilter = HelperAdapter.GenerateEmptyPoolFilter();
                poolFilter["Thin"] = GetPoolType();
                poolFilter["Capacity"] = capacity;
                poolFilter["PoolType"] = poolType;
                GetEmcStoragePool pool = new GetEmcStoragePool();
                string poolString = pool.RunCMD(psMachine, true);
                arrayPoolIDOrName = HelperAdapter.SelectPool(poolString, poolFilter);                              
            }
            else
            {
                string poolNameForStorageType = "PoolNameFor" + storageType;
                arrayPoolIDOrName = dic[poolNameForStorageType];
            }

            if (arrayPoolIDOrName == null)
            {
                return null;
            } 
 

            GetEmcStoragePool getPool;
            if (storageType == "VNXe")
            {
                getPool = new GetEmcStoragePool(arrayPoolIDOrName, null, null, null, "block");
            }
            else
            {
                getPool = new GetEmcStoragePool(arrayPoolIDOrName);
            }
            getPool.PrefixString = prefix;
            string result = getPool.RunCMD(psMachine, true);
            return result;
        }

        /// <summary>
        /// SetLunEnvironment
        ///     Create a lun for test    
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="thinFlag">the flag for thin lun</param>
        /// <param name="poolPrefix">the prefix used for the pool</param>
        /// <param name="lunPrefix">the prefix used for the lun</param>
        /// <returns>New-EmcLun output string</returns>
        public static string SetLunEnvironment(PowershellMachine psMachine, bool thinFlag = true, string poolPrefix = null, string lunPrefix = null)
        {
            if (poolPrefix == null)
            {
                poolPrefix = HelperAdapter.GetParameter("Pool");
            }
            if (lunPrefix == null)
            {
                lunPrefix = HelperAdapter.GetParameter("Lun");
            }
            string result = null;
            int count = 0;
            string path = HelperAdapter.GetProperty("LunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);

            while (true)
            {
                string lunName = HelperAdapter.GenerateName(dic["NamePrefix"]);
                NewEmcLun lun;
                //thinFlag will be byPass by isPoolThin parameter which is not set by thinFlag parameter from method.
                thinFlag = isPoolThin;
                if (thinFlag)
                {
                    lun = new NewEmcLun(poolPrefix, dic["Capacity"], lunName, null,"Thin", dic["Description"]);
                }
                else
                {
                    lun = new NewEmcLun(poolPrefix, dic["Capacity"], lunName, null,null, dic["Description"]);
                }
                lun.PrefixString = lunPrefix;
                try
                {
                    result = lun.RunCMD(psMachine, true);
                }
                catch
                {
                    count++;
                    if (count <= 3)
                    {
                        Thread.Sleep(3000);
                        continue;
                    }
                }
                break;
            }

            return result;
        }

        /// <summary>
        /// ClearLunEnvironment
        ///     Remove a lun
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="lunPrefix">prefix used for a lun</param>
        public static void ClearLunEnvironment(PowershellMachine psMachine, string lunPrefix = null)
        {
            if (lunPrefix == null)
            {
                lunPrefix = HelperAdapter.GetParameter("Lun");
            }
            RemoveEmcLun removeLun = new RemoveEmcLun(lunPrefix);
            removeLun.RunCMD(psMachine);
        }

        /// <summary>
        /// GetRandomTargetPort
        ///     Get random taget port of a storage systen
        /// </summary>
        /// <param name="psMachine">PowerShell machine instance</param>
        /// <param name="storage">storage system prefix</param>
        /// <param name="targetPort">target port prefix</param>
        /// <returns>The key/value pairs of the target port</returns>
        public static string GetRandomTargetPort(PowershellMachine psMachine, string storage = null, string targetPort = null)
        {
            if (storage == null)
            {
                storage = HelperAdapter.GetParameter("Storage");
            }

            if (targetPort == null)
            {
                targetPort = HelperAdapter.GetParameter("TargetPort");
            }

            GetEmcTargetPort port = new GetEmcTargetPort(null, storage);
            port.PrefixString = targetPort;
            port.RunCMD(psMachine);
            GetPropertyValue(psMachine, targetPort + "=" + targetPort + "| Where-Object {$_.wwn -ne $null -or $_.ipaddress -ne $null }");

            Random rand = new Random();
            int i = rand.Next(int.Parse(GetPropertyValue(psMachine, targetPort, "Count")));

            GetPropertyValue(psMachine, targetPort + "=" + targetPort + "[" + i + "]");
            string result = GetPropertyValue(psMachine, targetPort);

            return result;
        }
        # endregion         

        # region Cluster/Host Disk
        /// <summary>
        /// SetLunAccess
        ///     Unmask Lun to host
        /// </summary>
        /// <param name="psMachine">Powershell machine instance</param>
        /// <param name="lunPrefix">Lun object prefix</param>
        /// <param name="hostPefix">Host object prefix</param>
        /// <param name="clusterPrefix">Cluster object prefix</param>
        public static void SetLunAccess(PowershellMachine psMachine, string lunPrefix = null, string hostPefix = null, string clusterPrefix = null)
        {
            if (lunPrefix == null)
            {
                lunPrefix = HelperAdapter.GetParameter("Lun");
            }
            if (hostPefix == null && clusterPrefix == null)
            {
                hostPefix = HelperAdapter.GetParameter("Host");
            }

            SetEmcLunAccess setEmcLunAccess = new SetEmcLunAccess(lunPrefix, hostPefix, null, null, "Available", null, null, null, clusterPrefix);
            setEmcLunAccess.RunCMD(psMachine);
        }

        /// <summary>
        /// The method is mask a lun to a host and find the lun.
        ///    After the method there will add $host for the host machine, $disk for disk whihc the lun is masked. 
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="prefix">The disk parameter.</param>
        /// <param name="host">The host parameter.</param>
        /// <param name="lun">The lun parameter.</param>
        /// <param name="cluster">The cluster parameter.</param>
        /// <param name="isInitialize">Flag to indicate whether to initialize a disk</param>
        /// <returns>The result for Find-EmcHostDisk.</returns>
        public static string SetDiskEnvironment(PowershellMachine psMachine, string prefix = null,string host=null,string lun=null,string cluster=null, bool isInitialize=true)
        {
            TestLog log = TestLog.GetInstance();
            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Disk");
            string rescanCount = dic["RescanCount"];
            

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Disk");
            }
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (lun == null)
            {
                lun = HelperAdapter.GetParameter("Lun");
            }
            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(lun, host, null, null, "Available", null, null, null, cluster);
            setLunAccess.RunCMD(psMachine, false);
            
            FindEmcHostDisk findDisk = new FindEmcHostDisk(host, null, rescanCount, null, lun, cluster);
            findDisk.PrefixString = prefix;
            string result = null;
            try
            {
                result = findDisk.RunCMD(psMachine, true);
            }
            catch
            {
                log.LogError(findDisk.ToCMDString());
            }
            if (isInitialize)
            {
                InitializeEmcHostDisk initializeDisk = new InitializeEmcHostDisk(prefix, host, null, null, cluster);
                try
                {
                    if (cluster == null)
                    {
                        initializeDisk.VerifyTheCMD(psMachine, lun, prefix, host);
                    }
                    else
                    {
                        initializeDisk.VerifyTheCMD(psMachine, lun, prefix, null, cluster);
                    }
                }
                catch
                {
                    log.LogError(initializeDisk.ToCMDString());
                }
            }

            return result; 
        }

        /// <summary>
        /// This method is used to set host environment.
        ///  After the method, $host is set to the host machine.
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="prefix">Prefix for host.</param>
        public static void SetHostEnvironment(PowershellMachine psMachine, string prefix = null)
        {
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Host");
            }
            string blob = HelperAdapter.GetBlobContent("Host");
            ConnectEmcSystem hostSystem = new ConnectEmcSystem(blob);
            hostSystem.PrefixString = prefix;
            hostSystem.RunCMD(psMachine, true);
        }

        /// <summary>
        /// This method is used to set cluster environment.
        ///  After the method, prefix is set to the cluster.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        /// <param name="prefix">prefix parameter for cluster.</param>
        public static void SetClusterEnvironment(PowershellMachine psMachine, string prefix = null)
        {
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Cluster");
            }
            TestSetup.ConnectSystem(psMachine, "Cluster", prefix);
        }

        /// <summary>
        /// SetVolumeEnvironment
        ///     New a volume on a host or cluster, set the mount point if required
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="lun">The lun parameter</param>
        /// <param name="disk">The host disk parameter</param>
        /// <param name="host">The host system parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        /// <param name="prefix">Prefix of the volume</param>
        /// <param name="mountPoint">Mount point of the volume</param>
        /// <returns>volume information</returns>
        public static string SetVolumeEnvironment(PowershellMachine psMachine, string disk = null, string host = null, string cluster = null, string prefix = null, MountPoint mountPoint = MountPoint.None, string mountPath = null)
        {
            TestLog log = TestLog.GetInstance();

            if (disk == null)
            {
                disk = HelperAdapter.GetParameter("Disk");
            }
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Volume");
            }
            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Volume");
            
            string random = HelperAdapter.GenerateRandomString();
            string label = dic["LabelPrefix"] + random;
            NewEmcVolume volume = new NewEmcVolume(host, disk, label, null, null, null, null, cluster);
            volume.PrefixString = prefix;
            string result = null;
            try
            {
                result = volume.RunCMD(psMachine, true);
            }
            catch
            {
                log.LogError(volume.ToCMDString());
            }

            SetEmcVolumeMountPoint setMountPoint = null;

            switch (mountPoint)
            {
                case MountPoint.DriveLetter:
                    {
                        string letter = GetRandomDriveLetter(psMachine, host, cluster);
                        setMountPoint = new SetEmcVolumeMountPoint(host, letter, prefix, null, null, cluster);
                        setMountPoint.RunCMD(psMachine);
                        break;
                    }
                case MountPoint.MountPath:
                    {
                        if (mountPath == null)
                        {
                            mountPath = dic["MountPathPrefix"] + random;
                        }
                        setMountPoint = new SetEmcVolumeMountPoint(host, null, prefix, null, mountPath, cluster);
                        setMountPoint.RunCMD(psMachine);
                        break;
                    }
                default:
                    {
                        log.LogInfo("The volume is not mounted");
                        break;
                    }
            }

            return result;
        }

        /// <summary>
        /// UpdateHostVolumeInfo
        ///     Use Get-EmcHostVolume to update volume information for specified volume prefix
        /// </summary>
        /// <param name="psMachine">PowershellMachine instance</param>
        /// <param name="disk">Host Disk prefix</param>
        /// <param name="host">Host System prefix</param>
        /// <param name="volume">Host Volume prefix</param>
        /// <returns>Get-EmcHostVolume result string</returns>
        public static string UpdateHostVolumeInfo(PowershellMachine psMachine, string disk = null, string host = null, string volume = null)
        {
            TestLog log = TestLog.GetInstance();
            
            if (disk == null)
            {
                disk = HelperAdapter.GetParameter("Disk");
            }
            if (host == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (volume == null)
            {
                volume = HelperAdapter.GetParameter("Volume");
            }

            string idPrefix = disk + ".HostDiskIdentifier";
            GetEmcHostDisk getEmcHostDisk = new GetEmcHostDisk(idPrefix);
            getEmcHostDisk.PrefixString = disk;
            getEmcHostDisk.RunCMD(psMachine, true);

            GetEmcHostVolume getEmcHostVolume = new GetEmcHostVolume(null, disk, host);
            getEmcHostVolume.PrefixString = volume;
            string result = getEmcHostVolume.RunCMD(psMachine, true);
            return result;
        }

        /// <summary>
        /// GetClusterMountPath
        ///     Get Cluster system mount path
        /// </summary>
        /// <param name="psMachine">PowershellMachine instance</param>
        /// <param name="cluster">Cluster system prefix</param>
        /// <returns>mount path</returns>
        public static string GetClusterMountPath(PowershellMachine psMachine, string cluster = null)
        {
            if (cluster == null)
            {
                cluster = HelperAdapter.GetParameter("Cluster");
            }
            string mountPath = null;
            GetEmcHostVolume getVolumes = new GetEmcHostVolume(null, null, null, null, null, cluster);
            string result = getVolumes.RunCMD(psMachine);
            List<SortedList<string, string>> volumesKeyValue = HelperAdapter.GenerateKeyValuePairsList(result);
            foreach (SortedList<string, string> keyValue in volumesKeyValue)
            {
                if (!string.IsNullOrEmpty(keyValue["MountPath"]))
                {
                    if (keyValue["MountPath"].EndsWith("\\"))
                    {
                        mountPath = keyValue["MountPath"] + HelperAdapter.GenerateRandomString();
                    }
                    else
                    {
                        mountPath = keyValue["MountPath"] + "\\" + HelperAdapter.GenerateRandomString();
                    }
                    
                    break;
                }
                
            }
            return mountPath;
        }

        /// <summary>
        /// SetClusterDiskEnvironment
        ///     Add host disk to cluster system, must be used after New-EmcVolume
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="hostDisk">The host disk parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        /// <returns>cluster disk information</returns>
        public static string SetClusterDiskEnvironment(PowershellMachine psMachine, string hostDisk = null, string cluster = null, string clusterDisk = null, string clusterGroupName = null, bool isAddToSharedVolume = false)
        {
            string addToSharedVolume = null;
            if (hostDisk == null)
            {
                hostDisk = HelperAdapter.GetParameter("Disk");
            }
            if (cluster == null)
            {
                cluster = HelperAdapter.GetParameter("Cluster");
            }

            if (clusterDisk == null)
            {
                clusterDisk = HelperAdapter.GetParameter("ClusterDisk");
            }

            if (isAddToSharedVolume)
            {
                addToSharedVolume = "AddToClusterSharedVolume";
            }
            else
            {
                if (clusterGroupName == null)
                {
                    GetEmcClusterGroup getGroup = new GetEmcClusterGroup(cluster);
                    string group = getGroup.RunCMD(psMachine, true);
                    List<SortedList<string, string>> groupList = HelperAdapter.GenerateKeyValuePairsList(group);
                    Random rd = new Random();
                    int i = rd.Next(groupList.Count);
                    clusterGroupName = groupList[i]["Name"];
                }

            
            }

            AddEmcHostDiskToCluster addDisk = new AddEmcHostDiskToCluster(hostDisk + ".HostLunIdentifier", cluster, clusterGroupName, null, addToSharedVolume);
            addDisk.PrefixString = clusterDisk;
            string result = addDisk.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// ClearClusterDiskEnvironment
        ///     Remove host disk from cluster system and update the cluster system
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="hostDisk">The host disk paramter</param>
        /// <param name="cluster">The cluster system paramter</param>
        public static void ClearClusterDiskEnvironment(PowershellMachine psMachine, string hostDisk = null, string cluster = null)
        {
            if (hostDisk == null)
            {
                hostDisk = HelperAdapter.GetParameter("Disk");
            }
            if (cluster == null)
            {
                cluster = HelperAdapter.GetParameter("Cluster");
            }
            RemoveEmcHostDiskFromCluster removeDisk = new RemoveEmcHostDiskFromCluster(null, null, null, null, cluster, null, hostDisk);
            removeDisk.RunCMD(psMachine);
            Thread.Sleep(5000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(cluster);
            updateSystem.RunCMD(psMachine);
        }

        /// <summary>
        /// ClearVolumeEnvironment
        ///     Remove the volume's mount point
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="volume">The volume parameter</param>
        /// <param name="host">The host system parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        public static void ClearVolumeEnvironment(PowershellMachine psMachine, string volume = null, string host = null, string cluster = null)
        {
            if (volume == null)
            {
                volume = HelperAdapter.GetParameter("Volume");
            }
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            RemoveEmcVolumeMountPoint removeVolume = new RemoveEmcVolumeMountPoint(volume, host, null, cluster);
            removeVolume.RunCMD(psMachine);
        }

        /// <summary>
        /// The method is unmask a lun from host.
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="host">The host parametere.</param>
        /// <param name="lun">The lun parameter.</param>
        /// <param name="cluster">The cluster parameter</param>
        /// <param name="update">update flag which indicated when update-emcsystem will be invoked</param>
        public static void ClearDiskEnvironment(PowershellMachine psMachine, string host = null, string cluster = null, string lun = null, bool update = true)
        {
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (lun == null)
            {
                lun = HelperAdapter.GetParameter("Lun");
            }

            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(lun, host, "Unavailable", null, null, null, null, null, cluster);
            setLunAccess.RunCMD(psMachine, false);
            Thread.Sleep(5000);
            if (update)
            {
                if (host != null)
                {
                    UpdateEmcSystem updateSystem = new UpdateEmcSystem(host);
                    updateSystem.RunCMD(psMachine);
                }
                if (cluster != null)
                {
                    UpdateEmcSystem updateSystem = new UpdateEmcSystem(cluster);
                    updateSystem.RunCMD(psMachine);
                }
            }
        }

        /// <summary>
        /// GetRandomDriveLetter
        ///     Get the random available drive letter of a host system or cluster system
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="host">The host system parameter</param>
        /// <param name="cluster">The cluster system parameter</param>
        /// <returns>drive letter</returns>
        public static string GetRandomDriveLetter(PowershellMachine psMachine, string host = null, string cluster = null)
        {
            if (host == null && cluster == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }

            GetEmcAvailableDriveLetter getLetter = new GetEmcAvailableDriveLetter(host,null, cluster);
            string result = getLetter.RunCMD(psMachine, true);

            string[] resultLines = result.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);

            Random rand = new Random();
            int i = rand.Next(resultLines.Length);

            return resultLines[i];
        }

        /// <summary>
        /// The method is to set HostbusAdapter parameter.
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance.</param>
        /// <param name="hostString">The host system.</param>
        /// <param name="prefix">The parameter for HostbusAdapter.</param>
        public static void SetHBAEnvironment(PowershellMachine psMachine, string hostString = null, string prefix = null)
        {
            if (hostString == null)
            {
                hostString = HelperAdapter.GetParameter("Host");
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("HostbusAdapter");
            }
            UpdateEmcSystem update = new UpdateEmcSystem(hostString);
            update.RunCMD(psMachine);
            List<string> ps = new List<string>();
            ps.Add(string.Format("{0}.RefreshHostBusAdapters()", hostString));
            ps.Add(string.Format("{0}={1}.HostBusAdapters", prefix, hostString));
            psMachine.RunScript(ps, new List<PSParam>());
        }

        /// <summary>
        /// GetRandomInitiatorId
        ///     Get the initiator id of a random hba
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="hostPrefix">host prefix string</param>
        /// <returns></returns>
        public static string GetRandomInitiatorId(PowershellMachine psMachine, string hostPrefix = null)
        {
            if (hostPrefix == null)
            {
                hostPrefix = HelperAdapter.GetParameter("Host");
            }

            string hbaPrefix = HelperAdapter.GetParameter("HostbusAdapter");

            GetEmcHostBusAdapter getEmcHostBusAdapter = new GetEmcHostBusAdapter(hostPrefix);
            getEmcHostBusAdapter.PrefixString = hbaPrefix;
            string result = getEmcHostBusAdapter.RunCMD(psMachine, true);

            string count = GetPropertyValue(psMachine, hbaPrefix, "count");

            if (! String.IsNullOrEmpty(count))
            {                
                Random r = new Random();
                int i = r.Next(0, Int16.Parse(count));
                result = GetPropertyValue(psMachine, hbaPrefix + "=" + hbaPrefix + "[" + i + "]");
            }
            string initiatorId = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];

            return initiatorId;
        }

        /// <summary>
        /// GetStorageGroupForHost
        ///    Get the specified storage group for a host
        /// </summary>
        /// <param name="psMachine">Powershell machine isntance</param>
        /// <param name="hostname">hostname</param>
        /// <param name="storagePrefix">storage prefix</param>
        /// <returns>storage group output string</returns>
        public static string GetStorageGroupForHost(PowershellMachine psMachine, string hostname, string storagePrefix = null)
        {
            string result;
            
            if (storagePrefix == null)
            {
                storagePrefix = HelperAdapter.GetParameter("System");
            }
            GetEmcStorageGroup getEmcStorageGroup = new GetEmcStorageGroup(storagePrefix);
            getEmcStorageGroup.PrefixString = HelperAdapter.GetParameter("StorageGroup");
            getEmcStorageGroup.PostfixString = " | where {$_.Name -match \"" + hostname + "\"}";

            result = getEmcStorageGroup.RunCMD(psMachine);

            return result;
        }

        /// <summary>
        /// GetHostLunIdFromArrayLunId
        ///    Get the mapping hostlunid from arraylunid
        /// </summary>
        /// <param name="psMachine">Powershell machine instance</param>
        /// <param name="arrayLunId">Array Lun Id</param>
        /// <param name="storageGroupPrefix">Storage group prefix</param>
        /// <returns>Host Lun Id</returns>
        public static string GetHostLunIdFromArrayLunId(PowershellMachine psMachine, string arrayLunId, string storageGroupPrefix = null)
        {
            string hostLunId;

            if (storageGroupPrefix == null)
            {
                storageGroupPrefix = HelperAdapter.GetParameter("StorageGroup");
            }

            hostLunId = GetPropertyValue(psMachine, storageGroupPrefix, "ArrayLunIdToHostLunIdMappings[" + arrayLunId + "]");

            return hostLunId;
        }

        /// <summary>
        /// SetHostDiskOnline
        ///     Set host disk online/offline
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="online">if online is true, the disk will be set online; if false, the disk will be set offline</param>
        /// <param name="diskPrefix">disk prefix</param>
        public static void SetHostDiskOnline(PowershellMachine psMachine, bool online = true, string diskPrefix = null)
        {
            if (diskPrefix == null)
            {
                diskPrefix = HelperAdapter.GetParameter("Disk");
            }
            SetEmcHostDiskOnlineState setEmcHostDiskOnlineState;
            if (online)
            {
                setEmcHostDiskOnlineState = new SetEmcHostDiskOnlineState(diskPrefix, "Online");
            }
            else
            {
                setEmcHostDiskOnlineState = new SetEmcHostDiskOnlineState(diskPrefix, null, null, "Offline");
            }

            setEmcHostDiskOnlineState.RunCMD(psMachine);
        }
        # endregion

        # region FileBasesdDisk Environment

        /// <summary>
        /// SetFileBasedDiskEnvironment
        ///    Create a file based disk 
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="hypervPrefix">the prefix for hypervisor</param>
        /// <param name="type">HyperVisor Type</param>
        /// <param name="vhdType">Vhd Type</param>
        /// <param name="vmdkType">Vmdk Type</param>
        public static string SetFileBasedDiskEnvironment(PowershellMachine psMachine, string hypervPrefix = null, HyperVisorType type = HyperVisorType.HyperV)
        {            
            string directory;
            string filePath = null;
            string file = "ps_test_" + HelperAdapter.GenerateRandomString();
           
            NewEmcFileBasedDisk newEmcFileBasedDisk = null;
            TestLog log = TestLog.GetInstance();

            if (hypervPrefix == null)
            {
                hypervPrefix = HelperAdapter.GetParameter("Hypervisor");
            }
           
            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> fileBasedDiskConfig = HelperAdapter.Load(path, "FileBasedDisk");
            string size = fileBasedDiskConfig["Size"];

            if (type == HyperVisorType.HyperV)
            {                
                directory = fileBasedDiskConfig["Path"];
                filePath = directory + file + ".vhd";
                string vhdType = HelperAdapter.GenerateRandomValue(HelperAdapter.VhdType);
                newEmcFileBasedDisk = new NewEmcFileBasedDisk(hypervPrefix, filePath, size, vhdType);
            }
            if (type == HyperVisorType.VMWare)
            {
                string dataStoreName = HelperAdapter.Load(path, "DataStore")["Name"];
                string dataStorePath = HelperAdapter.Load(path, "DataStore")["DataStorePath"];
                directory = "[" + dataStoreName + "]" + dataStorePath + "/";
                filePath = directory + file + ".vmdk";
                string vmdkType = HelperAdapter.GenerateRandomValue(HelperAdapter.VmdkType); ;
                newEmcFileBasedDisk = new NewEmcFileBasedDisk(hypervPrefix, filePath, size, null, null, vmdkType);
            }
            newEmcFileBasedDisk.RunCMD(psMachine);

            return filePath;
        }

        /// <summary>
        /// ClearFileBasedDiskEnvironment
        /// </summary>
        /// <param name="psMachine">Powershell machine instance</param>
        /// <param name="hypervisorPrefix">hypervisor prefix</param>
        /// <param name="filePath">path of file based disk</param>
        public static void ClearFileBasedDiskEnvironment(PowershellMachine psMachine, string filePath, string hypervisorPrefix = null)
        {
            
            if (hypervisorPrefix == null)
            {
                hypervisorPrefix = HelperAdapter.GetParameter("Hypervisor");
            }

            RemoveEmcFileBasedDisk removeEmcFileBasedDisk = new RemoveEmcFileBasedDisk(hypervisorPrefix, filePath);
            removeEmcFileBasedDisk.RunCMD(psMachine);
            
        }

        /// <summary>
        /// GetVhdFileBasedDiskSize
        ///     Get the size of vhd file
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="filePath">File Path</param>
        /// <returns>file size</returns>
        public static UInt64 GetVhdFileBasedDiskSize(PowershellMachine psMachine, string filePath)
        {
            List<string> ps = new List<string>();
            ps.Add(string.Format("(Get-Item \"{0}\").Length", filePath));
            string ret = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            return UInt64.Parse(ret.Trim());
        }

        /// <summary>
        /// GetVmdkFileBasedDiskSize
        ///     Get the size of vmdk file
        /// </summary>
        /// <param name="psMachine">Powershell Machine</param>
        /// <param name="filePath">File Path</param>
        /// <param name="pwd">remote esx host password</param>
        /// <param name="username">remote esx host username</param>
        /// <param name="hostIP">remote esx host ip</param>
        /// <returns>file size</returns>
        public static UInt64 GetVmdkFileBasedDiskSize(PowershellMachine psMachine, string filePath, string pwd, string username, string hostIP)
        {
            filePath = filePath.Replace(".vmdk", "-flat.vmdk");
            string cmdStr = " ls -l " + filePath;
            string ret = RunSSHCmd(psMachine, pwd, username, hostIP, cmdStr);

            Regex r = new Regex(" +");
            string[] splitString = r.Split(ret);
            string size = splitString[4];

            return UInt64.Parse(size.Trim());
        }
        # endregion 
        
        # region ConnectSystem/DisconnectSystem
        /// <summary>
        /// ConnectSystem
        ///     Connect Host/Storage/Cluster System
        /// </summary>
        /// <param name="psMachine"></param>
        /// <param name="type">"Host"/"Cluster"/"CLARiiON-CX4/"VMAX"/"VMAXe"/"VNX"/"VNX-Block"/"VNX-CIFS"/"Hyperv"/"VMware"/"ESXHost"</param>
        /// <param name="prefix">The parameter in powershell.</param>
        /// <param dic="null">The key/value pairs in the configuration file.</param>
        /// <returns>The result for connectsystem.</returns>
        public static string ConnectSystem(PowershellMachine psMachine, string type, string prefix = null, Dictionary<string, string> dic = null)
        {
            string blob = null;

            if (prefix == null) 
            {
                prefix = HelperAdapter.GetParameter("System");
            }
            if (dic == null)
            {
                blob = HelperAdapter.GetBlobContent(type);
            }
            else
            {
                StreamReader file = new StreamReader(dic["BlobFile"]);
                blob = file.ReadToEnd().Trim();
            }

            ConnectEmcSystem connectSystem = new ConnectEmcSystem(blob);

            connectSystem.PrefixString = prefix;
            
            if (blob == null)
            {
                TestLog log = TestLog.GetInstance();
                log.BypassTest();
            }

            string result = connectSystem.RunCMD(psMachine, true);

            string path = HelperAdapter.GetProperty("SystemConfig");
            Dictionary<string, string> storageDic = HelperAdapter.Load(path, "Storage");
            foreach (string key in storageDic.Keys)
            {
                string[] storageList = storageDic[key].Split(new char[] { ',', ' ' }, StringSplitOptions.RemoveEmptyEntries);
                
                foreach (string storage in storageList)
                {
                    if (storage == type)
                    {
                        storageSystemType = type;
                        goto LABLE_RETURN;
                    }
                }
            }

        LABLE_RETURN:
            return result;
        }
        
        /// <summary>
        /// DisconnectSystem
        ///     Disconnect Host/Storage/Cluster System
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="id">User Friendly Name/Global Id</param>
        /// <param name="system">The system parameter</param>
        public static void DisconnectSystem(PowershellMachine psMachine, string id = null, string system = null)
        {
            TestLog log = TestLog.GetInstance();

            DisconnectEmcSystem disconnectSystem = new DisconnectEmcSystem(id, null, null, null, system);
            try
            {
                disconnectSystem.RunCMD(psMachine);
            }
            catch
            {
                log.LogWarning("Get error when disconnectting system(s)");
            }
        }

        /// <summary>
        /// ConnectVirtualMachine
        ///     Connect a Virtual Machine of a Hyperviosr
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="type">Hypervisor type</param>
        /// <param name="vmPrefix">vm prefix</param>
        /// <param name="hostIndex">host index in hypervisor</param>
        /// <param name="vmIndex">vm index in host</param>
        /// <returns></returns>
        public static string ConnectVirtualMachine(PowershellMachine psMachine, HyperVisorType type = HyperVisorType.HyperV, string vmPrefix = null, int hostIndex = 0, int vmIndex = 0)
        {
            if(vmPrefix == null)
            {
                vmPrefix = HelperAdapter.GetParameter("VirtualMachine");
            }

            Dictionary<string, string> dic = HelperAdapter.GetHostVMs(type, hostIndex)[vmIndex];
            string result = ConnectSystem(psMachine, "VM", vmPrefix, dic);

            return result;
        }

        # endregion 

        # region Virtual Disk Environment
        /// <summary>
        /// GetRandomScsiController
        ///    Get Random ScsiController, including ScsiControllerIndex and ScsiControllerId
        /// </summary>
        /// <param name="psMachine">PowerShell machine</param>
        /// <param name="scsiControllerPrefix">the variable for ScsiController</param>
        /// <param name="vmConfigPrefix">the variable for Virtual machine configuraiton</param>
        /// <returns>A random picked up ScsiController</returns>
        public static SortedList<string, string> GetRandomScsiController(PowershellMachine psMachine, string scsiControllerPrefix = null, string vmConfigPrefix = null)
        {
            Random rand = new Random();
            SortedList<string, string> scsiController = new SortedList<string, string>();

            if (scsiControllerPrefix == null)
            {
                scsiControllerPrefix = HelperAdapter.GetParameter("ScsiController");
            }

            if (vmConfigPrefix == null)
            {
                vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }

            // Get ScsiController 
            GetEmcVirtualMachineScsiController getScsiController = new GetEmcVirtualMachineScsiController(vmConfigPrefix);
            getScsiController.PrefixString = scsiControllerPrefix;
            getScsiController.RunCMD(psMachine, true);

            string result = GetPropertyValue(psMachine, scsiControllerPrefix, "count");

            if (result.Trim() == string.Empty)
            {
                // scsiController object is not an array, mean there's only 1 scsi controller in the vm
                string scsiControllerIndex = GetPropertyValue(psMachine, scsiControllerPrefix, "ScsiControllerIndex");
                scsiController.Add("ScsiControllerIndex", scsiControllerIndex);

                string scsiControllerId = GetPropertyValue(psMachine, scsiControllerPrefix, "ScsiControllerId");
                scsiController.Add("ScsiControllerId", scsiControllerId);
            }
            else
            {
                // multiple scsi controllers
                int count = int.Parse(result);
                int i = rand.Next(count);
                string scsiControllerIndex = GetPropertyValue(psMachine, scsiControllerPrefix + "[" + i.ToString() + "]", "ScsiControllerIndex");
                scsiController.Add("ScsiControllerIndex", scsiControllerIndex);

                string scsiControllerId = GetPropertyValue(psMachine, scsiControllerPrefix + "[" + i.ToString() + "]", "ScsiControllerId");
                scsiController.Add("ScsiControllerId", scsiControllerId);
            }

            return scsiController;

        }

        /// <summary>
        /// GetVirtualMachineConfiguration
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="prefix">vm configuraiton prefix</param>
        /// <param name="vmPrefix">vm prefix</param>
        /// <param name="hypervisorPrefix">hypervisor prefix</param>
        /// <returns>Get-EmcVirtualMachineConfiguration output string</returns>
        public static string GetVirtualMachineConfiguration(PowershellMachine psMachine, string prefix = null, string vmPrefix = null, string hypervisorPrefix = null)
        {
            string result;
            GetEmcVirtualMachineConfiguration getEmcVirtualMachineConfiguration;

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }
            if (vmPrefix == null && hypervisorPrefix == null)
            {
                vmPrefix = HelperAdapter.GetParameter("VirtualMachine");
            }

            if (vmPrefix != null)
            {
                getEmcVirtualMachineConfiguration = new GetEmcVirtualMachineConfiguration(null, vmPrefix);
            }
            else
            {
                getEmcVirtualMachineConfiguration = new GetEmcVirtualMachineConfiguration(null, null, hypervisorPrefix);
            }

            getEmcVirtualMachineConfiguration.PrefixString = prefix;
            result = getEmcVirtualMachineConfiguration.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// GetRandomScsiControllerLocation
        ///    Get the random available scsi controller location
        /// </summary>
        /// <param name="psMachine">PowerShell machine</param>
        /// <param name="scsiControllerIndex">string of scsi controller index</param>
        /// <param name="scsiControllerId">string of scsi controller id</param>
        /// <param name="hypervPrefix">prefix for hyprvisor object</param>
        /// <param name="vmConfigurationPrefix">prefix for virtual machine configuration object</param>
        /// <returns></returns>
        public static string GetRandomScsiControllerLocation(PowershellMachine psMachine, string scsiControllerIndex = null, string scsiControllerId = null,
            string vmConfigurationPrefix = null)
        {
            Random rand = new Random();

            if (vmConfigurationPrefix == null)
            {
                vmConfigurationPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }
            GetEmcAvailableScsiControllerLocation getScsiControllerLocation = new GetEmcAvailableScsiControllerLocation(vmConfigurationPrefix, 
                scsiControllerIndex, null, scsiControllerId);
            string result = getScsiControllerLocation.RunCMD(psMachine, true);
            string[] resultLines = result.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            int i = rand.Next(resultLines.Length);
            return resultLines[i];
        }

        /// <summary>
        /// GetRandomPassthroughDisk
        ///     Get the random available passthrough disk
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="hypervPrefix">The prefix of hypervisor</param>
        /// <param name="psthruDiskPrefix">The prefix of passthrough disk</param>
        /// <returns>The key/value pairs of the passthrough disk</returns>
        public static SortedList<string, string> GetRandomPassthroughDisk(PowershellMachine psMachine, string hypervPrefix = null, string psthruDiskPrefix = null, HyperVisorType type = HyperVisorType.HyperV)
        {
            Random rand = new Random();
            List<string> ps = new List<string>();

            if (hypervPrefix == null)
            {
                hypervPrefix = HelperAdapter.GetParameter("Hypervisor");
            }
            if (psthruDiskPrefix == null)
            {
                psthruDiskPrefix = HelperAdapter.GetParameter("PassthroughDisk");
            }

            GetEmcAvailablePassthroughDiskCandidate getPassthroughDisk = null;
            if (type == HyperVisorType.HyperV)
            {
                getPassthroughDisk = new GetEmcAvailablePassthroughDiskCandidate(hypervPrefix);
            }
            else if (type == HyperVisorType.VMWare)
            {
                getPassthroughDisk = new GetEmcAvailablePassthroughDiskCandidate(null, null, hypervPrefix);
            }
            else
            {
                PSException ex = new PSException("hypervisor type not support");
                throw ex;
            }
            getPassthroughDisk.PrefixString = HelperAdapter.GetParameter("PassthroughDisks");
            string result = getPassthroughDisk.RunCMD(psMachine, true);
            List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(result);

            int i = 0;
            if (disksList.Count == 1)
            {
                ps.Add(psthruDiskPrefix + " = " + getPassthroughDisk.PrefixString);
                psMachine.RunScript(ps, new List<PSParam>());
            }
            else
            {
                i = rand.Next(disksList.Count);

                ps.Add(psthruDiskPrefix + " = " + getPassthroughDisk.PrefixString + "[" + i + "]");
                psMachine.RunScript(ps, new List<PSParam>());
            }

            return disksList[i];
        }

        /// <summary>
        /// SetVirtualDiskEnvironment
        ///     Add filebased/passthourgh virtual disk to virtual machine
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="hostDisk">the prefix of passthrough disk in hyperV</param>
        /// <param name="scsiLun">the prefix of scsi disk in VMware</param>
        /// <param name="path">the path of the filebased disk</param>
        /// <param name="vmConfig">the prefix of virtual machine configuration</param>
        /// <param name="location">scsi controller location</param>
        /// <param name="scsiControllerIndex">scsi controller index</param>
        /// <param name="prefix">the prefix of virtual disk configuration</param>
        /// <returns>virtual disk configuration</returns>
        public static string SetVirtualDiskEnvironment(PowershellMachine psMachine, string candidateDisk, string path = null, string vmConfig = null, string location = null, string scsiControllerIndex = null, string prefix = null)
        {
            string result = null;
            TestLog log = TestLog.GetInstance();

            if (vmConfig == null)
            {
                vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }
            if (location == null)
            {
                location = HelperAdapter.GetParameter("Location");
            }

            if (path != null)
            {
                if (prefix == null)
                {
                    prefix = HelperAdapter.GetParameter("FilebasedDiskConfiguration");
                }
                AddEmcFilebasedDiskToVirtualMachine addFilebsedDisk = new AddEmcFilebasedDiskToVirtualMachine(path, vmConfig, location, null, null, null, scsiControllerIndex);
                addFilebsedDisk.PrefixString = prefix;
                result = addFilebsedDisk.RunCMD(psMachine, true);
            }
            else
            {
                if (prefix == null)
                {
                    prefix = HelperAdapter.GetParameter("PassthroughDiskConfiguration");
                }

                AddEmcPassthroughDiskToVirtualMachine addPassthoughDisk = null;

                GetEmcVirtualMachineHypervisor hypervisor = new GetEmcVirtualMachineHypervisor(vmConfig);
                hypervisor.PrefixString = HelperAdapter.GetParameter("Hypervisor");
                hypervisor.RunCMD(psMachine);
                if (TestSetup.GetPropertyValue(psMachine, hypervisor.PrefixString, "Model").Contains("Hyper-V"))
                {
                    addPassthoughDisk = new AddEmcPassthroughDiskToVirtualMachine(null,  vmConfig, location, null, scsiControllerIndex, null, null, candidateDisk);
                }
                else
                {
                    addPassthoughDisk = new AddEmcPassthroughDiskToVirtualMachine(null, vmConfig, location, null, scsiControllerIndex, null, null, null, candidateDisk);
                }
                addPassthoughDisk.PrefixString = prefix;
                result = addPassthoughDisk.RunCMD(psMachine, true);
            }

            return result;
        }

        /// <summary>
        /// ClearVirtualDiskEnvironment
        ///     Remove filebased/passthrough disk from virtual machine
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="location">scsi controller location</param>
        /// <param name="scsiControllerIndex">scsi controller index</param>
        /// <param name="vmConfig">the prefix of virtual machine configuration</param>
        public static void ClearVirtualDiskEnvironment(PowershellMachine psMachine, string location = null, string scsiControllerIndex = null, string vmConfig = null)
        {
            if (vmConfig == null)
            {
                vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            }
            if (location == null)
            {
                location = HelperAdapter.GetParameter("Location");
            }

            RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfig, location, "Force", null, scsiControllerIndex);
            removeDisk.RunCMD(psMachine);
        }
        # endregion         
        
        #region CIFS SharedfolderPool SharedFolder Environment
        public static void SetVNXESharedFolderPoolEnvironment(PowershellMachine psMachine, string prefix = null)
        {
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("SharedFolderPool");
            }
            string poolID=HelperAdapter.GetParameter("PoolNameForVNXeFile","LunConfig");
            GetEmcStoragePool getPool = new GetEmcStoragePool(poolID, null, null, null, "File");
            getPool.PrefixString = prefix;
            getPool.RunCMD(psMachine);
        }

        /// <summary>
        /// The method is to get a name or ID for VNXFilePool.
        /// </summary>
        /// <param name="psMachine">PowerShell instance.</param>
        /// <returns>The name or ID for VNXFilePool.</returns>
        public static string GetVNXFileStoagePoolNameOrID(PowershellMachine psMachine)
        {
            GetEmcVNXFileStoragePool filePool = new GetEmcVNXFileStoragePool();
            string result = filePool.RunCMD(psMachine);
            List<SortedList<string, string>> resultList = HelperAdapter.GenerateKeyValuePairsList(result);
            List<string> nameOrID = new List<string>();
            foreach (SortedList<string, string> temp in resultList)
            {
                if (temp["AvailableCapacity"] != "0")
                {
                    nameOrID.Add(temp["Name"]);
                    nameOrID.Add(temp["ArrayPoolId"]);
                }
            }
            int randomNum = new Random().Next(nameOrID.Count);
            return nameOrID[randomNum];
        }

        /// <summary>
        /// The method is used to Set prefix value to a vnxFileStoragePool.
        /// </summary>
        /// <param name="psMachine">PSMachine instance.</param>
        /// <param name="systemString">Storage system.</param>
        /// <param name="prefix">The parameter for storagepool.</param>
        public static void SetVNXFileStoragePoolEnvironment(PowershellMachine psMachine, string systemString = null, string prefix = null)
        {
            if (systemString == null)
            {
                systemString = HelperAdapter.GetParameter("System");
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("FileStoragePool");
            }
            string idString = TestSetup.GetVNXFileStoagePoolNameOrID(psMachine);
            GetEmcVNXFileStoragePool getPool = new GetEmcVNXFileStoragePool(idString, systemString);
            getPool.PrefixString = prefix;
            getPool.RunCMD(psMachine);
        }

        /// <summary>
        /// The method is used to set SharedFolderPool environment.
        /// </summary>
        /// <param name="psMachien">PowerShell instance.</param>
        /// <param name="filsStoragePool">file storage pool to create sharedfolderpool.</param>
        /// <param name="prefix">the shared folder pool parameter.</param>
        public static void SetVNXSharedFolderPoolEnvironment(PowershellMachine psMachien, string filsStoragePool = null, string prefix = null)
        {
            if (filsStoragePool == null)
            {
                filsStoragePool = HelperAdapter.GetParameter("FileStoragePool");
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("SharedFolderPool");
            }
            string capacityString = "1gb";
            string nameString = HelperAdapter.GenerateName("SFP");
            string pathString = HelperAdapter.GenerateName("SFPPath");
            NewEmcVNXSharedFolderPool sharedFolderPool = new NewEmcVNXSharedFolderPool(filsStoragePool, nameString,pathString, capacityString);
            sharedFolderPool.PrefixString = prefix;
            sharedFolderPool.RunCMD(psMachien);
        }

        /// <summary>
        /// The method is used to remove VNX SharedFolderPool
        /// </summary>
        /// <param name="psMachine">PowerShell instance.</param>
        /// <param name="sharedFolderPool">The sharedfolderPool to be removed.</param>
        public static void RemoveVNXSharedFolderPoolEnvironment(PowershellMachine psMachine, string sharedFolderPool = null)
        {
            if (sharedFolderPool == null)
            {
                sharedFolderPool = HelperAdapter.GetParameter("SharedFolderPool");
            }
            RemoveEmcVNXSharedFolderPool removeSharedFolder = new RemoveEmcVNXSharedFolderPool(sharedFolderPool, "force");
            removeSharedFolder.RunCMD(psMachine);
        }

        /// <summary>
        /// The mehod is used to remove sharedfolder.
        /// </summary>
        /// <param name="psMachine">The powershell instance.</param>
        /// <param name="sharedFolder">The sharedfolder to be removed,</param>
        /// <param name="sharedFolderName">The shared folder name to be removed.</param>
        public static void RemoveSharedFolderEnvironment(PowershellMachine psMachine, string sharedFolder = null, string sharedFolderName = null)
        {
            if ((sharedFolder == null) && (sharedFolderName == null))
            {
                sharedFolder = HelperAdapter.GetParameter("SharedFolder");
            }
            if (sharedFolderName != null)
            {
                GetEmcSharedFolder getFolder = new GetEmcSharedFolder(sharedFolderName);
                getFolder.PrefixString = HelperAdapter.GetParameter("SharedFolder");
                getFolder.VerifyTheCMD(psMachine);
                sharedFolder = HelperAdapter.GetParameter("SharedFolder");
            }
            RemoveEmcCIFSSharedFolder removeFolder = new RemoveEmcCIFSSharedFolder(sharedFolder, "Force");
            removeFolder.RunCMD(psMachine);
        }

        /// <summary>
        /// The mothod is used to create a sharedfolder.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        /// <param name="pool">The pool for sharedfolder.</param>
        /// <param name="name">The name for sharedfolder.</param>
        /// <param name="path">The path for sharedfolder.</param>
        /// <param name="capacity">The capacity for sharedfolder.</param>
        /// <param name="prefix">The sharedfolder prefix.</param>
        /// <returns>The sharedfolder paremeter.</returns>
        public static string SetCIFSSharedFolderEnvironment(PowershellMachine psMachine, string pool = null, string name = null, string path = null,
            string capacity = null, string prefix = null)
        {
            if (pool == null)
            {
                pool = HelperAdapter.GetParameter("SharedFolderPool");
            }
            if (name == null)
            {
                name = HelperAdapter.GenerateName("SFName");
            }
            if (path == null)
            {
                path = HelperAdapter.GenerateName("SFPath");
            }
            if (capacity == null)
            {
                string capacityString = HelperAdapter.GetParameter("CapacityForFileFolder", "LunConfig");
                capacity = capacityString;
            }
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("SharedFolder");
            }
            NewEmcCIFSSharedFolder newFolder = new NewEmcCIFSSharedFolder(pool, name, path, capacity);
            newFolder.PrefixString = prefix;
            string result=newFolder.RunCMD(psMachine);
            return result;
        }

        /// <summary>
        /// The method is used to set mountpoint of a sharedfolder.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        /// <param name="host">Host.</param>
        /// <param name="driver">The mount point.</param>
        /// <param name="sharedFolder">Shared folder</param>
        /// <param name="credential">Credential for host.</param>
        /// <returns>The mounted result.</returns>
        public static string SetMountPointEnvironment(PowershellMachine psMachine, string host = null, string driver = null, string sharedFolder = null,
            string credential = null)
        {
            if (host == null)
            {
                host = HelperAdapter.GetParameter("Host");
            }
            if (driver == null)
            {
                driver = GetRandomDriveLetter(psMachine, host);
            }
            if (sharedFolder == null)
            {
                sharedFolder = HelperAdapter.GetParameter("SharedFolder");
            }
            if (credential == null)
            {
                credential = HelperAdapter.GetParameter("HostCredential");
            }
            SetEmcCIFSSharedFolderMountPoint setMount = new SetEmcCIFSSharedFolderMountPoint(host, driver, sharedFolder, credential);
            setMount.PrefixString = HelperAdapter.GetParameter("NetworkShareFolder");
            string result=setMount.RunCMD(psMachine);
            return result;
        }

        /// <summary>
        /// The method is used to remove the mountpoint of sharedfolder on host.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        /// <param name="host">The host.</param>
        /// <param name="sharedfolder">SharedFolder to be removed.</param>
        public static void RemoveMountPointEnvironment(PowershellMachine psMachine, string host = null, string sharedfolder = null)
        {
            if (sharedfolder == null)
            {
                sharedfolder = HelperAdapter.GetParameter("NetworkShareFolder");
            }
            if (host == null)
            {
                host=HelperAdapter.GetParameter("Host");
            }
            RemoveEmcCIFSSharedFolderMountPoint removeMountPoint = new RemoveEmcCIFSSharedFolderMountPoint(host, sharedfolder);
            removeMountPoint.RunCMD(psMachine);
        }

        #endregion        

        #region StandByLun Envionment
        /// <summary>
        /// The method is used to create StandByLunEnvironment
        /// </summary>
        /// <param name="psMachine">PowerShell instance.</param>
        /// <returns>The result for create standbyLun.</returns>
        public static string SetStandbyLunEnvironment(PowershellMachine psMachine)
        {
            string storagesystem = HelperAdapter.GetParameter("System");
            string count = HelperAdapter.GetParameter("CountForStandByLun", "LunConfig");
            string capacity = HelperAdapter.GetParameter("CapacityForStandByLun", "LunConfig");

            NewEmcStandByLun standbyLuns = new NewEmcStandByLun(storagesystem, count, capacity);
            standbyLuns.PrefixString = HelperAdapter.GetParameter("StandByLuns");
            string result = standbyLuns.RunCMD(psMachine);
            return result;
        }

        /// <summary>
        /// The method is used to remove standbylun envrionment according to standbylun.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        public static void RemoveStandbyLunEnvironment(PowershellMachine psMachine)
        {
            RemoveEmcStandByLun rmLun = new RemoveEmcStandByLun(HelperAdapter.GetParameter("StandByLuns"));
            rmLun.RunCMD(psMachine);
        }
        #endregion

        # region XenServer Environment
        /// <summary>
        /// SetSREnvironment
        ///     Create a XenServer storage repository
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="lun">The Lun parameter</param>
        /// <param name="xenServer">The XenServer parameter</param>
        /// <param name="name">Storage repository's name</param>
        /// <param name="description">Storage repository's description</param>
        /// <param name="srPrefix">Storage repository prefix</param>
        /// <returns>Storage repository information</returns>
        public static string SetSREnvironment(PowershellMachine psMachine, string lun = null, string xenServer = null, string name = null, string description = null, string srPrefix = null)
        {
            TestLog log = TestLog.GetInstance();
            string result = null;

            if (lun == null)
            {
                lun = HelperAdapter.GetParameter("Lun");
            }
            if (xenServer == null)
            {
                xenServer = HelperAdapter.GetParameter("XenServer");
            }
            if (name == null)
            {
                string path = HelperAdapter.GetProperty("DiskVolumeConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path, "SR");
                name = dic["NamePrefix"] + HelperAdapter.GenerateRandomString();
            }
            if (srPrefix == null)
            {
                srPrefix = HelperAdapter.GetParameter("StorageRepository");
            }

            string targetPort = HelperAdapter.GetParameter("TargetPort");
            TestSetup.GetRandomTargetPort(psMachine);

            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(lun, xenServer, null, null, "Available");
            setLunAccess.RunCMD(psMachine);

            NewEmcXenServerStorageRepository xenServerSR = new NewEmcXenServerStorageRepository(lun, xenServer, name, targetPort, description, null, null);
            xenServerSR.PrefixString = srPrefix;
            try
            {
                result = xenServerSR.RunCMD(psMachine, true);
            }
            catch
            {
                log.LogError(xenServerSR.ToCMDString());
                setLunAccess = new SetEmcLunAccess(lun, xenServer, null, null, "Unavailable");
                setLunAccess.RunCMD(psMachine);
            }

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);

            return result;
        }

        /// <summary>
        /// SetXenServerVirtualDiskEnvironment
        ///     Create a new virtual disk in a XenServer storage repository
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="sr">The storage repository parameter</param>
        /// <param name="xenServer">The XenServer parameter</param>
        /// <param name="size">Virtual disk's size</param>
        /// <param name="name">Vitual disk's name</param>
        /// <param name="diskPrefix">Virtual disk's prefix</param>
        /// <returns>The vitual disk information</returns>
        public static string SetXenServerVirtualDiskEnvironment(PowershellMachine psMachine, string sr = null, string xenServer = null, string size = null, string name = null, string diskPrefix = null)
        {
            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "XenServerVirtualDisk");

            if (sr == null)
            {
                sr = HelperAdapter.GetParameter("StorageRepository");
            }
            if (xenServer == null)
            {
                xenServer = HelperAdapter.GetParameter("XenServer");
            }
            if (size == null)
            {
                size = dic["Size"];
            }
            if (name == null)
            {
                name = dic["NamePrefix"] + HelperAdapter.GenerateRandomString();
            }
            if (diskPrefix == null)
            {
                diskPrefix = HelperAdapter.GetParameter("XenServerVirtualDisk");
            }

            NewEmcXenServerVirtualDiskImage xenServerDisk = new NewEmcXenServerVirtualDiskImage(sr, xenServer, size, name, null, null);
            xenServerDisk.PrefixString = diskPrefix;
            string result = xenServerDisk.RunCMD(psMachine, true);

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);

            return result;
        }

        /// <summary>
        /// ClearXenServerVirtualDiskEnvironment
        ///     Remove XenServer virtual disk from SR
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="virtualDisk">virtual disk's prefix</param>
        public static void ClearXenServerVirtualDiskEnvironment(PowershellMachine psMachine, string virtualDisk = null, string xenServer = null)
        {
            if (virtualDisk == null)
            {
                virtualDisk = HelperAdapter.GetParameter("XenServerVirtualDisk");
            }
            if (xenServer == null)
            {
                xenServer = HelperAdapter.GetParameter("XenServer");
            }

            RemoveEmcXenServerVirtualDiskImage xenServerDisk = new RemoveEmcXenServerVirtualDiskImage(virtualDisk);
            xenServerDisk.RunCMD(psMachine);

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);
        }

        /// <summary>
        /// ClearSREnvironment
        ///     Remove the specified storage repository
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="srPrefix">Storage repository's prefix</param>
        public static void ClearSREnvironment(PowershellMachine psMachine, string srPrefix = null, string lun = null, string xenServer = null)
        {
            if (srPrefix == null)
            {
                srPrefix = HelperAdapter.GetParameter("StorageRepository");
            }
            if (lun == null)
            {
                lun = HelperAdapter.GetParameter("Lun");
            }
            if (xenServer == null)
            {
                xenServer = HelperAdapter.GetParameter("XenServer");
            }

            RemoveEmcXenServerStorageRepository xenServerSR = new RemoveEmcXenServerStorageRepository(srPrefix, null, null);
            xenServerSR.RunCMD(psMachine);

            SetEmcLunAccess setLunAccess = new SetEmcLunAccess(lun, xenServer, "Unavailable");
            setLunAccess.RunCMD(psMachine);

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);
        }
        # endregion 

        # region VMware Environment
        /// <summary>
        /// SetDataStoreEnvironment
        ///     Retrieve the datastore information 
        /// </summary>
        /// <param name="psMachine">Powershell machine instance</param>
        /// <param name="prefix">datastore prefix string</param>
        /// <returns>Get-EmcDataStore output string</returns>
        public static string SetDataStoreEnvironment(PowershellMachine psMachine, string prefix = null)
        {
            string result;

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("DataStore");
            }
            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            string dataStoreName = HelperAdapter.Load(path, "DataStore")["Name"];
            GetEmcDataStore getEmcDataStore = new GetEmcDataStore(dataStoreName);
            getEmcDataStore.PrefixString = prefix;
            result = getEmcDataStore.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// SetESXHostEnvironment
        ///    Retrieve ESX Host information
        /// </summary>
        /// <param name="psMachine">Powershell machine isntance</param>
        /// <param name="prefix">esx host prefix string</param>
        /// <param name="vmwarePrefix">vmware prefix string</param>
        /// <param name="index">index number of esx hosts in configure file</param>
        /// <returns>Get-EmcESXHost output string</returns>
        public static string SetESXHostEnvironment(PowershellMachine psMachine, string prefix = null, string vmwarePrefix = null, int index = 0)
        {
            string result;
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("ESXHost");
            }
            if (vmwarePrefix == null)
            {
                vmwarePrefix = HelperAdapter.GetParameter("VMWare");
            }

            Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[index];
            string esxhostname = dic["HostName"];
            GetEmcESXHost getEmcESXHost = new GetEmcESXHost(esxhostname, vmwarePrefix);
            getEmcESXHost.PrefixString = prefix;
            result = getEmcESXHost.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// GetScsiLunFromDataStore
        ///    Get scsi luns of a specified datastore
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="prefix">scsilun prefix</param>
        /// <param name="datastorePrefix">datastore prefix</param>
        /// <returns>Get-EmcScsiLun result string</returns>
        public static string GetScsiLunFromDataStore(PowershellMachine psMachine, string prefix = null, string datastorePrefix = null)
        {
            string result;

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("ScsiLun");
            }
            if (datastorePrefix == null)
            {
                datastorePrefix = HelperAdapter.GetParameter("DataStore");
            }
            
            GetEmcScsiLun getEmcScsiLun = new GetEmcScsiLun(null, null, null, null, null, datastorePrefix);
            getEmcScsiLun.PrefixString = prefix;
            result = getEmcScsiLun.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// GetLunFromScsiLun
        ///    Get Lun information of a scsi lun
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="prefix">lun prefix string</param>
        /// <param name="scsiLunPrefix">scsilun prefix string</param>
        /// <returns>Get-EmcLun output string</returns>
        public static string GetLunFromScsiLun(PowershellMachine psMachine, string prefix = null, string scsiLunPrefix = null)
        {

            string result;

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Lun");
            }
            if (scsiLunPrefix == null)
            {
                scsiLunPrefix = HelperAdapter.GetParameter("ScsiLun");
            }

            GetEmcLun getEmcLun = new GetEmcLun(null, null, null, null, null, null, null, null, null,scsiLunPrefix);
            getEmcLun.PrefixString = prefix;
            result = getEmcLun.RunCMD(psMachine, true);

            return result;
        }
        # endregion 

        # region Snapshot Environment
        /// <summary>
        /// SetSnapshotPool
        ///     Random select a snapshot pool
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="prefix">snapshot pool prefix</param>
        public static void SetSnapshotPool(PowershellMachine psMachine, string prefix = null, string poolId = null)
        {
            GetEmcSnapshotPool getEmcSnapshotPool = null;

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("SnapshotPool");
            }
            string snapshotPools = prefix + "s";

            if (poolId != null)
            {
                getEmcSnapshotPool = new GetEmcSnapshotPool("\"" + poolId + "\"");
            }
            else
            {
                getEmcSnapshotPool = new GetEmcSnapshotPool();
            }

            getEmcSnapshotPool.PrefixString = snapshotPools;
            getEmcSnapshotPool.RunCMD(psMachine);

            string count = GetPropertyValue(psMachine, snapshotPools, "count");
            if (String.IsNullOrEmpty(count))
            {
                GetPropertyValue(psMachine, prefix + "=" + snapshotPools);
            }
            else 
            {
                Random r = new Random();
                int i;
                i = r.Next(0, int.Parse(count));
                GetPropertyValue(psMachine, prefix + "=" + snapshotPools + "[" + i + "]");
            }
        }

        /// <summary>
        /// EnableSnapshotLun
        ///    activate snapshot lun
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="snapshotLunPrefix">snapshot lun prefix string</param>
        /// <param name="sourceLunPrefix">source lun prefix string</param>
        public static string EnableSnapshotLun(PowershellMachine psMachine, string snapshotLunPrefix = null, string sourceLunPrefix = null)
        {
            string result;
            if (snapshotLunPrefix == null)
            {
                snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");
            }
            if (sourceLunPrefix == null)
            {
                sourceLunPrefix = HelperAdapter.GetParameter("Lun");
            }
            EnableEmcSnapshotLun enableSnapshotLun = new EnableEmcSnapshotLun(snapshotLunPrefix, sourceLunPrefix);
            result = enableSnapshotLun.VerifyTheCMD(psMachine);

            return result;
        }

        /// <summary>
        /// GetSnapshotPoolId
        ///     Get snapshot pool id from config file
        /// </summary>
        /// <param name="storageType">storage type</param>
        /// <returns>snapshot pool id</returns>
        public static string GetSnapshotPoolId(string storageType)
        {
            string poolID = null;

            if (storageType == "VMAX")
            {
                string path = HelperAdapter.GetProperty("SnapshotLunConfig");
                Dictionary<string, string> dic = HelperAdapter.Load(path);
                string poolNameForStorageType = "SnapshotPoolIdFor" + storageType;
                poolID = dic[poolNameForStorageType];
            }
            else if (storageType == "VNX" || storageType == "VNX-Block" || storageType == "CLARiiON-CX4")
            {
                poolID = "Reserved Lun Pool";
            }

            return poolID;

        }

        /// <summary>
        /// SetRetention
        ///     Create timespan object
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="prefix">timespan object prefix</param>
        /// <returns>timespan object output string</returns>
        public static string SetRetention(PowershellMachine psMachine, string prefix = null)
        {
            string result;

            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("Timespan");
            }
            
            // New Retention timespan object
            string path = HelperAdapter.GetProperty("SnapshotLunConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path);
            string hours = dic["RetentionHours"];
            string minutes = dic["RetentionMinutes"];
            string seconds = dic["RetentionSeconds"];

            string cmd = prefix + "= New-Object system.timespan(" + hours + "," + minutes + "," + seconds + ")";
            result = GetPropertyValue(psMachine, cmd);

            return result;
        }

        /// <summary>
        /// SetSnasphotLunEnvironment
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="prefix">snapshot lun prefix</param>
        /// <param name="sourcLunPrefix">source lun prefix</param>
        /// <param name="snapshotPoolPrefix">snapshot pool prefix</param>
        /// <param name="noactivation">activate flag</param>
        /// <returns></returns>
        public static string SetSnapshotLunEnvironment(PowershellMachine psMachine, string prefix = null, string sourcLunPrefix = null, string snapshotPoolPrefix = null, 
            bool noactivation = false, string retentionPrefix = null)
        {
            string result;
            
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("SnapshotLun");
            }
            if (sourcLunPrefix == null)
            {
                sourcLunPrefix = HelperAdapter.GetParameter("Lun");
            }
            if (storageSystemType == "VNXe")
            {
                snapshotPoolPrefix = null;
                noactivation = true;
            }
            

            NewEmcSnapshotLun newEmcSnapshotLun;
            if (noactivation)
            {
                newEmcSnapshotLun = new NewEmcSnapshotLun(sourcLunPrefix, snapshotPoolPrefix, null, "noactivation", retentionPrefix);
            }
            else
            {
                newEmcSnapshotLun = new NewEmcSnapshotLun(sourcLunPrefix, snapshotPoolPrefix, null, null, retentionPrefix);
            }
            newEmcSnapshotLun.PrefixString = prefix;
            result = newEmcSnapshotLun.RunCMD(psMachine, true);

            return result;
        }

        /// <summary>
        /// ClearSnapshotLunEnvironment
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="snapshotLunID">snapshot lun id</param>
        /// <param name="prefix">snapshot lun prefix</param>
        public static void ClearSnapshotLunEnvironment(PowershellMachine psMachine, string snapshotLunID, string prefix = null)
        {
            // Remove snapshot Lun 
            if (prefix == null)
            {
                prefix = HelperAdapter.GetParameter("SnapshotLun");
            }
            RemoveEmcSnapshotLun removesnapshotLun = new RemoveEmcSnapshotLun(prefix);

            removesnapshotLun.VerifyTheCMD(psMachine, snapshotLunID);
        }

        /// <summary>
        /// GetSnapshotLunTimeSpan
        ///     Get the milliseconds between expiration and creation time
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="snapshotLunPrefix">snapshotLun prefix</param>
        /// <returns>milliseconds between expiration and creation time</returns>
        public static string GetSnapshotLunTimeSpan(PowershellMachine psMachine, string snapshotLunPrefix = null)
        {
            string milliSeconds;

            if (snapshotLunPrefix == null)
            {
                snapshotLunPrefix = HelperAdapter.GetParameter("SnapshotLun");               
            }
            GetPropertyValue(psMachine, "$createdate = " + snapshotLunPrefix, "OtherProperties[\"CreationTime\"].data");
            GetPropertyValue(psMachine, "$createdate");
            GetPropertyValue(psMachine, "$expiredate = " + snapshotLunPrefix,  "OtherProperties[\"ExpirationTime\"].data");
            GetPropertyValue(psMachine, "$expiredate");
            milliSeconds = GetPropertyValue(psMachine, "([datetime]$expiredate - [datetime]$createdate)", "TotalMilliseconds");

            return milliSeconds;
        }

        # endregion

        # region Common functions: GetParameterValue, GetPropertyValue
        /// <summary>
        /// The method is used to get value of parameter which is used in the powershell session.
        /// </summary>
        /// <param name="psMachine">The Powershell machine instance.</param>
        /// <param name="parameter">The parameter name defined in PSParameterConfig fiel.</param>
        /// <param name="parameterName">The parameter name defined in PS section.</param>
        /// <returns>The value for the parameter in the powershell session.</returns>
        public static string GetParameterValue(PowershellMachine psMachine, string parameter, string parameterName = null)
        {
            if (parameterName == null)
            {
                parameterName = HelperAdapter.GetParameter(parameter);
            }
            List<string> ps = new List<string>();
            ps.Add(parameterName);
            string parameterValue = psMachine.RunScript(ps, new List<PSParam> { }).OutStr;
            return parameterValue;
        }

        /// <summary>
        /// GetPropertyValue
        /// </summary>
        /// <param name="psMachine"></param>
        /// <param name="prefix"></param>
        /// <param name="property"></param>
        /// <returns></returns>
        public static string GetPropertyValue(PowershellMachine psMachine, string prefix, string property = null)
        {
            List<string> ps = new List<string>();

            if (property != null)
            {
                ps.Add(prefix + "." + property);
            }
            else
            {
                ps.Add(prefix);
            }

            string result = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

            return result;
        }
        # endregion 

        # region SSH related methods/non-ESI powershell command
        /// <summary>
        /// RunSSHCmd
        ///     Run SSH command on remote host
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="password">remote host password</param>
        /// <param name="username">remote host username</param>
        /// <param name="hostIP">remote host IP</param>
        /// <param name="command">Command string</param>
        /// <returns>Output result</returns>
        public static string RunSSHCmd(PowershellMachine psMachine, string password, string username, string hostIP, string command)
        {
            List<string> ps = new List<string>();
            string cmdstr = @".\plink.exe";
            cmdstr = cmdstr + " " + username + "@" + hostIP + " -pw " + password + " -ssh" + " \"" + command + "\"";

            ps.Add(cmdstr);
            string result = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            return result;
        }


        /// <summary>
        /// TestPath
        ///     Verify whether path exists
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="path">directory/file path</param>
        /// <returns>return true when path exists, return false when path doesn't exist</returns>
        public static bool TestPath(PowershellMachine psMachine, string path)
        {
            List<string> ps = new List<string>();

            ps.Add(string.Format("Test-Path \"{0}\"", path));
            string ret = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;

            if (ret.Trim().Equals("True"))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// TestPath
        ///     Verify whether path exists using SSH
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="path">directory/file path</param>
        /// <param name="password">remote machine password</param>
        /// <param name="username">remote machine username</param>
        /// <param name="hostIP">remote machine host IP</param>
        /// <returns>return true when path exists, return false when path doesn't exist</returns>
        public static bool TestPath(PowershellMachine psMachine, string path, string password, string username, string hostIP)
        {
            string command = "ls " + path;
            try
            {
                string ret = RunSSHCmd(psMachine, password, username, hostIP, command);
            }
            catch
            {
                return false;
            }
            return true;
        }

        /// <summary>
        /// RemoveItem
        ///     Deletes the specified items
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="path">Specifies a path to the items being removed.</param>
        public static void RemoveItem(PowershellMachine psMachine, string path)
        {
            List<string> ps = new List<string>();

            ps.Add(string.Format("Remove-Item -path \"{0}\"", path));
            psMachine.RunScript(ps, new List<PSParam>() { });

        }

        /// <summary>
        /// RemoveItem
        ///     Deletes the specified items using SSH
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="path">Specifies a path to the items being removed.</param>
        /// <param name="password">remote machine password</param>
        /// <param name="username">remote machine username</param>
        /// <param name="hostIP">remote machine host IP</param>
        public static void RemoveItem(PowershellMachine psMachine, string path, string password, string username, string hostIP)
        {
            string command = "vmkfstools -U " + path;
            string ret = RunSSHCmd(psMachine, password, username, hostIP, command);
            if (ret.Contains("No such file or directory"))
            {
                PSException pe = new PSException(ret);
                throw pe;
            }
        }

        /// <summary>
        /// CopyItem
        ///     Copy file
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="sourcePath">Source file path</param>
        /// <param name="targetPath">Target file path</param>
        public static void CopyItem(PowershellMachine psMachine, string sourcePath, string targetPath)
        {
            List<string> ps = new List<string>();

            ps.Add(string.Format("Copy-Item -path \"{0}\" \"{1}\"", sourcePath, targetPath));
            psMachine.RunScript(ps, new List<PSParam>() { });
        }

        /// <summary>
        /// AddContent
        ///     Append content to a file
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="path">file path</param>
        /// <param name="content">content to append</param>
        public static void AddContent(PowershellMachine psMachine, string path, string content)
        {
            List<string> ps = new List<string>();

            ps.Add(string.Format("Add-Content -path \"{0}\" -value \"{1}\"", path, content));
            psMachine.RunScript(ps, new List<PSParam>() { });
        }

        /// <summary>
        /// CompareFiles
        ///     Check whether the content of two files are same
        /// </summary>
        /// <param name="psMachine">PowerShellMachine instance</param>
        /// <param name="file1Path">path of file1</param>
        /// <param name="file2Path">path of file2</param>
        /// <returns>
        /// If file contents are same, return "true",
        /// If file contents are different, return "false"
        /// </returns>
        public static bool CompareFiles(PowershellMachine psMachine, string file1Path, string file2Path)
        {
            List<string> ps = new List<string>();

            ps.Add(string.Format("Compare-Object -referenceobject $(get-content \"{0}\") -differenceobject $(get-content \"{1}\")", file1Path, file2Path));
            string result = psMachine.RunScript(ps, new List<PSParam>() { }).OutStr;
            if (String.IsNullOrEmpty(result.Trim()))
            {
                return true;
            }
            else
            {
                return false;
            }
        }

        /// <summary>
        /// The method is used to set host credential parameter environment.
        /// </summary>
        /// <param name="psMachine">Powershell instance.</param>
        public static void SetHostCreadentialEnvironment(PowershellMachine psMachine)
        {
            List<string> psList = new List<string>();
            psList.Add(@"$pword=ConvertTo-SecureString -String ""Password!"" -AsPlainText -Force");
            psList.Add(@"$hostCredential=New-Object -TypeName System.Management.Automation.PSCredential -ArgumentList sr5dom\administrator,$pword");
            psMachine.RunScript(psList, new List<PSParam>());
        }

        /// <summary>
        /// GetValue
        ///     Get the result of a Powershell command
        ///     Catch the exception
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="cmd">command string</param>
        /// <returns>cmd output</returns>
        public static string GetValue(PowershellMachine psMachine, string cmd)
        {
            string result = null;
            List<string> ps = new List<string>();

            ps.Add(cmd);

            try
            {
                result = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            }
            catch
            {
            }

            return result;
        }

        /// <summary>
        /// CreateFile
        ///     Create a file in current directory and write content to the file
        /// </summary>
        /// <param name="psMachine">powershell machin instance</param>
        /// <param name="file">file name</param>
        public static void CreateFile(PowershellMachine psMachine, string file)
        {
            List<string> ps = new List<string>();
            string cmd = "New-Item " + file + " -type \"file\" -value \"This is a text file.\"";
            ps.Add(cmd);

            psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
        }
        # endregion
    }        
}

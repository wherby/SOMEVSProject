using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcVNXSharedFolderPool : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string sharedfolderpoolString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcVNXSharedFolderPool
        ///     Constructor for RemoveEmcVNXSharedFolderPool class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcVNXSharedFolderPool(string sharedfolderpool = null, string force = null, string silent = null, string whatif = null,  string cmd=null)
        {

            sharedfolderpoolString = sharedfolderpool;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcVNXSharedFolderPool");

			if (sharedfolderpoolString != null)
            {
		        sb.AppendFormat(" -SharedFolderPool {0}", sharedfolderpoolString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcVNXSharedFolderPool commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcVNXSharedFolderPool</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            if (whatifString == null)
            {
                string poolResult = TestSetup.GetPropertyValue(psMachine, sharedfolderpoolString);
                SortedList<string, string> poolKeyValue = HelperAdapter.GenerateKeyValuePairs(poolResult);
                GetEmcStoragePool getPool = new GetEmcStoragePool(poolKeyValue["Name"]);
                string poolGeted= getPool.RunCMD(psMachine);
                log.AreEqual<string>(string.Empty, poolGeted.Trim(), "Pool is removed");
            }
        }
    }
}
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{
    public class UpdateEmcSystem : BaseClass
    {
        
#if true
        #region AutoGenerate
        
        private string emcsystemString = null;
        private string silentString = null;

        
        /// <summary>
        /// UpdateEmcSystem
        ///     Constructor for UpdateEmcSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public UpdateEmcSystem(string emcsystem = null, string silent = null,  string cmd = null)
        {

            emcsystemString = emcsystem;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Update-EmcSystem");

			if (emcsystemString != null)
            {
		        sb.AppendFormat(" -EmcSystem {0}", emcsystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion
#endif
        
    
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine);            
            
            return result;
        }


        private void VerifyFields(SortedList<string, string> connectSystemKeyValue, PowershellMachine psMachine)
        {                      
                        
        }

    }
}
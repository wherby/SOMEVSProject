using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcFileBasedDisk : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string hypervisorString = null;
        private string pathString = null;
        private string silentString = null;
        private string forceString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcFileBasedDisk
        ///     Constructor for RemoveEmcFileBasedDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcFileBasedDisk(string hypervisor = null, string path = null, string silent = null,  string cmd = null, string force = null, string whatif = null)
        {

            hypervisorString = hypervisor;
            pathString =  path ;
            silentString = silent;
            forceString = force;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcFileBasedDisk");

			if (hypervisorString != null)
            {
		        sb.AppendFormat(" -Hypervisor {0}", hypervisorString);
            }
			if (pathString != null)
            {
                pathString = "\"" + pathString + "\"";
                sb.AppendFormat(" -Path {0}", pathString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
            if (forceString != null)
            {
                sb.AppendFormat(" -Force");
            }
            if (whatifString != null)
            {
                sb.AppendFormat(" -WhatIf");
            }
            sb.AppendFormat(" -Confirm:$false");

            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcFileBasedDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcFileBasedDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string type, string netShare, string datastorePath, string password, string username, string hostIP)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, type, netShare, datastorePath, password, username, hostIP);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string type, string netShare, string datastorePath, string password, string username, string hostIP)
        {
            string file;
            if (pathString.IndexOf("\"") == 0)
            {
                pathString = pathString.Replace("\"", "");
            }
            if (type.Equals("vhd"))
            {                
                file = netShare + pathString.Replace(":", "$");
                if (TestSetup.TestPath(psMachine, file))
                {
                    if (whatifString == null)
                    {
                        log.LogError(String.Format("Failed to remove hyperv file based disk {0}", file));
                        PSException pe = new PSException(String.Format("Failed to remove hyperv file based disk {0}", file));
                        throw pe;
                    }
                }
                else
                {
                    if (whatifString != null)
                    {
                        log.LogError(string.Format("FileBasedDisk should not be removed with WhatIf parameter."));
                        PSException pe = new PSException(string.Format("FileBasedDisk should not be removed with WhatIf parameter."));
                        throw pe;
                    }
                }

            }
            else if (type.Equals("vmdk"))
            {
                file = datastorePath + pathString.Split(']')[1];
                if (TestSetup.TestPath(psMachine, file, password, username, hostIP))
                {
                    if (whatifString == null)
                    {
                        log.LogError(String.Format("Failed to remove vmware file based disk {0}", file));
                        PSException pe = new PSException(String.Format("Failed to remove vmware file based disk {0}", file));
                        throw pe;
                    }
                }
                else
                {
                    if (whatifString != null)
                    {
                        log.LogError(string.Format("FileBasedDisk should not be removed with WhatIf parameter."));
                        PSException pe = new PSException(string.Format("FileBasedDisk should not be removed with WhatIf parameter."));
                        throw pe;
                    }
                }
            }            
        }
    }
}
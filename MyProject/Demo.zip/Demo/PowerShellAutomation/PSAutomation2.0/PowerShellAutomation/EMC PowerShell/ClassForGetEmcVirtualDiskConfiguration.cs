using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualDiskConfiguration:BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private SortedList<string, string> diskConfig;
        private HyperVisorType hvType = HyperVisorType.HyperV;
        private DiskType diskType = DiskType.FilebasedDisk;

        public SortedList<string, string> DiskConfig
        {
            set
            {
                diskConfig = value;
            }
        }

        public HyperVisorType HvType
        {
            set
            {
                hvType = value;
            }
        }

        public DiskType DiskType
        {
            set
            {
                diskType = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string hostdiskString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcVirtualDiskConfiguration
        ///     Constructor for GetEmcVirtualDiskConfiguration class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVirtualDiskConfiguration(string hostdisk = null, string silent = null,  string cmd = null)
        {

            hostdiskString = hostdisk;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualDiskConfiguration");

			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion
#endif
                

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualDiskConfiguration command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="hypervVmConfiguration">All the VM configuration in that hyperv</param>
        /// <param name="hypervName">The name of Hyper-V host</param>
        /// <param name="vmName">The name of Virtual Machine</param>
        /// <returns>Get-EmcVirtualMachineConfiguration result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualDiskConfiguration
        /// </summary>
        /// <param name="result">Get-EmcVirtualDiskConfiguration result string</param>
        private void VerifyFields(PowershellMachine psMachine, string result)
        {            
            SortedList<string, string> diskConfigKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            List<string> exclude = new List<string>();

            if(hvType == HyperVisorType.VMWare)
            {
                exclude.Add("Description");
                if (diskType == DiskType.FilebasedDisk)
                {
                    log.AreEqual<string>( diskConfig["Description"], diskConfigKeyValue["Description"].Replace(" ", ""));
                }
                else
                {
                    string getLunId = diskConfigKeyValue["Description"].Split(new char[] { ':', '.' }, StringSplitOptions.RemoveEmptyEntries)[1];
                    string lunId = diskConfig["Description"].Split(new char[] { ':', '.' }, StringSplitOptions.RemoveEmptyEntries)[1];
                    log.AreEqual<string>(getLunId, lunId);
                }
            }

            HelperAdapter.SortedListIsEqual(diskConfigKeyValue, diskConfig, exclude);
        }

        private string getPropertyValue(PowershellMachine psMachine, string prefix, string property = null)
        {
            List<string> ps = new List<string>();

            if (property == null)
            {
                ps.Add(prefix + property);
            }
            else
            {
                ps.Add(prefix + "." + property);
            }
            string getValue = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

            return getValue;
        }
    }
}
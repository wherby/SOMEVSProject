using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcSnapshotLun : BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string sourcelunString = null;
        private string snapshotpoolString = null;
        private string nameString = null;
        private string noactivationString = null;
        private string retentionString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcSnapshotLun
        ///     Constructor for NewEmcSnapshotLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcSnapshotLun(string sourcelun = null, string snapshotpool = null, string name = null, string noactivation = null, string retention = null, string silent = null,  string cmd = null)
        {

            sourcelunString = sourcelun;
            snapshotpoolString = snapshotpool;
            nameString = name;
            noactivationString = noactivation;
            retentionString = retention;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcSnapshotLun");

			if (sourcelunString != null)
            {
		        sb.AppendFormat(" -SourceLun {0}", sourcelunString);
            }
			if (snapshotpoolString != null)
            {
		        sb.AppendFormat(" -SnapshotPool {0}", snapshotpoolString);
            }
			if (nameString != null)
            {
		        sb.AppendFormat(" -Name {0}", nameString);
            }
			if (noactivationString != null)
            {
		        sb.AppendFormat(" -NoActivation");
            }
			if (retentionString != null)
            {
		        sb.AppendFormat(" -Retention {0}", retentionString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion
    
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcSnapshotLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="lunID">The lun name or lun id</param>
        /// <param name="storageGlobalId">Storage Global Id</param>
        /// <returns>The result of new-emcsnapshotlun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string lunID, string storageGlobalId)
        {
            PrefixString = HelperAdapter.GetParameter("SnapshotLun");
            string result = RunCMD(psMachine, true);
            SortedList<string, string> newSnapshotLunProperties = HelperAdapter.GenerateKeyValuePairs(result);

            string blockStorageSystem = HelperAdapter.GetParameter("System");
            string id;
            if (TestSetup.StorageSystemType == "VNXe")
            {
                id = newSnapshotLunProperties["Name"];
            }
            else
            {
                id = newSnapshotLunProperties["Wwn"];
            }
            GetEmcSnapshotLun snapshotLun = new GetEmcSnapshotLun(id, null, blockStorageSystem);
            string getResult = snapshotLun.RunCMD(psMachine, true);
            SortedList<string, string> getSnapshotLunProperties = HelperAdapter.GenerateKeyValuePairs(getResult);           

            if (getSnapshotLunProperties == null)
            {
                log.LogError(string.Format("Failed to find the following snapshot lun: {0}", newSnapshotLunProperties));
                PSException pe = new PSException(string.Format("Failed to find the following snapshot lun: {0}", newSnapshotLunProperties));
                throw pe;
            }                     
            
            VerifyFields(psMachine, getSnapshotLunProperties, lunID, storageGlobalId);
            return result;
        }        

        /// <summary>
        /// VerifyFields
        ///     verify the source lun of a snapshot lun
        /// </summary>
        /// <param name="getLunProperties">The snapshot lun properties retrieved from Get-EmcSnapshotLun</param>        
        /// <param name="lunID">The lun name or lun id</param>
        /// <param name="storageGlobalId">Storage Global Id</param>
        private void VerifyFields(PowershellMachine psMachine, SortedList<string, string> getLunProperties, string lunID, string storageGlobalId)
        {           

            #region verification for fields
            log.AreEqual(storageGlobalId, getLunProperties["StorageSystemGlobalId"], "Verify storage global Id: ");
            
            string sourceLunID = null;
            if (nameString != null)
            {
                log.AreEqual<string>(nameString, getLunProperties["Name"], "Verify the Name of a Snapshot Lun: "); 
            }            
            
            sourceLunID = getLunProperties["SourceLunId"];

            if (noactivationString == null)
            {                
                log.AreEqual<string>("True", getLunProperties["IsActivated"], "IsActivated Flag of the Snapshot Lun is: ");
            }
            else
            {
                log.AreEqual<string>("False", getLunProperties["IsActivated"], "IsActivated Flag of the Snapshot Lun is: ");
            }

            if (noactivationString == null || TestSetup.StorageSystemType != "VMAX")
            {
                log.AreEqual<string>(lunID, sourceLunID, "Verify the Source Lun ID of a Snapshot Lun: ");
            }

            // Verify storage rentention for VNXe system
            if (TestSetup.StorageSystemType == "VNXe" && (retentionString != null))
            {
                string prefixStr = HelperAdapter.GetParameter("Timespan");
                Int64 expectedTimespan = Int64.Parse(TestSetup.GetPropertyValue(psMachine, prefixStr, "TotalMilliseconds"));
                // VNXe requires 1 hours as the smallest timespan
                if (expectedTimespan < 3600000)
                {
                    expectedTimespan = 3600000;
                }
                string realTimespan = TestSetup.GetSnapshotLunTimeSpan(psMachine, PrefixString);
                log.AreEqual(expectedTimespan.ToString(), realTimespan, "Timespan: ");                  
            }            
            #endregion
        }
    }
}
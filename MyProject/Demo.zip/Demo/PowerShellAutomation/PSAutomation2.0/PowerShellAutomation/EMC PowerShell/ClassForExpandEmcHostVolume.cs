using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class ExpandEmcHostVolume : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        private SortedList<string, string> volumeKeyValue;
        private ulong oldCapacity;

        public SortedList<string, string> VolumeKeyValue
        {
            set
            {
                volumeKeyValue = value;
            }
        }

        public ulong OldCapacity
        {
            set
            {
                oldCapacity = value;
            }
        }

        #region AutoGenerate
        
        private string hostsystemString = null;
        private string volumeString = null;
        private string capacityString = null;
        private string silentString = null;

        
        /// <summary>
        /// ExpandEmcHostVolume
        ///     Constructor for ExpandEmcHostVolume class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public ExpandEmcHostVolume(string hostsystem, string volume, string capacity, string silent,  string cmd)
        {

            hostsystemString = hostsystem;
            volumeString = volume;
            capacityString = capacity;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Expand-EmcHostVolume");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (volumeString != null)
            {
		        sb.AppendFormat(" -Volume {0}", volumeString);
            }
            if (capacityString != null)
            {
                sb.AppendFormat(" -CapacityToAdd {0}", capacityString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Expand-EmcHostVolume commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Expand-EmcHostVolume</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("Volume");

            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> expandedVolume = HelperAdapter.GenerateKeyValuePairs(result);

            List<string> excludeKey = new List<string>();
            excludeKey.Add("Size");
            excludeKey.Add("TotalAllocationUnits");
            excludeKey.Add("FreeAllocationUnits");
            log.AreEqual<bool>(true, HelperAdapter.SortedListIsEqual(expandedVolume, volumeKeyValue, excludeKey), "Verify properties");

            string path = HelperAdapter.GetProperty("DiskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Expand");
            ulong newCapacity = ulong.Parse(TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Volume"), "Size.Value"));
            ulong volumeExpand = 0;

            if (capacityString != null)
            {
                volumeExpand = ulong.Parse(TestSetup.GetPropertyValue(psMachine, dic["VolumeExpand"]));
            }
            else
            {
                volumeExpand = ulong.Parse(TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Disk"), "MaxFreeExtentSize.Value"));
            }
            log.AreEqual<ulong>(oldCapacity + volumeExpand, newCapacity, "Verify new capacity");

            ulong totalAUOld = ulong.Parse(volumeKeyValue["TotalAllocationUnits"]);
            ulong freeAUOld = ulong.Parse(volumeKeyValue["FreeAllocationUnits"]);
            ulong totalAUNew = ulong.Parse(expandedVolume["TotalAllocationUnits"]);
            ulong freeAUNew = ulong.Parse(expandedVolume["FreeAllocationUnits"]);
            ulong auSize = ulong.Parse(expandedVolume["AllocationUnitSize"]);

            log.AreEqual<ulong>(totalAUOld - freeAUOld, totalAUNew - freeAUNew, "Verify AUs in use");
            log.AreEqual<ulong>(oldCapacity - totalAUOld * auSize, newCapacity - totalAUNew * auSize, "Verify Size");
        }
    }
}
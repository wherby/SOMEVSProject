using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcCifsNetworkShare : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string hostsystemString = null;
        private string idString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcCifsNetworkShare
        ///     Constructor for GetEmcCifsNetworkShare class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcCifsNetworkShare(string hostsystem = null, string id = null, string silent = null,  string cmd=null)
        {

            hostsystemString = hostsystem;
            idString = id;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcCifsNetworkShare");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcCifsNetworkShare commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcCifsNetworkShare</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> netWorkSharedKeyValuePairs = HelperAdapter.GenerateKeyValuePairsList(result);
            if (hostsystemString != null)
            {
                string hostID = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("Host"), "GlobalId");
                foreach (SortedList<string, string> temp in netWorkSharedKeyValuePairs)
                {
                    log.AreEqual<string>(hostID, temp["HostSystemGlobalId"], "Host ID ");
                }
            }
            if (idString != null)
            {
                log.AreEqual<int>(1, netWorkSharedKeyValuePairs.Count, "There will be one NewworkSharedfolder");
                string idStringString = idString.Replace("\"", "");
                bool isTheFolderFound = result.IndexOf(idStringString, StringComparison.OrdinalIgnoreCase) >= 0;
                log.AreEqual<bool>(true, isTheFolderFound, "The shared folder is found");
            }
        }
    } 
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcStorageAccessControl : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string accesscontrolString = null;
        private string poolString = null;
        private string silentString = null;

        
        /// <summary>
        /// RemoveEmcStorageAccessControl
        ///     Constructor for RemoveEmcStorageAccessControl class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcStorageAccessControl(string accesscontrol, string pool, string silent = null,  string cmd = null)
        {

            accesscontrolString = accesscontrol;
            poolString = pool;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcStorageAccessControl");

			if (accesscontrolString != null)
            {
		        sb.AppendFormat(" -AccessControl {0}", accesscontrolString);
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcStorageAccessControl commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="storageGlobalID">storage global ID</param>
        /// <param name="poolName">pool Name</param>
        /// <returns>the result of Remove-EmcStorageAccessControl</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string storageGlobalID, string poolName)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, storageGlobalID, poolName);
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///    Verify the spcified pool entry is removed from access control
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="result">the result string of Remove-EmcStorageAccessControl</param>
        /// <param name="storageGlobalID">storage global ID</param>
        /// <param name="poolName">pool name</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string storageGlobalID, string poolName)
        {
            string controlValue = HelperAdapter.GetPoolAccessControlValue(result, storageGlobalID, poolName);
            if (controlValue != null)
            {
                log.LogError(String.Format("Access control for pool {0} is not removed: {1}", poolName, result));
                PSException pe = new PSException(String.Format("Access control for pool {0} is not removed {0}: {1}", poolName, result));
                throw pe;
            }     
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcFileBasedDisk : BaseClass
    {
       
        private TestLog log = TestLog.GetInstance();        


        #region AutoGenerate
        
        private string hypervisorString = null;
        private string pathString = null;
        private string sizeString = null;
        private string vhdtypeString = null;
        private string silentString = null;
        private string vmdktypeString = null;

        
        /// <summary>
        /// NewEmcFileBasedDisk
        ///     Constructor for NewEmcFileBasedDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcFileBasedDisk(string hypervisor = null, string path = null, string size = null, string vhdtype = null, string silent = null, string vmdktype = null,  string cmd = null)
        {

            hypervisorString = hypervisor;
            pathString = "\"" + path + "\"";
            sizeString = size;
            vhdtypeString = vhdtype;
            silentString = silent;
            vmdktypeString = vmdktype;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcFileBasedDisk");

			if (hypervisorString != null)
            {
		        sb.AppendFormat(" -Hypervisor {0}", hypervisorString);
            }
			if (pathString != null)
            {
		        sb.AppendFormat(" -Path {0}", pathString);
            }
			if (sizeString != null)
            {
		        sb.AppendFormat(" -Size {0}", sizeString);
            }
			if (vhdtypeString != null)
            {
		        sb.AppendFormat(" -VhdType {0}", vhdtypeString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (vmdktypeString != null)
            {
		        sb.AppendFormat(" -VmdkType {0}", vmdktypeString);
            }


            return sb.ToString();
        }
        #endregion
      
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcFileBasedDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="netFilePath">The network path for filebaseddisk</param>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="password">remote esx host password</param>
        /// <param name="username">remote esx host username</param>
        /// <param name="hostIP">remote esx host IP</param>
        /// <returns>The result of New-EmcFileBasedDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string netFilePath, string password, string username, string hostIP)
        {
            string result = RunCMD(psMachine);

            if (vhdtypeString != null)
            {
                if (!TestSetup.TestPath(psMachine, netFilePath))
                {
                    log.LogError(string.Format("Failed to create file based disk {0}", pathString));
                    PSException pe = new PSException(string.Format("Failed to create file based disk {0}", pathString));
                    throw pe;
                }
            }

            if (vmdktypeString != null)
            {
                if (!TestSetup.TestPath(psMachine, netFilePath, password, username, hostIP))
                {
                    log.LogError(string.Format("Failed to create file based disk {0}", pathString));
                    PSException pe = new PSException(string.Format("Failed to create file based disk {0}", pathString));
                    throw pe;
                }
            }
            VerifyFields(psMachine, netFilePath, password, username, hostIP);
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields for New-EmcFileBasedDisk
        /// </summary>
        /// <param name="psMachine">The PowerShell Machine instance</param>
        /// <param name="netFilePath">The network path for filebaseddisk</param>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="password">remote esx host password</param>
        /// <param name="username">remote esx host username</param>
        /// <param name="hostIP">remote esx host IP</param>
        /// <returns>The result of New-EmcFileBasedDisk</returns>
        private void VerifyFields(PowershellMachine psMachine, string netFilePath, string password, string username, string hostIP)
        {
            UInt64 sizeInput = UInt64.Parse(TestSetup.GetPropertyValue(psMachine, sizeString));
            UInt64 size;
            
            if (hypervisorString.IndexOf("hyperv", StringComparison.OrdinalIgnoreCase) > 0)
            {
                size = TestSetup.GetVhdFileBasedDiskSize(psMachine, netFilePath);                

                if (vhdtypeString != null && vhdtypeString.Equals("Dynamic", StringComparison.OrdinalIgnoreCase))
                {
                    if ((size == 0) || size >= sizeInput)
                    {
                        log.LogError(string.Format("Incorrect size of file based disk {0}: expected {1}, actual {2}", pathString, sizeInput, size));
                        PSException pe = new PSException(string.Format("Incorrect size of file based disk {0}: expected {1}, actual {2}", pathString, sizeInput, size));
                        throw pe;
                    }
                }                   
                else
                { // default type is fixed
                    if ((size < sizeInput))
                    {
                        log.LogError(string.Format("Incorrect size of file based disk {0}: expected {1}, actual {2}", pathString, sizeInput, size));
                        PSException pe = new PSException(string.Format("Incorrect size of file based disk {0}: expected {1}, actual {2}", pathString, sizeInput, size));
                        throw pe;
                    }
                }
            }

            if (vmdktypeString != null || hypervisorString.IndexOf("vmware", StringComparison.OrdinalIgnoreCase) > 0)
            {
                size = TestSetup.GetVmdkFileBasedDiskSize(psMachine, netFilePath, password, username, hostIP);
                log.AreEqual(sizeInput, size, "Filed Based Disk Size: ");
            }
        }
    }
}
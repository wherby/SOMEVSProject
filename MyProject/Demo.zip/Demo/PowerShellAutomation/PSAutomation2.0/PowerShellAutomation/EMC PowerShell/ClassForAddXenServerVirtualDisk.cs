using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcXenServerVirtualDisk : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string virtualdiskString = null;
        private string virtualmachineconfigurationString = null;
        private string silentString = null;

        
        /// <summary>
        /// AddEmcXenServerVirtualDisk
        ///     Constructor for AddEmcXenServerVirtualDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcXenServerVirtualDisk(string virtualdisk, string virtualmachineconfiguration, string silent = null,  string cmd = null)
        {

            virtualdiskString = virtualdisk;
            virtualmachineconfigurationString = virtualmachineconfiguration;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcXenServerVirtualDisk");

			if (virtualdiskString != null)
            {
		        sb.AppendFormat(" -VirtualDisk {0}", virtualdiskString);
            }
			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcXenServerVirtualDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Add-EmcXenServerVirtualDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> addDisk = HelperAdapter.GenerateKeyValuePairs(result);
            string xenServer = HelperAdapter.GetParameter("XenServer");
            bool diskAdded = false;

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);
            string disks = TestSetup.GetPropertyValue(psMachine, xenServer, "VirtualMachinesConfigurations[1].VmDisksConfigs");

            log.AreEqual<bool>(false, string.IsNullOrEmpty(disks), "Verify VM has one or more disks");

            List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(disks);

            foreach (SortedList<string, string> disk in disksList)
            {
                if (HelperAdapter.SortedListIsEqual(disk, addDisk))
                {
                    diskAdded = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, diskAdded, "Verify the disk is added to VM");
        }
    }
}

using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcXenServerVirtualDiskImage : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string storagerepositoryString = null;
        private string xenserverString = null;
        private string sizeString = null;
        private string nameString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcXenServerVirtualDiskImage
        ///     Constructor for NewEmcXenServerVirtualDiskImage class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcXenServerVirtualDiskImage(string storagerepository = null, string xenserver = null, string size = null, string name = null, string silent = null,  string cmd = null)
        {

            storagerepositoryString = storagerepository;
            xenserverString = xenserver;
            sizeString = size;
            nameString = name;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcXenServerVirtualDiskImage");

			if (storagerepositoryString != null)
            {
		        sb.AppendFormat(" -StorageRepository {0}", storagerepositoryString);
            }
			if (xenserverString != null)
            {
		        sb.AppendFormat(" -XenServer {0}", xenserverString);
            }
			if (sizeString != null)
            {
		        sb.AppendFormat(" -Size {0}", sizeString);
            }
			if (nameString != null)
            {
		        sb.AppendFormat(" -Name {0}", nameString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcXenServerVirtualDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of New-EmcXenServerVirtualDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("XenServerVirtualDisk");
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string xenServer = HelperAdapter.GetParameter("XenServer");
            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);
            string sruuid = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("StorageRepository"), "Uuid");
            log.AreEqual<string>(sruuid, keyValue["SrUuid"], "Verify Sr Uuid");
            log.AreEqual<string>(nameString, keyValue["Name"], "Verify disk name");

            string sizeExp = TestSetup.GetPropertyValue(psMachine, sizeString);
            string sizeActual = TestSetup.GetPropertyValue(psMachine, PrefixString, "Size.Value");
            log.AreEqual<string>(sizeExp, sizeActual, "Verify disk size");
        }
    }
}
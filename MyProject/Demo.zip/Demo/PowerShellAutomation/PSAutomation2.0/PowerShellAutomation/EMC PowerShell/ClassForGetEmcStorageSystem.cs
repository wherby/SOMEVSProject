using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcStorageSystem:BaseClass
    {
        #region CMD fields
        private int getSystemCount;
        private SortedList<string, string>[] connectSystemKeyValue;
        private string globalId;
        #endregion

        public SortedList<string, string>[] ConnectSystemKeyValue
        {
            get
            {
                return connectSystemKeyValue;
            }
            set
            {
                connectSystemKeyValue = value;
            }
        }

        public int GetSystemCount
        {
            get
            {
                return getSystemCount;
            }
            set
            {
                getSystemCount = value;
            }
        }

        public string GlobalId
        {
            get
            {
                return globalId;
            }
            set
            {
                globalId = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string idString = null;
        private string silentString = null;
        private string filestoragesystemString = null;
        private string blockstoragesystemString = null;
        private string lunString = null;
        private string poolString = null;
        private string clarstoragegroupString = null;

        
        /// <summary>
        /// GetEmcStorageSystem
        ///     Constructor for GetEmcStorageSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcStorageSystem(string id = null, string silent = null, string filestoragesystem = null, string blockstoragesystem = null, string lun = null, string pool = null, string clarstoragegroup = null,  string cmd = null)
        {

            idString = id;
            silentString = silent;
            filestoragesystemString = filestoragesystem;
            blockstoragesystemString = blockstoragesystem;
            lunString = lun;
            poolString = pool;
            clarstoragegroupString = clarstoragegroup;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStorageSystem");

			if (idString != null)
            {
		        sb.AppendFormat(" -Id {0}", idString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (filestoragesystemString != null)
            {
		        sb.AppendFormat(" -FileStorageSystem");
            }
			if (blockstoragesystemString != null)
            {
		        sb.AppendFormat(" -BlockStorageSystem");
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (clarstoragegroupString != null)
            {
		        sb.AppendFormat(" -ClarStorageGroup {0}", clarstoragegroupString);
            }


            return sb.ToString();
        }
        #endregion
#endif
        
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getSystemKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            log.AreEqual<int>(getSystemCount, getSystemKeyValueList.Count, "Verify get system count");

            foreach (SortedList<string, string> keyValue in getSystemKeyValueList)
            {
                VerifyFields(keyValue, psMachine);
            }
            

            return result;
        }

        private void VerifyFields(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            List<string> excludeKeys = new List<string>();
            #endregion

            log.AreEqual<string>("StorageSystem", getSystemKeyValue["AdapterType"], "Verify Adapter Type");

            if (globalId != null)
            {
                log.AreEqual<string>(globalId, getSystemKeyValue["GlobalId"], "Verify GlobalId");
            }

            string[] fields = {"UserFriendlyName", "Name", "Model", "SoftwareRevision"};
            
            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (keyValue == null)
                {
                    continue;
                }

                if (keyValue["GlobalId"] == getSystemKeyValue["GlobalId"])
                {
                    foreach (string field in fields)
                    {
                        log.AreEqual<string>(keyValue[field], getSystemKeyValue[field], "Verify " + field);
                    }

                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify storage system key value exists in connected storage system");
            
        }

        private void AssertLunsInStorage(List<SortedList<string, string>> resultList, string value, string[] splitString, string globalId)
        {
            string[] names = value.Split(splitString, StringSplitOptions.RemoveEmptyEntries);
            TestLog log = TestLog.GetInstance();
            bool exist = false;

            for (int i = 0; i < names.Length; i++)
            {
                for (int j = 0; j < resultList.Count; j++)
                {
                    if (names[i].Trim() == resultList[j]["Name"] && globalId == resultList[j]["StorageSystemGlobalId"])
                    {
                        exist = true;
                        break;
                    }
                }
                log.AreEqual<bool>(true, exist, string.Format("Verify {0} is in the storage system", names[i]));
                exist = false;
            }
        }
    }
}
using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcHostSystem:BaseClass
    {
        #region CMD fields
        private SortedList<string, string>[] connectSystemKeyValue;
        private List<SortedList<string, string>> esxSystemKeyValue;
        #endregion

        public SortedList<string, string>[] ConnectSystemKeyValue
        {
            set
            {
                connectSystemKeyValue = value;
            }
        }
        public List<SortedList<string, string>> ESXSystemKeyValue
        {
            set
            {
                esxSystemKeyValue = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string idString = null;
        private string hostsystemtypeString = null;
        private string silentString = null;
        private string hostdiskString = null;
        private string volumeString = null;

        
        /// <summary>
        /// GetEmcHostSystem
        ///     Constructor for GetEmcHostSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcHostSystem(string id = null, string hostsystemtype = null, string silent = null, string hostdisk = null, string volume = null, string cmd = null)
        {

            idString = id;
            hostsystemtypeString = hostsystemtype;
            silentString = silent;
            hostdiskString = hostdisk;
            volumeString = volume;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcHostSystem");

			if (idString != null)
            {
		        sb.AppendFormat(" -Id {0}", idString);
            }
			if (hostsystemtypeString != null)
            {
		        sb.AppendFormat(" -HostSystemType {0}", hostsystemtypeString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (volumeString != null)
            {
		        sb.AppendFormat(" -Volume {0}", volumeString);
            }


            return sb.ToString();
        }
        #endregion
#endif
        

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getSystemKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach (SortedList<string, string> keyValue in getSystemKeyValueList)
            {
                VerifyFields(keyValue, psMachine);
            }

            return result;
        }

        private void VerifyFields(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            string model = getSystemKeyValue["Model"];
            #endregion

            log.AreEqual<string>("HostSystem", getSystemKeyValue["AdapterType"], "Verify Adapter Type");

            if (hostsystemtypeString == "VmWare" || model.Contains("VMware ESX Server"))
            {
                VerifyVMWare(getSystemKeyValue, psMachine);
            }
            else if (hostsystemtypeString == "ESXHost" || model == "")
            {
               VerifyESXHost(getSystemKeyValue, psMachine);
            }
            else if (hostsystemtypeString == "HyperV" || model.Contains("Hyper-V"))
            {
                VerifyHyperV(getSystemKeyValue, psMachine);
            }
            else
            {
                VerifyNormalHost(getSystemKeyValue, psMachine);
            }
        }

        #region VerifyHyperV
        private void VerifyHyperV(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
      
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            List<string> excludeKeys = new List<string>();
            #endregion

            log.AreEqual<string>("Hyper-V, PowerEdge R610", getSystemKeyValue["Model"], "Verify HyperV Module");

            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (keyValue == null)
                {
                    continue;
                }
                if (HelperAdapter.SortedListIsEqual(keyValue, getSystemKeyValue, excludeKeys))
                {
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify host system key value exists in connected host systems");
            
            
        }
        #endregion

        #region VerifyVMWare
        private void VerifyVMWare(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            List<string> excludeKeys = new List<string>();
            #endregion

            log.AreEqual<string>("VMware ESX Server", getSystemKeyValue["Model"], "Verify VmWare Module");                 

            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (keyValue == null)
                {
                    continue;
                }
                if ((keyValue["IpAddress"] == getSystemKeyValue["IpAddress"]) && (keyValue["Model"] == getSystemKeyValue["Model"]))
                {
                    log.AreEqual<string>(keyValue["AdapterType"], getSystemKeyValue["AdapterType"], "Verify AdapterType");
                    log.AreEqual<string>(keyValue["UserFriendlyName"], getSystemKeyValue["UserFriendlyName"], "Verify UserFriendlyName");
                    log.AreEqual<string>(keyValue["UserName"], getSystemKeyValue["UserName"], "Verify UserName");
                    log.AreEqual<string>(keyValue["Server"], getSystemKeyValue["Server"], "Verify Server");
                    log.AreEqual<string>(keyValue["IsVirtualCenter"], getSystemKeyValue["IsVirtualCenter"], "Verify IsVirtualCenter");
                    log.AreEqual<string>(keyValue["AboutInfo"], getSystemKeyValue["AboutInfo"], "Verify AboutInfo");
                    log.AreEqual<string>(keyValue["Name"], getSystemKeyValue["Name"], "Verify Name");
                    log.AreEqual<string>(keyValue["OsString"], getSystemKeyValue["OsString"], "Verify OsString");
                    log.AreEqual<string>(keyValue["GlobalId"], getSystemKeyValue["GlobalId"], "Verify GlobalId");
                    break;
                }
            }
            
        }
        #endregion

        #region VerifyESXHost
        private void VerifyESXHost(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {

            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            List<string> excludeKeys = new List<string>();
            #endregion

            log.AreEqual<string>("", getSystemKeyValue["Model"], "Verify ESXHost Module");

            foreach (SortedList<string, string> keyValueList in esxSystemKeyValue)
            {
                if (keyValueList["GlobalId"] == getSystemKeyValue["GlobalId"])
                {
                    log.AreEqual<string>(keyValueList["IpAddress"], getSystemKeyValue["IpAddress"], "Verify IpAddress");
                    log.AreEqual<string>(keyValueList["Domain"], getSystemKeyValue["Domain"], "Verify Domain");
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify host system key value exists in connected host systems");
        }
        #endregion

        #region VerifyNormalHost
        private void VerifyNormalHost(SortedList<string, string> getSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            #endregion

            log.AreEqual<bool>(true, getSystemKeyValue["Model"].Contains("Virtual"), "Verify Normal Host Module");

            string[] keys = { "HostDisks", "HostVolumes", "AvailablePassthroughDiskCandidates" };

            string[] result = new string[keys.Length];
            List<string> excludeKeys = new List<string>();
            //GetEmcHostSystem system = new GetEmcHostSystem(getSystemKeyValue["GlobalId"]);
            //system.PrefixString = "$verifyHost";
            //system.RunCMD(psMachine);

            //GetEmcHostDisk disk = new GetEmcHostDisk(null, null, null, system.PrefixString);
            //disk.PrefixString = "$verifyDisk";
            //result[0] = disk.RunCMD(psMachine);

            //GetEmcHostVolume volume = new GetEmcHostVolume(null, null, system.PrefixString);
            //volume.PrefixString = "$verifyVolume";
            //result[1] = volume.RunCMD(psMachine);

            //if (getSystemKeyValue.ContainsKey("AvailablePassthroughDiskCandidates"))
            //{
            //    GetEmcAvailablePassthroughDiskCandidate psthruDisk = new GetEmcAvailablePassthroughDiskCandidate(system.PrefixString);
            //    result[2] = psthruDisk.RunCMD(psMachine);
            //}


            //string[] split1 = { "{[", "], [", "]}", "]...}", "],[" };
            //string[] split2 = { "." };
            //string[] split3 = { ":" };

            //for (int i = 0; i < keys.Length; i++)
            //{
            //    string key = keys[i];
            //    if (getSystemKeyValue.ContainsKey(key) && getSystemKeyValue[key] != "{}")
            //    {
            //        excludeKeys.Add(key);

            //        VerifyComplexEntry(getSystemKeyValue[key], result[i], split1, split2, split3);
            //    }
            //}
            //if (getSystemKeyValue.ContainsKey("HostBusAdapters") && getSystemKeyValue["HostBusAdapters"] != "{}")
            //{
            //    excludeKeys.Add("HostBusAdapters");

            //    string[] adapters = getSystemKeyValue["HostBusAdapters"].Split(new string[] { "{", "}", "[", "]", ",", "..." }, 3, StringSplitOptions.RemoveEmptyEntries);
            //    foreach (string adapter in adapters)
            //    {
            //        bool adptersTrue = false;

            //        string[] info = adapter.Split(new string[] { ". HostName=", ". Id= " }, 3, StringSplitOptions.RemoveEmptyEntries);

            //        string path = HelperAdapter.GetProperty("SystemConfig");
            //        string[] hosts = { "Host"};
            //        foreach (string host in hosts)
            //        {
            //            GetEmcHostBusAdapter hba = new GetEmcHostBusAdapter(system.PrefixString);
            //            string hbaResult = hba.RunCMD(psMachine, true);
            //            SortedList<string, string> hbaKeyValue = HelperAdapter.GenerateKeyValuePairs(hbaResult);
            //            if ((connectSystemKeyValue[0]["Name"] + "." + connectSystemKeyValue[0]["Domain"]).ToLower() == info[1].Trim().ToLower() && hbaKeyValue["Iqn"].ToLower() == info[2].Trim().ToLower())
            //            {
            //                adptersTrue = true;
            //                break;
            //            }
            //        }

            //        log.AreEqual<bool>(true, adptersTrue, "Verify Host Bus Adapters");
            //    }
            //}

            foreach (SortedList<string, string> keyValue in connectSystemKeyValue)
            {
                if (keyValue == null)
                {
                    continue;
                }
                if ((keyValue["IpAddress"] == getSystemKeyValue["IpAddress"]) && (keyValue["GlobalId"] == getSystemKeyValue["GlobalId"]))
                {
                    log.AreEqual<string>(keyValue["AdapterType"], getSystemKeyValue["AdapterType"], "Verify AdapterType");
                    log.AreEqual<string>(keyValue["UserFriendlyName"], getSystemKeyValue["UserFriendlyName"], "Verify UserFriendlyName");
                    log.AreEqual<string>(keyValue["UserName"], getSystemKeyValue["UserName"], "Verify UserName");
                    log.AreEqual<string>(keyValue["HypervisorType"], getSystemKeyValue["HypervisorType"], "Verify HypervisorType");
                    log.AreEqual<string>(keyValue["IsInDomain"], getSystemKeyValue["IsInDomain"], "Verify IsInDomain");
                    log.AreEqual<string>(keyValue["Manufacturer"], getSystemKeyValue["Manufacturer"], "Verify Manufacturer");
                    log.AreEqual<string>(keyValue["Name"], getSystemKeyValue["Name"], "Verify Name");
                    log.AreEqual<string>(keyValue["OsString"], getSystemKeyValue["OsString"], "Verify OsString");
                    log.AreEqual<string>(keyValue["Model"], getSystemKeyValue["Model"], "Verify Model");
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify host system key value exists in connected host systems");
        }
        #endregion

        #region VerifyComplexEntry
        private void VerifyComplexEntry(string entryValue, string result, string[] split1, string[] split2 = null , string[] split3 = null, string key = null)
        {
            TestLog log = TestLog.GetInstance();

            List<SortedList<string, string>> list = HelperAdapter.GenerateKeyValuePairsList(result);

            string[] bigArray = entryValue.Split(split1, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < bigArray.Length; i++)
            {                 
                if (split2 != null)
                {
                   string[] midArray = bigArray[i].Split(split2, StringSplitOptions.RemoveEmptyEntries);
                    for (int j = 0; j < midArray.Length; j++)
                    {
                        if (split3 != null)
                        {                        
                            string[] smallArray = midArray[j].Split(split3, 2, StringSplitOptions.None);
                            log.AreEqual<string>(smallArray[1].Trim(), list[i][smallArray[0].Trim()], string.Format("Verify {0}", smallArray[0]));
                        }
                        else
                        {
                            log.AreEqual<string>(midArray[1].Trim(), list[i][midArray[0].Trim()], string.Format("Verify {0}", midArray[0]));
                        }
                    }                    
                }
                else
                {
                    if (key != null)
                    {
                        log.AreEqual<string>(bigArray[i].Trim(), list[i][key], string.Format("Verify {0}", key));
                    }
                }
            }

        }
        #endregion
    }
}

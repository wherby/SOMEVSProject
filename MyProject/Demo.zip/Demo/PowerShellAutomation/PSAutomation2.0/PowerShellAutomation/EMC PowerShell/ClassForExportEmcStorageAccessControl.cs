using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class ExportEmcStorageAccessControl : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string accesscontrolString = null;
        private string fileString = null;
        private string protectionkeyString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// ExportEmcStorageAccessControl
        ///     Constructor for ExportEmcStorageAccessControl class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public ExportEmcStorageAccessControl(string accesscontrol, string file, string protectionkey, string force = null, string silent = null, 
            string whatif = null,  string cmd = null)
        {

            accesscontrolString = accesscontrol;
            fileString = file;
            protectionkeyString = protectionkey;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Export-EmcStorageAccessControl");

			if (accesscontrolString != null)
            {
		        sb.AppendFormat(" -AccessControl {0}", accesscontrolString);
            }
			if (fileString != null)
            {
		        sb.AppendFormat(" -File {0}", fileString);
            }
			if (protectionkeyString != null)
            {
		        sb.AppendFormat(" -ProtectionKey {0}", protectionkeyString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Export-EmcStorageAccessControl commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Export-EmcStorageAccessControl</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the access control file is exported successfully
        /// </summary>
        /// <param name="psMachine">Powershell Machine</param>
        private void VerifyFields(PowershellMachine psMachine)
        {
            if ((whatifString != null) && TestSetup.TestPath(psMachine, fileString))
            {
                log.LogError(String.Format("Access control file should not be exported with WhatIf parameter {0}", fileString));
                PSException pe = new PSException(String.Format("Access control file should not be exported with WhatIf parameter {0}", fileString));
                throw pe;
            }
            
            if ((whatifString == null) && (!TestSetup.TestPath(psMachine, fileString)))
            {
                log.LogError(String.Format("Failed to export access control file {0}", fileString));
                PSException pe = new PSException(String.Format("Failed to export access control file {0}", fileString));
                throw pe;
            }            
        }
    }
}
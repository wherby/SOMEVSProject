using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcHostVolume:BaseClass
    {
        #region CMD fields
        private SortedList<string, string> volumeInfo;
        #endregion

        public SortedList<string, string> VolumeInfo
        {
            get
            {
                return volumeInfo;
            }
            set
            {
                volumeInfo = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string idString = null;
        private string hostdiskString = null;
        private string hostsystemString = null;
        private string silentString = null;
        private string clusterdiskString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// GetEmcHostVolume
        ///     Constructor for GetEmcHostVolume class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcHostVolume(string id = null, string hostdisk = null, string hostsystem = null, string silent = null, string clusterdisk = null, string clustersystem = null,  string cmd = null)
        {

            idString = id;
            hostdiskString = hostdisk;
            hostsystemString = hostsystem;
            silentString = silent;
            clusterdiskString = clusterdisk;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcHostVolume");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clusterdiskString != null)
            {
		        sb.AppendFormat(" -ClusterDisk {0}", clusterdiskString);
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion
#endif
        
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> getVolumeKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            VerifyFields(getVolumeKeyValueList, psMachine);

            return result;
        }

        private void VerifyFields(List<SortedList<string, string>> getVolumeKeyValueList, PowershellMachine psMachine)
        {
            #region verification fields
            TestLog log = TestLog.GetInstance();
            bool equalKeyValue = false;
            #endregion

            foreach (SortedList<string, string> keyValue in getVolumeKeyValueList)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, volumeInfo))
                {
                    equalKeyValue = true;
                    break;
                }
            }
            log.AreEqual<bool>(true, equalKeyValue, "Verify host volume is got correctly");
        }
    }
}
using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
using System.Threading;
namespace PowerShellAutomation
{

    public class SetEmcLunAccess : BaseClass
    {

        #region AutoGenerate
        
        private string lunString = null;
        private string hostsystemString = null;
        private string unavailableString = null;
        private string silentString = null;
        private string availableString = null;
        private string initiatoridString = null;
        private string hostnameString = null;
        private string hostipaddressString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// SetEmcLunAccess
        ///     Constructor for SetEmcLunAccess class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcLunAccess(string lun = null, string hostsystem = null, string unavailable = null, string silent = null, string available = null, string initiatorid = null, string hostname = null, string hostipaddress = null, string clustersystem = null,  string cmd = null)
        {

            lunString = lun;
            hostsystemString = hostsystem;
            unavailableString = unavailable;
            silentString = silent;
            availableString = available;
            initiatoridString = initiatorid;
            hostnameString = hostname;
            hostipaddressString = hostipaddress;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcLunAccess");

			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (unavailableString != null)
            {
		        sb.AppendFormat(" -Unavailable");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (availableString != null)
            {
		        sb.AppendFormat(" -Available");
            }
			if (initiatoridString != null)
            {
		        sb.AppendFormat(" -InitiatorId {0}", initiatoridString);
            }
			if (hostnameString != null)
            {
		        sb.AppendFormat(" -HostName {0}", hostnameString);
            }
			if (hostipaddressString != null)
            {
		        sb.AppendFormat(" -HostIpAddress {0}", hostipaddressString);
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);
            

            string hostSystem = hostsystemString;
            if (initiatoridString != null)
            {
                hostSystem = HelperAdapter.GetParameter("Host");
            }


            TestLog log = TestLog.GetInstance();

            if (availableString == "Available")
            {
                FindEmcHostDisk findDisk = new FindEmcHostDisk(hostSystem, null, null, null, lunString, clustersystemString);
                string resultDisk = findDisk.RunCMD(psMachine, false);
                bool isEmpty = resultDisk.Trim().Equals(string.Empty);
                log.AreEqual<bool>(false, isEmpty, "Disk can be find.");
            }
            else
            {
                RemoveEmcLun removeLun = new RemoveEmcLun(lunString);
                removeLun.RunCMD(psMachine);
                string lunName = TestSetup.GetPropertyValue(psMachine, lunString, "Name");
                GetEmcLun getlun = new GetEmcLun(lunName);
                string resultForLun = getlun.RunCMD(psMachine);
                log.AreEqual<string>(string.Empty, resultForLun, "The Lun is unmasked");
                TestSetup.SetLunEnvironment(psMachine, true, null, lunString);
            }
            return result;
        }
    }
}
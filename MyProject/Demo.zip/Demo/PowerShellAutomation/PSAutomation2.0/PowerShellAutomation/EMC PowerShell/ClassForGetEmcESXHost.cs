using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcESXHost : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string idString = null;
        private string vmwaresystemString = null;
        private string silentString = null;
        private string scsilunString = null;
        private string datastoreString = null;
        private string virtualmachineconfigurationString = null;

        
        /// <summary>
        /// GetEmcESXHost
        ///     Constructor for GetEmcESXHost class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcESXHost(string id = null, string vmwaresystem = null, string silent = null, string scsilun = null, 
            string datastore = null, string virtualmachineconfiguration = null,  string cmd = null)
        {

            idString = id;
            vmwaresystemString = vmwaresystem;
            silentString = silent;
            scsilunString = scsilun;
            datastoreString = datastore;
            virtualmachineconfigurationString = virtualmachineconfiguration;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcESXHost");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (vmwaresystemString != null)
            {
		        sb.AppendFormat(" -VMwareSystem {0}", vmwaresystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (scsilunString != null)
            {
		        sb.AppendFormat(" -ScsiLun {0}", scsilunString);
            }
			if (datastoreString != null)
            {
		        sb.AppendFormat(" -Datastore {0}", datastoreString);
            }
			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcESXHost commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="name">ESX Host Name</param>
        /// <param name="vmwareSystemGlobalId">VMware System Global Id</param>
        /// <param name="uuid">ESX Host UUID</param>
        /// <param name="ipAddress">Ip Address of ESX Host</param>
        /// <param name="managementServerIp">Management Server IP</param>
        /// <returns>the result of Get-EmcESXHost</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string name, string vmwareSystemGlobalId, string uuid, string ipAddress, string managementServerIp)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, name, vmwareSystemGlobalId, uuid, ipAddress, managementServerIp);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields of Get-EmcESXHost
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="result">output result of Get-EmcESXHost</param>
        /// <param name="vmwareSystemGlobalId">VMware System Global Id</param>
        /// <param name="uuid">ESX Host UUID</param>
        /// <param name="ipAddress">Ip Address of ESX Host</param>
        /// <param name="managementServerIp">Management Server IP</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string name, string vmwareSystemGlobalId, string uuid, string ipAddress,
            string managementServerIp)
        {
            List<SortedList<string, string>> esxHosts = HelperAdapter.GenerateKeyValuePairsList(result);
            SortedList<string, string> esxHost = HelperAdapter.FindElementFromList(name, "Name", esxHosts);
            log.AreEqual("HostSystem", esxHost["AdapterType"], "Adapter Type: ");
            log.AreEqual(uuid, esxHost["Uuid"], "Uuid: ");
            log.AreEqual(name, esxHost["Name"], "Name: ");
            log.AreEqual(vmwareSystemGlobalId, esxHost["VMwareSystemGlobalId"]);
            log.AreEqual(ipAddress, esxHost["IpAddress"]);
            log.AreEqual(managementServerIp, esxHost["ManagementServerIp"]);
        }
    }
}
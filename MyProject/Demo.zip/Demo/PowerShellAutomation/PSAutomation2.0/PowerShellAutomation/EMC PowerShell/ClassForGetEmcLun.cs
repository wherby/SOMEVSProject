using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  
  

    public class GetEmcLun:BaseClass
    {

        #region AutoGenerate
        
        private string idString = null;
        private string poolString = null;
        private string silentString = null;
        private string hostdiskString = null;
        private string volumeString = null;
        private string clusterdiskString = null;
        private string blockstoragesystemString = null;
        private string hostlunidentifierString = null;
        private string datastoreString = null;
        private string scsilunString = null;
        private string clariionstoragesystemString = null;
        private string initiatoridString = null;
        private string hostlunidString = null;

        
        /// <summary>
        /// GetEmcLun
        ///     Constructor for GetEmcLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcLun(string id = null, string pool = null, string silent = null, string hostdisk = null, string volume = null, string clusterdisk = null, string blockstoragesystem = null, string hostlunidentifier = null, string datastore = null, string scsilun = null, string clariionstoragesystem = null, string initiatorid = null, string hostlunid = null,  string cmd = null)
        {

            idString = id;
            poolString = pool;
            silentString = silent;
            hostdiskString = hostdisk;
            volumeString = volume;
            clusterdiskString = clusterdisk;
            blockstoragesystemString = blockstoragesystem;
            hostlunidentifierString = hostlunidentifier;
            datastoreString = datastore;
            scsilunString = scsilun;
            clariionstoragesystemString = clariionstoragesystem;
            initiatoridString = initiatorid;
            hostlunidString = hostlunid;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcLun");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (volumeString != null)
            {
		        sb.AppendFormat(" -Volume {0}", volumeString);
            }
			if (clusterdiskString != null)
            {
		        sb.AppendFormat(" -ClusterDisk {0}", clusterdiskString);
            }
			if (blockstoragesystemString != null)
            {
		        sb.AppendFormat(" -BlockStorageSystem {0}", blockstoragesystemString);
            }
			if (hostlunidentifierString != null)
            {
		        sb.AppendFormat(" -HostLunIdentifier {0}", hostlunidentifierString);
            }
			if (datastoreString != null)
            {
		        sb.AppendFormat(" -DataStore {0}", datastoreString);
            }
			if (scsilunString != null)
            {
		        sb.AppendFormat(" -ScsiLun {0}", scsilunString);
            }
			if (clariionstoragesystemString != null)
            {
		        sb.AppendFormat(" -ClariionStorageSystem {0}", clariionstoragesystemString);
            }
			if (initiatoridString != null)
            {
		        sb.AppendFormat(" -InitiatorId {0}", initiatoridString);
            }
			if (hostlunidString != null)
            {
		        sb.AppendFormat(" -HostLunId {0}", hostlunidString);
            }


            return sb.ToString();
        }
        #endregion


        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine);
            if (result.Trim() == string.Empty)
            {
                string warningMSG = string.Format("There is no result for command: {0}", GetFullString());
                log.LogWarning(warningMSG);
                PSException pe = new PSException(warningMSG);
                throw pe;
            }

           string[] lunStrings = result.Split(new string[] { "\r\n\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
           VerifyFields(psMachine,result);


           return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            TestLog log = TestLog.GetInstance();
            List<SortedList<string, string>> lunsKeyValuePairs = HelperAdapter.GenerateKeyValuePairsList(result);
            string wwnForFirstLun = lunsKeyValuePairs[0]["Wwn"].Replace("\r\n", "").Replace(" ", "");
            bool isWwnEqual = false;
            if (idString != null)
            {
                log.AreEqual<int>(1, lunsKeyValuePairs.Count, "There should be only one lun");
            }
            if (poolString != null)
            {
                string globalID = TestSetup.GetPropertyValue(psMachine, poolString, "StorageSystemGlobalId");
                string poolID = TestSetup.GetPropertyValue(psMachine, poolString, "ArrayPoolId");
                foreach (SortedList<string, string> temp in lunsKeyValuePairs)
                {
                    log.AreEqual<string>(globalID, temp["StorageSystemGlobalId"], "StorageSystemGlobalId");
                    log.AreEqual<string>(poolID, temp["ArrayPoolId"], "Array Pool ID");
                }
            }
            if (hostdiskString != null)
            {
                log.AreEqual<int>(1, lunsKeyValuePairs.Count, "There should be only one lun");
                string wwnStringForLun = lunsKeyValuePairs[0]["Wwn"];
                wwnStringForLun = wwnStringForLun.Replace(" ", "");
                string hostLunIdentifierStringGet = TestSetup.GetPropertyValue(psMachine, hostdiskString, "HostLunIdentifier");
                hostLunIdentifierStringGet = hostLunIdentifierStringGet.Replace(" ", "");
                hostLunIdentifierStringGet = hostLunIdentifierStringGet.Replace("\r\n", "");
                bool isWwnNumberEqual = hostLunIdentifierStringGet.IndexOf(wwnStringForLun) >= 0;
                log.AreEqual<bool>(true, isWwnNumberEqual, "The Wwn number is equal");
            }
            if (volumeString != null)
            {
                log.AreEqual<int>(1, lunsKeyValuePairs.Count, "There should be only one lun");
            }
            if (blockstoragesystemString != null)
            {
                string globalID = TestSetup.GetPropertyValue(psMachine, blockstoragesystemString, "GlobalId");
                foreach (SortedList<string, string> temp in lunsKeyValuePairs)
                {
                    log.AreEqual<string>(globalID, temp["StorageSystemGlobalId"], "StorageSystemGlobalId");
                }
            }
            if (hostlunidentifierString != null)
            {
                log.AreEqual<int>(1, lunsKeyValuePairs.Count, "There should be only one lun");
                string WwnForHostLunIdentifier = TestSetup.GetPropertyValue(psMachine, hostlunidentifierString).Replace("\r\n","").Replace(" ","");
                isWwnEqual = WwnForHostLunIdentifier.IndexOf(wwnForFirstLun) >= 0;
                log.AreEqual<bool>(true, isWwnEqual, "WWn is equal for hostlunidentifier");
            }
            if (datastoreString != null)
            {
                string wwnForDataStore = TestSetup.GetPropertyValue(psMachine, datastoreString, "HostLunIdentifiers");
                wwnForDataStore = wwnForDataStore.Replace("\r\n","").Replace(" ", "");
                isWwnEqual = wwnForDataStore.IndexOf(wwnForFirstLun) >= 0;
                log.AreEqual<bool>(true, isWwnEqual, "Wwn of DataStore is equal");
            }
            if (scsilunString != null)
            {
                string wwnForScsi = TestSetup.GetPropertyValue(psMachine, scsilunString, "HostLunIdentifier");
                wwnForScsi = wwnForScsi.Replace("\r\n","").Replace(" ", "");
                isWwnEqual = wwnForScsi.IndexOf(wwnForFirstLun) >= 0;
                log.AreEqual<bool>(true, isWwnEqual, "Wwn of ScsiLun is equal");
                log.AreEqual<int>(1, lunsKeyValuePairs.Count, "There should be only one lun");
            }
            if (hostlunidString != null)
            {
                log.AreEqual<int>(1, lunsKeyValuePairs.Count, "There should be only one lun");
            }
        }
    }
}
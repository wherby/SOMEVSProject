using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class SetEmcHostDiskReadonlyState:BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string hostdiskString = null;
        private string readonlyparamString = null;
        private string silentString = null;
        private string readwriteString = null;

        
        /// <summary>
        /// SetEmcHostDiskReadonlyState
        ///     Constructor for SetEmcHostDiskReadonlyState class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcHostDiskReadonlyState(string hostdisk = null, string readonlyparam = null, string silent = null, string readwrite = null,  string cmd = null)
        {

            hostdiskString = hostdisk;
            readonlyparamString = readonlyparam;
            silentString = silent;
            readwriteString = readwrite;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcHostDiskReadonlyState");

			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (readonlyparamString != null)
            {
		        sb.AppendFormat(" -Readonly");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (readwriteString != null)
            {
		        sb.AppendFormat(" -ReadWrite");
            }


            return sb.ToString();
        }
        #endregion
     

        /// <summary>
        /// VerifyTheCMD
        ///     Verify SetEmcHostDiskReadonlyState command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <returns>SetEmcHostDiskReadonlyState result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {            
            string result = RunCMD(psMachine);
            
            // Update Host System
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Host"));
            updateSystem.RunCMD(psMachine);

            // Get the disk again
            GetEmcHostDisk hostDisk = new GetEmcHostDisk(null, HelperAdapter.GetParameter("Lun"),  HelperAdapter.GetParameter("Host"));
            hostDisk.PrefixString = HelperAdapter.GetParameter("Disk");
            result = hostDisk.RunCMD(psMachine, true);

            if (readonlyparamString != null)
            {
                VerifyFields(result, "ReadOnly");
            }
            if (readwriteString != null)
            {
                VerifyFields(result, "ReadWrite");
            }
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of SetEmcHostDiskReadonlyState 
        /// </summary>
        /// <param name="result">SetEmcHostDiskReadonlyState result string</param>
        /// <param name="status">The disk status</param>        
        private void VerifyFields(string result, string status)
        {            
            SortedList<string, string> getHostDiskProperties = HelperAdapter.GenerateKeyValuePairs(result);

            #region verification for fields
            if (status.Equals("ReadOnly", StringComparison.OrdinalIgnoreCase))
            {
                if (!getHostDiskProperties["Flags"].Contains(status))
                {
                    log.LogError(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    PSException pe = new PSException(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    throw pe;
                }
            }
            else if (status.Equals("ReadWrite", StringComparison.OrdinalIgnoreCase))
            {
                if (getHostDiskProperties["Flags"].Contains("ReadOnly"))
                {
                    log.LogError(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    PSException pe = new PSException(string.Format("Expect ReadOnly flag: {0}, Actual flag: {1}", status, getHostDiskProperties["Flags"]));
                    throw pe;
                }
            }
    
            #endregion
        }
    }
}
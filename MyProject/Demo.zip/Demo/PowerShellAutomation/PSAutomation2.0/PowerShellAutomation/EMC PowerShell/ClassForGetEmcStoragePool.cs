using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;


namespace PowerShellAutomation
{
    public class GetEmcStoragePool:BaseClass
    {
        #region AutoGenerate
        
        private string idString = null;
        private string lunString = null;
        private string silentString = null;
        private string storagesystemString = null;
        private string pooltypeString = null;

        
        /// <summary>
        /// GetEmcStoragePool
        ///     Constructor for GetEmcStoragePool class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcStoragePool(string id = null, string lun = null, string silent = null, string storagesystem = null, string pooltype = null,  string cmd = null)
        {

            idString = id;
            lunString = lun;
            silentString = silent;
            storagesystemString = storagesystem;
            pooltypeString = pooltype;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStoragePool");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (storagesystemString != null)
            {
		        sb.AppendFormat(" -StorageSystem {0}", storagesystemString);
            }
			if (pooltypeString != null)
            {
		        sb.AppendFormat(" -PoolType {0}", pooltypeString);
            }
            return sb.ToString();
        }
        #endregion

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();
            string result = RunCMD(psMachine);
            TestSetup.VerifyStoragePoolInfo(psMachine, result);
            if (result.Trim() == string.Empty)
            {
                string warningMSG = string.Format("There is no result for command: {0}", GetFullString());
                log.LogWarning(warningMSG);
                PSException pe = new PSException(warningMSG);
                throw pe;
            }

            string[] poolStrings = result.Trim().Split(new string[] { "\r\n\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            foreach (string poolString in poolStrings)
            {
                SortedList<string, string> storagePoolKeyValue = HelperAdapter.GenerateKeyValuePairs(poolString);

                VerifyFields(storagePoolKeyValue,psMachine);
            }
            return result;
        }

        private void VerifyFields(SortedList<string, string> storagePool,PowershellMachine psMachine)
        {
            string storageSystemString = TestSetup.GetParameterValue(psMachine, "System");
            SortedList<string, string> storageSystemKeyValue = HelperAdapter.GenerateKeyValuePairs(storageSystemString);
            TestLog log = TestLog.GetInstance();
            log.AreEqual<string>(storageSystemKeyValue["GlobalId"], storagePool["StorageSystemGlobalId"], "Storage system global id is equal");
        }
    }
}

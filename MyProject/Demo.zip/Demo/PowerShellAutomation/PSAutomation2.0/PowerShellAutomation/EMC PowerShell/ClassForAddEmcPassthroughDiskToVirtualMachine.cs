using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcPassthroughDiskToVirtualMachine : BaseClass
    {
        
        private int diskNumber = 0;
        private int vmIndex = 0;

        public int DiskNumber
        {
            set
            {
                diskNumber = value;
            }
        }

        public int VMIndex
        {
            set
            {
                vmIndex = value;
            }
        }

        private TestLog log = TestLog.GetInstance();

#if true
        #region AutoGenerate
        
        private string diskidString = null;
        private string virtualmachineconfigurationString = null;
        private string locationString = null;
        private string scsicontrolleridString = null;
        private string scsicontrollerindexString = null;
        private string silentString = null;
        private string disknumberString = null;
        private string hostdiskString = null;
        private string scsilunString = null;
        private string persistenceString = null;
        private string compatibilityString = null;
        private string datastoreString = null;

        
        /// <summary>
        /// AddEmcPassthroughDiskToVirtualMachine
        ///     Constructor for AddEmcPassthroughDiskToVirtualMachine class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcPassthroughDiskToVirtualMachine(string diskid = null, string virtualmachineconfiguration = null, string location = null, string scsicontrollerid = null, string scsicontrollerindex = null, string silent = null, string disknumber = null, string hostdisk = null, string scsilun = null, string persistence = null, string compatibility = null, string datastore = null,  string cmd = null)
        {

            diskidString = diskid;
            virtualmachineconfigurationString = virtualmachineconfiguration;
            locationString = location;
            scsicontrolleridString = scsicontrollerid;
            scsicontrollerindexString = scsicontrollerindex;
            silentString = silent;
            disknumberString = disknumber;
            hostdiskString = hostdisk;
            scsilunString = scsilun;
            persistenceString = persistence;
            compatibilityString = compatibility;
            datastoreString = datastore;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcPassthroughDiskToVirtualMachine");

			if (diskidString != null)
            {
		        sb.AppendFormat(" -DiskId {0}", diskidString);
            }
			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (locationString != null)
            {
		        sb.AppendFormat(" -Location {0}", locationString);
            }
			if (scsicontrolleridString != null)
            {
		        sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsicontrolleridString + "\"");
            }
			if (scsicontrollerindexString != null)
            {
		        sb.AppendFormat(" -ScsiControllerIndex {0}", scsicontrollerindexString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (disknumberString != null)
            {
		        sb.AppendFormat(" -DiskNumber {0}", disknumberString);
            }
			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (scsilunString != null)
            {
		        sb.AppendFormat(" -ScsiLun {0}", scsilunString);
            }
			if (persistenceString != null)
            {
		        sb.AppendFormat(" -Persistence {0}", persistenceString);
            }
			if (compatibilityString != null)
            {
		        sb.AppendFormat(" -Compatibility {0}", compatibilityString);
            }
			if (datastoreString != null)
            {
		        sb.AppendFormat(" -Datastore {0}", datastoreString);
            }


            return sb.ToString();
        }
        #endregion
#endif
                
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcPassthroughDiskToVirtualMachine commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Add-EmcPassthroughDiskToVirtualMachine</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> scsiController)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, scsiController);
            
            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, SortedList<string, string> scsiController)
        {
            string[] hypervisor = { "HyperV", "VMWare" };
            string host = HelperAdapter.GetParameter("VirtualMachine") + vmIndex;

            //Thread.Sleep(3000);
            //UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter(hypervisor[vmIndex]));
            //updateSystem.RunCMD(psMachine);

            //updateSystem = new UpdateEmcSystem(host);
            //updateSystem.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, host);
            vmConfig.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
            vmConfig.RunCMD(psMachine, true);

            if (vmIndex == 0)
            {
                string description = TestSetup.GetPropertyValue(psMachine, PrefixString, "Description");
                log.AreEqual<bool>(true, description.Contains("Disk " + diskNumber), "Verify description");
                log.AreEqual<bool>(true, description.Contains("Bus") && description.Contains("Lun") && description.Contains("Target"), "Verify description");
            }

            if (scsicontrolleridString != null || scsicontrollerindexString != null)
            {
                string index = TestSetup.GetPropertyValue(psMachine, PrefixString, "ScsiControllerIndex");
                log.AreEqual<string>(scsiController["ScsiControllerIndex"], index, "Verify ScsiControllerIndex");

                string scsiControllerId = TestSetup.GetPropertyValue(psMachine, PrefixString, "HostLunIdentifier.ScsiControllerId");
                log.AreEqual<string>(scsiController["ScsiControllerId"], scsiControllerId, "Verify ScsiControllerId");
            }

            string hostLunidentifier = TestSetup.GetPropertyValue(psMachine, PrefixString, "HostLunIdentifier");
            SortedList<string, string> hostLunIdKeyValue = HelperAdapter.GenerateKeyValuePairs(hostLunidentifier);

            
            FindEmcHostDisk disk = new FindEmcHostDisk(null, null, null, null, null, null, host, PrefixString);
            string diskResult = null;
            int i = 0;
            while (true)
            {
                i++;
                try
                {
                    diskResult = disk.RunCMD(psMachine, true);
                }
                catch(PSException pe)
                {
                    if (i == 5)
                    {
                        throw pe;
                    }
                    else
                    {
                        continue;
                    }
                }
                break;
            }

            SortedList<string, string> diskKeyValue = HelperAdapter.GenerateKeyValuePairs(diskResult);

            if (compatibilityString == "Virtual")
            {
                log.AreEqual<string>("FilebasedVmDisk", diskKeyValue["DiskType"], "Verify disk type");
            }
            else
            {
                log.AreEqual<string>("PassthroughVmDisk", diskKeyValue["DiskType"], "Verify disk type");
            }
        }
    }
}
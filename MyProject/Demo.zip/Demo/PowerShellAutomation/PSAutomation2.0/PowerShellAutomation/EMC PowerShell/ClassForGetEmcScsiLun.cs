using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcScsiLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string idString = null;
        private string vmwaresystemString = null;
        private string lunString = null;
        private string silentString = null;
        private string esxhostsystemString = null;
        private string datastoreString = null;

        
        /// <summary>
        /// GetEmcScsiLun
        ///     Constructor for GetEmcScsiLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcScsiLun(string id = null, string vmwaresystem = null, string lun = null, string silent = null, 
            string esxhostsystem = null, string datastore = null,  string cmd = null)
        {

            idString = id;
            vmwaresystemString = vmwaresystem;
            lunString = lun;
            silentString = silent;
            esxhostsystemString = esxhostsystem;
            datastoreString = datastore;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcScsiLun");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (vmwaresystemString != null)
            {
		        sb.AppendFormat(" -VMwareSystem {0}", vmwaresystemString);
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (esxhostsystemString != null)
            {
		        sb.AppendFormat(" -ESXHostSystem {0}", esxhostsystemString);
            }
			if (datastoreString != null)
            {
		        sb.AppendFormat(" -Datastore {0}", datastoreString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcScsiLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="vmwareSystemGlobalId">VMware System Global Id</param>
        /// <param name="esxHostSystemGlobalId">ESX Host System Global Id</param>
        /// <param name="lunWwn">Lun WWN</param>
        /// <param name="lunCapacity">Lun Capacity</param>
        /// <param name="dataStoreRet">Datastore output result</param>
        /// <param name="uuid">ScsiLun UUID</param>
        /// <returns>the result of Get-EmcScsiLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string vmwareSystemGlobalId, string esxHostSystemGlobalId,
            string lunWwn, string lunCapacity, string dataStoreRet, string uuid)
        {
            PrefixString = HelperAdapter.GetParameter("ScsiLun");
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, vmwareSystemGlobalId, esxHostSystemGlobalId, lunWwn, lunCapacity, dataStoreRet, uuid);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields 
        /// </summary>
        /// <param name="psMachine"></param>
        /// <param name="result"></param>
        /// <param name="vmwareSystemGlobalId"></param>
        /// <param name="esxHostSystemGlobalId"></param>
        /// <param name="lunWwn"></param>
        /// <param name="lunCapacity"></param>
        /// <param name="dataStoreRet"></param>
        /// <param name="uuid"></param>
        private void VerifyFields(PowershellMachine psMachine, string result, string vmwareSystemGlobalId, string esxHostSystemGlobalId,
            string lunWwn, string lunCapacity, string dataStoreRet, string uuid)
        {
            List<SortedList<string, string>> scsiLuns = HelperAdapter.GenerateKeyValuePairsList(result);
            SortedList<string, string> scsiLun;
            if (datastoreString != null)
            {
                scsiLun = scsiLuns[0];
            }
            else
            {
                scsiLun = HelperAdapter.FindElementFromList(uuid, "Uuid", scsiLuns);
            }
            
            log.AreEqual(vmwareSystemGlobalId, scsiLun["VMwareSystemGlobalId"], "VMware System Global Id: ");
            log.AreEqual(esxHostSystemGlobalId, scsiLun["ESXHostSystemGlobalId"], "ESX Host System Global Id: ");
            // log.AreEqual("VRAID", scsiLun["Model"], "Model: ");
            log.AreEqual("disk", scsiLun["LunType"], "Lun Type: ");
            if (!scsiLun["OperationalState"].Contains("ok"))
            {
                log.LogError(String.Format("Incorrect opertational state {0}", scsiLun["OperationalState"]));
                PSException pe = new PSException(String.Format("Incorrect opertational state {0}", scsiLun["OperationalState"]));
                throw pe;
            }
            string canonicalName;
            if (datastoreString != null)
            {
                SortedList<string, string> datastore = HelperAdapter.GenerateKeyValuePairs(dataStoreRet);
                log.AreEqual(datastore["CanonicalNames"], scsiLun["CanonicalNames"], "Canonical Names: ");
                canonicalName = datastore["CanonicalNames"].Replace("{","").Replace("}", "");
                log.AreEqual(datastore["HostLunIdentifiers"], "{" + scsiLun["HostLunIdentifier"] + "}", "Host Lun Identifier: ");
                Int64 dsCapacity = Int64.Parse(TestSetup.GetPropertyValue(psMachine, datastoreString, "Capacity.Value"));
                Int64 scsiLunCapacity = Int64.Parse(TestSetup.GetPropertyValue(psMachine, PrefixString, "Capacity.Value"));
                if (scsiLunCapacity < dsCapacity)
                {
                    log.LogError(String.Format("The capacity of datastore is {0} while the capacity of scsilun is {1}", datastore["Capacity"], scsiLun["Capacity"]));
                    PSException pe = new PSException(String.Format("The capacity of datastore is {0} while the capacity of scsilun is {1}", datastore["Capacity"], scsiLun["Capacity"]));
                    throw pe;
                }
            }
            else
            {
                canonicalName = "naa." + lunWwn.Replace(":", "").ToLower();
                string canonicalNames = "{" + canonicalName + "}";
                string hostLunIdentifier = "{Wwn=" + lunWwn + "}";
                
                log.AreEqual(uuid, scsiLun["Uuid"], "Uuid: ");
                log.AreEqual(canonicalNames, scsiLun["CanonicalNames"], "Canonical Names: ");
                log.AreEqual(hostLunIdentifier, "{" + scsiLun["HostLunIdentifier"] + "}", "Host Lun Identifier: ");
                log.AreEqual(lunCapacity, scsiLun["Capacity"], "Capacity: ");
            }

            log.AreEqual(canonicalName, scsiLun["CanonicalName"], "Canonical Name: ");
            string deviceName = "/vmfs/devices/disks/" + canonicalName;
            log.AreEqual(deviceName, scsiLun["DeviceName"], "Device Name: ");
            log.AreEqual(deviceName, scsiLun["DevicePath"], "Device Path: ");
        }
    }
    
}
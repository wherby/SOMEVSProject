using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcSharedFolder : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string idString = null;
        private string cifsstoragesystemString = null;
        private string silentString = null;
        private string poolString = null;
        private string networkshareString = null;

        
        /// <summary>
        /// GetEmcSharedFolder
        ///     Constructor for GetEmcSharedFolder class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcSharedFolder(string id = null, string cifsstoragesystem = null, string silent = null, string pool = null, string networkshare = null,  string cmd=null)
        {

            idString = id;
            cifsstoragesystemString = cifsstoragesystem;
            silentString = silent;
            poolString = pool;
            networkshareString = networkshare;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSharedFolder");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (cifsstoragesystemString != null)
            {
		        sb.AppendFormat(" -CifsStorageSystem {0}", cifsstoragesystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (networkshareString != null)
            {
		        sb.AppendFormat(" -NetworkShare {0}", networkshareString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcSharedFolder commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcSharedFolder</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);


            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> sharedFoldersKeyValuePairs = HelperAdapter.GenerateKeyValuePairsList(result);
            if (idString != null)
            {
                log.AreEqual<int>(1, sharedFoldersKeyValuePairs.Count, "There will be one NewworkSharedfolder");
                string idStringString = idString.Replace("\"", "");
                bool isTheFolderFound = result.IndexOf(idStringString, StringComparison.OrdinalIgnoreCase) >= 0;
                log.AreEqual<bool>(true, isTheFolderFound, "The shared folder is found");
            }
            else
            {
                //There will verify all shared folders's info from storage side.
                TestSetup.VerifySharedFolderInfo(psMachine, result);
            }
            if (cifsstoragesystemString != null)
            {
                string storageSystemGlobalIDString = TestSetup.GetPropertyValue(psMachine, cifsstoragesystemString, "GlobalId");
                foreach (SortedList<string, string> temp in sharedFoldersKeyValuePairs)
                {
                    log.AreEqual<string>(storageSystemGlobalIDString, temp["StorageSystemGlobalId"], "StorageSystemGlobalId");
                }
            }
            if(poolString!=null)
            {
                string arrayPoolIdString = TestSetup.GetPropertyValue(psMachine, poolString, "ArrayPoolId");
                foreach (SortedList<string, string> temp in sharedFoldersKeyValuePairs)
                {
                    log.AreEqual<string>(arrayPoolIdString, temp["ArrayPoolId"], "ArrayPoolId");
                }
            }
            if (networkshareString != null)
            {
                string remotePathString = TestSetup.GetPropertyValue(psMachine, networkshareString, "RemotePath");
                foreach (SortedList<string, string> temp in sharedFoldersKeyValuePairs)
                {
                    bool isPathEqual = remotePathString.IndexOf(temp["SharedFolderPath"], StringComparison.OrdinalIgnoreCase) >= 0;
                    log.AreEqual<bool>(true, isPathEqual, "The SharedFolderPath");
                }
            }
        }
    }
}
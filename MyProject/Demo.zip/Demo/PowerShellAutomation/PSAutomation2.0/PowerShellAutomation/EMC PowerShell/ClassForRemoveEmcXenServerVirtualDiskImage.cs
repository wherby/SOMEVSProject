using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcXenServerVirtualDiskImage : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private string uuid = null;

        public string Uuid
        {
            set
            {
                uuid = value;
            }
        }

        #region AutoGenerate

        private string virtualdiskimageString = null;
        private string silentString = null;

        
        /// <summary>
        /// RemoveEmcXenServerVirtualDiskImage
        ///     Constructor for RemoveEmcXenServerVirtualDiskImage class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcXenServerVirtualDiskImage(string virtualdiskimage , string silent = null, string cmd = null)
        {
            virtualdiskimageString = virtualdiskimage;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcXenServerVirtualDiskImage");

            if (virtualdiskimageString != null)
            {
                sb.AppendFormat(" -VirtualDiskImage {0}", virtualdiskimageString);
            }

            if (silentString != null)
            {
                sb.Append(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcXenServerVirtualDiskImage commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcXenServerVirtualDiskImage</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string xenServer = HelperAdapter.GetParameter("XenServer");

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);

            GetEmcXenServerVirtualDiskImage getImage = new GetEmcXenServerVirtualDiskImage(uuid, xenServer);
            string getResult = getImage.RunCMD(psMachine);

            log.AreEqual<string>(string.Empty, getResult.Trim(), "Verify virtual disk is removed");
        }
    }
}
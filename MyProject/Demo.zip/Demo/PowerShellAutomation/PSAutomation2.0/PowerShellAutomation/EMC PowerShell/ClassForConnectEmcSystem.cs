using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{
    public class ConnectEmcSystem : BaseClass
    {
        #region CMD fields
        private string systemType = null;
        #endregion

        public string SystemType
        {
            get
            {
                return systemType;
            }
            set
            {
                systemType = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string creationblobString = null;
        private string silentString = null;

        
        /// <summary>
        /// ConnectEmcSystem
        ///     Constructor for ConnectEmcSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public ConnectEmcSystem(string creationblob = null, string silent = null,  string cmd = null)
        {

            creationblobString = creationblob;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Connect-EmcSystem");

			if (creationblobString != null)
            {
		        sb.AppendFormat(" -CreationBlob {0}", creationblobString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion
#endif
        
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);            
            
            SortedList<string, string> connectSystemKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            VerifyFields(connectSystemKeyValue, psMachine);

            return result;
        }


        private void VerifyFields(SortedList<string, string> connectSystemKeyValue, PowershellMachine psMachine)
        {
            #region verification for fields
            TestLog log = TestLog.GetInstance();
            string path = HelperAdapter.GetProperty("SystemConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, systemType);
            SortedList<string, string> getSystemKeyValue = new SortedList<string, string>();
            #endregion

            switch (systemType)
            {
                case "Host":
                    {
                        log.AreEqual<string>("HostSystem", connectSystemKeyValue["AdapterType"], "Verify Adapter Type");
                        break;
                    }
                case "VNX-Block":
                    {
                        goto case "Storage";
                    }
                case "VNX-CIFS":
                    {
                        goto case "VNX";
                    }
                case "VMAX": goto case "Storage";
                case "VMAXe": goto case "Storage";
                case "CLARiiON-CX4": goto case "Storage";
                case "VNX":
                    {
                        
                        goto case "Storage";
                    }
                case "Storage":
                    {
                        log.AreEqual<string>("StorageSystem", connectSystemKeyValue["AdapterType"], "Verify Adapter Type");
                        break;
                    }
                case "Cluster":
                    {
                        log.AreEqual<string>("ClusterSystem", connectSystemKeyValue["AdapterType"], "Verify Adapter Type");
                        break;
                    }
                default:
                    {
                        PSException pe = new PSException("invalid system type: " + systemType + ".");
                        throw pe;
                    }
            }
                        
        }
    }
}
using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualMachineHypervisor:BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string virtualmachineconfigurationString = null;
        private string silentString = null;
        private string virtualmachineString = null;

        
        /// <summary>
        /// GetEmcVirtualMachineHypervisor
        ///     Constructor for GetEmcVirtualMachineHypervisor class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVirtualMachineHypervisor(string virtualmachineconfiguration = null, string silent = null, string virtualmachine = null,  string cmd = null)
        {

            virtualmachineconfigurationString = virtualmachineconfiguration;
            silentString = silent;
            virtualmachineString = virtualmachine;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualMachineHypervisor");

			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (virtualmachineString != null)
            {
		        sb.AppendFormat(" -VirtualMachine {0}", virtualmachineString);
            }


            return sb.ToString();
        }
        #endregion
      

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualMachineHypervisor command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="hypervPrefix">Hyper-V prefix</param>
        /// <param name="vmwarePrefix">VMware Prefix</param>
        /// <param name="xenPrefix">Xen Prefix</param>
        /// <returns>Get-EmcVirtualMachineHypervisor result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hypervPrefix, string vmwarePrefix, string xenPrefix)
        {            
            string result = RunCMD(psMachine, true);
            VerifyFields(psMachine, result, hypervPrefix, vmwarePrefix, xenPrefix);       
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualMachineHypervisor
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="result">Get-EmcVirtualMachineHypervisor result string</param> 
        /// <param name="hypervPrefix">Hyper-V prefix</param>
        /// <param name="vmwarePrefix">VMware Prefix</param>
        /// <param name="xenPrefix">Xen Prefix</param>      
        private void VerifyFields(PowershellMachine psMachine, string result, string hypervPrefix, string vmwarePrefix, string xenPrefix)
        {
            string hyperv = TestSetup.GetPropertyValue(psMachine, hypervPrefix);
            string vmware = TestSetup.GetPropertyValue(psMachine, vmwarePrefix);
            string xen = TestSetup.GetPropertyValue(psMachine, xenPrefix);
            SortedList<string, string> getHypervProperties = HelperAdapter.GenerateKeyValuePairs(result);
            SortedList<string, string> expectedHypervProperties = null;

            if ((virtualmachineconfigurationString != null && virtualmachineconfigurationString.Contains("hyperv")) ||
                (virtualmachineString != null && virtualmachineString.Contains("hyperv")))
            {
                 expectedHypervProperties = HelperAdapter.GenerateKeyValuePairs(hyperv);
            }

            if ((virtualmachineconfigurationString != null && virtualmachineconfigurationString.Contains("vmware")) ||
                (virtualmachineString != null && virtualmachineString.Contains("vmware")))
            {
                expectedHypervProperties = HelperAdapter.GenerateKeyValuePairs(vmware);
            }

            if ((virtualmachineconfigurationString != null && virtualmachineconfigurationString.Contains("xen")) ||
                (virtualmachineString != null && virtualmachineString.Contains("xen")))
            {
                expectedHypervProperties = HelperAdapter.GenerateKeyValuePairs(xen);
            }

            #region verification for fields
            HelperAdapter.AssertPropertiesComparision(getHypervProperties, expectedHypervProperties);
            #endregion
        }
    }
}
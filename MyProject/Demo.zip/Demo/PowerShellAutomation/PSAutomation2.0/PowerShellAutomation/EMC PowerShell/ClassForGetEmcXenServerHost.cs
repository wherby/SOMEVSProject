using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcXenServerHost : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private static int hostIndex;
        private static List<Dictionary<string, string>> hostsKeyValue;

        public int HostIndex
        {
            get
            {
                return hostIndex;
            }
            set
            {
                hostIndex = value;
            }
        }

        public List<Dictionary<string, string>> HostsKeyValue
        {
            get
            {
                return hostsKeyValue;
            }
            set
            {
                hostsKeyValue = value;
            }
        }

        #region AutoGenerate
        
        private string idString = null;
        private string xenserverString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcXenServerHost
        ///     Constructor for GetEmcXenServerHost class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcXenServerHost(string id, string xenserver, string silent,  string cmd)
        {

            idString = id;
            xenserverString = xenserver;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcXenServerHost");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (xenserverString != null)
            {
		        sb.AppendFormat(" -XenServer {0}", xenserverString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcXenServerHost commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcXenServerHost</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> hostsList = HelperAdapter.GenerateKeyValuePairsList(result);
            bool hostGet = false;

            if (hostIndex == -1)
            {
                log.AreEqual<int>(hostsKeyValue.Count, hostsList.Count, "Verify hosts number");
                foreach (SortedList<string, string> host in hostsList)
                {
                    hostGet = false;
                    foreach (Dictionary<string, string> dic in hostsKeyValue)
                    {
                        if (dic["Name"] == host["Name"])
                        {
                            VerifyConfig(psMachine, dic, host);
                            hostGet = true;
                            break;
                        }
                        else
                        {
                            continue;
                        }
                    }
                    log.AreEqual<bool>(true, hostGet, "Verify host " + host["Name"] + " is got");
                }
            }
            else
            {
                log.AreEqual<int>(1, hostsList.Count, "Verify hosts number");
                VerifyConfig(psMachine, hostsKeyValue[hostIndex], hostsList[0]);
            }
        }

        private void VerifyConfig(PowershellMachine psMachine, Dictionary<string, string> dic, SortedList<string, string> getObj)
        {
            log.AreEqual<string>("HostSystem", getObj["AdapterType"], "Verify AdapterType");
            log.AreEqual<string>(dic["IPAddress"], getObj["IpAddress"], "Verify IpAddress");
            string xenServerGlobalId = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("XenServer"), "GlobalId");
            log.AreEqual<string>(xenServerGlobalId, getObj["XenServerSystemGlobalId"], "Verify XenServer GlobalId");
            
            string xenServer = HelperAdapter.GetParameter("XenServer");
            TestSetup.GetPropertyValue(psMachine, xenServer, "RefreshHostBusAdapters()");
            string result = TestSetup.GetPropertyValue(psMachine, xenServer, "HostBusAdapters");
            List<SortedList<string, string>> hbas = HelperAdapter.GenerateKeyValuePairsList(result);

            string[] hostBusAdaptersExp = new string[hbas.Count];
            for(int i = 0; i < hbas.Count; i++)
            {
                hostBusAdaptersExp[i] = hbas[i]["Iqn"];
            }
            
            string[] hostBusAdaptersActual = getObj["HostBusAdapters"].Split(new string[] { "{[", "]}", "[", "]", "], [" }, StringSplitOptions.RemoveEmptyEntries);
            log.AreEqual<int>(hostBusAdaptersExp.Length, hostBusAdaptersActual.Length, "Verify HostBusAdapters count");

            foreach (string hostBusAdapter in hostBusAdaptersActual)
            {
                bool adapterExist = false;
                string[] adapterProperties = hostBusAdapter.Split(new string[]{". "}, StringSplitOptions.RemoveEmptyEntries);
                log.AreEqual<string>("HostName= " + dic["Name"], adapterProperties[1], "Verify HostName in hostBustAdpater");
                string id = adapterProperties[2].Split(new string[] { "= " }, StringSplitOptions.RemoveEmptyEntries)[1];
                foreach (string adapterExp in hostBusAdaptersExp)
                {
                    if (adapterExp.Contains(id))
                    {
                        adapterExist = true;
                        break;
                    }
                }
                log.AreEqual<bool>(true, adapterExist, "Verify " + hostBusAdapter + " exists");
            }
            
        }
    }
}
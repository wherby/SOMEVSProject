using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;


namespace PowerShellAutomation
{
    public class GetEmcSnapshotPool : BaseClass
    {
       
        TestLog log = TestLog.GetInstance();
        

        #region AutoGenerate
        
        private string idString = null;
        private string blockstoragesystemString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcSnapshotPool
        ///     Constructor for GetEmcSnapshotPool class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcSnapshotPool(string id = null, string blockstoragesystem = null, string silent = null,  string cmd = null)
        {

            idString = id;
            blockstoragesystemString = blockstoragesystem;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSnapshotPool");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (blockstoragesystemString != null)
            {
		        sb.AppendFormat(" -BlockStorageSystem {0}", blockstoragesystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcSnapshotPool succeeds
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="globalID">The storage global id</param>
        /// <param name="poolID">The id for snapshot pool</param>
        /// <returns>Get-EmcSnapshotPool result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string globalID, string poolID)
        {
            string result;

            result = RunCMD(psMachine, true);
            VerifyFields(result, globalID, poolID);
            if (idString == null && blockstoragesystemString == null && silentString == null)
            {
                TestSetup.VerifySnapshotPoolInfo(psMachine, result);
            }

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the  fields for Get-EmcSnapshotPool
        /// </summary>     
        /// <param name="result">Get-EmcSnapshotPool result</param>
        /// <param name="globalID">The storage global id</param>
        /// <param name="poolID">The id for snapshot pool</param>
        private void VerifyFields(string result, string globalID, string poolID)
        { 

            List<SortedList<string, string>> snapshotPoolKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            SortedList<string, string> snapshotPoolProperites = HelperAdapter.FindElementFromList(poolID, "PoolId", snapshotPoolKeyValueList);

           

            if (snapshotPoolProperites == null)
            {
                log.LogError(string.Format("Failed to get the snapshot pool of storage: {0}", globalID));
                PSException pe = new PSException(string.Format("Failed to get the snapshot pool of storage: {0}", globalID));
                throw pe;
            }
            else
            {                
                log.AreEqual(globalID, snapshotPoolProperites["StorageSystemGlobalId"], "Verfity snapshot pool id:");
            }
        }
    }
}

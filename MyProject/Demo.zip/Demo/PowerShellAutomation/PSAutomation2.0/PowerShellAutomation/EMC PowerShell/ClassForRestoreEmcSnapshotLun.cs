using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RestoreEmcSnapshotLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string snapshotlunString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RestoreEmcSnapshotLun
        ///     Constructor for RestoreEmcSnapshotLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RestoreEmcSnapshotLun(string snapshotlun, string force = null, string silent = null, string whatif = null,  string cmd = null)
        {

            snapshotlunString = snapshotlun;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Restore-EmcSnapshotLun");

			if (snapshotlunString != null)
            {
		        sb.AppendFormat(" -SnapshotLun {0}", snapshotlunString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Restore-EmcSnapshotLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Restore-EmcSnapshotLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hostDiskPath, string driveLetter, string content)
        {
            
            string result = RunCMD(psMachine);
            Thread.Sleep(10000);

            TestSetup.SetHostDiskOnline(psMachine, true);
            result = TestSetup.UpdateHostVolumeInfo(psMachine);
            string newDriveLetter = HelperAdapter.GenerateKeyValuePairs(result)["MountPath"];
            if (newDriveLetter != driveLetter)
            {
                hostDiskPath.Replace(driveLetter + "$", newDriveLetter + "$");
            }

            VerifyFields(psMachine, hostDiskPath, content);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string hostDiskPath, string content)
        {

            // You can extend the sleep time and delete the while loop
            Thread.Sleep(5000);

            string fileContent = TestSetup.GetValue(psMachine, "Get-Content " + hostDiskPath);
            while (String.IsNullOrEmpty(fileContent))
            {
                fileContent = TestSetup.GetValue(psMachine, "Get-Content " + hostDiskPath);
                Thread.Sleep(1000);                
            }

            // Compare the files, make sure the file is snapshot back 
            if (whatifString != null)
            {
                if (! fileContent.Contains(content))
                //if (TestSetup.CompareFiles(psMachine, sourceFile, hostDiskPath))
                {
                    log.LogError("Restore-EmcSnapshotLun should not take effect with whatif paramter");
                    PSException pe = new PSException("Restore-EmcSnapshotLun should not take effect with whatif paramter");
                    throw pe;
                }
            }
            else
            {
                if (fileContent.Contains(content))
                //if (!TestSetup.CompareFiles(psMachine, sourceFile, hostDiskPath))
                {
                    log.LogError("Failed to restore the snapshot");
                    PSException pe = new PSException("Failed to restore the snapshot");
                    throw pe;
                }
            }
        }

        
    }
}
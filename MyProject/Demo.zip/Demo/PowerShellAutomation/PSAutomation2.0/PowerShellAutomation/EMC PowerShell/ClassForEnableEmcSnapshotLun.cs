using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class EnableEmcSnapshotLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate

        private string snapshotlunString = null;
        private string sourcelunString = null;
        private string snapshotpoolString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;


        /// <summary>
        /// EnableEmcSnapshotLun
        ///     Constructor for EnableEmcSnapshotLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public EnableEmcSnapshotLun(string snapshotlun, string sourcelun = null, string snapshotpool = null, string force = null, string silent = null, string whatif = null, string cmd = null)
        {

            snapshotlunString = snapshotlun;
            sourcelunString = sourcelun;
            snapshotpoolString = snapshotpool;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Enable-EmcSnapshotLun");

            if (snapshotlunString != null)
            {
                sb.AppendFormat(" -SnapshotLun {0}", snapshotlunString);
            }
            if (sourcelunString != null)
            {
                sb.AppendFormat(" -SourceLun {0}", sourcelunString);
            }
            if (snapshotpoolString != null)
            {
                sb.AppendFormat(" -SnapshotPool {0}", snapshotpoolString);
            }
            if (forceString != null)
            {
                sb.AppendFormat(" -Force");
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            if (whatifString != null)
            {
                sb.AppendFormat(" -WhatIf");
            }
            sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Enable-EmcSnapshotLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Enable-EmcSnapshotLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result;

            if (whatifString != null)
            {
                result = RunCMD(psMachine);
            }
            else
            {
                result = RunCMD(psMachine, true);
            }
            VerifyFields(psMachine, result);

            return result;
        }

        /// <summary>
        ///VerifyFields
        ///    Verify whether the snapshot lun is activated
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="result">return string of Enable-EmcSnapshotLun cmdlet</param>
        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            if (whatifString != null)
            {
                if (!String.IsNullOrEmpty(result.Trim()))
                {
                    log.LogError(string.Format("SnapshotLun should not be activated with WhatIf parameter."));
                    PSException pe = new PSException(string.Format("SnapshotLun should not be activated with WhatIf parameter."));
                    throw pe;
                }
            }
            else
            {
                // Verify IsActivated field is true
                string isActivated = HelperAdapter.GenerateKeyValuePairs(result)["IsActivated"];
                log.AreEqual("True", isActivated, "Verify IsActivated field of the Snapshot Lun: ");
            }
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class DisableEmcSnapshotLun : BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string snapshotlunString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;


        /// <summary>
        /// DisableEmcSnapshotLun
        ///    Constructor for DisableEmcSnapshotLun class
        /// </summary>
        /// <param name="snapshotLun">snapshot lun object string</param>
        /// <param name="force">The force switch parameter</param>
        /// <param name="silent">The silent switch parameter</param>
        /// <param name="whatif">The whatif switch parameter</param>
        /// <param name="cmd">Command string to test</param>
        public DisableEmcSnapshotLun(string snapshotlun = null, string force = null, string silent = null, string whatif = null,  string cmd = null)
        {

            snapshotlunString = snapshotlun;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Disable-EmcSnapshotLun");

			if (snapshotlunString != null)
            {
		        sb.AppendFormat(" -SnapshotLun {0}", snapshotlunString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

     
            
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whethe Disable-EmcSnapshotLun succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="snapshotLunID">Snapshot Lun ID</param>
        /// <returns>the result of Disable-EmcSnapshotLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string snapshotLunID)
        {
            string result = RunCMD(psMachine);            

            VerifyFields(psMachine, snapshotLunID);
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify whether the snapshot lun is deactivated
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="snapshotLunID">Snapshot Lun ID</param>
        private void VerifyFields(PowershellMachine psMachine, string snapshotLunID)
        {
            GetEmcSnapshotLun getSnapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, HelperAdapter.GetParameter("System"));
            string result = getSnapshotLun.RunCMD(psMachine, true);
            string isActivated = HelperAdapter.GenerateKeyValuePairs(result)["IsActivated"];
            
            if (whatifString != null)
            {
                if (isActivated.Equals("False"))
                {
                    log.LogError(string.Format("SnapshotLun should not be deactivated with WhatIf parameter."));
                    PSException pe = new PSException(string.Format("SnapshotLun should not be deactivated with WhatIf parameter."));
                    throw pe;
                }
            }
            else
            {
                // Verify IsActivated field is true                
                log.AreEqual("False", isActivated, "Verify IsActivated field of the Snapshot Lun: ");
            }
        }
    }
}
using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcSnapshotLun:BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string idString = null;
        private string sourcelunString = null;
        private string blockstoragesystemString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcSnapshotLun
        ///     Constructor for GetEmcSnapshotLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcSnapshotLun(string id = null, string sourcelun = null, string blockstoragesystem = null, string silent = null,  string cmd = null)
        {

            idString = id;
            sourcelunString = sourcelun;
            blockstoragesystemString = blockstoragesystem;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSnapshotLun");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (sourcelunString != null)
            {
		        sb.AppendFormat(" -SourceLun {0}", sourcelunString);
            }
			if (blockstoragesystemString != null)
            {
		        sb.AppendFormat(" -BlockStorageSystem {0}", blockstoragesystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

               

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcSnapshotLun command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="newSnapshotLunProperties">Lun properties retrieved from New-EmcSnapshotLun</param>
        /// <returns>Get-EmcSnapshotLun result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> newSnapshotLunProperties)
        {            
            string result = RunCMD(psMachine, true);
            VerifyFields(result, newSnapshotLunProperties);
            if (idString == null && blockstoragesystemString == null && sourcelunString == null && silentString == null)
            {
                TestSetup.VerifySnapshotLunInfo(psMachine, result);
            }
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcSnapShotLun
        /// </summary>
        /// <param name="result">Get-EmcSnapShotLun result string</param>
        /// <param name="newSnapshotLunProperties">Lun properties retrieved from New-EmcSnapshotLun</param>        
        private void VerifyFields(string result, SortedList<string, string> newSnapshotLunProperties)
        {            
            List<SortedList<string, string>> getSnapshotLunPropertiesList = HelperAdapter.GenerateKeyValuePairsList(result);

            SortedList<string, string> getSnapshotLunProperties = null;

            if (idString != null && getSnapshotLunPropertiesList.Count != 1)
            {
                log.LogError(string.Format("{0} snapshot lun have been found by specifying ID {1}.", getSnapshotLunPropertiesList.Count, idString));
                PSException pe = new PSException(string.Format("{0} snapshot lun have been found by specifying ID {1}.", getSnapshotLunPropertiesList.Count, idString));
                throw pe;
            }

            foreach (SortedList<string, string> properties in getSnapshotLunPropertiesList)
            {                
                
                if (properties["Wwn"].Equals(newSnapshotLunProperties["Wwn"]))
                {
                    getSnapshotLunProperties = properties;
                }
            }

            if (getSnapshotLunProperties == null)
            {
                log.LogError(string.Format("Failed to get the following snapshot lun: {0}", newSnapshotLunProperties));
                PSException pe = new PSException(string.Format("Failed to get the following snapshot lun: {0}", newSnapshotLunProperties));
                throw pe;
            }

            #region verification for fields
            HelperAdapter.AssertPropertiesComparision(getSnapshotLunProperties, newSnapshotLunProperties);    
            #endregion
        }
    }
}
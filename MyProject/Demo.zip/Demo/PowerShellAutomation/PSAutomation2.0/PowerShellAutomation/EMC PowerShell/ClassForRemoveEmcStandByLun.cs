using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcStandByLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string standbylunsString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcStandByLun
        ///     Constructor for RemoveEmcStandByLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcStandByLun(string standbyluns = null, string silent = null, string whatif = null,  string cmd=null)
        {

            standbylunsString = standbyluns;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcStandByLun");

			if (standbylunsString != null)
            {
		        sb.AppendFormat(" -StandByLuns {0}", standbylunsString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcStandByLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcStandByLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            if (whatifString == null)
            {
                string standbyLuns = TestSetup.GetPropertyValue(psMachine, standbylunsString);
                List<SortedList<string, string>> standbyLunsKeyValuePairs = HelperAdapter.GenerateKeyValuePairsList(standbyLuns);
                foreach (SortedList<string, string> temp in standbyLunsKeyValuePairs)
                {
                    string storageSystemString=HelperAdapter.GetParameter("System");
                    GetEmcStandbyLun getlun = new GetEmcStandbyLun(storageSystemString, temp["ArrayLunId"]);
                    string getlunResult = getlun.RunCMD(psMachine);
                    log.AreEqual<string>(string.Empty, getlunResult.Trim(), "The standby lun is removed");
                }
            }
        }
    }
}
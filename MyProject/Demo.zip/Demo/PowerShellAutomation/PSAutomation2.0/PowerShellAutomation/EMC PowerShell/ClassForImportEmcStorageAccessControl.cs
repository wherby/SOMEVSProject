using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class ImportEmcStorageAccessControl : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string fileString = null;
        private string protectionkeyString = null;
        private string forceString = null;
        private string listonlyString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// ImportEmcStorageAccessControl
        ///     Constructor for ImportEmcStorageAccessControl class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public ImportEmcStorageAccessControl(string file = null, string protectionkey = null, string force = null, string listonly = null, string silent = null, string whatif = null,  string cmd = null)
        {

            fileString = file;
            protectionkeyString = protectionkey;
            forceString = force;
            listonlyString = listonly;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Import-EmcStorageAccessControl");

			if (fileString != null)
            {
		        sb.AppendFormat(" -File {0}", fileString);
            }
			if (protectionkeyString != null)
            {
		        sb.AppendFormat(" -ProtectionKey {0}", protectionkeyString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (listonlyString != null)
            {
		        sb.AppendFormat(" -ListOnly");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Import-EmcStorageAccessControl commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Import-EmcStorageAccessControl</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string storageGlobalID, string poolName)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, result, storageGlobalID, poolName);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, string storageGlobalID, string poolName)
        {
            
            // Verify the storage is imported successfully
            GetEmcStorageSystem getEmcStorageSystem = new GetEmcStorageSystem();
            if (whatifString == null && listonlyString == null)
            {
                string ret = getEmcStorageSystem.RunCMD(psMachine, true);
                string storageID = HelperAdapter.GenerateKeyValuePairs(ret)["GlobalId"];
                log.AreEqual(storageGlobalID, storageID, "Storage Global ID is: ");

                // Verify the pool is imported successfully
                GetEmcStoragePool getEmcStoragePool = new GetEmcStoragePool();
                ret = getEmcStoragePool.RunCMD(psMachine, true);
                List<SortedList<string, string>> pools = HelperAdapter.GenerateKeyValuePairsList(ret);
                if (pools.Count != 1)
                {
                    log.LogError("Incorrect number of pools is imported");
                    PSException pe = new PSException("Incorrect number of pools is imported");
                    throw pe;
                }
                log.AreEqual(poolName, pools[0]["Name"], "The pool name is: ");
            }
            else
            {
                string ret = getEmcStorageSystem.RunCMD(psMachine);
                if (! String.IsNullOrEmpty(ret.Trim()))
                {
                    log.LogError("Access Control should not be imported with WhatIf/ListOnly parameter");
                    PSException pe = new PSException("Access Control should not be imported with WhatIf/ListOnly parameter");
                    throw pe;
                }
            }
            if (listonlyString != null)
            {
                List<StorageAccessControlStruct> acls = HelperAdapter.ParseAccessControlOutput(result);
                log.AreEqual(storageGlobalID, acls[0].StorageGlobalID, "Storage Global ID: ");
                if (! acls[0].Pools.Contains(poolName))
                {
                    log.LogError(String.Format("Pool {0} doesn't find in access control: {1}", poolName, result));
                    PSException pe = new PSException(String.Format("Pool {0} doesn't find in access control: {1}", poolName, result));
                    throw pe;
                }
            }          
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcXenServerStorageRepository : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private string uuid = null;

        public string UUID
        {
            set
            {
                uuid = value;
            }
        }

        #region AutoGenerate
        
        private string storagerepositoryString = null;
        private string silentString = null;

        
        /// <summary>
        /// RemoveEmcXenServerStorageRepository
        ///     Constructor for RemoveEmcXenServerStorageRepository class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcXenServerStorageRepository(string storagerepository = null, string silent = null,  string cmd = null)
        {

            storagerepositoryString = storagerepository;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcXenServerStorageRepository");

			if (storagerepositoryString != null)
            {
		        sb.AppendFormat(" -StorageRepository {0}", storagerepositoryString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcXenServerStorageRepository commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcXenServerStorageRepository</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string xenServer = HelperAdapter.GetParameter("XenServer");

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);

            GetEmcXenServerStorageRepository sr = new GetEmcXenServerStorageRepository(uuid, xenServer, null, null);
            string getSR = sr.RunCMD(psMachine);

            log.AreEqual<string>(string.Empty, getSR, "Verify get SR");
        }
    }
}
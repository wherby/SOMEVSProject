using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcDataStore : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string idString = null;
        private string vmwaresystemString = null;
        private string silentString = null;
        private string esxhostsystemString = null;
        private string scsilunString = null;
        private string lunString = null;

        
        /// <summary>
        /// GetEmcDataStore
        ///     Constructor for GetEmcDataStore class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcDataStore(string id = null, string vmwaresystem = null, string silent = null, 
            string esxhostsystem = null, string scsilun = null, string lun = null,  string cmd = null)
        {

            idString = "\"" + id + "\"";
            vmwaresystemString = vmwaresystem;
            silentString = silent;
            esxhostsystemString = esxhostsystem;
            scsilunString = scsilun;
            lunString = lun;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcDataStore");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (vmwaresystemString != null)
            {
		        sb.AppendFormat(" -VMwareSystem {0}", vmwaresystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (esxhostsystemString != null)
            {
		        sb.AppendFormat(" -ESXHostSystem {0}", esxhostsystemString);
            }
			if (scsilunString != null)
            {
		        sb.AppendFormat(" -ScsiLun {0}", scsilunString);
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcDataStore commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="name">datastore name</param>
        /// <param name="uuid">datastore uuid</param>
        /// <param name="lunCapacity">lun capacity</param>
        /// <param name="lunWwn">lun wwn</param>
        /// <param name="esxHostIP">ESX Host IP</param>
        /// <param name="vmwareSystemGlobalId">VMware System Global Id</param>
        /// <returns>the result of Get-EmcDataStore</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string name, string uuid, string lunWwn, string esxHostIP,
            string vmwareSystemGlobalId)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, name, uuid, lunWwn, esxHostIP, vmwareSystemGlobalId);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields of Get-EmcDataStore
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="result">output result of Get-EmcDataStore</param>
        /// <param name="name">datastore name</param>
        /// <param name="uuid">datastore uuid</param>
        /// <param name="lunWwn">lun wwn</param>
        /// <param name="esxHostIP">ESX Host IP</param>
        /// <param name="vmwareSystemGlobalId">VMware System Global Id</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string name, string uuid, string lunWwn, string esxHostIP,
            string vmwareSystemGlobalId)
        {
            List<SortedList<string, string>> datastores = HelperAdapter.GenerateKeyValuePairsList(result);
            SortedList<string, string> datastore;
            datastore = HelperAdapter.FindElementFromList(name, "Name", datastores);
            log.AreEqual("VMFS5", datastore["Type"], "Datastore Type: ");
            log.AreEqual(uuid, datastore["Uuid"], "Datastore Uuid: ");
            log.AreEqual(vmwareSystemGlobalId, datastore["VMwareSystemGlobalId"], "VMware Global Id: ");
            log.AreEqual("{" + esxHostIP + "}", datastore["EsxHosts"], "EsxHosts: ");
            if (lunWwn != null)
            {
                string hostLunIdentifier = "{Wwn=" + lunWwn + "}";
                log.AreEqual(hostLunIdentifier, datastore["HostLunIdentifiers"], "Host Lun Identifiers: ");
                string canonicalNames = "{" + "naa." + lunWwn.Replace(":", "").ToLower() + "}";
                log.AreEqual(canonicalNames, datastore["CanonicalNames"], "Canonical Names: ");
            }
        }
    }
}
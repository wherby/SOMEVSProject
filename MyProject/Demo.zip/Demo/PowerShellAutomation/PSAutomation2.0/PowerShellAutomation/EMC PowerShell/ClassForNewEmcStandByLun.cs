using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcStandByLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string storagesystemString = null;
        private string countString = null;
        private string capacityString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcStandByLun
        ///     Constructor for NewEmcStandByLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcStandByLun(string storagesystem = null, string count = null, string capacity = null, string silent = null,  string cmd=null)
        {

            storagesystemString = storagesystem;
            countString = count;
            capacityString = capacity;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcStandByLun");

			if (storagesystemString != null)
            {
		        sb.AppendFormat(" -StorageSystem {0}", storagesystemString);
            }
			if (countString != null)
            {
		        sb.AppendFormat(" -Count {0}", countString);
            }
			if (capacityString != null)
            {
		        sb.AppendFormat(" -Capacity {0}", capacityString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcStandByLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of New-EmcStandByLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> standbyLuns = HelperAdapter.GenerateKeyValuePairsList(result);
            if (countString != null)
            {
                log.AreEqual<int>(int.Parse(countString), standbyLuns.Count, "Standby Luns count");
            }
            if (capacityString != null)
            {
                foreach (SortedList<string, string> temp in standbyLuns)
                {
                    string capacityCreated = temp["Capacity"];
                    capacityCreated = capacityCreated.Replace(" ", "");
                    string capacityCreatedString = TestSetup.GetPropertyValue(psMachine, capacityCreated);
                    string capacityStringCapacity = TestSetup.GetPropertyValue(psMachine, capacityString);
                    log.AreEqual<string>(capacityStringCapacity, capacityCreatedString, "Capacity");
                    string systemGlobID = TestSetup.GetPropertyValue(psMachine, storagesystemString, "GlobalId");
                    log.AreEqual<string>(systemGlobID, temp["StorageSystemGlobalId"], "System golbal id");
                }
            }
        }
    }
}
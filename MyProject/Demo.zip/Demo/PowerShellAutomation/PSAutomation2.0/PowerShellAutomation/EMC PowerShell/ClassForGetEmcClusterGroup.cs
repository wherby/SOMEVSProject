using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcClusterGroup:BaseClass
    {
       

#if true
        #region AutoGenerate
        
        private string clustersystemString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcClusterGroup
        ///     Constructor for GetEmcClusterGroup class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcClusterGroup(string clustersystem = null, string silent = null,  string cmd = null)
        {

            clustersystemString = clustersystem;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcClusterGroup");

			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion
#endif
        

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            List<SortedList<string, string>> keyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach(SortedList<string, string> keyValue in keyValueList)
            {
                VerifyFields(psMachine, keyValue);
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, SortedList<string, string> getGroupKeyValue)
        {
            string state = null;
            TestLog log = TestLog.GetInstance();

            GetEmcClusterDisk clusterDisk = new GetEmcClusterDisk(null, HelperAdapter.GetParameter("Cluster"), getGroupKeyValue["Name"]);
            string diskResult = clusterDisk.RunCMD(psMachine);

            if (diskResult.Trim() != string.Empty)
            {
                List<SortedList<string, string>> diskList = HelperAdapter.GenerateKeyValuePairsList(diskResult);
                foreach (SortedList<string, string> diskKeyValue in diskList)
                {
                    if (diskKeyValue["ClusterDiskResouceState"] == "Offline")
                    {
                        if(state == null)
                        {
                            state = "Offline";
                        }
                        else if (state == "Online")
                        {
                            state = "PartialOnline";
                        }
                    }
                    else if (diskKeyValue["ClusterDiskResouceState"] == "Online")
                    {
                        if (state == null)
                        {
                            state = "Online";
                        }
                        else if (state == "Offline")
                        {
                            state = "PartialOnline";
                        }
                    }

                    if (diskKeyValue["ClusterDiskResouceState"] == "Failed")
                    {
                        state = "Failed";
                        break;
                    }

                }

                log.AreEqual<string>(state, getGroupKeyValue["State"], "Verify State");
            }
                        
        }
    }
}

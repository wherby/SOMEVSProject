using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcAvailableScsiControllerLocation:BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string virtualmachineconfigurationString = null;
        private string scsicontrollerindexString = null;
        private string silentString = null;
        private string scsicontrolleridString = null;

        
        /// <summary>
        /// GetEmcAvailableScsiControllerLocation
        ///     Constructor for GetEmcAvailableScsiControllerLocation class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcAvailableScsiControllerLocation(string virtualmachineconfiguration = null, string scsicontrollerindex = null, string silent = null, string scsicontrollerid = null,  string cmd = null)
        {

            virtualmachineconfigurationString = virtualmachineconfiguration;
            scsicontrollerindexString = scsicontrollerindex;
            silentString = silent;
            scsicontrolleridString = scsicontrollerid;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcAvailableScsiControllerLocation");

			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (scsicontrollerindexString != null)
            {
		        sb.AppendFormat(" -ScsiControllerIndex {0}", scsicontrollerindexString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (scsicontrolleridString != null)
            {
		        sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsicontrolleridString + "\"");
            }


            return sb.ToString();
        }
        #endregion

              

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcAvailableScsiControllerLocation command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>Get-EmcAvailableScsiControllerLocation result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hypervVMPrefix, string vmwareVMPrefix)
        {  
            string result = RunCMD(psMachine);            
            VerifyFields(psMachine, result, hypervVMPrefix, vmwareVMPrefix);
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///   Verify the fields of Get-EmcAvailableScsiControllerLocation
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="availableScsiControllerLocationResult">Get-EmcAvaiableScsiControllerLocation result string</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string hypervVMPrefix, string vmwareVMPrefix)
        {
            string[] availableScsiControllerLocation = null;
            if (! String.IsNullOrEmpty(result))
            {
                result.Split(new string[] { "\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            }
            GetEmcHostDisk hd = null;
            
            // Get all disks on VM
            if (virtualmachineconfigurationString.Contains("hyperv"))
            {
                hd = new GetEmcHostDisk(null, null, hypervVMPrefix);
            }
            if (virtualmachineconfigurationString.Contains("vmware"))
            {
                hd = new GetEmcHostDisk(null, null, vmwareVMPrefix);
            }
            hd.PrefixString = HelperAdapter.GetParameter("Disks");
            string diskResult = hd.RunCMD(psMachine, true);

            List<SortedList<string, string>> disks = HelperAdapter.GenerateKeyValuePairsList(diskResult);

            // Get Virtual Disk Configuration for all filebaseddisk and passthrough disk
            int i = 0;
            int usedScsiControllerLocationCount = 0;
            foreach ( SortedList<string, string> disk in disks )
            {
                if (disk["DiskType"].Contains("Filebased")
                    || disk["DiskType"].Contains("Passthrough"))
                {
                    string hostDisk = hd.PrefixString;
                    if (disks.Count > 1)
                    {
                        hostDisk = hostDisk + "[" + i.ToString() + "]";
                    }
                    GetEmcVirtualDiskConfiguration vd = new GetEmcVirtualDiskConfiguration(hostDisk);
                    vd.PrefixString = HelperAdapter.GetParameter("Disk");
                    vd.RunCMD(psMachine, true);

                    string scsiControllerId = TestSetup.GetPropertyValue(psMachine, vd.PrefixString, "HostLunIdentifier.ScsiControllerId");
                    string scsiControllerIndex = TestSetup.GetPropertyValue(psMachine, vd.PrefixString, "ScsiControllerIndex");
                    if ((scsicontrolleridString != null && scsiControllerId.Equals(scsicontrolleridString)) ||
                        (scsicontrollerindexString != null && scsiControllerIndex.Equals(scsicontrollerindexString)))
                    {
                        usedScsiControllerLocationCount++;
                        string location = TestSetup.GetPropertyValue(psMachine, vd.PrefixString, "HostLunIdentifier.ScsiAddress.Lun");

                        // Verify the scsicontrollerlocation being used doesn't occur in available scsi location list
                        if (availableScsiControllerLocation != null)
                        {
                            for (int j = 0; j < availableScsiControllerLocation.Length; j++)
                            {
                                if (availableScsiControllerLocation[j].Trim() == location.Trim())
                                {
                                    log.LogError(string.Format("Available ScsiLocation {0} is actually used by disk {1}.", location, disk["HostDiskIdentifier"]));
                                    PSException pe = new PSException(string.Format("Available ScsiLocation {0} is actually used by disk {1}.", location, disk["HostDiskIdentifier"]));
                                    throw pe;
                                }
                            }
                        }
                     }
                }
                i++;
            }

        //    // Verify the sum of available scsi controller number and used scsi controller number is 64
        //    if (usedScsiControllerLocationCount + availableScsiControllerLocation.Length != 64)
        //    {
        //        log.LogError(string.Format("Incorrect available ScsiController Location. Used location number: {0}, Available location number {1}.",
        //            usedScsiControllerLocationCount, availableScsiControllerLocation.Length));
        //        PSException pe = new PSException(string.Format("Incorrect available ScsiController Location. Used location number: {0}, Available location number {1}.",
        //            usedScsiControllerLocationCount, availableScsiControllerLocation.Length));
        //        throw pe;
        //    }
        } 
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcFilebasedDiskToVirtualMachine : BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();
        private int vmIndex = 0;

        public int VMIndex
        {
            set
            {
                vmIndex = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string pathString = null;
        private string virtualmachineconfigurationString = null;
        private string locationString = null;
        private string persistenceString = null;
        private string datastoreString = null;
        private string scsicontrolleridString = null;
        private string scsicontrollerindexString = null;
        private string silentString = null;

        
        /// <summary>
        /// AddEmcFilebasedDiskToVirtualMachine
        ///     Constructor for AddEmcFilebasedDiskToVirtualMachine class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcFilebasedDiskToVirtualMachine(string path = null, string virtualmachineconfiguration = null, string location = null, string persistence = null, string datastore = null, string scsicontrollerid = null, string scsicontrollerindex = null, string silent = null,  string cmd = null)
        {

            pathString = path;
            virtualmachineconfigurationString = virtualmachineconfiguration;
            locationString = location;
            persistenceString = persistence;
            datastoreString = datastore;
            scsicontrolleridString = scsicontrollerid;
            scsicontrollerindexString = scsicontrollerindex;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcFilebasedDiskToVirtualMachine");

			if (pathString != null)
            {
		        sb.AppendFormat(" -Path {0}", "\"" + pathString + "\"");
            }
			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (locationString != null)
            {
		        sb.AppendFormat(" -Location {0}", locationString);
            }
			if (persistenceString != null)
            {
		        sb.AppendFormat(" -Persistence {0}", persistenceString);
            }
			if (datastoreString != null)
            {
		        sb.AppendFormat(" -Datastore {0}", datastoreString);
            }
			if (scsicontrolleridString != null)
            {
		        sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsicontrolleridString + "\"");
            }
			if (scsicontrollerindexString != null)
            {
		        sb.AppendFormat(" -ScsiControllerIndex {0}", scsicontrollerindexString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion
#endif  
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcFilebasedDiskToVirtualMachine commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Add-EmcFilebasedDiskToVirtualMachine</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> scsiController)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, scsiController);
            
            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, SortedList<string, string> scsiController)
        {
            string[] hypervisor = { "HyperV", "VMWare" };
            string host = HelperAdapter.GetParameter("VirtualMachine") + vmIndex;

            Thread.Sleep(3000);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter(hypervisor[vmIndex]));
            updateSystem.RunCMD(psMachine);

            updateSystem = new UpdateEmcSystem(host);
            updateSystem.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, host);
            vmConfig.PrefixString = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
            vmConfig.RunCMD(psMachine, true);

            string path = TestSetup.GetPropertyValue(psMachine, PrefixString, "Path");
            log.AreEqual<string>(pathString, path, "Verify path");

            if (scsicontrolleridString != null || scsicontrollerindexString != null)
            {
                string index = TestSetup.GetPropertyValue(psMachine, PrefixString, "ScsiControllerIndex");
                log.AreEqual<string>(scsiController["ScsiControllerIndex"], index, "Verify ScsiControllerIndex");

                string scsiControllerId = TestSetup.GetPropertyValue(psMachine, PrefixString, "HostLunIdentifier.ScsiControllerId");
                log.AreEqual<string>(scsiController["ScsiControllerId"], scsiControllerId, "Verify ScsiControllerId");
            }

            string hostLunIdentifier = TestSetup.GetPropertyValue(psMachine, PrefixString, "HostLunIdentifier");
            SortedList<string, string> hostLunIdKeyValue = HelperAdapter.GenerateKeyValuePairs(hostLunIdentifier);

            FindEmcHostDisk disk = new FindEmcHostDisk(null, null, null, null, null, null, host, PrefixString);
            string diskResult = null;
            int i = 0;
            while (true)
            {
                i++;
                try
                {
                    diskResult = disk.RunCMD(psMachine, true);
                }
                catch (PSException pe)
                {
                    if (i == 5)
                    {
                        throw pe;
                    }
                    else
                    {
                        continue;
                    }
                }
                break;
            }

            SortedList<string, string> diskKeyValue = HelperAdapter.GenerateKeyValuePairs(diskResult);

            log.AreEqual<string>("FilebasedVmDisk", diskKeyValue["DiskType"], "Verify disk type");   
        }
    }
}
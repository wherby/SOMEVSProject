using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcXenServerSystem : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private SortedList<string, string> xenServerKeyValue;

        public SortedList<string, string> XenServerKeyValue
        {
            set
            {
                xenServerKeyValue = value;
            }
        }

        #region AutoGenerate
        
        private string idString = null;
        private string silentString = null;
        private string xenserverhostsystemString = null;
        private string storagerepositoryString = null;

        
        /// <summary>
        /// GetEmcXenServerSystem
        ///     Constructor for GetEmcXenServerSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcXenServerSystem(string id = null, string silent = null, string xenserverhostsystem = null, string storagerepository = null,  string cmd = null)
        {

            idString = id;
            silentString = silent;
            xenserverhostsystemString = xenserverhostsystem;
            storagerepositoryString = storagerepository;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcXenServerSystem");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (xenserverhostsystemString != null)
            {
		        sb.AppendFormat(" -XenServerHostSystem {0}", xenserverhostsystemString);
            }
			if (storagerepositoryString != null)
            {
		        sb.AppendFormat(" -StorageRepository {0}", storagerepositoryString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcXenServerSystem commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcXenServerSystem</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> getKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            List<string> excludeKey = new List<string>();
            
            excludeKey.Add("VirtualMachinesConfigurations");
            excludeKey.Add("HostBusAdapters");
            excludeKey.Add("XenServerHosts");
            excludeKey.Add("StorageRepositories");
            excludeKey.Add("VirtualDiskImages");
            log.AreEqual<bool>(true, HelperAdapter.SortedListIsEqual(getKeyValue, xenServerKeyValue, excludeKey), "Verify all properties");
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;
using Verification;

namespace PowerShellAutomation
{

    public class ExpandEmcLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private SortedList<string, string>[] lunsKeyValue = new SortedList<string,string>[2];
        private ulong[] capacity = new ulong[2];

        public SortedList<string, string>[] LunsKeyValue
        {
            set
            {
                lunsKeyValue = value;
            }
        }

        public ulong[] Capacity
        {
            set
            {
                capacity = value;
            }
        }

        #region AutoGenerate
        
        private string lunString = null;
        private string newCapacityString = null;
        private string silentString = null;

        
        /// <summary>
        /// ExpandEmcLun
        ///     Constructor for ExpandEmcLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public ExpandEmcLun(string lun, string newCapacity, string silent,  string cmd)
        {

            lunString = lun;
            newCapacityString = newCapacity;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Expand-EmcLun");

			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (newCapacityString != null)
            {
		        sb.AppendFormat(" -NewCapacity {0}", newCapacityString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Expand-EmcLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Expand-EmcLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            if (HelperAdapter.IsVerifyStorageSide())
            {
                VerifyFieldsOnStorageSide(psMachine, result);
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);
            int lunIndex = 0;

            if (lunString == HelperAdapter.GetParameter("Lun"))
            {
                lunIndex = 0;
            }
            else
            {
                lunIndex = 1;
            }

            List<string> excludeKey = new List<string>();
            excludeKey.Add("Capacity");
            excludeKey.Add("OperationalStatus");
            excludeKey.Add("StatusMessages");

            log.AreEqual<bool>(true, HelperAdapter.SortedListIsEqual(keyValue, lunsKeyValue[lunIndex], excludeKey), "Verify properties");

            string path = HelperAdapter.GetProperty("diskVolumeConfig");
            Dictionary<string, string> dic = HelperAdapter.Load(path, "Expand");

            ulong capacityIncrease = ulong.Parse(TestSetup.GetPropertyValue(psMachine, dic["LunIncreaseBy"]));
            ulong capacityNew = ulong.Parse(TestSetup.GetPropertyValue(psMachine, newCapacityString));

            log.AreEqual<ulong>(capacity[lunIndex] + capacityIncrease, capacityNew, "Verify capacity");

        }

        private void VerifyFieldsOnStorageSide(PowershellMachine psMachine, string result)
        {
            TestSetup.VerifyLunInfo(psMachine, result);
        }

    }
}
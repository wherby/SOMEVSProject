using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class RemoveEmcHostDiskFromCluster : BaseClass
    {

#if true
        #region AutoGenerate
        
        private string clusterdiskString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;
        private string clustersystemString = null;
        private string hostlunidentifierString = null;
        private string hostdiskString = null;

        
        /// <summary>
        /// RemoveEmcHostDiskFromCluster
        ///     Constructor for RemoveEmcHostDiskFromCluster class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcHostDiskFromCluster(string clusterdisk = null, string force = null, string silent = null, string whatif = null, string clustersystem = null, string hostlunidentifier = null, string hostdisk = null,  string cmd = null)
        {

            clusterdiskString = clusterdisk;
            forceString = force;
            silentString = silent;
            whatifString = whatif;
            clustersystemString = clustersystem;
            hostlunidentifierString = hostlunidentifier;
            hostdiskString = hostdisk;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcHostDiskFromCluster");

			if (clusterdiskString != null)
            {
		        sb.AppendFormat(" -ClusterDisk {0}", clusterdiskString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }
			if (hostlunidentifierString != null)
            {
		        sb.AppendFormat(" -HostLunIdentifier {0}", hostlunidentifierString);
            }
			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion
#endif

        public string VerifyTheCMD(PowershellMachine psMachine, string resourceName)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, resourceName);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine, string resourceName)
        {
            TestLog log = TestLog.GetInstance();

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(null, null, HelperAdapter.GetParameter("Cluster"));
            updateSystem.RunCMD(psMachine);

            GetEmcClusterDisk disk = new GetEmcClusterDisk(resourceName);
            string result = disk.RunCMD(psMachine).Trim();

            if (result == string.Empty && whatifString != null || result != string.Empty && whatifString == null)
            {
                log.LogError(string.Format("Cmd error:{0}", CmdString));
                PSException pe = new PSException(string.Format("Cmd error:{0}", CmdString));
                throw pe;
            }
        }
    }
}
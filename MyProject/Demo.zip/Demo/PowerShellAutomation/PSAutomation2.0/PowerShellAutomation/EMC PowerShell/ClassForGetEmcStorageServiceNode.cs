using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;
using Verification;

namespace PowerShellAutomation
{

    public class GetEmcStorageServiceNode : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private SortedList<string, string> blockStorageKeyValue;
        private SortedList<string, string> fileStorageKeyValue;
        private SortedList<string, string> poolKeyValue;
        private SortedList<string, string> lunKeyValue;
        private SortedList<string, string> shareFolderKeyValue;
        private int storageIndex;

        public SortedList<string, string> BlockStorageKeyValue
        {
            set
            {
                blockStorageKeyValue = value;
            }
        }

        public SortedList<string, string> FileStorageKeyValue
        {
            set
            {
                fileStorageKeyValue = value;
            }
        }

        public SortedList<string, string> PoolKeyValue
        {
            set
            {
                poolKeyValue = value;
            }
        }

        public SortedList<string, string> LunKeyValue
        {
            set
            {
                lunKeyValue = value;
            }
        }

        public SortedList<string, string> ShareFolderKeyValue
        {
            set
            {
                shareFolderKeyValue = value;
            }
        }

        public int StorageIndex
        {
            set
            {
                storageIndex = value;
            }
        }

        #region AutoGenerate
        
        private string idString = null;
        private string storagesystemString = null;
        private string silentString = null;
        private string poolString = null;
        private string lunString = null;
        private string cifssharedfolderString = null;

        
        /// <summary>
        /// GetEmcStorageServiceNode
        ///     Constructor for GetEmcStorageServiceNode class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcStorageServiceNode(string id = null, string storagesystem = null, string silent = null, string pool = null, string lun = null, string cifssharedfolder = null,  string cmd = null)
        {

            idString = id;
            storagesystemString = storagesystem;
            silentString = silent;
            poolString = pool;
            lunString = lun;
            cifssharedfolderString = cifssharedfolder;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStorageServiceNode");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", "\"" + idString + "\"");
            }
			if (storagesystemString != null)
            {
		        sb.AppendFormat(" -StorageSystem {0}", storagesystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (cifssharedfolderString != null)
            {
		        sb.AppendFormat(" -CifsSharedFolder {0}", cifssharedfolderString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcStorageServiceNode commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcStorageServiceNode</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, result);

            if (HelperAdapter.IsVerifyStorageSide())
            {
                VerifyFieldsOnStorageSide(psMachine, result);
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> nodesList = HelperAdapter.GenerateKeyValuePairsList(result);
            if(poolString != null)
            {
                string[] lunServiceNodeIds = poolKeyValue["LunServiceNodeIds"].Split(new string[] { "{", "}", ",", ", " }, StringSplitOptions.RemoveEmptyEntries);
                if (idString != null)
                {
                    if (poolKeyValue["LunServiceNodeIds"].ToLower().Contains(idString.ToLower()))
                    {
                        log.AreEqual<int>(1, nodesList.Count, "Verify node count");
                    }
                    else
                    {
                        log.AreEqual<int>(0, nodesList.Count, "Verify node count");
                    }

                }
                else
                {
                    log.AreEqual<int>(lunServiceNodeIds.Length, nodesList.Count, "Verify node count");
                }

                foreach (SortedList<string, string> keyValue in nodesList)
                {
                    bool exist = false;
                    foreach (string id in lunServiceNodeIds)
                    {
                        if (id.Trim() == keyValue["ServiceNodeId"].Trim() )
                        {
                            exist = true;
                            break;
                        }
                    }
                    log.AreEqual<bool>(true, exist, "Verify get service nodes exist in storage system service nodes");
                    log.AreEqual<string>(blockStorageKeyValue["GlobalId"], keyValue["StorageSystemGlobalId"], "Verify storage system global id");
                }
            }
            else if (lunString != null)
            {
                string[] serviceNodeIds = lunKeyValue["ServiceNodeIds"].Split(new string[] { "{", "}", ",", ", " }, StringSplitOptions.RemoveEmptyEntries);
                if (idString != null)
                {
                    if (lunKeyValue["ServiceNodeIds"].ToLower().Contains(idString.ToLower()))
                    {
                        log.AreEqual<int>(1, nodesList.Count, "Verify node count");
                    }
                    else
                    {
                        log.AreEqual<int>(0, nodesList.Count, "Verify node count");
                    }
                }
                else
                {
                    log.AreEqual<int>(serviceNodeIds.Length, nodesList.Count, "Verify node count");
                }

                foreach (SortedList<string, string> keyValue in nodesList)
                {
                    bool exist = false;
                    foreach (string id in serviceNodeIds)
                    {
                        if (id == keyValue["ServiceNodeId"])
                        {
                            exist = true;
                            break;
                        }
                    }
                    log.AreEqual<bool>(true, exist, "Verify get service nodes exist in storage system service nodes");
                    log.AreEqual<string>(blockStorageKeyValue["GlobalId"], keyValue["StorageSystemGlobalId"], "Verify storage system global id");
                }
            }
            else if (cifssharedfolderString != null)
            {
                string serviceNodeAddresses = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("SharedFolder"), "ServiceNodeAddresses");
                string[] addressList = serviceNodeAddresses.Split(new string[]{"{", "}", "] ,[", "]", "["}, StringSplitOptions.RemoveEmptyEntries);

                foreach (string key in shareFolderKeyValue.Keys)
                {
                    log.LogInfo(key);
                    log.LogInfo(shareFolderKeyValue[key]);
                }
                               

                foreach (SortedList<string, string> keyValue in nodesList)
                {
                    bool exist = false;
                    foreach (string address in addressList)
                    {
                        if (address.Trim() == keyValue["Address"].Trim())
                        {
                            exist = true;
                            break;
                        }
                    }
                    log.AreEqual<bool>(true, exist, "Verify get service nodes exist in storage system service nodes");
                    log.AreEqual<string>(fileStorageKeyValue["GlobalId"], keyValue["StorageSystemGlobalId"], "Verify storage system global id");
                }
            }
        }

        private List<SortedList<string, string>> GetKeyValueList(string entryValue, string[] split1, string[] split2, string[] split3)
        {
            TestLog log = TestLog.GetInstance();
            List<SortedList<string, string>> keyValueList = new List<SortedList<string,string>>();

            string[] bigArray = entryValue.Split(split1, StringSplitOptions.RemoveEmptyEntries);

            for (int i = 0; i < bigArray.Length; i++)
            {
                SortedList<string, string> pairs = new SortedList<string,string>();

                string[] midArray = bigArray[i].Split(split2, StringSplitOptions.RemoveEmptyEntries);
                
                for (int j = 0; j < midArray.Length; j++)
                {
                    string[] smallArray = midArray[j].Split(split3, 2, StringSplitOptions.None);
                    pairs.Add(smallArray[0].Trim(), smallArray[1].Trim());
                }
                keyValueList.Add(pairs);
            }

            return keyValueList;
        }

        private void VerifyFieldsOnStorageSide(PowershellMachine psMachine, string result)
        {
            TestSetup.VerifyServiceNodeInfo(psMachine, result);
        }

    }
}
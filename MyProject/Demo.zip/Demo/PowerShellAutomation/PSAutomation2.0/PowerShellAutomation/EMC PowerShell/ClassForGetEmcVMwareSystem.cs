using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcVMwareSystem : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string idString = null;
        private string silentString = null;
        private string esxhostsystemString = null;
        private string scsilunString = null;
        private string datastoreString = null;

        
        /// <summary>
        /// GetEmcVMwareSystem
        ///     Constructor for GetEmcVMwareSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVMwareSystem(string id = null, string silent = null, string esxhostsystem = null, string scsilun = null, string datastore = null,  string cmd = null)
        {

            idString = id;
            silentString = silent;
            esxhostsystemString = esxhostsystem;
            scsilunString = scsilun;
            datastoreString = datastore;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVMwareSystem");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (esxhostsystemString != null)
            {
		        sb.AppendFormat(" -ESXHostSystem {0}", esxhostsystemString);
            }
			if (scsilunString != null)
            {
		        sb.AppendFormat(" -ScsiLun {0}", scsilunString);
            }
			if (datastoreString != null)
            {
		        sb.AppendFormat(" -Datastore {0}", datastoreString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcVMwareSystem commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="vmwareSystemGlobalId">VMware system global id</param>
        /// <param name="hostname">VMware system host name</param>
        /// <param name="username">VMware system username</param>
        /// <param name="ipAddress">VMware system ip Address</param>
        /// <param name="isVirtualCenter">whether the system is vcenter of not</param>
        /// <returns>the result of Get-EmcVMwareSystem</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string vmwareSystemGlobalId, string hostname, string username, string ipAddress,
            string isVirtualCenter)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, vmwareSystemGlobalId, hostname, username, ipAddress, isVirtualCenter);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields of Get-EmcVMwareSystem output
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="result">output result of Get-EmcVMwareSystem</param>
        /// <param name="vmwareSystemGlobalId">VMware system global id</param>
        /// <param name="hostname">VMware system host name</param>
        /// <param name="username">VMware system username</param>
        /// <param name="ipAddress">VMware system ip Address</param>
        /// <param name="isVirtualCenter">whether the system is vcenter of not</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string vmwareSystemGlobalId, string hostname, string username, string ipAddress, 
            string isVirtualCenter)
        {            
            List<SortedList<string, string>> vmwareSystems = HelperAdapter.GenerateKeyValuePairsList(result);
            SortedList<string, string> vmwareSystem = HelperAdapter.FindElementFromList(hostname, "Name", vmwareSystems);
            log.AreEqual("HostSystem", vmwareSystem["AdapterType"], "Adapter Type: ");
            log.AreEqual(isVirtualCenter.ToLower(), vmwareSystem["IsVirtualCenter"].ToLower(), "Is Virtual Center: ");
            log.AreEqual(username.ToLower(), vmwareSystem["UserName"].ToLower(), "UserName: ");
            log.AreEqual("Vim25Api.AboutInfo", vmwareSystem["AboutInfo"], "About Info: ");
            log.AreEqual(hostname, vmwareSystem["Name"], "Name: ");
            log.AreEqual(hostname, vmwareSystem["Server"], "Server: ");
            log.AreEqual(ipAddress, vmwareSystem["IpAddress"], "Ip Address: ");
            log.AreEqual(vmwareSystemGlobalId, vmwareSystem["GlobalId"], "Global Id: ");
            if (isVirtualCenter.ToLower().Equals("true"))
            {
                log.AreEqual("VMware VirtualCenter Server", vmwareSystem["Model"], "Model: ");
                if (! vmwareSystem["OsString"].Contains("VMware vCenter"))
                {
                    log.LogError(String.Format("Incorrect vCenter OS string {0}", vmwareSystem["OsString"]));
                    PSException pe = new PSException(String.Format("Incorrect vCenter OS string {0}", vmwareSystem["OsString"]));
                    throw pe;
                }
            }
            else
            {
                log.AreEqual("VMware ESX Server", vmwareSystem["Model"], "Model: ");
                if (! vmwareSystem["OsString"].Contains("VMware ESXi"))
                {
                    log.LogError(String.Format("Incorrect ESX OS string {0}", vmwareSystem["OsString"]));
                    PSException pe = new PSException(String.Format("Incorrect ESX OS string {0}", vmwareSystem["OsString"]));
                    throw pe;
                }
            }
        }
    }
}
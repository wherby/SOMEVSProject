using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;
using System.Text.RegularExpressions;

namespace PowerShellAutomation
{

    public class ExpandEmcFileBasedDisk : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private string netPath = null;
        private HyperVisorType type = HyperVisorType.HyperV;

        public string NetPath
        {
            set
            {
                netPath = value;
            }
        }

        public HyperVisorType Type
        {
            set
            {
                type = value;
            }
        }

        #region AutoGenerate

        private string virtualmachineconfigurationString = null;
        private string sizeString = null;
        private string locationString = null;
        private string scsicontrolleridString = null;
        private string scsicontrollerindexString = null;
        private string silentString = null;
        
        /// <summary>
        /// ExpandEmcFileBasedDisk
        ///     Constructor for ExpandEmcFileBasedDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public ExpandEmcFileBasedDisk(string size, string virtualmachineconfiguration, string location, string scsicontrollerid = null, string scsicontrollerindex = null, string silent = null, string cmd = null)
        {
            sizeString = size;
            virtualmachineconfigurationString = virtualmachineconfiguration;
            locationString = location;
            scsicontrolleridString = scsicontrollerid;
            scsicontrollerindexString = scsicontrollerindex;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Expand-EmcFileBasedDisk");

            if (sizeString != null)
            {
                sb.AppendFormat(" -Size {0}", sizeString);
            }
            if (virtualmachineconfigurationString != null)
            {
                sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
            if (locationString != null)
            {
                sb.AppendFormat(" -Location {0}", locationString);
            }
            if (scsicontrolleridString != null)
            {
                sb.AppendFormat(" -ScsiControllerId {0}", scsicontrolleridString);
            }
            if (scsicontrollerindexString != null)
            {
                sb.AppendFormat(" -ScsiControllerIndex {0}", scsicontrollerindexString);
            }
            if (sizeString != null)
            {
                sb.AppendFormat(" -Size {0}", sizeString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }

            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Expand-EmcFileBasedDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Expand-EmcFileBasedDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            ulong newSize = 0;

            if (type == HyperVisorType.HyperV)
            {
                newSize = TestSetup.GetVhdFileBasedDiskSize(psMachine, netPath);
            }
            else
            {
                Dictionary<string, string> dic = HelperAdapter.GetHypervisorHosts(HyperVisorType.VMWare)[0];
                newSize = TestSetup.GetVmdkFileBasedDiskSize(psMachine, netPath, dic["Password"], dic["UserName"], dic["IPAddress"]);
            }

            log.AreEqual<ulong>(ulong.Parse(sizeString), newSize, "Verify disk size");
        }
    }
}
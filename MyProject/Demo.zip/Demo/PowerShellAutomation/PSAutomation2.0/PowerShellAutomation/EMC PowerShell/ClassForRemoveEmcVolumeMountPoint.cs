using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class RemoveEmcVolumeMountPoint : BaseClass
    {
        
#if true
        #region AutoGenerate
        
        private string volumeString = null;
        private string hostsystemString = null;
        private string silentString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// RemoveEmcVolumeMountPoint
        ///     Constructor for RemoveEmcVolumeMountPoint class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcVolumeMountPoint(string volume = null, string hostsystem = null, string silent = null, string clustersystem = null,  string cmd = null)
        {

            volumeString = volume;
            hostsystemString = hostsystem;
            silentString = silent;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcVolumeMountPoint");

			if (volumeString != null)
            {
		        sb.AppendFormat(" -Volume {0}", volumeString);
            }
			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion
#endif
        

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            GetEmcHostVolume volume = new GetEmcHostVolume(volumeString + ".Label", null, hostsystemString, null, null, clustersystemString);

            string result = volume.RunCMD(psMachine, true);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.AreEqual<string>(string.Empty, keyValue["MountPath"], "Verify mount path");
        }
    }
}
using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class GetEmcClusterDisk : BaseClass
    {

#if true
        #region AutoGenerate
        
        private string idString = null;
        private string clustersystemString = null;
        private string clustergroupnameString = null;
        private string silentString = null;
        private string clustersharedvolumeString = null;

        
        /// <summary>
        /// GetEmcClusterDisk
        ///     Constructor for GetEmcClusterDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcClusterDisk(string id = null, string clustersystem = null, string clustergroupname = null, string silent = null, string clustersharedvolume = null,  string cmd = null)
        {

            idString = id;
            clustersystemString = clustersystem;
            clustergroupnameString = clustergroupname;
            silentString = silent;
            clustersharedvolumeString = clustersharedvolume;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcClusterDisk");

			if (idString != null)
            {
                sb.AppendFormat(" -ID {0}", "\"" + idString + "\"");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }
			if (clustergroupnameString != null)
            {
                sb.AppendFormat(" -ClusterGroupName {0}", "\"" + clustergroupnameString + "\"");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clustersharedvolumeString != null)
            {
		        sb.AppendFormat(" -ClusterSharedVolume");
            }


            return sb.ToString();
        }
        #endregion
#endif
        

        public string VerifyTheCMD(PowershellMachine psMachine, SortedList<string, string> diskKeyValue)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, diskKeyValue);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine, string result, SortedList<string, string> diskKeyValue)
        {
            TestLog log = TestLog.GetInstance();

            bool diskExist = false;

            List<string> exclude = new List<string>();
            exclude.Add("HostDisks");

            List<SortedList<string, string>> diskKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach (SortedList<string, string> keyValue in diskKeyValueList)
            {
                if (HelperAdapter.SortedListIsEqual(keyValue, diskKeyValue, exclude))
                {
                    diskExist = true;
                    break;
                }
            }

            log.AreEqual<bool>(true, diskExist, "Verify Disk Exists");
        }
    }
}
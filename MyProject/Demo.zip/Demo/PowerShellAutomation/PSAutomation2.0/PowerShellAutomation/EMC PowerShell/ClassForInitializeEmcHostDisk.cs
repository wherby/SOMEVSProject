using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class InitializeEmcHostDisk : BaseClass
    {
        #region AutoGenerate
        
        private string hostdiskString = null;
        private string hostsystemString = null;
        private string partitionstyleString = null;
        private string silentString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// InitializeEmcHostDisk
        ///     Constructor for InitializeEmcHostDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public InitializeEmcHostDisk(string hostdisk = null, string hostsystem = null, string partitionstyle = null, string silent = null, string clustersystem = null,  string cmd = null)
        {

            hostdiskString = hostdisk;
            hostsystemString = hostsystem;
            partitionstyleString = partitionstyle;
            silentString = silent;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Initialize-EmcHostDisk");

			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (partitionstyleString != null)
            {
		        sb.AppendFormat(" -PartitionStyle {0}", partitionstyleString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion


        public string VerifyTheCMD(PowershellMachine psMachine,string lunStringV=null,string hostDiskStringV=null,string hostSystemStringV=null
            ,string clusterStringV=null)
        {
            string result = RunCMD(psMachine, false);
            TestLog log = TestLog.GetInstance();

            GetEmcHostDisk getdisk;
            if (clustersystemString == null)
            {
                getdisk = new GetEmcHostDisk(hostdiskString + ".HostDiskIdentifier", null, hostsystemString);
            }
            else
            {
                string lunForCluster = HelperAdapter.GetParameter("LunC");
                getdisk = new GetEmcHostDisk(hostdiskString + ".HostDiskIdentifier",lunForCluster, null, null, clustersystemString);
            }
            if(lunStringV!=null)
            {
                getdisk = new GetEmcHostDisk(hostDiskStringV + ".HostDiskIdentifier", lunStringV, hostSystemStringV, null,clusterStringV);
            }
            string resultDisk = getdisk.RunCMD(psMachine, true);
            SortedList<string, string> diskKeyValue = HelperAdapter.GenerateKeyValuePairs(resultDisk);
            string isInitialized = diskKeyValue["IsInitialized"];
            log.AreEqual<string>("True", isInitialized, "The disk is initialized");

            return result;
        }
    }
}

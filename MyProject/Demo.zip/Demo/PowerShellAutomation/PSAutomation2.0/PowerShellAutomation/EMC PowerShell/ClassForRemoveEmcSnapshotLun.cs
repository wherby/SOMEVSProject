using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcSnapshotLun : BaseClass
    {        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string snapshotlunString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcSnapshotLun
        ///     Constructor for RemoveEmcSnapshotLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcSnapshotLun(string snapshotlun = null, string force = null, string silent = null, string whatif = null,  string cmd = null)
        {

            snapshotlunString = snapshotlun;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcSnapshotLun");

			if (snapshotlunString != null)
            {
		        sb.AppendFormat(" -SnapshotLun {0}", snapshotlunString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion
     
        
        /// <summary>
        /// VerifyTheCMD
        ///     Verify whethe Remove-EmcSnapshotLun succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="snapshotLunID">snapshot lun id or lun name</param>
        /// <returns>result string</returns>
        //public string VerifyTheCMD(PowershellMachine psMachine, string snapshotLunID, bool deactivate = false)
        public string VerifyTheCMD(PowershellMachine psMachine, string snapshotLunID)
        {

            string result = RunCMD(psMachine);
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("System"));
            updateSystem.RunCMD(psMachine);

            VerifyFields(psMachine, snapshotLunID);
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify snapshot lun is removed successfully
        /// </summary>     
        /// <param name="psMacine">powershell machine</param>
        /// <param name="snapshotLunID">lun name or lun id</param>
        private void VerifyFields(PowershellMachine psMachine, string snapshotLunID)
        {
            string blockStorageSystem = null;
            blockStorageSystem = HelperAdapter.GetParameter("System");
            GetEmcSnapshotLun snapshotLun = new GetEmcSnapshotLun(snapshotLunID, null, blockStorageSystem);
            string result = snapshotLun.RunCMD(psMachine);

            if (whatifString != null)
            {
                if (result.Trim() == String.Empty)
                {
                    log.LogError(string.Format("SnapshotLun should not be removed with WhatIf parameter."));
                    PSException pe = new PSException(string.Format("SnapshotLun should not be removed with WhatIf parameter."));
                    throw pe;
                }
            }
            else
            {
                if (result.Trim() != String.Empty)
                {
                    log.LogError(string.Format("Failed to remove SnapshotLun: {0}.", result));
                    PSException pe = new PSException(string.Format("Failed to remove SnapshotLun: {0}.", result));
                    throw pe;
                }
            }
        }
    }
}
using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class FindEmcHostDisk : BaseClass
    {
        #region AutoGenerate
        
        private string hostsystemString = null;
        private string hostlunidentifierString = null;
        private string rescancountString = null;
        private string silentString = null;
        private string lunString = null;
        private string clustersystemString = null;
        private string virtualmachineString = null;
        private string vmdiskconfigString = null;

        
        /// <summary>
        /// FindEmcHostDisk
        ///     Constructor for FindEmcHostDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public FindEmcHostDisk(string hostsystem = null, string hostlunidentifier = null, string rescancount = null, string silent = null, string lun = null, string clustersystem = null, string virtualmachine = null, string vmdiskconfig = null,  string cmd = null)
        {

            hostsystemString = hostsystem;
            hostlunidentifierString = hostlunidentifier;
            rescancountString = rescancount;
            silentString = silent;
            lunString = lun;
            clustersystemString = clustersystem;
            virtualmachineString = virtualmachine;
            vmdiskconfigString = vmdiskconfig;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Find-EmcHostDisk");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (hostlunidentifierString != null)
            {
		        sb.AppendFormat(" -HostLunIdentifier {0}", hostlunidentifierString);
            }
			if (rescancountString != null)
            {
		        sb.AppendFormat(" -RescanCount {0}", rescancountString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }
			if (virtualmachineString != null)
            {
		        sb.AppendFormat(" -VirtualMachine {0}", virtualmachineString);
            }
			if (vmdiskconfigString != null)
            {
		        sb.AppendFormat(" -VmDiskConfig {0}", vmdiskconfigString);
            }


            return sb.ToString();
        }
        #endregion



        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            return result;
        }
    }
}
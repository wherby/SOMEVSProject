using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class GetEmcAvailableDriveLetter : BaseClass
    {

        #region AutoGenerate
        
        private string hostsystemString = null;
        private string silentString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// GetEmcAvailableDriveLetter
        ///     Constructor for GetEmcAvailableDriveLetter class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcAvailableDriveLetter(string hostsystem = null, string silent = null, string clustersystem = null,  string cmd = null)
        {

            hostsystemString = hostsystem;
            silentString = silent;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcAvailableDriveLetter");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion


        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            return result;
        }
    }
}

using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcXenServerStorageRepository : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private int srCount = 0;
        private SortedList<string, string> srKeyValue;

        public int SRCount
        {
            set
            {
                srCount = value;
            }
        }

        public SortedList<string, string> SRKeyValue
        {
            set
            {
                srKeyValue = value;
            }
        }

        #region AutoGenerate
        
        private string idString = null;
        private string xenserverString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcXenServerStorageRepository
        ///     Constructor for GetEmcXenServerStorageRepository class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcXenServerStorageRepository(string id = null, string xenserver = null, string silent = null,  string cmd = null)
        {

            idString = id;
            xenserverString = xenserver;
            silentString = silent;

            CmdString = cmd;
        }


        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcXenServerStorageRepository");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", "\"" + idString + "\"");
            }
			if (xenserverString != null)
            {
		        sb.AppendFormat(" -XenServer {0}", xenserverString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcXenServerStorageRepository commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcXenServerStorageRepository</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> srKeyValueList = HelperAdapter.GenerateKeyValuePairsList(result);

            if (srCount == 1)
            {
                log.AreEqual<int>(srCount, srKeyValueList.Count, "Verify SR count");

                log.AreEqual<bool>(true, HelperAdapter.SortedListIsEqual(srKeyValueList[0], srKeyValue), "Verify SR content");
            }
            else
            {
                bool srExist = false;
                foreach (SortedList<string, string> sr in srKeyValueList)
                {
                    if (HelperAdapter.SortedListIsEqual(sr, srKeyValue))
                    {
                        srExist = true;
                        break;
                    }
                }
                log.AreEqual<bool>(true, srExist, "Verify SR exists");
            }
        }
    }
}
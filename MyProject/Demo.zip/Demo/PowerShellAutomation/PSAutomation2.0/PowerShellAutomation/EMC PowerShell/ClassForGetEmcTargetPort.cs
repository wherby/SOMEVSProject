using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;
using Verification;

namespace PowerShellAutomation
{

    public class GetEmcTargetPort : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        private string storageGlobalId;

        public string StorageGlobalId
        {
            set
            {
                storageGlobalId = value;
            }
        }

        #region AutoGenerate
        
        private string idString = null;
        private string blockstoragesystemString = null;
        private string silentString = null;
        private string poolString = null;
        private string lunString = null;

        
        /// <summary>
        /// GetEmcTargetPort
        ///     Constructor for GetEmcTargetPort class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcTargetPort(string id = null, string blockstoragesystem = null, string silent = null, string pool = null, string lun = null,  string cmd = null)
        {

            idString = id;
            blockstoragesystemString = blockstoragesystem;
            silentString = silent;
            poolString = pool;
            lunString = lun;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcTargetPort");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (blockstoragesystemString != null)
            {
		        sb.AppendFormat(" -BlockStorageSystem {0}", blockstoragesystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcTargetPort commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcTargetPort</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            if (HelperAdapter.IsVerifyStorageSide())
            {
                VerifyFieldsOnStorageSide(psMachine, result);
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> portList = HelperAdapter.GenerateKeyValuePairsList(result);

            foreach (SortedList<string, string> port in portList)
            {
                log.AreEqual<string>(storageGlobalId, port["StorageSystemGlobalId"], "Verify Storage System GlobalId");
            }
            
        }

        private void VerifyFieldsOnStorageSide(PowershellMachine psMachine, string result)
        {
            TestSetup.VerifyTargetPortInfo(psMachine, result);
        }

    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcStandbyLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string storagesystemString = null;
        private string idString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcStandbyLun
        ///     Constructor for GetEmcStandbyLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcStandbyLun(string storagesystem = null, string id = null, string silent = null,  string cmd=null)
        {

            storagesystemString = storagesystem;
            idString = id;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStandbyLun");

			if (storagesystemString != null)
            {
		        sb.AppendFormat(" -StorageSystem {0}", storagesystemString);
            }
			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcStandbyLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcStandbyLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> standbyLunsKeyValueParis = HelperAdapter.GenerateKeyValuePairsList(result);
            if (storagesystemString != null)
            {
                string storageSystemGlobID = TestSetup.GetPropertyValue(psMachine, storagesystemString, "GlobalId");
                foreach (SortedList<string, string> temp in standbyLunsKeyValueParis)
                {
                    log.AreEqual<string>(storageSystemGlobID, temp["StorageSystemGlobalId"], "StorageSystem Global ID");
                }
            }
            if (idString != null)
            {
                log.AreEqual<int>(1, standbyLunsKeyValueParis.Count, "There should be only one lun");
                log.AreEqual<string>(idString, standbyLunsKeyValueParis[0]["ArrayLunId"], "ArrayLunID");
            }
        }
    }
}
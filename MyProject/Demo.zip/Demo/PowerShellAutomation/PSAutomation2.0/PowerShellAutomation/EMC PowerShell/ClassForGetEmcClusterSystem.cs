using System.Collections.Generic;
using System;
using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{  

    public class GetEmcClusterSystem:BaseClass
    {
        #region CMD fields
        
        private SortedList<string, string> connectSystemKeyValue;
        #endregion

        public SortedList<string, string> ConnectSystemKeyValue
        {
            set
            {
                connectSystemKeyValue = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string idString = null;
        private string silentString = null;
        private string clusterdiskString = null;

        
        /// <summary>
        /// GetEmcClusterSystem
        ///     Constructor for GetEmcClusterSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcClusterSystem(string id = null, string silent = null, string clusterdisk = null, string cmd = null)
        {

            idString = id;
            silentString = silent;
            clusterdiskString = clusterdisk;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcClusterSystem");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clusterdiskString != null)
            {
		        sb.AppendFormat(" -ClusterDisk {0}", clusterdiskString);
            }


            return sb.ToString();
        }
        #endregion
#endif
       

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();

            string result = RunCMD(psMachine, true);

            SortedList<string, string> getSystemKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            VerifyFields(psMachine, getSystemKeyValue);

            return result;
        }

        private void VerifyFields( PowershellMachine psMachine, SortedList<string, string> getSystemKeyValue)
        {
      
            #region verification fields
            TestLog log = TestLog.GetInstance();
            //bool equalKeyValue = false;
            #endregion

            
            log.AreEqual<string>(connectSystemKeyValue["AdapterType"], getSystemKeyValue["AdapterType"], "Verify AdapterType");
            log.AreEqual<string>(connectSystemKeyValue["UserFriendlyName"], getSystemKeyValue["UserFriendlyName"], "Verify UserFriendlyName");
            log.AreEqual<string>(connectSystemKeyValue["IpAddress"], getSystemKeyValue["IpAddress"], "Verify IpAddress");
            log.AreEqual<string>(connectSystemKeyValue["Name"], getSystemKeyValue["Name"], "Verify Name");
            log.AreEqual<string>(connectSystemKeyValue["OsString"], getSystemKeyValue["OsString"], "Verify OsString");
            log.AreEqual<string>(connectSystemKeyValue["GlobalId"], getSystemKeyValue["GlobalId"], "Verify GlobalId");
               
        }

        
    }
}

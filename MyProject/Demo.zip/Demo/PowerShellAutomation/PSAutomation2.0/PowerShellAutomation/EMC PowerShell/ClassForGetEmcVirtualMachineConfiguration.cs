using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualMachineConfiguration:BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string silentString = null;
        private string virtualmachineString = null;
        private string hypervisorString = null;

        
        /// <summary>
        /// GetEmcVirtualMachineConfiguration
        ///     Constructor for GetEmcVirtualMachineConfiguration class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVirtualMachineConfiguration(string silent = null, string virtualmachine = null, string hypervisor = null,  string cmd = null)
        {

            silentString = silent;
            virtualmachineString = virtualmachine;
            hypervisorString = hypervisor;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualMachineConfiguration");

			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (virtualmachineString != null)
            {
		        sb.AppendFormat(" -VirtualMachine {0}", virtualmachineString);
            }
			if (hypervisorString != null)
            {
		        sb.AppendFormat(" -Hypervisor {0}", hypervisorString);
            }


            return sb.ToString();
        }
        #endregion

              

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualMachineConfiguration command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="hypervisorList">Hypervisor list, including hypervisorName and vmConfigurationFromHypervisor</param>
        /// <returns>Get-EmcVirtualMachineConfiguration result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, List<SortedList<string, string>> hypervisorList)
        {            
            string result = RunCMD(psMachine, true);
            VerifyFields(result, hypervisorList);       
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualMachineConfiguration
        /// </summary>
        /// <param name="result">Get-EmcVirtualMachineConfiguration result string</param>
        /// <param name="hypervisorList">Hypervisor list, including hypervisorName and vmConfigurationFromHypervisor</param>
        private void VerifyFields(string result, List<SortedList<string, string>> hypervisorList)
        {        
            
            List<SortedList<string, string>> getVmConfigurations = HelperAdapter.GenerateKeyValuePairsList(result);
            SortedList<string, string> vmConfiguration = null;
            string hypervisorName;
            List<SortedList<string, string>> vmConfigurationFromHypervisor = new List<SortedList<string,string>>();
            
            //Virtual Machine or Hypervisor is specified
            if (virtualmachineString != null || hypervisorString != null)
            {
                hypervisorName = getVmConfigurations[0]["HypervisorName"].Replace("{", "").Replace("}", "");
                SortedList<string, string> hypervisor = HelperAdapter.FindElementFromList(hypervisorName, "Name", hypervisorList);
                vmConfigurationFromHypervisor = HelperAdapter.GenerateKeyValuePairsList(hypervisor["VmConfiguration"]);

                if (virtualmachineString != null)
                {
                    vmConfiguration = HelperAdapter.FindElementFromList(getVmConfigurations[0]["Name"], "Name", vmConfigurationFromHypervisor);

                    if (vmConfiguration == null)
                    {
                        log.LogError(string.Format("Failed to find the following VM: {0}", getVmConfigurations[0]));
                        PSException pe = new PSException(string.Format("Failed to find the following VM: {0}", getVmConfigurations[0]));
                        throw pe;
                    }

                    #region verification for fields
                    HelperAdapter.AssertPropertiesComparision(getVmConfigurations[0], vmConfiguration);
                    #endregion
                }

                // Hypervisor is specified
                if (hypervisorString != null)
                {
                    HelperAdapter.VerifyTwoListsAreEqual(vmConfigurationFromHypervisor, getVmConfigurations);
                }
            }
            else
            {
                // Get all Vms under all Hypervisors
                foreach (SortedList<string, string> hyper in hypervisorList)
                {
                    log.LogInfo(hyper["VmConfiguration"]);
                    vmConfigurationFromHypervisor.AddRange(HelperAdapter.GenerateKeyValuePairsList(hyper["VmConfiguration"]));
                    
                }
                HelperAdapter.VerifyTwoListsAreEqual(vmConfigurationFromHypervisor, getVmConfigurations);
            }
        }        
    }
}

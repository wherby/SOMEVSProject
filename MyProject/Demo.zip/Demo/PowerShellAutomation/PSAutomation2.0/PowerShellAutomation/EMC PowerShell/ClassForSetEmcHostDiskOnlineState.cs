using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class SetEmcHostDiskOnlineState:BaseClass
    {
        
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string hostdiskString = null;
        private string onlineString = null;
        private string silentString = null;
        private string offlineString = null;

        
        /// <summary>
        /// SetEmcHostDiskOnlineState
        ///     Constructor for SetEmcHostDiskOnlineState class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcHostDiskOnlineState(string hostdisk = null, string online = null, string silent = null, string offline = null,  string cmd = null)
        {

            hostdiskString = hostdisk;
            onlineString = online;
            silentString = silent;
            offlineString = offline;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcHostDiskOnlineState");

			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }
			if (onlineString != null)
            {
		        sb.AppendFormat(" -Online");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (offlineString != null)
            {
		        sb.AppendFormat(" -Offline");
            }


            return sb.ToString();
        }
        #endregion
    

        /// <summary>
        /// VerifyTheCMD
        ///     Verify SetEmcHostDiskOnlineState command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <returns>SetEmcHostDiskOnlineState result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {            
            string result = RunCMD(psMachine);

            // Update Host System
            UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("Host"));
            updateSystem.RunCMD(psMachine);            

            // Get the disk again
            GetEmcHostDisk hostDisk = new GetEmcHostDisk(null, HelperAdapter.GetParameter("Lun"),HelperAdapter.GetParameter("Host"));
            hostDisk.PrefixString = HelperAdapter.GetParameter("Disk");
            result = hostDisk.RunCMD(psMachine, true);

            if (onlineString != null)
            {
                VerifyFields(result, "Online");
            }
            if (offlineString != null)
            {
                VerifyFields(result, "Offline");
            }
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of SetEmcHostDiskOnlineState
        /// </summary>
        /// <param name="result">SetEmcHostDiskOnlineState result string</param>
        /// <param name="status">The disk status</param>        
        private void VerifyFields(string result, string status)
        {            
            SortedList<string, string> getHostDiskProperties = HelperAdapter.GenerateKeyValuePairs(result);

            #region verification for fields
            log.AreEqual(status, getHostDiskProperties["Status"], "Host disk status: ");    
            #endregion
        }
    }
}
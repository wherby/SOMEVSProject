using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class SetEmcCIFSSharedFolderMountPoint : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string hostsystemString = null;
        private string driveletterString = null;
        private string sharedfolderString = null;
        private string credentialString = null;
        private string silentString = null;

        
        /// <summary>
        /// SetEmcCIFSSharedFolderMountPoint
        ///     Constructor for SetEmcCIFSSharedFolderMountPoint class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcCIFSSharedFolderMountPoint(string hostsystem = null, string driveletter = null, string sharedfolder = null, string credential = null, string silent = null,  string cmd=null)
        {

            hostsystemString = hostsystem;
            driveletterString = driveletter;
            sharedfolderString = sharedfolder;
            credentialString = credential;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcCIFSSharedFolderMountPoint");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (driveletterString != null)
            {
		        sb.AppendFormat(" -DriveLetter {0}", driveletterString);
            }
			if (sharedfolderString != null)
            {
		        sb.AppendFormat(" -SharedFolder {0}", sharedfolderString);
            }
			if (credentialString != null)
            {
		        sb.AppendFormat(" -Credential {0}", credentialString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Set-EmcCIFSSharedFolderMountPoint commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Set-EmcCIFSSharedFolderMountPoint</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> volumeInfor = HelperAdapter.GenerateKeyValuePairs(result);
            if (driveletterString != null)
            {
                bool isDriveLetterSet = volumeInfor["LocalPath"].IndexOf(driveletterString) >= 0;
                log.AreEqual<bool>(true, isDriveLetterSet, "The DriveLetter Setted");
            }
            if (sharedfolderString != null)
            {
                string sharedFolderPath = TestSetup.GetPropertyValue(psMachine, sharedfolderString, "SharedFolderPath");
                bool isSharedFolderSet = volumeInfor["RemotePath"].IndexOf(sharedFolderPath) >= 0;
                log.AreEqual<bool>(true, isSharedFolderSet, "Shared Folder Mounted");
            }
            log.AreEqual<string>("Connected", volumeInfor["Status"], "Volume is connected");
        }
    }
}
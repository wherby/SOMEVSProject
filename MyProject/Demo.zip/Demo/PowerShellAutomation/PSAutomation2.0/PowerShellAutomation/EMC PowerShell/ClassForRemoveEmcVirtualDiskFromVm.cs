using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;
using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class RemoveEmcVirtualDiskFromVm:BaseClass
    {
        private TestLog log = TestLog.GetInstance();
       

        private SortedList<string, string> diskConfig;
        private int vmIndex;

        public SortedList<string, string> DiskConfig
        {
            set
            {
                diskConfig = value;
            }
        }

        public int VMIndex
        {
            set
            {
                vmIndex = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string virtualmachineconfigurationString = null;
        private string locationString = null;
        private string forceString = null;
        private string scsicontrolleridString = null;
        private string scsicontrollerindexString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcVirtualDiskFromVm
        ///     Constructor for RemoveEmcVirtualDiskFromVm class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcVirtualDiskFromVm(string virtualmachineconfiguration = null, string location = null, string force = null, string scsicontrollerid = null, string scsicontrollerindex = null, string silent = null, string whatif = null,  string cmd = null)
        {

            virtualmachineconfigurationString = virtualmachineconfiguration;
            locationString = location;
            forceString = force;
            scsicontrolleridString = scsicontrollerid;
            scsicontrollerindexString = scsicontrollerindex;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcVirtualDiskFromVm");

			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (locationString != null)
            {
		        sb.AppendFormat(" -Location {0}", locationString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (scsicontrolleridString != null)
            {
		        sb.AppendFormat(" -ScsiControllerId {0}", "\"" + scsicontrolleridString + "\"");
            }
			if (scsicontrollerindexString != null)
            {
		        sb.AppendFormat(" -ScsiControllerIndex {0}", scsicontrollerindexString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion
#endif
               

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Remove-EmcVirtualDiskFromVm command executed successfully 
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        public void VerifyTheCMD(PowershellMachine psMachine)
        {
            RunCMD(psMachine);

            VerifyFields(psMachine);
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Remove-EmcVirtualDiskFromVm
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        private void VerifyFields(PowershellMachine psMachine)
        {
            string[] hyperVisors = { "HyperV", "VMWare"};
            string vm = HelperAdapter.GetParameter("VirtualMachine") + vmIndex;
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;

            //UpdateEmcSystem updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter( hyperVisors[vmIndex]));
            //updateSystem.RunCMD(psMachine);

            //updateSystem = new UpdateEmcSystem(vm);
            //updateSystem.RunCMD(psMachine);

            GetEmcVirtualMachineConfiguration getVMConfig = new GetEmcVirtualMachineConfiguration(null, vm);
            getVMConfig.PrefixString = vmConfig;
            getVMConfig.RunCMD(psMachine, true);            

            GetEmcAvailableScsiControllerLocation getLocations = null;
            if (scsicontrolleridString == null && scsicontrollerindexString == null)
            {
                getLocations = new GetEmcAvailableScsiControllerLocation(vmConfig, "0");
            }
            else if (scsicontrollerindexString != null)
            {
                getLocations = new GetEmcAvailableScsiControllerLocation(vmConfig, scsicontrollerindexString);
            }
            else
            {
                getLocations = new GetEmcAvailableScsiControllerLocation(vmConfig, null, null, scsicontrolleridString);
            }
            string scsiLocations = getLocations.RunCMD(psMachine);
            SortedList<string, string> locations = HelperAdapter.GenerateKeyValuePairs(scsiLocations);

            if(whatifString == null)
            {
                log.AreEqual<bool>(true, locations.ContainsKey(locationString), "Verify location is released");
            }
            else
            {
                log.AreEqual<bool>(false, locations.ContainsKey(locationString), "Verify location is still occupied");
            }

        }
    }
}
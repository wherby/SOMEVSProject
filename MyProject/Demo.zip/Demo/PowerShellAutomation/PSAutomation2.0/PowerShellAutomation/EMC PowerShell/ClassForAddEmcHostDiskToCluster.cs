using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class AddEmcHostDiskToCluster : BaseClass
    {

#if true
        #region AutoGenerate
        
        private string hostlunidentifierString = null;
        private string clustersystemString = null;
        private string clustergroupnameString = null;
        private string silentString = null;
        private string addtoclustersharedvolumeString = null;
        private string hostdiskString = null;

        
        /// <summary>
        /// AddEmcHostDiskToCluster
        ///     Constructor for AddEmcHostDiskToCluster class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcHostDiskToCluster(string hostlunidentifier = null, string clustersystem = null, string clustergroupname = null, string silent = null, string addtoclustersharedvolume = null, string hostdisk = null,  string cmd = null)
        {

            hostlunidentifierString = hostlunidentifier;
            clustersystemString = clustersystem;
            clustergroupnameString = clustergroupname;
            silentString = silent;
            addtoclustersharedvolumeString = addtoclustersharedvolume;
            hostdiskString = hostdisk;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcHostDiskToCluster");

			if (hostlunidentifierString != null)
            {
		        sb.AppendFormat(" -HostLunIdentifier {0}", hostlunidentifierString);
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }
			if (clustergroupnameString != null)
            {
		        sb.AppendFormat(" -ClusterGroupName {0}", "\"" + clustergroupnameString + "\"");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (addtoclustersharedvolumeString != null)
            {
		        sb.AppendFormat(" -AddToClusterSharedVolume");
            }
			if (hostdiskString != null)
            {
		        sb.AppendFormat(" -HostDisk {0}", hostdiskString);
            }


            return sb.ToString();
        }
        #endregion

#endif

        public string VerifyTheCMD(PowershellMachine psMachine, string clusterGlobalId)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, clusterGlobalId);

            return result;
       }

        private void VerifyFields(PowershellMachine psMachine, string result, string clusterGlobalId)
        {
            TestLog log = TestLog.GetInstance();
            string groupName = string.Empty;
            string isSharedVolume = "False";
            string ownerNodeName = null;

            SortedList<string, string> clusterDiskKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            log.AreEqual<string>(clusterGlobalId, clusterDiskKeyValue["ClusterSystemGlobalId"], "Verify Cluster System Global Id");

            if (addtoclustersharedvolumeString == null)
            {
                if (clustergroupnameString != null)
                {
                    groupName = clustergroupnameString;
                }
                else
                {
                    groupName = "Available Storage";
                }

                GetEmcClusterGroup getGroup = new GetEmcClusterGroup(HelperAdapter.GetParameter("Cluster"));
                string groupResult = getGroup.RunCMD(psMachine, true);
                List<SortedList<string, string>> groupList = HelperAdapter.GenerateKeyValuePairsList(groupResult);
                foreach (SortedList<string, string> group in groupList)
                {
                    if (group["Name"] == groupName)
                    {
                        ownerNodeName = group["CurrentOwnerNodeName"];
                        break;
                    }
                }
                log.AreEqual<string>(ownerNodeName, clusterDiskKeyValue["CurrentOwnerNodeName"], "Verify Current Owner Node Name");
            }
            log.AreEqual<string>(groupName, clusterDiskKeyValue["ClusterGroupName"], "Verify Cluster Group Name");

            if (addtoclustersharedvolumeString != null)
            {
                isSharedVolume = "True";
            }
            log.AreEqual<string>(isSharedVolume, clusterDiskKeyValue["IsClusterSharedVolume"], "Verify Cluster Shared Volume");

            
        }
    }
}
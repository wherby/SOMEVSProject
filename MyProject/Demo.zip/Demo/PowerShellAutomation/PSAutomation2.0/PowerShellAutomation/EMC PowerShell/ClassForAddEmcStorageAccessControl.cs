using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcStorageAccessControl : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string accesscontrolString = null;
        private string poolString = null;
        private string viewonlyString = null;
        private string silentString = null;
        private string fullcontrolString = null;

        
        /// <summary>
        /// AddEmcStorageAccessControl
        ///     Constructor for AddEmcStorageAccessControl class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcStorageAccessControl(string accesscontrol, string pool, string viewonly = null, string silent = null, 
            string fullcontrol = null,  string cmd = null)
        {

            accesscontrolString = accesscontrol;
            poolString = pool;
            viewonlyString = viewonly;
            silentString = silent;
            fullcontrolString = fullcontrol;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcStorageAccessControl");

			if (accesscontrolString != null)
            {
		        sb.AppendFormat(" -AccessControl {0}", accesscontrolString);
            }
			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (viewonlyString != null)
            {
		        sb.AppendFormat(" -ViewOnly");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (fullcontrolString != null)
            {
		        sb.AppendFormat(" -FullControl");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcStorageAccessControl commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="storageGlobalID">Storage Global ID</param>
        /// <param name="poolName">Pool Name</param>
        /// <returns>the result of Add-EmcStorageAccessControl</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string storageGlobalID, string poolName)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, storageGlobalID, poolName);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify Add-EmcStorageAccessControl
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="result">the result string of Add-EmcStorageAccessControl</param>
        /// <param name="storageGlobalID">Storage Global ID</param>
        /// <param name="poolName">Pool Name</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string storageGlobalID, string poolName)
        {           
            string controlValue = HelperAdapter.GetPoolAccessControlValue(result, storageGlobalID, poolName);
            if (controlValue == null)
            {
                log.LogError(String.Format("Access control for pool {0} is not added: {1}", poolName, result));
                PSException pe = new PSException(String.Format("Access control for pool {0} is not added {0}: {1}", poolName, result));
                throw pe;
            }
            if (viewonlyString != null)
            {
                if (!controlValue.Equals("View Only"))
                {
                    log.LogError(String.Format("Incorrect access control for pool {0}: {1}", poolName, controlValue));
                    PSException pe = new PSException(String.Format("Incorrect access control for pool {0}: {1}", poolName, controlValue));
                    throw pe;
                }
            }
            else
            {
                if (!controlValue.Equals("Full Control"))
                {
                    log.LogError(String.Format("Incorrect access control for pool {0}: {1}", poolName, controlValue));
                    PSException pe = new PSException(String.Format("Incorrect access control for pool {0}: {1}", poolName, controlValue));
                    throw pe;
                }
            }
        }
    }
}
using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
namespace PowerShellAutomation
{

    public class SetEmcVolumeMountPoint : BaseClass
    {
        #region CMD fields
        private SortedList<string, string> volumeInfo = null;
        #endregion

        public SortedList<string, string> VolumeInfo
        {
            get
            {
                return volumeInfo;
            }
            set
            {
                volumeInfo = value;
            }
        }

#if true
        #region AutoGenerate
        
        private string hostsystemString = null;
        private string driveletterString = null;
        private string volumeString = null;
        private string silentString = null;
        private string mountpathString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// SetEmcVolumeMountPoint
        ///     Constructor for SetEmcVolumeMountPoint class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcVolumeMountPoint(string hostsystem = null, string driveletter = null, string volume = null, string silent = null, string mountpath = null, string clustersystem = null,  string cmd = null)
        {

            hostsystemString = hostsystem;
            driveletterString = driveletter;
            volumeString = volume;
            silentString = silent;
            mountpathString = mountpath;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcVolumeMountPoint");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (driveletterString != null)
            {
		        sb.AppendFormat(" -DriveLetter {0}", driveletterString);
            }
			if (volumeString != null)
            {
		        sb.AppendFormat(" -Volume {0}", volumeString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (mountpathString != null)
            {
		        sb.AppendFormat(" -MountPath {0}", mountpathString);
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion
#endif
        

        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine)
        {
            string mountPath = null;
            TestLog log = TestLog.GetInstance();
            
            GetEmcHostVolume volume = new GetEmcHostVolume(volumeString + ".Label", null, hostsystemString, null, null, clustersystemString);

            string result = volume.RunCMD(psMachine, true);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

            if (driveletterString != null)
            {
                mountPath = driveletterString + @":\";
            }
            else
            {
                if (mountpathString.Length == 1)
                {
                    mountPath = mountpathString + @":\";
                }
                else
                {
                    mountPath = mountpathString + @"\";
                }                
            }

            log.AreEqual<string>(mountPath.ToLower(), keyValue["MountPath"].ToLower(), "Verify mount path");

            HelperAdapter.SortedListIsEqual(keyValue, volumeInfo, new List<string> { "MountPath"});
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcXenServerVirtualDiskImage : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        private SortedList<string, string> virtualDiskKeyValue;
        private int count;

        public SortedList<string, string> VirtualDiskKeyValue
        {
            set
            {
                virtualDiskKeyValue = value;
            }
        }

        public int Count
        {
            set
            {
                count = value;
            }
        }

        #region AutoGenerate
        
        private string idString = null;
        private string xenserverString = null;
        private string silentString = null;
        private string storagerepositoryString = null;

        
        /// <summary>
        /// GetEmcXenServerVirtualDiskImage
        ///     Constructor for GetEmcXenServerVirtualDiskImage class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcXenServerVirtualDiskImage(string id = null, string xenserver = null, string silent = null, string storagerepository = null,  string cmd = null)
        {

            idString = id;
            xenserverString = xenserver;
            silentString = silent;
            storagerepositoryString = storagerepository;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();

            sb.Append("Get-EmcXenServerVirtualDiskImage");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (xenserverString != null)
            {
		        sb.AppendFormat(" -XenServer {0}", xenserverString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (storagerepositoryString != null)
            {
		        sb.AppendFormat(" -StorageRepository {0}", storagerepositoryString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcXenServerVirtualDiskImage commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcXenServerVirtualDiskImage</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(result);
            if (count == 1)
            {
                log.AreEqual<int>(count, disksList.Count, "Verify virtual disk count");
                log.AreEqual<bool>(true, HelperAdapter.SortedListIsEqual(disksList[0], virtualDiskKeyValue), "Verify virtual disk properties");
            }
            else
            {
                bool diskExist = false;
                foreach (SortedList<string, string> disk in disksList)
                {
                    if (HelperAdapter.SortedListIsEqual(disk, virtualDiskKeyValue))
                    {
                        diskExist = true;
                        break;
                    }
                }
                log.AreEqual<bool>(true, diskExist, "Verify disk exists in list");
            }
        }
    }
}
using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcAvailablePassthroughDiskCandidate:BaseClass
    {
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string hypervisorString = null;
        private string silentString = null;
        private string esxhostsystemString = null;

        
        /// <summary>
        /// GetEmcAvailablePassthroughDiskCandidate
        ///     Constructor for GetEmcAvailablePassthroughDiskCandidate class
        /// </summary>
        /// <param name="hypervisor"> hypervisor object string</param>
        /// <param name="silent"> silent switch</param>
        /// <param name="esxhostsystem">esx host object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcAvailablePassthroughDiskCandidate(string hypervisor = null, string silent = null, string esxhostsystem = null,  string cmd = null)
        {

            hypervisorString = hypervisor;
            silentString = silent;
            esxhostsystemString = esxhostsystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcAvailablePassthroughDiskCandidate");

			if (hypervisorString != null)
            {
		        sb.AppendFormat(" -Hypervisor {0}", hypervisorString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (esxhostsystemString != null)
            {
		        sb.AppendFormat(" -EsxHostSystem {0}", esxhostsystemString);
            }


            return sb.ToString();
        }
        #endregion

            

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcAvailablePassthroughDiskCandidate command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <param name="hypervDiskResult">Newly added Hyperv Passthrough disk output string</param>
        /// <param name="vmwareDiskResult">Newly added VMware Passthrough disk output string<</param>
        /// <returns>Get-EmcAvailablePassthroughDiskCandidate result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hypervDiskResult, string vmwareDiskResult)
        {
                    

            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, hypervDiskResult, vmwareDiskResult);            

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcAvailablePassthroughDiskCandidate
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="result">Get-EmcAvailablePassthroughDiskCandidate result string</param>
        /// <param name="hypervDiskResult">Newly added Hyperv Passthrough disk output string</param>
        /// <param name="vmwareDiskResult">Newly added VMware Passthrough disk output string<</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string hypervDiskResult, string vmwareDiskResult)
        {
           
            string expectResult = String.Empty;
            SortedList<string, string> disk = null; 

            List<SortedList<string, string>> availableDisks = HelperAdapter.GenerateKeyValuePairsList(result);


            if (hypervisorString != null && hypervisorString.Contains("hyperv"))
            {
                expectResult = TestSetup.GetPropertyValue(psMachine, hypervisorString, "AvailablePassthroughDiskCandidates");
                disk = HelperAdapter.GenerateKeyValuePairs(hypervDiskResult);
            }
            if (hypervisorString != null && hypervisorString.Contains("vmware"))
            {
                expectResult = TestSetup.GetPropertyValue(psMachine, hypervisorString, "AvailablePassthroughDiskCandidates");
                disk = HelperAdapter.GenerateKeyValuePairs(vmwareDiskResult);
            }
            if (esxhostsystemString != null )
            {
                expectResult = TestSetup.GetPropertyValue(psMachine, esxhostsystemString, "AvailablePassthroughDiskCandidates");
                disk = HelperAdapter.GenerateKeyValuePairs(vmwareDiskResult);
            }

            List<SortedList<string, string>> expectedAvailableDisks = HelperAdapter.GenerateKeyValuePairsList(expectResult);
            log.AreEqual(expectedAvailableDisks.Count, availableDisks.Count, "The number of EmcAvailablePassthroughDisks: ");

            HelperAdapter.VerifyTwoListsAreEqual(expectedAvailableDisks, availableDisks, "HostLunIdentifier");
            SortedList<string, string> getAvailableDisk = HelperAdapter.FindElementFromList(disk["HostLunIdentifier"], "HostLunIdentifier", availableDisks);

            if (getAvailableDisk == null)
            {
                log.LogError(string.Format("Failed to find available disk candidate: {0}", disk));
                PSException pe = new PSException(string.Format("Failed to find available disk candidate: {0}", disk));
                throw pe;
            }
            HelperAdapter.AssertPropertiesComparision(getAvailableDisk, disk);            
                
        }        
        
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcCIFSSharedFolder : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string sharedfolderString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcCIFSSharedFolder
        ///     Constructor for RemoveEmcCIFSSharedFolder class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcCIFSSharedFolder(string sharedfolder = null, string force = null, string silent = null, string whatif = null,  string cmd=null)
        {

            sharedfolderString = sharedfolder;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcCIFSSharedFolder");

			if (sharedfolderString != null)
            {
		        sb.AppendFormat(" -SharedFolder {0}", sharedfolderString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcCIFSSharedFolder commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcCIFSSharedFolder</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            if (whatifString == null)
            {
                string folderName = TestSetup.GetPropertyValue(psMachine, sharedfolderString,"Name");
                GetEmcSharedFolder getFolder = new GetEmcSharedFolder(folderName);
                string folderResult = getFolder.RunCMD(psMachine);
                log.AreEqual<string>(string.Empty, folderResult.Trim(), "Folder is removed");
            }        
        }
    }
}
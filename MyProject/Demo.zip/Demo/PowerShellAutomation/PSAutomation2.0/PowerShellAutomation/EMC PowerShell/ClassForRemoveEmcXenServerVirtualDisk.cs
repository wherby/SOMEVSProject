using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcXenServerVirtualDisk : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string virtualmachineconfigurationString = null;
        private string locationString = null;
        private string silentString = null;
        private SortedList<string, string> diskKeyValue = null;

        public SortedList<string, string> DiskKeyValue
        {
            set
            {
                diskKeyValue = value;
            }
        }

        
        /// <summary>
        /// RemoveEmcXenServerVirtualDisk
        ///     Constructor for RemoveEmcXenServerVirtualDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcXenServerVirtualDisk(string virtualmachineconfiguration, string location, string silent = null,  string cmd = null)
        {

            virtualmachineconfigurationString = virtualmachineconfiguration;
            locationString = location;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcXenServerVirtualDisk");

			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (locationString != null)
            {
		        sb.AppendFormat(" -Location {0}", locationString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcXenServerVirtualDisk commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcXenServerVirtualDisk</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string xenServer = HelperAdapter.GetParameter("XenServer");
            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration");
            string disks = null;

            UpdateEmcSystem updateXenServer = new UpdateEmcSystem(xenServer);
            updateXenServer.RunCMD(psMachine);

            TestSetup.GetPropertyValue(psMachine, vmConfig + "=" + xenServer + ".VirtualMachinesConfigurations[1]");
            disks = TestSetup.GetPropertyValue(psMachine, vmConfig, "VmDisksConfigs");

            if (!string.IsNullOrEmpty(disks))
            {
                List<SortedList<string, string>> disksList = HelperAdapter.GenerateKeyValuePairsList(disks);
                foreach (SortedList<string, string> disk in disksList)
                {
                    log.AreEqual<bool>(false, HelperAdapter.SortedListIsEqual(disk, diskKeyValue), "Verify disk key values are not equal");
                }
            }

        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Text.RegularExpressions;

using PowerShellTestTools;

namespace PowerShellAutomation
{  
    
    public class GetEmcVirtualMachineScsiController:BaseClass
    {
        private TestLog log = TestLog.GetInstance();


        #region AutoGenerate
        
        private string virtualmachineconfigurationString = null;
        private string silentString = null;
        private string virtualmachineString = null;

        
        /// <summary>
        /// GetEmcVirtualMachineScsiController
        ///     Constructor for GetEmcVirtualMachineScsiController class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVirtualMachineScsiController(string virtualmachineconfiguration = null, string silent = null, string virtualmachine = null,  string cmd = null)
        {

            virtualmachineconfigurationString = virtualmachineconfiguration;
            silentString = silent;
            virtualmachineString = virtualmachine;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVirtualMachineScsiController");

			if (virtualmachineconfigurationString != null)
            {
		        sb.AppendFormat(" -VirtualMachineConfiguration {0}", virtualmachineconfigurationString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (virtualmachineString != null)
            {
		        sb.AppendFormat(" -VirtualMachine {0}", virtualmachineString);
            }


            return sb.ToString();
        }
        #endregion
     

        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcVirtualMachineScsiController command executed successfully 
        /// </summary>
        /// <param name="psMachine">The powershell machine instance</param>
        /// <returns>Get-EmcVirtualMachineScsiController result string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hypervConfigPrefix, string vmwareConfigPrefix)
        {
            PrefixString = HelperAdapter.GetParameter("ScsiController");           

            string result = RunCMD(psMachine, true);            
            
            string ret = TestSetup.GetPropertyValue(psMachine, PrefixString, "count");
            if (ret.Trim() == string.Empty)
            {
                // ScsiController object is not an array, mean there's only 1 scsi controller in the vm                
                string vmName = TestSetup.GetPropertyValue(psMachine, PrefixString, "VmName");
                string scsiControllerId = TestSetup.GetPropertyValue(psMachine, PrefixString, "ScsiControllerId");

                VerifyFields(psMachine, vmName, scsiControllerId, hypervConfigPrefix, vmwareConfigPrefix); 
            }
            else
            {
                // multiple scsi controllers
                int count = int.Parse(ret);
                for (int i = 0; i < count; i++)
                {
                    string vmName = TestSetup.GetPropertyValue(psMachine, PrefixString + "[" + i.ToString() + "]", "VmName");
                    string scsiControllerId = TestSetup.GetPropertyValue(psMachine, PrefixString + "[" + i.ToString() + "]", "ScsiControllerId");

                    VerifyFields(psMachine, vmName, scsiControllerId, hypervConfigPrefix, vmwareConfigPrefix);
                }
            }
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     verify the fields of Get-EmcVirtualMachineScsiController
        /// </summary>
        /// <param name="vmName">Virtual Machine Name</param>
        /// <param name="scsiControllerId">Scsi Controller Id</param>    
        private void VerifyFields(PowershellMachine psMachine, string vmName, string scsiControllerId, string hypervConfigPrefix, string vmwareConfigPrefix)
        {
            string vmConfigPrefix = null;

            if (virtualmachineconfigurationString == null)
            {

                if (virtualmachineString.Contains("hyperv"))
                {
                    vmConfigPrefix = hypervConfigPrefix;
                }
                if (virtualmachineString.Contains("vmware"))
                {
                    vmConfigPrefix = vmwareConfigPrefix;
                }
            }
            else
            {
                vmConfigPrefix = virtualmachineconfigurationString;
            }
  
            string expectedVMName = TestSetup.GetPropertyValue(psMachine, vmConfigPrefix, "Name");
            string scsiControllersIds = TestSetup.GetPropertyValue(psMachine, vmConfigPrefix, "ScsiControllersIds");

            #region verification for fields
            log.AreEqual(expectedVMName, vmName, "The name of the Virtual Machine: ");
            if (!scsiControllersIds.Contains(scsiControllerId))
            {
                log.LogError(string.Format("ScsiControllerId {0} doesn't exist in Virtual Machine Configuration.", scsiControllerId));
                PSException pe = new PSException(string.Format("ScsiControllerId {0} doesn't exist in Virtual Machine Configuration.", scsiControllerId));
                throw pe;
            }
            #endregion
        }
    }
}
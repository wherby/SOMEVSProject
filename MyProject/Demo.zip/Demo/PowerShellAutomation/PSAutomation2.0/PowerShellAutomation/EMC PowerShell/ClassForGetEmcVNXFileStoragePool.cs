using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcVNXFileStoragePool : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string idString = null;
        private string storagesystemString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcVNXFileStoragePool
        ///     Constructor for GetEmcVNXFileStoragePool class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcVNXFileStoragePool(string id = null, string storagesystem = null, string silent = null,  string cmd=null)
        {

            idString = id;
            storagesystemString = storagesystem;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcVNXFileStoragePool");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (storagesystemString != null)
            {
		        sb.AppendFormat(" -StorageSystem {0}", storagesystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcVNXFileStoragePool commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcVNXFileStoragePool</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string storageSystemString = TestSetup.GetParameterValue(psMachine, "System");
            SortedList<string, string> storageSystemKeyValue = HelperAdapter.GenerateKeyValuePairs(storageSystemString);
            string[] resultEntities= result.Trim().Split(new string[] { "\r\n\r\n" }, System.StringSplitOptions.RemoveEmptyEntries);
            foreach(string temp in resultEntities)
            {
                SortedList<string ,string> filepoolKeyValue=HelperAdapter.GenerateKeyValuePairs(temp);
                log.AreEqual<string>(storageSystemKeyValue["GlobalId"], filepoolKeyValue["StorageSystemGlobalId"],"Storage System Id"); 
            }
        }
    }
}
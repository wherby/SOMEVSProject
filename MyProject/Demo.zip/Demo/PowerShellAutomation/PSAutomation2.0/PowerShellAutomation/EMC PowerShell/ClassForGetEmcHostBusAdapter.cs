using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcHostBusAdapter : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string hostsystemString = null;
        private string silentString = null;
        private string clustersystemString = null;

        
        /// <summary>
        /// GetEmcHostBusAdapter
        ///     Constructor for GetEmcHostBusAdapter class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcHostBusAdapter(string hostsystem=null, string silent=null, string clustersystem=null,  string cmd=null)
        {

            hostsystemString = hostsystem;
            silentString = silent;
            clustersystemString = clustersystem;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcHostBusAdapter");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcHostBusAdapter commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcHostBusAdapter</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> hostBusAdapterKeyValuePairs = HelperAdapter.GenerateKeyValuePairsList(result);
            if(hostsystemString!=null)
            {
                log.AreEqual<int>(1, hostBusAdapterKeyValuePairs.Count, "There is one HBA for host");
                string ipAdress=TestSetup.GetPropertyValue(psMachine,hostsystemString,"IpAddress");
                log.AreEqual<string>(ipAdress, hostBusAdapterKeyValuePairs[0]["HostIpAddress"], "Host ip adress");
                string userFriendlyName = TestSetup.GetPropertyValue(psMachine, hostsystemString, "UserFriendlyName").ToLower();
                string iqnString = string.Format("iqn.1991-05.com.microsoft:{0}", userFriendlyName);
                log.AreEqual<string>(iqnString, hostBusAdapterKeyValuePairs[0]["Iqn"], "Iqn string");
                log.AreEqual<string>(iqnString, hostBusAdapterKeyValuePairs[0]["GlobalId"], "GlobalId string");
            }
            if (clustersystemString != null)
            {
                log.AreEqual<bool>(true, hostBusAdapterKeyValuePairs.Count > 1, "The cluster HBA count is more than one");
                string clusterName = TestSetup.GetPropertyValue(psMachine, clustersystemString, "Name");
                foreach (SortedList<string, string> temp in hostBusAdapterKeyValuePairs)
                {
                    log.AreEqual<string>(clusterName, temp["ClusterName"], "Cluster Name");
                }
            }
        }
    }
}
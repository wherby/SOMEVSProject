using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcLun : BaseClass
    {

        #region AutoGenerate
        
        private string poolString = null;
        private string capacityString = null;
        private string nameString = null;
        private string applicationhintString = null;
        private string thinString = null;
        private string descriptionString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcLun
        ///     Constructor for NewEmcLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcLun(string pool = null, string capacity = null, string name = null, string applicationhint = null, string thin = null, string description = null, string silent = null,  string cmd = null)
        {

            poolString = pool;
            capacityString = capacity;
            nameString = name;
            applicationhintString = applicationhint;
            thinString = thin;
            descriptionString = description;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcLun");

			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (capacityString != null)
            {
		        sb.AppendFormat(" -Capacity {0}", capacityString);
            }
			if (nameString != null)
            {
		        sb.AppendFormat(" -Name {0}", nameString);
            }
			if (applicationhintString != null)
            {
		        sb.AppendFormat(" -ApplicationHint {0}", applicationhintString);
            }
			if (thinString != null)
            {
		        sb.AppendFormat(" -Thin");
            }
			if (descriptionString != null)
            {
		        sb.AppendFormat(" -Description {0}", descriptionString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion



        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine,true);

            
            SortedList<string, string> newLunKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            GetEmcLun getLun = new GetEmcLun(newLunKeyValue["Wwn"]);
            string resultForVerification = getLun.RunCMD(psMachine);
            SortedList<string, string> getLunKeyValue = HelperAdapter.GenerateKeyValuePairs(resultForVerification);

            VerifyFields(getLunKeyValue,psMachine);
            return result;
        }


        private void VerifyFields(SortedList<string, string> getLunKeyValue, PowershellMachine psMachine)
        {
            #region verification for fields
            TestLog log = TestLog.GetInstance();
            if (poolString != null)
            {
                string poolInfo=psMachine.RunScript(new List<string>{poolString},new List<PSParam>{}).OutStr;
                SortedList<string, string> poolInforKeyValue = HelperAdapter.GenerateKeyValuePairs(poolInfo);
                string poolID = poolInforKeyValue["ArrayPoolId"];
                log.AreEqual<string>(poolID, getLunKeyValue["ArrayPoolId"], "Verify Pool ID");
            }
            if (nameString != null)
            {
                log.AreEqual<string>(nameString, getLunKeyValue["Name"], "Verify Name property");
            }
            if (capacityString != null)
            {
                ulong capInput = ulong.Parse(TestSetup.GetPropertyValue(psMachine, capacityString));
                string capacityGet = TestSetup.GetPropertyValue(psMachine, getLunKeyValue["Capacity"].Replace(" ", ""));
                ulong capGet = ulong.Parse(capacityGet);
                
                log.AreEqual<ulong>(capInput, capGet, "Verify capacity property");
            }
            if (thinString != null)
            {
                string expectValue = "Thin";
                log.AreEqual<string>(expectValue, getLunKeyValue["ProvisioningType"], "Verify provision type property");
            }
            else
            {
                string expectValue = "Thick";
                log.AreEqual<string>(expectValue, getLunKeyValue["ProvisioningType"], "Verify provision type property");
            }
            #endregion
        }
    }
}
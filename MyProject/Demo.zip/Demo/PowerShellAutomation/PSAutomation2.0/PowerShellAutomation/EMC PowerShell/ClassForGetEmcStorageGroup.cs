using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;


namespace PowerShellAutomation
{
    public class GetEmcStorageGroup:BaseClass
    {
        
        #region AutoGenerate
        
        private string storagesystemString = null;
        private string initiatoridString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcStorageGroup
        ///     Constructor for GetEmcStorageGroup class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcStorageGroup(string storagesystem = null, string initiatorid = null, string silent = null,  string cmd = null)
        {

            storagesystemString = storagesystem;
            initiatoridString = initiatorid;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcStorageGroup");

			if (storagesystemString != null)
            {
		        sb.AppendFormat(" -StorageSystem {0}", storagesystemString);
            }
			if (initiatoridString != null)
            {
		        sb.AppendFormat(" -InitiatorId {0}", initiatoridString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion


        /// <summary>
        /// VerifyTheCMD
        ///     Verify Get-EmcStorageGroup Command
        /// </summary>
        /// <param name="psMachine">Powershell machine instance</param>
        /// <param name="hostname">Hostname</param>
        /// <param name="hbaId">Hba Id</param>
        /// <param name="storageGlobalId">Storage global id</param>
        /// <param name="arrayLunId">Array lun Id</param>
        /// <param name="hostLunId">Host Lun Id</param>
        /// <returns>Get-EmcStorageGroup output string</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string hostname, string hbaId, string storageGlobalId, string arrayLunId, string hostLunId)
        {
            TestLog log = TestLog.GetInstance();
            PrefixString = HelperAdapter.GetParameter("StorageGroup");
            string result = RunCMD(psMachine, true);
            if (initiatoridString == null && storagesystemString == null && silentString == null)
            {
                TestSetup.VerifyStorageGroupInfo(psMachine, result, PrefixString);
            }
            VerifyFields(psMachine, result, hostname, hbaId, storageGlobalId, arrayLunId, hostLunId);
            
            return result;
        }

        /// <summary>
        /// VerifyFields
        ///    Verify the fields for Get-EmcStorageGroup Command
        /// </summary>
        /// <param name="psMachine">powershell machine instance</param>
        /// <param name="result">Get-EmcStorageGroup output string</param>
        /// <param name="hostname">Hostname</param>
        /// <param name="hbaId">Hba Id</param>
        /// <param name="storageGlobalId">Storage global id</param>
        /// <param name="arrayLunId">Array lun Id</param>
        /// <param name="hostLunId">Host Lun Id</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string hostname, string hbaId, string storageGlobalId, string arrayLunId, string hostLunId)
        {
            TestLog log = TestLog.GetInstance();
            if (initiatoridString == null)
            {
                result = TestSetup.GetStorageGroupForHost(psMachine, hostname);

                if (result == null)
                {
                    log.LogError(String.Format("Failed to find the storage group for host {0}", hostname));
                    PSException pe = new PSException(String.Format("Failed to find the storage group for host {0}", hostname));
                    throw pe;
                }
            }
            SortedList<string, string> storageGroup = HelperAdapter.GenerateKeyValuePairs(result);
            log.AreEqual(storageGlobalId, storageGroup["StorageSystemGlobalId"], "Storage Global Id: ");

            if (! storageGroup["Name"].ToLower().Contains(hostname))
            {
                log.LogError(String.Format("Incorrect storage group name {0}", storageGroup["Name"]));
                PSException pe = new PSException(String.Format("Incorrect storage group name {0}", storageGroup["Name"]));
                throw pe;
            }

            if (! storageGroup["HbaIds"].Contains(hbaId))
            {
                log.LogError(String.Format("hbaId {0} doesn't display in the storageGroup {1}", hbaId, storageGroup["HbaIds"]));
                PSException pe = new PSException(String.Format("hbaId {0} doesn't display in the storageGroup {1}", hbaId, storageGroup["HbaIds"]));
                throw pe;
            }

            log.AreEqual(hostLunId, TestSetup.GetHostLunIdFromArrayLunId(psMachine, arrayLunId), String.Format("Host Lun Id mapped to Array Lun Id {0}: ", arrayLunId));
            
        }
    }
}

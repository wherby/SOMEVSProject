using System;
using System.Collections.Generic;
using System.Text;


using PowerShellTestTools;

namespace PowerShellAutomation
{
    
    public class DisconnectEmcHostSystem : BaseClass
    {
        
#if true
        #region AutoGenerate
        
        private string idString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;
        private string systemString = null;

        
        /// <summary>
        /// DisconnectEmcHostSystem
        ///     Constructor for DisconnectEmcHostSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public DisconnectEmcHostSystem(string id = null, string force = null, string silent = null, string whatif = null, string system = null,  string cmd = null)
        {

            idString = id;
            forceString = force;
            silentString = silent;
            whatifString = whatif;
            systemString = system;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Disconnect-EmcHostSystem");

			if (idString != null)
            {
		        sb.AppendFormat(" -Id {0}", idString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
			if (systemString != null)
            {
		        sb.AppendFormat(" -System {0}", systemString);
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion
#endif
        
        public string VerifyTheCMD(PowershellMachine psMachine, string globalId)
        {
            string result = RunCMD(psMachine);

            VerifyFields(result.Trim(), psMachine, globalId);

            return result;
        }

        private void VerifyFields(string result, PowershellMachine psMachine, string globalId)
        {
            TestLog log = TestLog.GetInstance();

            log.AreEqual(string.Empty, result, "Cmdlet output");

            GetEmcHostSystem getHost = null;

            if (idString != null || systemString != null)
            {
                getHost = new GetEmcHostSystem(globalId);
            }
            else
            {
                getHost = new GetEmcHostSystem();
            }

            string resultForVerification = getHost.RunCMD(psMachine);

            if ((whatifString == null && resultForVerification.Trim() != string.Empty) || (whatifString != null && resultForVerification.Trim() == string.Empty))
            {
                log.LogError(string.Format("Disconnect Host System {0} Failed.", idString));
                PSException pe = new PSException(string.Format("Disconnect Host System {0} Failed.", idString));
                throw pe;
            }                 
        }
    }
}
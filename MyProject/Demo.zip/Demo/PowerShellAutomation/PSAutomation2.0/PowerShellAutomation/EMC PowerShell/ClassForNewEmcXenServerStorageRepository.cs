using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcXenServerStorageRepository : BaseClass
    {
        private TestLog log = TestLog.GetInstance();
        
        #region AutoGenerate
        
        private string lunString = null;
        private string xenserverString = null;
        private string nameString = null;
        private string targetportString = null;
        private string descriptionString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcXenServerStorageRepository
        ///     Constructor for NewEmcXenServerStorageRepository class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcXenServerStorageRepository(string lun = null, string xenserver = null, string name = null, string targetPort = null, string description = null, string silent = null,  string cmd = null)
        {

            lunString = lun;
            xenserverString = xenserver;
            nameString = name;
            targetportString = targetPort;
            descriptionString = description;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcXenServerStorageRepository");

			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (xenserverString != null)
            {
		        sb.AppendFormat(" -XenServer {0}", xenserverString);
            }
			if (nameString != null)
            {
		        sb.AppendFormat(" -Name {0}", "\"" + nameString + "\"");
            }
            if (targetportString != null)
            {
                sb.AppendFormat(" -TargetPort {0}", targetportString);
            }
			if (descriptionString != null)
            {
                sb.AppendFormat(" -Description {0}", "\"" + descriptionString + "\"");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-XenServerStorageRepository commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of New-XenServerStorageRepository</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("StorageRepository");

            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string lun = HelperAdapter.GetParameter("Lun");
            string sr = HelperAdapter.GetParameter("StorageRepository");
            SortedList<string, string> srKeyValue = HelperAdapter.GenerateKeyValuePairs(result);

            if (nameString != null)
            {
                log.AreEqual<string>(nameString, srKeyValue["Name"], "Verify Name");
            }

            if (descriptionString != null)
            {
                log.AreEqual<string>(descriptionString, srKeyValue["Description"], "Verify Description");
            }

            string fcWwn = TestSetup.GetPropertyValue(psMachine, HelperAdapter.GetParameter("TargetPort"), "Wwn");
            if (string.IsNullOrEmpty(fcWwn))
            {
                log.AreEqual<string>("lvmoiscsi", srKeyValue["Type"], "Verify Type");
            }
            else
            {
                log.AreEqual<string>("lvmohba", srKeyValue["Type"], "Verify Type");
            }

            string lunCapacity = TestSetup.GetPropertyValue(psMachine, lun, "Capacity.ValueMB");
            string srCapacity = TestSetup.GetPropertyValue(psMachine, sr, "Capacity.ValueMB");
            log.AreEqual<bool>(true, int.Parse(lunCapacity) > int.Parse(srCapacity), "Verify sr capacity is smaller than lun capacity");

            string srFreeSpace = TestSetup.GetPropertyValue(psMachine, sr, "FreeSpace.ValueMB");
            log.AreEqual<bool>(true, int.Parse(srCapacity) > int.Parse(srFreeSpace), "Verify sr FreeSpace is smaller than sr capacity");

            string lunWwn = TestSetup.GetPropertyValue(psMachine, lun, "Wwn");
            string srLunWwn = TestSetup.GetPropertyValue(psMachine, sr, "HostLunIdentifier.Wwn");
            //log.AreEqual<string>(lunWwn, srLunWwn, "Verify lun wwn");

            string xenServer = HelperAdapter.GetParameter("XenServer");
            string xenServerGlobalId = TestSetup.GetPropertyValue(psMachine, xenServer, "GlobalId");
            log.AreEqual<string>(xenServerGlobalId, srKeyValue["XenServerSystemGlobalId"], "Verify XenServer Global Id");
        }
    }
}

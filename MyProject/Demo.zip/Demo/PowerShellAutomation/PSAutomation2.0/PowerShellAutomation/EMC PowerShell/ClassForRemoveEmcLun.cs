using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;

using PowerShellTestTools;

namespace PowerShellAutomation
{
    public class RemoveEmcLun:BaseClass
    {

        #region AutoGenerate
        
        private string lunString = null;
        private string forceString = null;
        private string silentString = null;
        private string whatifString = null;

        
        /// <summary>
        /// RemoveEmcLun
        ///     Constructor for RemoveEmcLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcLun(string lun = null, string force = null, string silent = null, string whatif = null,  string cmd = null)
        {

            lunString = lun;
            forceString = force;
            silentString = silent;
            whatifString = whatif;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcLun");

			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (forceString != null)
            {
		        sb.AppendFormat(" -Force");
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (whatifString != null)
            {
		        sb.AppendFormat(" -WhatIf");
            }
		    sb.AppendFormat(" -Confirm:$false");


            return sb.ToString();
        }
        #endregion



        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string wwn = null;
            TestLog log = TestLog.GetInstance();
            string informationForLun = null;
            if (lunString != null)
            {
                List<string> ps = new List<string>();
                ps.Add(lunString);
                informationForLun = psMachine.RunScript(ps, new List<PSParam> { }).OutStr;
                if (informationForLun.IndexOf("Wwn") < 0)
                {
                    log.LogWarning("The lun is not existed");
                }
                SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(informationForLun);
                wwn = lunKeyValue["Wwn"];
            }
            GetEmcLun getLun = new GetEmcLun(wwn);

            string result = RunCMD(psMachine);
            
            string systemString= HelperAdapter.GetParameter("System");
            UpdateEmcSystem update = new UpdateEmcSystem( systemString);
            update.RunCMD(psMachine);

            string retriveLun = getLun.RunCMD(psMachine);
            if ((retriveLun.IndexOf("Wwn") > 0)&&(whatifString==null))
            {
                string errorMessage = string.Format("The Lun is not removed. The full command is: {0}.", GetFullString());
                log.LogWarning(errorMessage);
                PSException pe = new PSException(errorMessage);
                throw pe;
            }

            SortedList<string ,string > lunKeyValuePairs=HelperAdapter.GenerateKeyValuePairs(informationForLun);
            VerifyFields(lunKeyValuePairs,psMachine);
            return result;
        }

        private void VerifyFields(SortedList<string, string> storagePool,PowershellMachine psMachine)
        {
            TestLog log = TestLog.GetInstance();
            if (whatifString != null)
            {
                return;
            }
            if (lunString != null)
            {
                GetEmcLun getLun = new GetEmcLun(lunString);
                string information = getLun.RunCMD(psMachine);
                log.AreEqual<string>(string.Empty, information.Trim(), "The lun has been removed");
            }
        }
    }
}

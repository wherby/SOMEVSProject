using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcCandidateSnapshotLun : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string sourcelunString = null;
        private string countString = null;
        private string snapshotpoolString = null;
        private string namehintString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcCandidateSnapshotLun
        ///     Constructor for NewEmcCandidateSnapshotLun class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcCandidateSnapshotLun(string sourcelun, string count, string snapshotpool = null, string namehint = null, string silent = null,  string cmd = null)
        {

            sourcelunString = sourcelun;
            countString = count;
            snapshotpoolString = snapshotpool;
            namehintString = namehint;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcCandidateSnapshotLun");

			if (sourcelunString != null)
            {
		        sb.AppendFormat(" -SourceLun {0}", sourcelunString);
            }
			if (countString != null)
            {
		        sb.AppendFormat(" -Count {0}", countString);
            }
			if (snapshotpoolString != null)
            {
		        sb.AppendFormat(" -SnapshotPool {0}", snapshotpoolString);
            }
			if (namehintString != null)
            {
		        sb.AppendFormat(" -NameHint {0}", namehintString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcCandidateSnapshotLun commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="sourceLunID">Source Lun ID</param>
        /// <param name="storageGlobalID">Storage Global ID</param>
        /// <param name="sourceLunCapacity">Source Lun Capacity</param>
        /// <returns>the result of New-EmcCandidateSnapshotLun</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string sourceLunID, string storageGlobalID, string sourceLunCapacity)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, sourceLunID, storageGlobalID, sourceLunCapacity);

            return result;
        }

        /// <summary>
        /// VerifyFields
        ///     Verify the fields of New-EmcCandidateSnapshotLun
        /// </summary>
        /// <param name="psMachine">PowerShell Machine</param>
        /// <param name="result">result string of New-EmcCandidateSnapshotLun</param>
        /// <param name="sourceLunID">Source Lun ID</param>
        /// <param name="storageGlobalID">Storage System Global ID</param>
        /// <param name="sourceLunCapacity">Source Lun Capacity</param>
        private void VerifyFields(PowershellMachine psMachine, string result, string sourceLunID, string storageGlobalID, string sourceLunCapacity)
        {
            List<SortedList<string, string>> snapshotLuns = HelperAdapter.GenerateKeyValuePairsList(result);
            string namehint = namehintString;
            string systemPrefix = HelperAdapter.GetParameter("System");

            log.AreEqual<string>(countString, snapshotLuns.Count.ToString(), "The number of newly created Candidate Snapshot Luns is: ");

            foreach (SortedList<string, string> snapshotLun in snapshotLuns)
            {
                string id;
                if (TestSetup.StorageSystemType == "VNXe")
                {
                    id = snapshotLun["Name"];
                }
                else
                {
                    id = snapshotLun["Wwn"];
                }
                GetEmcSnapshotLun getEmcSnapshotLun = new GetEmcSnapshotLun(id, null, systemPrefix);
                string getResult = getEmcSnapshotLun.RunCMD(psMachine);
                if (String.IsNullOrEmpty(getResult))
                {
                    UpdateEmcSystem updateSystem = new UpdateEmcSystem(systemPrefix);
                    updateSystem.RunCMD(psMachine);
                    getResult = getEmcSnapshotLun.RunCMD(psMachine, true);
                }
                SortedList<string, string> getSnapshotLun = HelperAdapter.GenerateKeyValuePairs(getResult);
                if (TestSetup.StorageSystemType != "VMAX")
                {
                    HelperAdapter.AssertPropertiesComparision(getSnapshotLun, snapshotLun);
                }
                else
                {
                    // This is for a deferred artifact artf72804, should be removed when the issue is fixed
                    List<string> excludedKeys = new List<string>();
                    excludedKeys.Add("SnapshotPoolId");
                    excludedKeys.Add("ArrayPoolId");
                    if (!HelperAdapter.SortedListIsEqual(getSnapshotLun, snapshotLun, excludedKeys))
                    {
                        log.LogError("The output of Get-SnapshotLun is not consistent with New-SnapshotLun");
                        PSException pe = new PSException("The output of Get-SnapshotLun is not consistent with New-SnapshotLun");
                        throw pe;
                    }
                }
                
                log.AreEqual<string>("False", snapshotLun["IsActivated"], "IsActivated Flag of the Snapshot Lun is: ");
                log.AreEqual<string>(storageGlobalID, snapshotLun["StorageSystemGlobalId"], "Storage system global ID of the Snapshot Lun is: ");
                
                if (TestSetup.StorageSystemType != "VMAX")
                {
                    log.AreEqual<string>(sourceLunID, snapshotLun["SourceLunId"], "Source Lun ID of the Snapshot Lun is: ");

                    if (namehintString != null)
                    {
                        if (snapshotLun["Name"].IndexOf(namehint) != 0)
                        {
                            log.LogError(String.Format("Incorrect Name format. Name: {0}, Namehint: {1}", snapshotLun["Name"], namehint));
                            PSException pe = new PSException(String.Format("Incorrect Name format. Name: {0}, Namehint: {1}", snapshotLun["Name"], namehint));
                            throw pe;
                        }
                    }
                }
                if (TestSetup.StorageSystemType != "VNXe")
                {
                    log.AreEqual<string>(sourceLunCapacity, snapshotLun["Capacity"], "Capacity of the Snapshot Lun is: ");
                }
                log.AreEqual<string>("False", snapshotLun["IsPrivate"], "IsPrivate flag of the Snapshot Lun is: ");
                log.AreEqual<string>("True", snapshotLun["CanDestroy"], "CanDestroy flag of the Snapshot Lun is: ");
                log.AreEqual<string>("False", snapshotLun["CanExtend"], "CanExtend flag of the Snapshot Lun is: ");
            }
        }
    }
}
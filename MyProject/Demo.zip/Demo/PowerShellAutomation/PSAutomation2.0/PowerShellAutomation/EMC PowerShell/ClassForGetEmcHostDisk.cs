using System.Collections.Generic;

using PowerShellTestTools;
using System.Text;
using System;
namespace PowerShellAutomation
{

    public class GetEmcHostDisk : BaseClass
    {
        #region AutoGenerate
        
        private string idString = null;
        private string lunString = null;
        private string hostsystemString = null;
        private string silentString = null;
        private string clustersystemString = null;
        private string volumeString = null;

        
        /// <summary>
        /// GetEmcHostDisk
        ///     Constructor for GetEmcHostDisk class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcHostDisk(string id = null, string lun = null, string hostsystem = null, string silent = null, string clustersystem = null, string volume = null,  string cmd = null)
        {

            idString = id;
            lunString = lun;
            hostsystemString = hostsystem;
            silentString = silent;
            clustersystemString = clustersystem;
            volumeString = volume;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcHostDisk");

			if (idString != null)
            {
		        sb.AppendFormat(" -ID {0}", idString);
            }
			if (lunString != null)
            {
		        sb.AppendFormat(" -Lun {0}", lunString);
            }
			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (clustersystemString != null)
            {
		        sb.AppendFormat(" -ClusterSystem {0}", clustersystemString);
            }
			if (volumeString != null)
            {
		        sb.AppendFormat(" -Volume {0}", volumeString);
            }


            return sb.ToString();
        }
        #endregion


        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);
            if (lunString != null)
            {
                string lunInfo = TestSetup.GetParameterValue(psMachine, null,lunString);
                SortedList<string, string> lunKeyValue = HelperAdapter.GenerateKeyValuePairs(lunInfo);
                string wwnString = lunKeyValue["Wwn"];
                result = result.Replace("\r\n", "");
                result = result.Replace(" ", "");
                bool islunInResult = result.IndexOf(wwnString, StringComparison.OrdinalIgnoreCase) > 0;
                TestLog log = TestLog.GetInstance();
                log.AreEqual<bool>(true, islunInResult, "The disk is in result");
            }
            return result;
        }
    }
}

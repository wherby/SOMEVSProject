using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class NewEmcCIFSSharedFolder : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string poolString = null;
        private string nameString = null;
        private string pathString = null;
        private string capacityString = null;
        private string silentString = null;

        
        /// <summary>
        /// NewEmcCIFSSharedFolder
        ///     Constructor for NewEmcCIFSSharedFolder class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public NewEmcCIFSSharedFolder(string pool = null, string name = null, string path = null, string capacity = null, string silent = null,  string cmd=null)
        {

            poolString = pool;
            nameString = name;
            pathString = path;
            capacityString = capacity;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("New-EmcCIFSSharedFolder");

			if (poolString != null)
            {
		        sb.AppendFormat(" -Pool {0}", poolString);
            }
			if (nameString != null)
            {
		        sb.AppendFormat(" -Name {0}", nameString);
            }
			if (pathString != null)
            {
		        sb.AppendFormat(" -Path {0}", pathString);
            }
			if (capacityString != null)
            {
		        sb.AppendFormat(" -Capacity {0}", capacityString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether New-EmcCIFSSharedFolder commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of New-EmcCIFSSharedFolder</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result);



            return result;

        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> folderKeyValue = HelperAdapter.GenerateKeyValuePairs(result);
            if (capacityString != null)
            {
                string capacityToCreated = TestSetup.GetPropertyValue(psMachine, capacityString);
                string capString = folderKeyValue["TotalCapacity"];
                capString = capString.Replace(" ", "");
                string capacityCreated = TestSetup.GetPropertyValue(psMachine, capString);
                log.AreEqual<string>(capacityToCreated, capacityCreated, "Pool size");
            }
            if (pathString != null)
            {
                log.AreEqual<string>(pathString, folderKeyValue["Name"], "Pool Name");
            }
            if (poolString != null)
            {
                string poolName = TestSetup.GetPropertyValue(psMachine, poolString, "ArrayPoolId");
                log.AreEqual<string>(poolName, folderKeyValue["ArrayPoolId"], "SharedFolderPoool");
            }
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcCIFSSharedFolderMountPoint : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string hostsystemString = null;
        private string sharedfolderString = null;
        private string silentString = null;

        
        /// <summary>
        /// RemoveEmcCIFSSharedFolderMountPoint
        ///     Constructor for RemoveEmcCIFSSharedFolderMountPoint class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcCIFSSharedFolderMountPoint(string hostsystem = null, string sharedfolder = null, string silent = null,  string cmd=null)
        {

            hostsystemString = hostsystem;
            sharedfolderString = sharedfolder;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcCIFSSharedFolderMountPoint");

			if (hostsystemString != null)
            {
		        sb.AppendFormat(" -HostSystem {0}", hostsystemString);
            }
			if (sharedfolderString != null)
            {
		        sb.AppendFormat(" -SharedFolder {0}", sharedfolderString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcCIFSSharedFolderMountPoint commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcCIFSSharedFolderMountPoint</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            string remoteString = TestSetup.GetPropertyValue(psMachine, sharedfolderString, "RemotePath");
            GetEmcCifsNetworkShare getShare = new GetEmcCifsNetworkShare(hostsystemString, remoteString);
            string resultShare = getShare.RunCMD(psMachine);
            bool isShareFolderUnmounted=resultShare.Trim()==string.Empty;
            log.AreEqual<bool>(true, isShareFolderUnmounted, "The sharedFolder is unmounted");
        }
    }
}
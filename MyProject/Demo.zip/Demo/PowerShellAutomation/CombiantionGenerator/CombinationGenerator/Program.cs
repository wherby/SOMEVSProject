﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using Facet.Combinatorics;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Collections;
using System.Text.RegularExpressions;
using System.Xml;
using System.Xml.Serialization;
using System.Xml.XPath;
using System.Web;
using EMC.ESI.PowerShell.Helper;


namespace CombinationGenerator
{
    class Program
    {
        private static string psResultFile = null;
        static void Main(string[] args)
        {
            string testMachine = null;
            string modulestring = null;

            if (args.Length == 2)
            {
                testMachine = args[0];
                modulestring = args[1].ToLower().Replace("automation", "pstoolkit");
                modulestring = modulestring.Replace("powershell", "esi");
            }
            else
            {
                testMachine = HelperAdapter.GetProperty("TestMachine");
                modulestring = HelperAdapter.GetProperty("PowerShellModule");
            }

            string dirPath = HelperAdapter.GetProperty("CombinationFolder");
            string excludeWords = HelperAdapter.GetProperty("ExcludeWords");

            string[] excludeKeyWords = null;
            if (excludeWords != null && excludeWords != string.Empty)
            {
                excludeKeyWords = excludeWords.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            }

            if (!Directory.Exists(dirPath))
            {
                try
                {
                    Directory.CreateDirectory(dirPath);
                }
                catch (Exception excp)
                {
                    Console.WriteLine(excp.Message);
                    return;
                }
            }

            string assemblytPath = System.AppDomain.CurrentDomain.BaseDirectory;

            string scriptFile = assemblytPath + @"\getparameter.ps1";

            string[] modules = modulestring.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string module in modules)
            {
                string result = RunScript(scriptFile, assemblytPath, module, testMachine);
                psResultFile = result.Trim();
                Console.WriteLine(psResultFile);

                string dir = dirPath + @"\" + module + @"\";
                string posDir = dir + @"positive\";
                string negDir = dir + @"negative\";

                string cmdFile = assemblytPath + @"\cmdAll.txt";

                if (File.Exists(cmdFile))
                {
                    File.Delete(cmdFile);
                }
                GeneratePositiveCombination(posDir, cmdFile, excludeKeyWords, module, testMachine);
                GenerateNegativeCombination(negDir, posDir);

                string dropFile = @"..\..\..\..\Documents\Cmdlet Log\Current version\";
                File.Copy(cmdFile, assemblytPath + dropFile + module +"CmdAll.txt", true);
                File.Copy(psResultFile, assemblytPath + dropFile + module + "Parameter.txt", true);
            }
        }

        private static string RunScript(string psScriptPath, string param, string module, string testMachine = "localhost")
        {
            Runspace runspace = RunspaceFactory.CreateRunspace();
            runspace.Open();

            Pipeline pipeline = runspace.CreatePipeline();
            pipeline.Commands.AddScript("Set-ExecutionPolicy RemoteSigned");
            pipeline.Commands.AddScript("Invoke-command -computerName " + testMachine + " -filepath " + psScriptPath + " -argumentlist c:," + module);
            pipeline.Commands.AddScript(@"cp \\" + testMachine + @"\c$\" + module + "Parameter.txt  " + param);
            pipeline.Commands.Add("Out-String");
            Console.WriteLine("start invoke:" + psScriptPath);
            Collection<PSObject> results = pipeline.Invoke();
            runspace.Close();

            string paramFile = param + module + "Parameter.txt";

            return paramFile;
        }

        public static bool ContainUnprepared(string cmd, string[] words)
        {
            if (words == null)
            {
                return false;
            }

            foreach (string word in words)
            {
                if (cmd.Contains(word))
                {
                    return true;
                }
            }

            return false;
        }

        public static string ReplaceVarious(string str_case, string cmd, string module, string testMachine = "localhost")
        {
            string str_case_new = string.Empty;

            Dictionary<string, string> dic = Load(cmd);
            if (dic.Count == 0)
            {
                return str_case;
            }

            foreach (string key in dic.Keys)
            {
                if (str_case.Contains("$" + key))
                {
                    if (str_case_new != string.Empty)
                    {
                        str_case = str_case_new;
                        str_case_new = string.Empty;
                    }

                    string[] vals = dic[key].Split(new char[] { '[', ']' }, StringSplitOptions.RemoveEmptyEntries);
                    for (int i = 0; i < vals.Length; i++)
                    {
                        if (vals[i].Contains("PSCMD:"))
                        {
                            string pscmd = vals[i].Replace("PSCMD:", "");
                            Runspace runspace = RunspaceFactory.CreateRunspace();
                            runspace.Open();

                            Pipeline pipeline = runspace.CreatePipeline();
                            pipeline.Commands.AddScript("Set-ExecutionPolicy RemoteSigned");
                            pipeline.Commands.AddScript("Invoke-command -computerName " + testMachine + " -ScriptBlock { Import-Module " + module + ";" + pscmd + "}");
                            pipeline.Commands.Add("Out-String");
                            Collection<PSObject> results = pipeline.Invoke();
                            runspace.Close();

                            StringBuilder stringBuilder = new StringBuilder();

                            foreach (PSObject obj in results)
                            {
                                stringBuilder.AppendLine(obj.ToString());
                            }

                            vals[i] = stringBuilder.ToString().Replace("\r\n", ",");
                        }
                    }

                    str_case_new += recurrence(vals, str_case, key, 0, string.Empty);
                }
            }
            if (str_case_new != string.Empty)
            {
                return str_case_new;
            }
            else
            {
                return str_case;
            }
        }

        private static string recurrence(string[] vals, string str_case, string key, int i, string str)
        {

            string[] val = vals[i].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            string str_case_new = string.Empty;
            i++;
            foreach (string valkey in val)
            {
                if (i == vals.Length)
                {
                    str_case_new += str_case.Replace("$" + key, "$" + str + valkey);
                }
                else
                {
                    str_case_new += recurrence(vals, str_case, key, i, str + valkey);
                }
            }
            return str_case_new;
        }

        public static Dictionary<string, string> Load(string node)
        {
            XmlDocument xmldoc = new XmlDocument();
            Dictionary<string, string> dic = new Dictionary<string, string>();
            string assemblytPath = System.AppDomain.CurrentDomain.BaseDirectory;
            string configFile = assemblytPath + @"\paramconfig.xml";

            xmldoc.Load(configFile);
            XmlNodeList topM = xmldoc.DocumentElement.ChildNodes;

            foreach (XmlElement element in topM)
            {
                if (element.Name == node)
                {
                    XmlNodeList nodelist = element.ChildNodes;

                    foreach (XmlElement el in nodelist)
                    {
                        dic.Add(el.Attributes["Name"].Value, el.Attributes["Value"].Value);
                    }

                    break;
                }
            }
            return dic;
        }

        private static void GeneratePositiveCombination(string posDir, string cmdFile, string[] excludeWords, string module, string testMachine = "localhost")
        {
            StreamWriter cmdWriter = File.CreateText(cmdFile);

            StreamReader file = null;

            if (File.Exists(psResultFile))
            {
                file = new StreamReader(psResultFile);
            }
            else
            {
                throw new FileNotFoundException("Wrong path for the script file");
            }

            if (Directory.Exists(posDir))
            {
                Directory.Delete(posDir, true);
            }
            Directory.CreateDirectory(posDir);

            string sLine = string.Empty;
            StreamWriter caseFile = null;
            string[] alter_params = null;
            string[] mandatory_params = null;
            string cmd = null;
            List<string> param = new List<string>();
            Dictionary<string, int> dic = new Dictionary<string, int>();
            Dictionary<string, int> dic_param = new Dictionary<string, int>();

            string alter_temp = null;
            while ((sLine = file.ReadLine()) != null)
            {
                string[] split = sLine.Split(new char[] { ':' }, 2);

                if (split[0].Equals("mandatory"))
                {
                    if (alter_temp == "-.")
                    {
                        continue;
                    }

                    mandatory_params = split[1].Split(new char[] { ',' });
                }
                else if (split[0].Equals("optional"))
                {
                    if (alter_temp == "-.")
                    {
                        continue;
                    }

                    string[] option_split = split[1].Split(new char[] { ',' });

                    string str_case = cmd;
                    for (int i = 0; i <= option_split.Length; i++)
                    {
                        Combinations<string> combinations = new Combinations<string>(option_split, i);
                        foreach (IList<string> c in combinations)
                        {
                            str_case = null;
                            param.Clear();
                            param.Add(cmd);

                            foreach (string str in mandatory_params)
                            {
                                param.Add(str);
                                if (!dic_param.ContainsKey(str))
                                {
                                    dic_param.Add(str, 1);
                                }
                            }
                            foreach (string str in c)
                            {
                                param.Add(str);
                                if (!dic_param.ContainsKey(str))
                                {
                                    dic_param.Add(str, 1);
                                }
                            }
                            if (alter_params != null)
                            {
                                List<string> str_alter = new List<string>();
                                foreach (string str in alter_params)
                                {
                                    string[] str_alter_set = str.Split(new char[] { '.' });
                                    str_alter.Add(str_alter_set[0]);
                                    int position = int.Parse(str_alter_set[1]);

                                    for (int j = param.Count - 1; j >= 0; j--)
                                    {
                                        string parameter = param[j];
                                        if (parameter.Contains(str_alter_set[0]))
                                        {
                                            param.RemoveAt(j);
                                            param.Insert(position, parameter);
                                        }
                                    }

                                }
                                foreach (string str in param)
                                {
                                    str_case += str;
                                }
                                str_case += "\r\n";
                                if (dic.ContainsKey(str_case))
                                {
                                    continue;
                                }
                                else
                                {
                                    dic.Add(str_case, 1);
                                }

                                foreach (string str in str_alter)
                                {
                                    if (str_case.Contains(str))
                                    {
                                        string new_str_case = str_case.Replace(str, "");
                                        str_case += new_str_case;
                                    }
                                }
                            }
                            else
                            {
                                foreach (string str in param)
                                {
                                    str_case += str;
                                }
                                str_case += "\r\n";

                                if (dic.ContainsKey(str_case))
                                {
                                    continue;
                                }
                                else
                                {
                                    dic.Add(str_case, 1);
                                }
                            }

                            string str_case_new = ReplaceVarious(str_case, cmd, module, testMachine);
                            string[] lines = str_case_new.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                            foreach (string line in lines)
                            {
                                if (ContainUnprepared(line, excludeWords))
                                {
                                    continue;
                                }

                                if (dic.ContainsKey(line))
                                {
                                    continue;
                                }
                                else
                                {
                                    dic.Add(line, 1);
                                }
                                caseFile.WriteLine(line);
                            }
                        }
                    }

                    alter_params = null;
                }
                else if (split[0].Equals("alternate") && split.Length > 1)
                {
                    alter_temp = split[1].Trim();
                    alter_params = split[1].Split(new char[] { ',' });
                }
                else
                {
                    if (caseFile != null)
                    {
                        caseFile.Close();
                    }
                    cmd = split[0];
                    caseFile = File.CreateText(posDir + cmd + ".txt");
                    dic.Clear();
                    alter_temp = null;
                    alter_params = null;


                    if (cmd != "New-EmcVolume" && cmd != "New-EmcLun" && cmd != "Add-EmcPassthroughDiskToVirtualMachine" && cmd != "Add-EmcSystem" && cmd != "Remove-EmcSystem" && cmd != "Get-EmcSystem")
                    {
                        cmdWriter.WriteLine(cmd);
                    }
                }

            }
            caseFile.Close();
            if (module.ToLower() == "esipstoolkit")
            {
                cmdWriter.WriteLine("New-EmcVolume");
                cmdWriter.WriteLine("New-EmcLun");
                cmdWriter.WriteLine("Add-EmcPassthroughDiskToVirtualMachine");
            }
            else if (module.ToLower() == "esiservicepstoolkit")
            {
                cmdWriter.WriteLine("Add-EmcSystem");
                cmdWriter.WriteLine("Remove-EmcSystem");
                cmdWriter.WriteLine("Get-EmcSystem");
            }
            cmdWriter.Close();
        }

        private static void GenerateNegativeCombination(string negDir, string posDir)
        {

            if (!Directory.Exists(posDir))
            {
                Console.WriteLine("positive cases are not created!");
                return;
            }

            if (Directory.Exists(negDir))
            {
                Directory.Delete(negDir, true);
            }
            Directory.CreateDirectory(negDir);

            StreamReader file = null;
            string sLine = string.Empty;
            StreamWriter negCaseFile = null;
            string[] allParams = null;
            Dictionary<string, int> posDic = new Dictionary<string, int>();
            Dictionary<string, int> negDic = new Dictionary<string, int>();
            DirectoryInfo posDirInfo = new DirectoryInfo(posDir);

            foreach (FileInfo caseFile in posDirInfo.GetFiles())
            {
                negCaseFile = File.CreateText(negDir + "N" + caseFile.Name);

                file = new StreamReader(caseFile.FullName);
                bool containNamedParam = false;
                while ((sLine = file.ReadLine()) != null)
                {
                    if (sLine.ToLower().Contains("-id "))
                    {
                        containNamedParam = true;
                    }
                    try
                    {
                        posDic.Add(sLine, 1);
                    }
                    catch
                    {
                        Console.WriteLine(sLine);
                    }
                }

                foreach (KeyValuePair<string, int> item in posDic)
                {

                    allParams = item.Key.Split(new char[] { ' ' }, StringSplitOptions.RemoveEmptyEntries);
                    foreach (string param in allParams)
                    {
                        if (param.StartsWith("$"))
                        {
                            string negCase = item.Key.Replace(" " + param, "");
                            if (posDic.ContainsKey(negCase) || negDic.ContainsKey(negCase))
                            {
                                continue;
                            }
                            negCaseFile.WriteLine(negCase);
                            negDic.Add(negCase, 1);
                        }
                        else if (param.StartsWith("-"))
                        {
                            string negCase = item.Key.Replace(" " + param, "");
                            if (posDic.ContainsKey(negCase) || negDic.ContainsKey(negCase) || param == "-Confirm:$false" || (allParams[1].StartsWith("-") && !item.Key.ToLower().Contains("-id ") && containNamedParam))
                            {
                                continue;
                            }
                            negCaseFile.WriteLine(negCase);
                            negDic.Add(negCase, 1);
                        }
                    }
                }

                posDic.Clear();
                negDic.Clear();
                negCaseFile.Close();
            }
        }
    }
}

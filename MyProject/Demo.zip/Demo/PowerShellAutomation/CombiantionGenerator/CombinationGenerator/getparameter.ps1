param($path,$module)

import-module -name $module
$cmds = get-command -module $module
$output = "$path\$module" + "Parameter.txt"

if(test-Path $output)
{
	remove-item $output
}

$nr_cmds = $cmds.count;
#write-host $nr_cmds

foreach ($cmd in $cmds)
{
	$cmd_name = $cmd.name
	$cmd_syntaxItem = (get-help $cmd_name).syntax.syntaxItem
	$param_sets = (get-command $cmd_name).parametersets
	$nr_item = $cmd_syntaxItem.count
	$cmd.name + ":" + $nr_item | out-file $output -append
	$index = 0

	foreach($item in $cmd_syntaxItem)
	{
		$str_mandatory = ""
		$str_optional = ""
		$str_alternate = ""
		$m_prefix = ""
		$o_prefix = ""
		$a_prefix = ""

		foreach($param in $item.parameter)
		{
			#write-host $param.name
			$isSwitch = $false			
			$found = $false
			foreach($def_param in $param_sets[$index].parameters )
			{
				#write-host $def_param.name":"$param.name" type:"$def_param.parametertype.name
				if( $def_param.name -eq $param.name)
				{
					$found = $true
					if( $def_param.parametertype.name -eq "SwitchParameter")
					{
						$isSwitch = $true
					}
					break;
				}
			}
			if( $found -eq $false)
			{
				foreach($set in $param_sets)
				{
					foreach($def_param in $set.parameters )
					{
						if( $def_param.name -eq $param.name)
						{
							$found = $true
							if( $def_param.parametertype.name -eq "SwitchParameter")
							{
								$isSwitch = $true
							}
							break;
						}
					}
					if($found -eq $true)
					{
						break;
					}
				}
			}

			if($isSwitch -eq $true)
			{
				$value = ""
			}
			else
			{
				$value = " $" + $param.name
			}
			
			if($param.required -eq $true)
			{
				$str_mandatory += $m_prefix + " -" + $param.name + $value
				$m_prefix = ","
			}
			elseif( $param.name -eq "Confirm")
			{
				$str_mandatory += $m_prefix + " -" + $param.name + ":$" + "false"
				$m_prefix = ","
			}
			else
			{
				$str_optional += $o_prefix + " -" + $param.name + $value
				$o_prefix = ","
			}
			
			if($param.position -ne "named")
			{
				$str_alternate += $a_prefix + " -" + $param.name + "." + $param.position
				$a_prefix = ","
			}
			
		}
		
		if($str_alternate -ne "")
		{
			"alternate:" + $str_alternate | out-file $output -append
		}
		"mandatory:" + $str_mandatory | out-file $output  -append 
		"optional:" + $str_optional | out-file $output -append
		
		$index++
	}
		
}
$output
﻿using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.Diagnostics;
using System;
using System.IO;

namespace PowerShellTestTools
{
    /// <summary>
    /// The TestLog class is used to generate log for test. The class is designed as singleton.
    /// </summary>
    public class TestLog
    {
        /// <summary>
        /// The singleton TestLog instance.
        /// </summary>
        private static TestLog logInstance = null;

        /// <summary>
        /// This parameter is used for set log file name.
        /// </summary>
        private static string logFileName = null;

        

        /// <summary>
        /// The constructor of TestLog, initialize the property for TestLog instance.
        /// </summary>
        private TestLog()
        {
            System.Diagnostics.Trace.Listeners.Clear();
            System.Diagnostics.Trace.AutoFlush = true;
            TraceListener defaultListener = new ConsoleTraceListener();
            defaultListener.TraceOutputOptions = (TraceOptions.DateTime | TraceOptions.Timestamp | TraceOptions.ProcessId);

            #region Hide
            DateTime dataTime = DateTime.Now;
            string time = DateTime.Now.ToString("HHmmss");
            string date = DateTime.Now.ToString("MMddyy");
            string logFolder=null;
            try
            {
                logFolder = HelperAdapter.GetProperty("LogFolder");
            }
            catch (Exception)
            {
                logFolder = @"C:\DefaultLogFolder";
            }
            string logfile = logFolder + "\\log_" + logFileName + date + "_" + time + ".txt";
            if (logFileName != null)
            {
                logfile = logFolder + "\\" + logFileName + "_" + date + "_" + time + ".txt";
            }

            if (!Directory.Exists(logFolder))
            {
                Directory.CreateDirectory(logFolder);
            }
            #endregion
            TraceListener logListener = new TextWriterTraceListener(logfile);
            logListener.TraceOutputOptions = TraceOptions.DateTime | TraceOptions.ProcessId;
            System.Diagnostics.Trace.Listeners.Add(defaultListener);
            System.Diagnostics.Trace.Listeners.Add(logListener);            
        }

        /// <summary>
        /// Return a Testlog instance.
        /// </summary>
        /// <param name="fileName">The parameter is used to set log file name.</param>
        /// <returns>Testlog instance.</returns>
        public static TestLog GetInstance(TestContext testContext = null, string fileName = null)
        {
            if (logInstance == null || fileName != null || testContext != null)
            {
                if (fileName != null)
                {
                    logFileName = fileName;
                }
                else
                {
                    if (testContext.FullyQualifiedTestClassName.Contains("."))
                    {
                        string className = testContext.FullyQualifiedTestClassName;
                        string[] temp = className.Split(new char[]{'.'}, StringSplitOptions.RemoveEmptyEntries);
                        logFileName = temp[temp.Length - 1];
                    }
                }
                logInstance = new TestLog();
                return logInstance;
            }
            else
            {
                return logInstance;
            }
        }

        #region Log information
        /// <summary>
        /// Logout INFO message for test. This type of message will be only used for Debug.
        /// </summary>
        /// <param name="msg">The message of the INFO message.</param>
        public void LogInfo(string msg)
        {
#if DEBUG
            Debug.WriteLine(String.Format("{0:G} [INFO]: {1}", DateTime.Now, msg));
#else

#endif
 
        }
        #endregion

        #region Log Script information
        /// <summary>
        /// Logout PowerShell Script INFO message for test. This type of message will be only used for Debug.
        /// </summary>
        /// <param name="msg">The message of the INFO message.</param>
        public void LogScript(string msg)
        {
#if DEBUG
            Debug.WriteLine(String.Format("{0:G} [PowerShellScript]:{1}", DateTime.Now, msg));
#else

#endif

        }
        #endregion
        #region Log error message
        /// <summary>
        /// Logout ERROR message. This type of message will be used for both Debug and Release.
        /// </summary>
        /// <param name="msg">The error message</param>
        public void LogError(string msg)
        {
#if DEBUG
            Debug.WriteLine(String.Format("{0:G} [ERROR]: {1}", DateTime.Now, msg));
#else
                    string temp = DateTime.Now.ToString()  +" "+ msg;
                    Trace.WriteLine(temp);
#endif

        }
        #endregion 

        #region Log Warning message
        /// <summary>
        /// Logout Warning message. This type of message will be used for both Debug and Release.
        /// </summary>
        /// <param name="msg">The warning message</param>
        public void LogWarning(string msg)
        {
            string fullMSG = String.Format("{0:G} [Warning]: {1}", DateTime.Now, msg);
#if DEBUG
            Debug.WriteLine(fullMSG);
#else
                    Trace.WriteLine(fullMSG);
#endif
        }
        #endregion 

        #region Print out Test Case specified info
        /// <summary>
        /// Logout testcase information. This message will be used for both Debug and Release.
        /// </summary>
        /// <param name="testname">The information about test case.</param>
        public void LogTestCase(string testname)
        {
#if DEBUG
            Debug.WriteLine(String.Format("{0:G} [Test Case]: {1}", DateTime.Now, testname));
            Debug.WriteLine(Environment.NewLine);
#else
                    string temp = DateTime.Now.ToString()  +" "+ testname;
                    Trace.WriteLine(temp);
#endif

        }
        #endregion

        /// <summary>
        /// The mothod is to verify whether two values are equal.
        /// </summary>
        /// <typeparam name="T">The value type.</typeparam>
        /// <param name="expectedValue">Expected value.</param>
        /// <param name="realValue">The real value.</param>
        /// <param name="info">The information about the verification.</param>
        public void AreEqual<T>(T expectedValue, T realValue, string info = "", bool printInfo = false)
        {
            try
            {
                Assert.AreEqual<T>(expectedValue, realValue);

                string infoMSG = String.Format("{0:G} [DEBUG]:{1} {2} is equeal to {3}", DateTime.Now, info, expectedValue, realValue);

                if (printInfo)
                {
#if DEBUG
                    Debug.WriteLine(infoMSG);
#else
                   
                    Trace.WriteLine(infoMSG);
#endif
                }
            }
            catch (Exception ex)
            {
                string errorMSG = String.Format("{0:G} [ERROR]:{1} {2} is not equal to {3}", DateTime.Now, info, expectedValue, realValue);
#if DEBUG
                Debug.WriteLine(errorMSG);
#else
                    
                Trace.WriteLine(errorMSG);
#endif
                throw ex;
            }
        }

        /// <summary>
        /// The method is bypass the testcase.
        /// </summary>
        public void BypassTest( Exception e = null )
        {
            if (e == null)
            {
                Debug.WriteLine(String.Format("{0:G} [INFO]: {1}", DateTime.Now, "The test is bypassed"));
            }
            else
            {
                Debug.WriteLine(String.Format("{0:G} [INFO]: {1}", DateTime.Now, e.Message + ". The test is bypassed"));
            }
            Assert.Inconclusive();
        }
    }
}

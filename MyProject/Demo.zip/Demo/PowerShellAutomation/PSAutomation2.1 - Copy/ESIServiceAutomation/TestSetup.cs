﻿using System;
using System.Text;
using System.Text.RegularExpressions;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Threading;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    public enum StorageType
    {
        File,
        Block
    }

    public class TestSetup
    {
        private static PowershellMachine psMachine;

        #region Set entity environment

        /// <summary>
        /// SetEmcServiceEnvironment
        ///      Set ServiceURL Environment.
        /// </summary>
        public static void SetEmcServiceEnvironment()
        {
            string urlString = HelperAdapter.GetParameter("URL", ConfigType.ESIService).Split(',')[0];
            SetEmcServiceUrl setUrl = new SetEmcServiceUrl(urlString);
            setUrl.RunCMD(psMachine);
        }

        /// <summary>
        /// GetEntityClass
        ///     GetEntity Class List
        /// </summary>
        /// <returns></returns>
        public static List<string> GetEntityClass()
        {
            List<string> entityCls = new List<string>();
            GetEmcEntityClass entityClass = new GetEmcEntityClass();
            string result = entityClass.RunCMD(psMachine);
            if (string.IsNullOrEmpty(result))
            {
                return null;
            }
            string[] clsList = result.Split(new string[]{"\r\n"}, StringSplitOptions.RemoveEmptyEntries);
            foreach (string cls in clsList)
            {
                entityCls.Add(cls.Trim());
            }
            return entityCls;
        }

        /// <summary>
        /// GetClassEntity
        ///     Get entity of certain class
        /// </summary>
        /// <param name="className">class name</param>
        /// <param name="id">entity id/entity class name/user friendly name of the provider</param>
        /// <param name="url">service url</param>
        /// <returns>list of entity information</returns>
        public static List<SortedList<string, string>> GetClassEntity( string className = "StorageSystem", string id = null, string url = null)
        {
            if (url == null)
            {
                url = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
            }

            GetEmcEntity entity = new GetEmcEntity(className, id, url);
            string result = entity.RunCMD(psMachine);

            return HelperAdapter.GenerateKeyValuePairsList(result);
        }
        #endregion

        #region Set/Remove Security Account envioronment.
        public static void CleanSecurityAccountEnvironment(string serviceUrl)
        {
            string[] userName = HelperAdapter.GetParameter("UserNames", ConfigType.ESIService ).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            string[] roleName = HelperAdapter.GetParameter("RoleNames", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string userTemp in userName)
            {
                foreach (string roleTemp in roleName)
                {
                    Thread.Sleep(1000);
                    try
                    {
                        RemoveEmcUser removeSecurity = new RemoveEmcUser(userTemp, roleTemp,null,serviceUrl);
                        removeSecurity.RunCMD(psMachine);
                        Thread.Sleep(1000);
                    }
                    catch (Exception ex)
                    {
                        TestLog log = TestLog.GetInstance();
                        log.LogInfo(ex.Message);
                    }
                }
            }
        }

        public static void SetSecurityAccountEnvironment(string serviceUrl)
        {
            string[] userName = HelperAdapter.GetParameter("UserNames", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            string[] roleName = HelperAdapter.GetParameter("RoleNames", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
            foreach (string userTemp in userName)
            {
                foreach (string roleTemp in roleName)
                {
                    Thread.Sleep(1000);
                    try
                    {
                        AddEmcUser addUser = new AddEmcUser(userTemp, roleTemp,null,serviceUrl);
                        addUser.RunCMD(psMachine);            
                    }
                    catch (Exception)
                    {

                    }
                    Thread.Sleep(1000);
                }
            }
        }
        #endregion

        # region Import ESIPSToolKit
        public static int InitForEMCServiceStorage(PowershellMachine psmachine)
        {
            psMachine = psmachine;
            Runspace runspace = psMachine.GetRunspace();
            TestLog log = TestLog.GetInstance();
            //create a pipeline
            Pipeline pipeline = runspace.CreatePipeline();

            pipeline.Commands.AddScript("$error.clear()");
            log.LogInfo("Set Execution Policy to RemoteSigned");
            pipeline.Commands.AddScript("Set-ExecutionPolicy RemoteSigned");
            log.LogInfo("Import ESIServicePSToolKit Module");
            pipeline.Commands.AddScript("Import-Module -Name ESIServicePSToolKit");
            
            pipeline.Invoke();
            
            // Fetch the error output of PowerShell
            Pipeline pipeline2 = runspace.CreatePipeline();
            string scr = "if($error.count -gt 0){$error}";
            pipeline2.Commands.AddScript(scr);

            Collection<PSObject> errors = pipeline2.Invoke();

            if (errors.Count > 0)
            {
                foreach (PSObject err in errors)
                {
                    log.LogError(err.ToString());
                }

                log.LogInfo("Failed to import ESIServicePSToolKit Module");
                return 1;
            }

            SetEmcServiceEnvironment();

            return 0;
        }
        # endregion 

        /// <summary>
        /// AddSystem
        ///     Add Emc Storage System to ESI Service
        /// </summary>
        /// <param name="systemType">Storage System Type</param>
        public static void AddSystem(List<string> systemType = null)
        {
            TestLog log = TestLog.GetInstance();
            List<string> systems = new List<string>();
            if (systemType == null)
            {
                Dictionary<string, string> dic = HelperAdapter.Load(ConfigType.ESIService);
                string[] systemTypes = dic["SystemType"].Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string type in systemTypes)
                {
                    systems.Add(type);
                }
            }
            else
            {
                systems.AddRange(systemType);
            }

            GetEmcSystem getSystem = new GetEmcSystem();
            string result = getSystem.RunCMD(psMachine);
            List<SortedList<string, string>> systemList = null;
            if (!string.IsNullOrEmpty(result))
            {
                systemList = HelperAdapter.GenerateKeyValuePairsList(result);
            }

            foreach (string type in systems)
            {
                bool systemExist = false;

                if (systemList != null)
                {
                    foreach (SortedList<string, string> keyValue in systemList)
                    {
                        if (keyValue["SystemType"] == type)
                        {
                            systemExist = true;
                            break;
                        }
                    }
                }
                if (systemExist == false)
                {
                    string paramS = HelperAdapter.GetParameter("CreationParameters");
                    string creationParameters = HelperAdapter.GenerateCreationParameters(type, paramS);
                    TestSetup.RunPSCMD(creationParameters);
                    AddEmcSystem system = new AddEmcSystem(null, null, paramS, type, type.ToLower());
                    system.RunCMD(psMachine);
                }
            }
            
        }

        public static List<string> GetSystem(string serviceUrl = null)
        {
            List<string> systemType = new List<string>();

            if (serviceUrl == null)
            {
                serviceUrl = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
            }
            GetEmcSystem systems = new GetEmcSystem(null, serviceUrl);
            string result = systems.RunCMD(psMachine);

            List<SortedList<string, string>> systemsList = HelperAdapter.GenerateKeyValuePairsList(result);
            if (systemsList != null)
            {
                foreach (SortedList<string, string> system in systemsList)
                {
                    systemType.Add(system["SystemType"]);
                }
            }
            return systemType;
        }
        /// <summary>
        /// RemoveSystem
        ///     Remove All Registered Storage System
        /// </summary>
        public static void RemoveSystem()
        {
            RunPSCMD("Get-EmcSystem|Remove-EmcSystem -Force");
        }


        # region Common functions: GetParameterValue, GetPropertyValue
        /// <summary>
        /// The method is used to get value of parameter which is used in the powershell session.
        /// </summary>
        /// <param name="parameter">The parameter name defined in PSParameterConfig fiel.</param>
        /// <param name="parameterName">The parameter name defined in PS section.</param>
        /// <returns>The value for the parameter in the powershell session.</returns>
        public static string GetParameterValue(string parameter, string parameterName = null)
        {
            if (parameterName == null)
            {
                parameterName = HelperAdapter.GetParameter(parameter);
            }
            List<string> ps = new List<string>();
            ps.Add(parameterName);
            string parameterValue = psMachine.RunScript(ps, new List<PSParam> { }).OutStr;
            return parameterValue;
        }

        /// <summary>
        /// GetPropertyValue
        /// </summary>
        /// <param name="prefix">prefix string</param>
        /// <param name="property">property of an instance</param>
        /// <returns>property value string</returns>
        public static string GetPropertyValue(string prefix, string property = null)
        {
            List<string> ps = new List<string>();

            if (property != null)
            {
                ps.Add(prefix + "." + property);
            }
            else
            {
                ps.Add(prefix);
            }

            string result = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

            return result;
        }

        // <summary>
        /// RunPSCMD
        /// </summary>
        /// <param name="cmd">PowerShell cmd</param>
        /// <returns>command result</returns>
        public static string RunPSCMD(string cmd)
        {
            List<string> ps = new List<string>();

            ps.Add(cmd);

            string result = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();

            return result;
        }
        
        /// <summary>
        /// GetValue
        ///     Get the result of a Powershell command
        ///     Catch the exception
        /// </summary>
        /// <param name="cmd">command string</param>
        /// <returns>cmd output</returns>
        public static string GetValue(string cmd)
        {
            string result = null;
            List<string> ps = new List<string>();

            ps.Add(cmd);

            try
            {
                result = psMachine.RunScript(ps, new List<PSParam>()).OutStr.Trim();
            }
            catch
            {
            }

            return result;
        }

        # endregion

        #region Interface for Ex 
        /// <summary>
        /// The method is used to encapsulate Get-EmcEntity,
        /// </summary>
        /// <param name="entityClass">entity class name</param>
        /// <param name="entityID">entity id</param>
        /// <returns>the instance of get-emcentity</returns>
        public static GetEmcEntity GetEmcEntityEx(string entityClass=null, string entityID=null)
        {
            GetEmcEntity getEntity = new GetEmcEntity(null, null, null, entityID, null, null, null, null, null, entityClass);
            return getEntity;
        }

        public static GetEmcEntityRelationship GetEmcEntityRelationshipEx(string entityid = null, string outgoingRelation = null,
            string incomingRelation = null)
        {
            GetEmcEntityRelationship getRelation = new GetEmcEntityRelationship(null, null, null, null, null, null, null, null, outgoingRelation,
                entityid, incomingRelation);
            return getRelation;
        }
        #endregion

        # region Get Refresh Interval
        /// <summary>
        /// GetRefreshInterval
        ///     Get Refresh Interval in Minutes
        /// </summary>
        /// <param name="serviceUrl">service url string</param>
        /// <returns>refresh interval in minutes</returns>
        public static string GetRefreshInterval(string serviceUrl = null)
        {
            GetEmcServicePolicy servicePolicy = new GetEmcServicePolicy(null, serviceUrl);
            servicePolicy.PrefixString = HelperAdapter.GetParameter("ServicePolicy");
            servicePolicy.RunCMD(psMachine, true);
            return  TestSetup.GetPropertyValue(servicePolicy.PrefixString, "SystemRefreshIntervalMinutes");
        }
        # endregion
    }        
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcUserTest: test class for Get-EmcUser cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcUserTest
    {
        public GetEmcUserTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string serviceUrlString;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            serviceUrlString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("URL", ConfigType.ESIService));
            TestSetup.CleanSecurityAccountEnvironment(serviceUrlString);
            TestSetup.SetSecurityAccountEnvironment(serviceUrlString);
            TestSetup.SetSecurityAccountEnvironment(null);
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            TestSetup.CleanSecurityAccountEnvironment(serviceUrlString);
            TestSetup.CleanSecurityAccountEnvironment(null);
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);

            try
            {
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");
            
            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcUser instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcUser instance</returns>  
        public GetEmcUser ParseCmd(string cmd)
        {
            #region AutoGenerate
            string pattern = null;
            string role = null;
            string silent = null;
            string serviceurl = null;


            string cmdString = cmd;
   
            #endregion
            string roleString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("RoleNames", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            string nameString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("UserNames", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));

            if (cmd.IndexOf("$role", StringComparison.OrdinalIgnoreCase) > 0)
            {
                role = roleString;
                cmd = cmd.Replace("$Role", role);
            }
            if (cmd.IndexOf("$Pattern", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pattern = nameString;
                cmd = cmd.Replace("$Pattern", pattern);
            }
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                serviceurl = serviceUrlString;
                cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }

            GetEmcUser instance = new GetEmcUser(pattern, role, silent,  serviceUrlString,cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcUser:
        ///    The method to implement Get-EmcUser poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcUserTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcUser cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcUserNegativeTestMethod:
        ///    The method to implement Get-EmcUser negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcUserNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcUser getemcuserClass = ParseCmd(cmd);

            try
            {
                getemcuserClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcuserClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

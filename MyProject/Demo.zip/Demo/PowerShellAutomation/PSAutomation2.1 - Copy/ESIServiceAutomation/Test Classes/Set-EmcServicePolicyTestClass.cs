using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// SetEmcServicePolicyTest: test class for Set-EmcServicePolicy cmdlet
    /// </summary>
    [TestClass]
    public partial class SetEmcServicePolicyTest
    {
        public SetEmcServicePolicyTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private string orignalRefreshInterval;
        private static string orignalRefreshIntervalOfServiceUrl;
        private static string serviceUrl;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            serviceUrl = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
            orignalRefreshInterval = TestSetup.GetRefreshInterval();
            orignalRefreshIntervalOfServiceUrl = TestSetup.GetRefreshInterval(serviceUrl);
            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            SetEmcServicePolicy servicePolicy1 = new SetEmcServicePolicy(orignalRefreshInterval);
            servicePolicy1.VerifyTheCMD(psMachine);
            SetEmcServicePolicy servicePolicy2 = new SetEmcServicePolicy(orignalRefreshIntervalOfServiceUrl, null, serviceUrl);
            servicePolicy2.VerifyTheCMD(psMachine);
            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);

            try
            {
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");
            
            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Set-EmcServicePolicy instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Set-EmcServicePolicy instance</returns>  
        public SetEmcServicePolicy ParseCmd(string cmd)
        {
            #region AutoGenerate
            string refreshintervalinminutes = null;
            string silent = null;
            string serviceurl = null;


            string cmdString = cmd;
   
            #endregion

			if (cmd.IndexOf("$refreshintervalinminutes", StringComparison.OrdinalIgnoreCase) > 0)
            {
                refreshintervalinminutes = HelperAdapter.GenerateRandomRefreshInterval().ToString();
                cmd = cmd.Replace("$RefreshIntervalInMinutes", refreshintervalinminutes);
            }

            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                serviceurl = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
                cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            SetEmcServicePolicy instance = new SetEmcServicePolicy(refreshintervalinminutes, silent, serviceurl, cmd);
            return instance;
        }


        /// <summary>  
        /// Set-EmcServicePolicy:
        ///    The method to implement Set-EmcServicePolicy poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcServicePolicyTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            SetEmcServicePolicy cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// SetEmcServicePolicyNegativeTestMethod:
        ///    The method to implement Set-EmcServicePolicy negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcServicePolicyNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            SetEmcServicePolicy setemcservicepolicyClass = ParseCmd(cmd);

            try
            {
                setemcservicepolicyClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", setemcservicepolicyClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

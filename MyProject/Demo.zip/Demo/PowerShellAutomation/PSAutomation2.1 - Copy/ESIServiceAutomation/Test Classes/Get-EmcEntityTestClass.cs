using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcEntityTest: test class for Get-EmcEntity cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcEntityTest
    {
        public GetEmcEntityTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string systemType;
        private static string className;
        private static string entityIdGlo;
        private static string patternGlo;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            className = null;
            TestSetup.SetEmcServiceEnvironment();

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIServicePSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);

            systemType = HelperAdapter.Load(ConfigType.ESIService)["SystemType"];

            try
            {
               // TestSetup.AddSystem(); // THe system should be added firstly.
                TestSetup.GetValue("Import-Module ESIPSTOOLKIT");
                // TestSetup.RunPSCMD("Import-Module ESIPSTOOLKIT");
                TestSetup.RunPSCMD("Disconnect-EmcSystem -Force");
                string storageSystems = HelperAdapter.GetParameter("SystemType", ConfigType.ESIService);
                string[] systems = storageSystems.Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);
                foreach (string temp in systems)
                {
                    string prefix = HelperAdapter.GetParameter("CreationParameters");
                    string creationParameter = HelperAdapter.GenerateCreationParameters(temp, prefix);
                    TestSetup.RunPSCMD(creationParameter);
                    TestSetup.RunPSCMD(string.Format("{0} = Connect-EmcSystem  -CreationParameters {1} -SystemType {2} -Refresh", HelperAdapter.GetParameter("System"), prefix, temp));
                }
                SetEmcServicePolicy setPolicy = new SetEmcServicePolicy("2000");
                setPolicy.RunCMD(psMachine);
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            TestSetup.RunPSCMD("Disconnect-EmcSystem -Force");
            SetEmcServicePolicy setPolicy = new SetEmcServicePolicy("2");
            setPolicy.RunCMD(psMachine);
            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcEntity instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcEntity instance</returns>  
        public GetEmcEntity ParseCmd(string cmd)
        {
            #region AutoGenerate
            string pattern = null;
            string silent = null;
            string serviceurl = null;
            string entityid = null;
            string relatedtarget = null;
            string relatedsource = null;
            string targetclass = null;
            string sourceclass = null;
            string relationship = null;
            string classStr = null;


            string cmdString = cmd;
   
            #endregion

            string classes = TestSetup.GetValue("Get-EmcEntityClass");
            string[] entityClasses = classes.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
            
            
            if (className != null)
            {
                classStr = className;
                cmd = cmd.Replace("$" + className, classStr);
            }
            if (cmd.IndexOf("$EntityId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                entityid = entityIdGlo;
                cmd=cmd.Replace("$EntityId", entityid);
            }
            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                serviceurl = HelperAdapter.GetParameter("URL", ConfigType.ESIService).Split(',')[0]; //ServiceUrl is only for local when get-emcentity
                cmd=cmd.Replace("$ServiceUrl", serviceurl);
            }
            if (cmd.IndexOf("$Pattern", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pattern = "*";
                string patternTemp = pattern;
                if (cmd.IndexOf("-Pattern", StringComparison.OrdinalIgnoreCase) <0)
                {
                    patternTemp = "-Pattern " + pattern;
                }
                cmd = cmd.Replace("$Pattern", patternTemp);
            }
            if (cmd.IndexOf("RelatedTarget", StringComparison.OrdinalIgnoreCase) > 0)
            {
                relatedtarget = "relativeTarget";
            }
            if (cmd.IndexOf("RelatedSource", StringComparison.OrdinalIgnoreCase) > 0)
            {
                relatedsource = "RelativeSource";
            }
            if (cmd.IndexOf("$TargetClass", StringComparison.OrdinalIgnoreCase) > 0)
            {
                GetEmcEntityRelationship getRelation = TestSetup.GetEmcEntityRelationshipEx(entityIdGlo, "OutgoingRelation");
                string relationResults = getRelation.RunCMD(psMachine);
                List<SortedList<string, string>> relationKeyValueList = HelperAdapter.GenerateKeyValuePairsList(relationResults);
                if (relationKeyValueList==null)
                {
                    log.LogInfo("No Target class for the entity");
                    log.BypassTest();
                }
                targetclass = relationKeyValueList[HelperAdapter.GetRandomInt(relationKeyValueList.Count)]["TargetClass"];
                cmd = cmd.Replace("$TargetClass", targetclass);
            }
            if (cmd.IndexOf("$SourceClass", StringComparison.OrdinalIgnoreCase) > 0)
            {
                GetEmcEntityRelationship getRelation = TestSetup.GetEmcEntityRelationshipEx(entityIdGlo, null,"IncomingRelation");
                string relationResults = getRelation.RunCMD(psMachine);
                List<SortedList<string, string>> relationKeyValueList = HelperAdapter.GenerateKeyValuePairsList(relationResults);
                if (relationKeyValueList==null)
                {
                    log.LogInfo("No Source class for the entity");
                    log.BypassTest();
                }
                sourceclass  = relationKeyValueList[HelperAdapter.GetRandomInt(relationKeyValueList.Count)]["SourceClass"];
                cmd = cmd.Replace("$SourceClass", sourceclass);
            }
            if (cmd.IndexOf("$Relationship", StringComparison.OrdinalIgnoreCase) > 0)
            {
                GetEmcEntityRelationship getRelation = TestSetup.GetEmcEntityRelationshipEx(entityIdGlo);
                string relationResults = getRelation.RunCMD(psMachine);
                List<SortedList<string, string>> relationKeyValueList = HelperAdapter.GenerateKeyValuePairsList(relationResults);
                if (relationKeyValueList.Count == 0)
                {
                    log.LogInfo("No RelationShip for the entity");
                    log.BypassTest();
                }
                relationship  = relationKeyValueList[HelperAdapter.GetRandomInt(relationKeyValueList.Count)]["Name"];
                cmd = cmd.Replace("$Relationship", relationship);
            }


            GetEmcEntity instance = new GetEmcEntity(pattern, serviceurl, silent, entityid, relatedtarget, relatedsource, targetclass, sourceclass,
                relationship, classStr, cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcEntity:
        ///    The method to implement Get-EmcEntity poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcEntityTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            PrepareEnvironment(cmd);

            GetEmcEntity cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcEntityNegativeTestMethod:
        ///    The method to implement Get-EmcEntity negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcEntityNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            PrepareEnvironment(cmd);

            bool caseFail = false;

            GetEmcEntity getemcentityClass = ParseCmd(cmd);

            try
            {
                getemcentityClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcentityClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }

        private void PrepareEnvironment(string cmd)
        {
            className = null;
            string classes = TestSetup.GetValue("Get-EmcEntityClass");
            string[] entityClasses = classes.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);

            foreach (string entityClass in entityClasses)
            {
                if (cmd.IndexOf("$" + entityClass, StringComparison.OrdinalIgnoreCase) > 0)
                {
                    className = entityClass;
                    break;
                }
            }


            GetEmcEntity entity = TestSetup.GetEmcEntityEx(className);

            entity.PrefixString = HelperAdapter.GetParameter("Entity") + className;
            string result = entity.RunCMD(psMachine);

            if (!string.IsNullOrEmpty(result))
            {
                if(!string.IsNullOrEmpty(TestSetup.GetPropertyValue(entity.PrefixString, "Count")))
                {
                    int count = int.Parse(TestSetup.GetPropertyValue(entity.PrefixString, "Count"));
                    int rd = (new Random()).Next(count);
                    TestSetup.RunPSCMD(entity.PrefixString + "=" + entity.PrefixString + "[" + rd + "]");
                    entityIdGlo = TestSetup.GetPropertyValue(entity.PrefixString, "EntityId");
                    patternGlo = entityIdGlo;
                }
            }
        }
    }
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{
    /// <summary>
    /// RemoveEmcSystemTest: test class for Remove-EmcSystem cmdlet
    /// </summary>
    [TestClass]
    public partial class RemoveEmcSystemTest
    {
        public RemoveEmcSystemTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static List<string> systems;
        private static string systemType;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            TestSetup.SetEmcServiceEnvironment();

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            TestSetup.RemoveSystem();

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);
            systems = TestSetup.GetSystem();
            TestSetup.RemoveSystem();

            try
            {
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            TestSetup.AddSystem(systems);
            SetEmcServicePolicy setPolicy = new SetEmcServicePolicy("1");
            setPolicy.RunCMD(psMachine);
            Thread.Sleep(10000);
            while (true)
            {
                if (TestSetup.GetClassEntity() == null)
                {
                    Thread.Sleep(10000);
                    continue;
                }
                else
                {
                    setPolicy = new SetEmcServicePolicy("5");
                    setPolicy.RunCMD(psMachine);
                    break;
                }
            }

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Remove-EmcSystem instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Remove-EmcSystem instance</returns>  
        public RemoveEmcSystem ParseCmd(string cmd)
        {
            #region AutoGenerate
            string system = null;
            string force = null;
            string silent = null;
            string serviceurl = null;
            string whatif = null;
            string systemname = null;


            #endregion

            GetEmcSystem getSystem = new GetEmcSystem();
            getSystem.PrefixString = HelperAdapter.GetParameter("System");
            getSystem.RunCMD(psMachine);
            string count = TestSetup.GetPropertyValue(getSystem.PrefixString, "Count");
            if (!string.IsNullOrEmpty(count))
            {
                for (int i = 0; i < int.Parse(count); i++)
                {
                    string provider = TestSetup.GetPropertyValue(getSystem.PrefixString + "[" + i + "]", "SystemType");
                    if (provider == systemType)
                    {
                        TestSetup.RunPSCMD(HelperAdapter.GetParameter("System") + "=" + HelperAdapter.GetParameter("System") + "[" + i + "]");
                        break;
                    }
                }
            }

            if (cmd.IndexOf("$" + systemType + "Name", StringComparison.OrdinalIgnoreCase) > 0)
            {
                systemname = TestSetup.GetPropertyValue(HelperAdapter.GetParameter("System"), "FriendlyName");
                cmd = cmd.Replace("$" + systemType + "Name", systemname);
            }

			if (cmd.IndexOf("$" + systemType, StringComparison.OrdinalIgnoreCase) > 0)
            {
                system = HelperAdapter.GetParameter("System");
                cmd = cmd.Replace("$" + systemType, system);
            }
			if (cmd.IndexOf("force", StringComparison.OrdinalIgnoreCase) > 0)
            {
                force = "Force";
            }
			if (cmd.IndexOf("whatif", StringComparison.OrdinalIgnoreCase) > 0)
            {
                whatif = "WhatIf";
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                SetEmcServiceUrl url = new SetEmcServiceUrl("http://test:55555");
                url.RunCMD(psMachine);

                serviceurl = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
                cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }

            RemoveEmcSystem instance = new RemoveEmcSystem(system, force, silent, serviceurl, whatif, systemname,  cmd);
            return instance;
        }


        /// <summary>  
        /// Remove-EmcSystem:
        ///    The method to implement Remove-EmcSystem poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            PrepareEnvironmet(cmd);

            RemoveEmcSystem cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// RemoveEmcSystemNegativeTestMethod:
        ///    The method to implement Remove-EmcSystem negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void RemoveEmcSystemNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            PrepareEnvironmet(cmd);

            RemoveEmcSystem removeemcsystemClass = ParseCmd(cmd);

            try
            {
                removeemcsystemClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", removeemcsystemClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }

        private void PrepareEnvironmet(string cmd)
        {
            try
            {
                string[] systemTypes = HelperAdapter.GetParameter("SupportedSystemType", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries);

                foreach (string type in systemTypes)
                {
                    if (cmd.Contains("$" + type + "Name") || cmd.Contains("$" + type + " "))
                    {
                        systemType = type;
                        break;
                    }
                }

                if (systemType != null)
                {
                    List<string> temp = new List<string>();
                    temp.Add(systemType);
                    TestSetup.AddSystem(temp);
                }
                else
                {
                    TestSetup.AddSystem(systems);
                }
            }
            catch(PSException e)
            {
                log.BypassTest(e);
            }
        }
    }
}

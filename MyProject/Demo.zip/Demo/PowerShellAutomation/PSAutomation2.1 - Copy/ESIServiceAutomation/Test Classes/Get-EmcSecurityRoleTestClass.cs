using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcSecurityRoleTest: test class for Get-EmcSecurityRole cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcSecurityRoleTest
    {
        public GetEmcSecurityRoleTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string serviceUrlString;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");
            serviceUrlString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("URL", ConfigType.ESIService));
            TestSetup.CleanSecurityAccountEnvironment(serviceUrlString);
            TestSetup.SetSecurityAccountEnvironment(serviceUrlString);
            TestSetup.SetSecurityAccountEnvironment(null);
            log.LogInfo("--------Test Init End---------");
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");
            TestSetup.CleanSecurityAccountEnvironment(serviceUrlString);
            TestSetup.CleanSecurityAccountEnvironment(null);
            log.LogInfo("--------Test Clean Up End---------");
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);

            try
            {
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");

        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcSecurityRole instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcSecurityRole instance</returns>  
        public GetEmcSecurityRole ParseCmd(string cmd)
        {
            #region AutoGenerate
            string id = null;
            string silent = null;
            string serviceurl = null;
                    
            string cmdString = cmd;
   
            #endregion

            string idString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("RoleNames", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));

			if (cmd.IndexOf("$id", StringComparison.OrdinalIgnoreCase) > 0)
            {
                id = idString;
		        cmd = cmd.Replace("$Id", id);
            }
			if (cmd.IndexOf("$silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
		        cmd = cmd.Replace("$Silent", silent);
            }


            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                serviceurl = serviceUrlString;
                cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }

            GetEmcSecurityRole instance = new GetEmcSecurityRole(id, silent,  serviceurl,cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcSecurityRole:
        ///    The method to implement Get-EmcSecurityRole poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSecurityRoleTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcSecurityRole cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// GetEmcSecurityRoleNegativeTestMethod:
        ///    The method to implement Get-EmcSecurityRole negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSecurityRoleNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcSecurityRole getemcsecurityroleClass = ParseCmd(cmd);

            try
            {
                getemcsecurityroleClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcsecurityroleClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

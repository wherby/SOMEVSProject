using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// SetEmcServiceUrlTest: test class for Set-EmcServiceUrl cmdlet
    /// </summary>
    [TestClass]
    public partial class SetEmcServiceUrlTest
    {
        public SetEmcServiceUrlTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESISERVICEPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);


            try
            {
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");
            
            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Set-EmcServiceUrl instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Set-EmcServiceUrl instance</returns>  
        public SetEmcServiceUrl ParseCmd(string cmd)
        {
            #region AutoGenerate
            string serviceurl = null;
            string silent = null;
            string ipaddress = null;
            string port = null;
            string ssl = null;
            string clear = null;


            string cmdString = cmd;
   
            #endregion

            string ipaddressString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("URLIP", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            string portString = HelperAdapter.GenerateRandomValue(HelperAdapter.GetParameter("URLPort", ConfigType.ESIService).Split(new char[] { ',' }, StringSplitOptions.RemoveEmptyEntries));
            string serviceurlString = @"http://" + ipaddressString + ":" + portString;

			if (cmd.IndexOf("$serviceurl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                serviceurl = serviceurlString;
		        cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }
			if (cmd.IndexOf("$silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
		        cmd = cmd.Replace("$Silent", silent);
            }
			if (cmd.IndexOf("$ipaddress", StringComparison.OrdinalIgnoreCase) > 0)
            {
                ipaddress = ipaddressString;
		        cmd = cmd.Replace("$IpAddress", ipaddress);
            }
			if (cmd.IndexOf("$port", StringComparison.OrdinalIgnoreCase) > 0)
            {
                port = portString;
		        cmd = cmd.Replace("$Port", port);
            }
			if (cmd.IndexOf("ssl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                ssl = "SSL";
            }
            if (cmd.IndexOf("clear", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clear = "Clear";
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            SetEmcServiceUrl instance = new SetEmcServiceUrl(serviceurl, silent, ipaddress, port, ssl,  clear, cmd);
            return instance;
        }


        /// <summary>  
        /// Set-EmcServiceUrl:
        ///    The method to implement Set-EmcServiceUrl poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcServiceUrlTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            SetEmcServiceUrl cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine);
        }

        /// <summary>  
        /// SetEmcServiceUrlNegativeTestMethod:
        ///    The method to implement Set-EmcServiceUrl negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void SetEmcServiceUrlNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            SetEmcServiceUrl setemcserviceurlClass = ParseCmd(cmd);

            try
            {
                setemcserviceurlClass.VerifyTheCMD(psMachine);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", setemcserviceurlClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

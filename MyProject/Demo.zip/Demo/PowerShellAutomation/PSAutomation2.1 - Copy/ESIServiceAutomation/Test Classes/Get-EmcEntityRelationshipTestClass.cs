using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcEntityRelationshipTest: test class for Get-EmcEntityRelationship cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcEntityRelationshipTest
    {
        public GetEmcEntityRelationshipTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string> randomRelationship;
        private static List<SortedList<string, string>> relationshipsList;
        private static Dictionary<string, string> relationshipDic;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            Random rd = new Random();
            randomRelationship = relationshipsList[rd.Next(relationshipsList.Count)];

            TestSetup.SetEmcServiceEnvironment();

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);
            TestSetup.AddSystem();

            try
            {
                TestSetup.SetEmcServiceEnvironment();

                GetEmcEntityRelationship getRelationship = new GetEmcEntityRelationship();
                getRelationship.PrefixString = HelperAdapter.GetParameter("Relationship");
                string result = getRelationship.RunCMD(psMachine, true);
                relationshipsList = HelperAdapter.GenerateKeyValuePairsList(result);
                relationshipDic = new Dictionary<string, string>();
                relationshipDic.Add("StorageSystem_Enclosure", "LogicalPhysicalAssociation");
                relationshipDic.Add("LunStoragePool_DiskDrive", "LogicalPhysicalAssociation");
                relationshipDic.Add("Enclosure_StandbyPowerSupply", "PhysicalContainment");
                relationshipDic.Add("Enclosure_PowerSupply", "PhysicalContainment");
                relationshipDic.Add("Enclosure_LinkControlCard", "PhysicalContainment");
                relationshipDic.Add("Enclosure_DiskDrive", "PhysicalContainment");
                relationshipDic.Add("Enclosure_CoolingComponent", "PhysicalContainment");
                relationshipDic.Add("Enclosure_ServiceNodeContainer", "PhysicalContainment");
                relationshipDic.Add("ServiceNodeContainer_MemoryModule", "PhysicalContainment");
                relationshipDic.Add("ServiceNodeContainer_LunStorageServiceNode", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_FcStoragePort", "PhysicalContainment");
                relationshipDic.Add("Enclosure_LunStorageServiceNode", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_IscsiStoragePort", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_CPUModule", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_IOModule", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_MemoryModule", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_ManagementModule", "PhysicalContainment");
                relationshipDic.Add("LunStorageServiceNode_StoragePort", "PhysicalContainment");
                relationshipDic.Add("Enclosure_ManagementStorageServiceNode", "PhysicalContainment");
                relationshipDic.Add("Enclosure_CifsStorageServiceNode", "PhysicalContainment");
                relationshipDic.Add("CifsStorageServiceNode_IscsiStoragePort", "PhysicalContainment");
                relationshipDic.Add("CifsStorageServiceNode_MemoryModule", "PhysicalContainment");
                relationshipDic.Add("CifsStorageServiceNode_IOModule", "PhysicalContainment");
                relationshipDic.Add("Enclosure_NetworkSwitch", "PhysicalContainment");
                relationshipDic.Add("StorageSystem_LunStoragePool", "LogicalContainment");
                relationshipDic.Add("StorageSystem_ConcreteLun", "LogicalContainment");
                relationshipDic.Add("StorageSystem_LunMaskingView", "LogicalContainment");
                relationshipDic.Add("LunStoragePool_ConcreteLun", "LogicalContainment");
                relationshipDic.Add("StorageSystem_SnapshotPool", "LogicalContainment");
                relationshipDic.Add("StorageSystem_SnapshotLun", "LogicalContainment");
                relationshipDic.Add("StorageSystem_StorageManagementServiceEndpoint", "LogicalContainment");
                relationshipDic.Add("StorageSystem_CifsStoragePool", "LogicalContainment");
                relationshipDic.Add("StorageSystem_CifsSharedFolder", "LogicalContainment");
                relationshipDic.Add("CifsStoragePool_CifsSharedFolder", "LogicalContainment");
                relationshipDic.Add("LunMaskingView_ConcreteLun", "LogicalAssociation");
                relationshipDic.Add("LunMaskingView_SnapshotLun", "LogicalAssociation");
                relationshipDic.Add("ConcreteLun_SnapshotLun", "LogicalAssociation");
            }
            catch
            {
                log.BypassTest();
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");
            
            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcEntityRelationship instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcEntityRelationship instance</returns>  
        public GetEmcEntityRelationship ParseCmd(string cmd)
        {
            #region AutoGenerate
            string namesonly = null;;
            string relationship = null;
            string sourceid = null;
            string targetid = null;
            string sourceclass = null;
            string targetclass = null;
            string serviceurl = null;
            string silent = null;
            string outgoing = null;
            string entityid = null;
            string incoming = null;

            #endregion

            if (cmd.IndexOf("namesonly", StringComparison.OrdinalIgnoreCase) > 0)
            {
                namesonly = "NamesOnly";
            }

            if (cmd.IndexOf("$Relationship", StringComparison.OrdinalIgnoreCase) > 0)
            {
                relationship = randomRelationship["Name"];
                cmd = cmd.Replace("$Relationship", relationship);
            }

            if (cmd.IndexOf("$SourceId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourceid = randomRelationship["SourceId"];
                cmd = cmd.Replace("$SourceId", sourceid);
            }

            if (cmd.IndexOf("$TargetId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                targetid = randomRelationship["TargetId"];
                cmd = cmd.Replace("$TargetId", targetid);
            }

            if (cmd.IndexOf("$SourceClass", StringComparison.OrdinalIgnoreCase) > 0)
            {
                sourceclass = randomRelationship["SourceClass"];
                cmd = cmd.Replace("$SourceClass", sourceclass);
            }

            if (cmd.IndexOf("$TargetClass", StringComparison.OrdinalIgnoreCase) > 0)
            {
                targetclass = randomRelationship["TargetClass"];
                cmd = cmd.Replace("$TargetClass", targetclass);
            }

            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                SetEmcServiceUrl seturl = new SetEmcServiceUrl("http://test:55555");
                seturl.RunCMD(psMachine);
                serviceurl = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
                cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (cmd.IndexOf("Outgoing", StringComparison.OrdinalIgnoreCase) > 0)
            {
                outgoing = "Outgoing";
            }

            if (cmd.IndexOf("Incoming", StringComparison.OrdinalIgnoreCase) > 0)
            {
                incoming = "Incoming";
            }

            if (cmd.IndexOf("$EntityId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                entityid = randomRelationship["SourceId"];
                if (incoming != null)
                {
                    entityid = randomRelationship["TargetId"];
                }

                cmd = cmd.Replace("$EntityId", entityid);
            }

            GetEmcEntityRelationship instance = new GetEmcEntityRelationship(namesonly, relationship, sourceid, targetid, sourceclass, targetclass, serviceurl, silent, outgoing, entityid, incoming, cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcEntityRelationship:
        ///    The method to implement Get-EmcEntityRelationship poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcEntityRelationshipTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcEntityRelationship cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, relationshipsList, relationshipDic);
        }

        /// <summary>  
        /// GetEmcEntityRelationshipNegativeTestMethod:
        ///    The method to implement Get-EmcEntityRelationship negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcEntityRelationshipNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcEntityRelationship getemcentityrelationshipClass = ParseCmd(cmd);

            try
            {
                getemcentityrelationshipClass.VerifyTheCMD(psMachine, relationshipsList, relationshipDic);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcentityrelationshipClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

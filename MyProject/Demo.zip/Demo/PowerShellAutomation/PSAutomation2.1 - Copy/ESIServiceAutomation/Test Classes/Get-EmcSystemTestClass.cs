using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;

namespace PowerShellAutomation
{
    /// <summary>
    /// GetEmcSystemTest: test class for Get-EmcSystem cmdlet
    /// </summary>
    [TestClass]
    public partial class GetEmcSystemTest
    {
        public GetEmcSystemTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static List<string> systems;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            TestSetup.SetEmcServiceEnvironment();

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            log.LogInfo("--------Test Clean Up End---------");            
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {

            // Get log instance
            log = TestLog.GetInstance(testContext);

            log.LogInfo("--------Class Init Start---------");
            
            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCServiceStorage(psMachine);
            systems = TestSetup.GetSystem();
            TestSetup.RemoveSystem();

            systems = new List<string>();
            string[] types = HelperAdapter.GetParameter("SupportedSystemType", ConfigType.ESIService).Split(new char[]{','}, StringSplitOptions.RemoveEmptyEntries);
            foreach (string type in types)
            {
                try
                {
                    List<string> temp = new List<string>();
                    temp.Add(type);
                    TestSetup.AddSystem(temp);
                    systems.Add(type);
                }
                catch
                {
                    log.LogWarning( "Can not add " + type + " storage system");
                }
            }


            log.LogInfo("--------Class Init End---------");
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start---------");

            TestSetup.RemoveSystem();
            TestSetup.AddSystem(systems);
            SetEmcServicePolicy setPolicy = new SetEmcServicePolicy("1");
            setPolicy.RunCMD(psMachine);
            Thread.Sleep(10000);
            while (true)
            {
                if (TestSetup.GetClassEntity() == null)
                {
                    Thread.Sleep(10000);
                    continue;
                }
                else
                {
                    setPolicy = new SetEmcServicePolicy("5");
                    setPolicy.RunCMD(psMachine);
                    break;
                }
            }

            log.LogInfo("--------Class Clean Up End---------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Get-EmcSystem instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Get-EmcSystem instance</returns>  
        public GetEmcSystem ParseCmd(string cmd)
        {
            #region AutoGenerate
            string silent = null;
            string serviceurl = null;

            #endregion

			

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            if (cmd.IndexOf("$ServiceUrl", StringComparison.OrdinalIgnoreCase) > 0)
            {
                SetEmcServiceUrl url = new SetEmcServiceUrl("http://test:55555");
                url.RunCMD(psMachine);

                serviceurl = HelperAdapter.GetParameter("URL", ConfigType.ESIService);
                cmd = cmd.Replace("$ServiceUrl", serviceurl);
            }

            GetEmcSystem instance = new GetEmcSystem(silent, serviceurl, cmd);
            return instance;
        }


        /// <summary>  
        /// Get-EmcSystem:
        ///    The method to implement Get-EmcSystem poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            GetEmcSystem cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, systems);
        }

        /// <summary>  
        /// GetEmcSystemNegativeTestMethod:
        ///    The method to implement Get-EmcSystem negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void GetEmcSystemNegativeTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            GetEmcSystem getemcsystemClass = ParseCmd(cmd);

            try
            {
                getemcsystemClass.VerifyTheCMD(psMachine, systems);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", getemcsystemClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

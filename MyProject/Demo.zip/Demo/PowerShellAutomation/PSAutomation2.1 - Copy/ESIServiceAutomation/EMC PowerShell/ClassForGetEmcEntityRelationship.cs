using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcEntityRelationship : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate

        private string namesonlyString = null;
        private string relationshipString = null;
        private string sourceidstring = null;
        private string targetidString = null;
        private string sourceclassString = null;
        private string targetclassString = null;
        private string serviceurlString = null;
        private string silentString = null;
        private string outgoingString = null;
        private string entityidString = null;
        private string incomingString = null;

        
        /// <summary>
        /// GetEmcEntityRelationship
        ///     Constructor for GetEmcEntityRelationship class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcEntityRelationship( string namesonly = null, string relationship = null, string sourceid = null, 
            string targetid = null, string sourceclass = null, string targetclass = null, string serviceurl = null,
            string silent = null, string outgoing = null, string entityid = null, string incoming = null, string cmd = null)
        {
            namesonlyString = namesonly;
            relationshipString = relationship;
            sourceidstring = sourceid;
            targetidString = targetid;
            sourceclassString = sourceclass;
            targetclassString = targetclass;
            serviceurlString = serviceurl;
            silentString = silent;
            outgoingString = outgoing;
            entityidString = entityid;
            incomingString = incoming;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcEntityRelationship");

            if (namesonlyString != null)
            {
                sb.AppendFormat(" -NamesOnly");
            }
            if (relationshipString != null)
            {
                sb.AppendFormat(" -Relationship {0}", relationshipString);
            }
            if (sourceidstring != null)
            {
                sb.AppendFormat(" -SourceId {0}", sourceidstring);
            }
            if (targetidString != null)
            {
                sb.AppendFormat(" -TargetId {0}", targetidString);
            }
            if (sourceclassString != null)
            {
                sb.AppendFormat(" -SourceClass {0}", sourceclassString);
            }
            if (targetclassString != null)
            {
                sb.AppendFormat(" -TargetClass {0}", targetclassString);
            }
            if (serviceurlString != null)
            {
                sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }
            if (silentString != null)
            {
                sb.AppendFormat(" -Silent");
            }
            if (outgoingString != null)
            {
                sb.AppendFormat(" -Outgoing");
            }
            if (entityidString != null)
            {
                sb.AppendFormat(" -EntityId {0}", entityidString);
            }
            if (incomingString != null)
            {
                sb.AppendFormat(" -Incoming");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcEntityRelationship commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcEntityRelationship</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, List<SortedList<string, string>> relationshipsList, Dictionary<string, string> relationshipDic)
        {
            string result = RunCMD(psMachine, true);
            TestSetup.SetEmcServiceEnvironment();
            List<SortedList<string, string>> relationships = HelperAdapter.GenerateKeyValuePairsList(result);
            if (namesonlyString != null)
            {
                CmdString = CmdString.Replace("-NamesOnly", "");
                result = RunCMD(psMachine, true);
                List<SortedList<string, string>> temps = HelperAdapter.GenerateKeyValuePairsList(result);
                int relationCount = 0;
                for (int i = 0; i < relationships[0].Keys.Count; i++)
                {
                    bool foundRelation = false;
                    for (int j = 0; j < temps.Count; j++)
                    {
                        if (relationships[0].Keys[i] == temps[j]["Name"])
                        {
                            relationCount++;
                            foundRelation = true;
                        }
                    }
                    log.AreEqual<bool>(true, foundRelation, "Verify foundRelation");
                }
                log.AreEqual<int>(temps.Count, relationCount, "Verify relationship count");
                relationships = temps;
            }
            
            log.AreEqual<bool>(true, relationships.Count <= relationshipsList.Count, "Verify relationships count");

            foreach (SortedList<string, string> relationship in relationships)
            {
                VerifyFields(psMachine, relationship, relationshipsList, relationshipDic);
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, SortedList<string, string> relationship, List<SortedList<string, string>> relationshipsList, Dictionary<string, string> relationshipDic)
        {
            
            if (relationshipString != null)
            {
                log.AreEqual<string>(relationshipString, relationship["Name"], "Verify relationship's name");
            }

            if (sourceidstring != null)
            {
                log.AreEqual<string>(sourceidstring, relationship["SourceId"], "Verify relationship's SourceId");
            }

            if (targetidString != null)
            {
                log.AreEqual<string>(targetidString, relationship["TargetId"], "Verify relationship's TargetId");
            }

            if (sourceclassString != null)
            {
                log.AreEqual<string>(sourceclassString, relationship["SourceClass"], "Verify relationship's SourceClass");
            }

            if (targetclassString != null)
            {
                log.AreEqual<string>(targetclassString, relationship["TargetClass"], "Verify relationship's TargetClass");
            }

            if (entityidString != null)
            {
                if (incomingString != null && outgoingString == null)
                {
                    log.AreEqual<string>(entityidString, relationship["TargetId"], "Verify relationship's entityid");
                }
                else if (incomingString == null && outgoingString != null)
                {
                    log.AreEqual<string>(entityidString, relationship["SourceId"], "Verify relationship's entityid");
                }
                else
                {
                    try
                    {
                        log.AreEqual<string>(entityidString, relationship["TargetId"], "Verify relationship's entityid");
                    }
                    catch
                    {
                        log.AreEqual<string>(entityidString, relationship["SourceId"], "Verify relationship's entityid");
                    }
                }
            }

            if (namesonlyString == null)
            {
                if (relationship["Name"] == "Orphaned")
                {
                    log.AreEqual<string>("StorageSystem", relationship["SourceClass"], "Verify source class");
                    log.AreEqual<string>("CifsSharedFolder", relationship["TargetClass"], "Verify target class");
                }
                else
                {
                    log.LogInfo("Verify " + relationship["SourceClass"] + ":" + relationship["TargetClass"] + " relationship " + relationship["Name"] + " exists in dic");
                    log.AreEqual<string>(relationshipDic[relationship["SourceClass"] + "_" + relationship["TargetClass"]], relationship["Name"]);
                }
            }
        }
    }
}
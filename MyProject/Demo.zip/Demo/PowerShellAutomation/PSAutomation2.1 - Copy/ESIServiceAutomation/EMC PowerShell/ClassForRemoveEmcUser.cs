using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class RemoveEmcUser : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string nameString = null;
        private string roleString = null;
        private string silentString = null;
        private string serviceurlString = null;

        
        /// <summary>
        /// RemoveEmcUser
        ///     Constructor for RemoveEmcUser class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public RemoveEmcUser(string name = null, string role = null, string silent = null, string serviceurl = null,  string cmd = null)
        {

            nameString = name;
            roleString = role;
            silentString = silent;
            serviceurlString = serviceurl;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Remove-EmcUser");

			if (nameString != null)
            {
		        sb.AppendFormat(" -Name {0}", nameString);
            }
			if (roleString != null)
            {
		        sb.AppendFormat(" -Role {0}", roleString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (serviceurlString != null)
            {
		        sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Remove-EmcUser commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Remove-EmcUser</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            GetEmcUser getUser = new GetEmcUser(nameString, roleString,null,serviceurlString);
            bool isTheRoleDeleted = getUser.RunCMD(psMachine).Trim().Equals(string.Empty);
            log.AreEqual<bool>(true, isTheRoleDeleted, "The role is deleted");
        }
    }
}
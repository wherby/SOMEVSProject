using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class SetEmcServiceUrl : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string serviceurlString = null;
        private string silentString = null;
        private string ipaddressString = null;
        private string portString = null;
        private string sslString = null;
        private string clearString = null;

        
        /// <summary>
        /// SetEmcServiceUrl
        ///     Constructor for SetEmcServiceUrl class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcServiceUrl(string serviceurl = null, string silent = null, string ipaddress = null, string port = null, string ssl = null, string clear = null,  string cmd = null)
        {

            serviceurlString = serviceurl;
            silentString = silent;
            ipaddressString = ipaddress;
            portString = port;
            sslString = ssl;
            clearString = clear;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcServiceUrl");

			if (serviceurlString != null)
            {
		        sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (ipaddressString != null)
            {
		        sb.AppendFormat(" -IpAddress {0}", ipaddressString);
            }
			if (portString != null)
            {
		        sb.AppendFormat(" -Port {0}", portString);
            }
			if (sslString != null)
            {
		        sb.AppendFormat(" -SSL");
            }
			if (clearString != null)
            {
		        sb.AppendFormat(" -Clear");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Set-EmcServiceUrl commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Set-EmcServiceUrl</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            string result = RunCMD(psMachine, false);

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            GetEmcServiceConnectionOptions connection = new GetEmcServiceConnectionOptions();
            connection.PrefixString = HelperAdapter.GetParameter("Connection");
            connection.RunCMD(psMachine, true);
            string serviceURL = TestSetup.GetPropertyValue(connection.PrefixString, "ServiceURL");

            if (serviceurlString != null)
            {
                log.AreEqual(serviceurlString, serviceURL, "Service URL: ");
            }
            else if (ipaddressString != null && portString != null)
            {
                string url;
                if (sslString != null)
                {
                    url = "https://" + ipaddressString + ":" + portString;
                }
                else 
                {
                    url = "http://" + ipaddressString + ":" + portString;
                }
                log.AreEqual(url, serviceURL, "Service URL: ");
            }
            else if (clearString != null)
            {
                log.AreEqual("https://localhost:54501", serviceURL, "Service URL: ");
            }
        }
    }
}
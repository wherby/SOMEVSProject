using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcSystemType : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string silentString = null;
        private string serviceurlString = null;

        
        /// <summary>
        /// GetEmcSystemType
        ///     Constructor for GetEmcSystemType class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcSystemType(string silent = null, string serviceurl = null, string cmd = null)
        {

            silentString = silent;
            serviceurlString = serviceurl;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSystemType");

			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
            if (serviceurlString != null)
            {
                sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcSystemType commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcSystemType</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("SystemType");

            string result = RunCMD(psMachine, true);

            TestSetup.SetEmcServiceEnvironment();

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            int count = int.Parse( TestSetup.GetPropertyValue(PrefixString, "Count"));
            string[] types = HelperAdapter.GetParameter("SupportedSystemType", ConfigType.ESIService).Split(new char[]{','}, StringSplitOptions.RemoveEmptyEntries);
            log.AreEqual<int>(types.Length, count, "Verify count of System type");
            List<string> temp = new List<string>(types);
            for (int i = 0; i < count; i++)
            {
                log.AreEqual<string>("Storage", TestSetup.GetPropertyValue(PrefixString + "[" + i + "]", "ProviderType"));
                string providerName = TestSetup.GetPropertyValue(PrefixString + "[" + i + "]", "SystemType");
                log.AreEqual<bool>(true, temp.Contains(providerName), "Verify system type is contained in supported system type" );
                temp.Remove(providerName);
                string propertiesPrefix = "$properties";
                TestSetup.GetPropertyValue(propertiesPrefix + "=" + PrefixString + "[" + i + "].Properties");
                int propertiesCount = int.Parse( TestSetup.GetPropertyValue(propertiesPrefix, "Count"));
                switch (providerName)
                {
                    case "VNXe":
                        for(int j = 0; j < propertiesCount; j++)
                        {
                            string name = TestSetup.GetPropertyValue(propertiesPrefix + "[" + j + "]", "Name");
                            if (name != "Username" && name != "Password" && name != "SpaIpAddress" && name != "SpbIpAddress")
                            {
                                throw new Exception("Unexpected property name");
                            }
                        }
                        break;
                    case "VNX-CIFS":
                        for (int j = 0; j < propertiesCount; j++)
                        {
                            string name = TestSetup.GetPropertyValue(propertiesPrefix + "[" + j + "]", "Name");
                            if (name != "Username" && name != "Password" && name != "ControlStationIPAddress"
                                && name != "ControlStationPort" && name != "AddHostKeyIfMissing" && name != "ReplaceHostKeyIfChanged")
                            {
                                throw new Exception("Unexpected property name");
                            }
                        }
                        break;
                    case "CLARiiON-CX4":
                        for (int j = 0; j < propertiesCount; j++)
                        {
                            string name = TestSetup.GetPropertyValue(propertiesPrefix + "[" + j + "]", "Name");
                            if (name != "Username" && name != "Password" && name != "SpaIpAddress" && name != "SpbIpAddress" && name != "Port")
                            {
                                throw new Exception("Unexpected property name");
                            }
                        }
                        break;
                    case "VNX-Block":
                        for (int j = 0; j < propertiesCount; j++)
                        {
                            string name = TestSetup.GetPropertyValue(propertiesPrefix + "[" + j + "]", "Name");
                            if (name != "Username" && name != "Password" && name != "SpaIpAddress" && name != "SpbIpAddress" && name != "Port")
                            {
                                throw new Exception("Unexpected property name");
                            }
                        }
                        break;
                    case "VNX":
                        for (int j = 0; j < propertiesCount; j++)
                        {
                            string name = TestSetup.GetPropertyValue(propertiesPrefix + "[" + j + "]", "Name");
                            if (name != "Block-Username" && name != "Block-Password" && name != "SpaIpAddress" && name != "SpbIpAddress"
                                && name != "Block-Port" && name != "Cifs-Username" && name != "Cifs-Password" && name != "ControlStationIPAddress"
                                && name != "ControlStationPort" && name != "AddHostKeyIfMissing" && name != "ReplaceHostKeyIfChanged")
                            {
                                throw new Exception("Unexpected property name");
                            }
                        }
                        break;
                    case "VMAX":
                        for (int j = 0; j < propertiesCount; j++)
                        {
                            string name = TestSetup.GetPropertyValue(propertiesPrefix + "[" + j + "]", "Name");
                            if (name != "Username" && name != "Password" && name != "SerialNumber" && name != "Host" && name != "Port"
                                && name != "UseSSL" && name != "UseWindowsAuth" && name != "ConnectionTimeoutSeconds"
                                && name != "OperationTimeoutSeconds" && name != "IgnoreServerCACheck" && name != "IgnoreServerCNCheck")
                            {
                                throw new Exception("Unexpected property name");
                            }
                        }
                        break;
                    default:
                        throw new Exception("Unsupported system type");
                }
            }
        }
    }
}

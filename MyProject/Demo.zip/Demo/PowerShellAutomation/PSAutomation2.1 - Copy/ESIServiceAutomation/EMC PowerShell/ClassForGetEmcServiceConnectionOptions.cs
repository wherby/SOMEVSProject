using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcServiceConnectionOptions : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string silentString = null;
        
        /// <summary>
        /// GetEmcServiceConnectionOptions
        ///     Constructor for GetEmcServiceConnectionOptions class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcServiceConnectionOptions(string silent = null, string cmd = null)
        {

            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcServiceConnectionOptions");

			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcServiceConnectionOptions commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="urlString">service url</param>
        /// <returns>the result of Get-EmcServiceConnectionOptions</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string urlString)
        {
            PrefixString = HelperAdapter.GetParameter("Connection");
            string result = RunCMD(psMachine, true);

            VerifyFields(psMachine, result, urlString);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, string urlString)
        {
            
            string serviceURL = TestSetup.GetPropertyValue(PrefixString, "ServiceURL");
            
            log.AreEqual(urlString, serviceURL, "Service URL: ");
            string validateServerCertificate = TestSetup.GetPropertyValue(PrefixString, "ValidateServerCertificate");
            log.AreEqual("False", validateServerCertificate, "Validate server certificate: ");
        }
    }
}
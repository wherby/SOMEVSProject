using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcEntityClass : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate

        private string patternString = null;
        private string serviceurlString = null;
        private string silentString = null;

        
        /// <summary>
        /// GetEmcEntityClass
        ///     Constructor for GetEmcEntityClass class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcEntityClass(string pattern = null, string serviceurl = null, string silent = null,  string cmd = null)
        {

            patternString = pattern;
            serviceurlString = serviceurl;
            silentString = silent;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcEntityClass");

            if (patternString != null)
            {
                sb.AppendFormat(" -Pattern {0}", patternString);
            }
            if (serviceurlString != null)
            {
                sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcEntityClass commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcEntityClass</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, List<string> wholeClass, List<string> mandatoryClass, List<string> optionalClass)
        {
            string result = RunCMD(psMachine, true);

            TestSetup.SetEmcServiceEnvironment();

            VerifyFields(psMachine, result, wholeClass, mandatoryClass, optionalClass);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result, List<string> wholeClass, List<string> mandatoryClass, List<string> optionalClass)
        {
            SortedList<string, string> resultClasses = HelperAdapter.GenerateKeyValuePairs(result);

            if (patternString == null)
            {
                log.AreEqual<bool>( true,  wholeClass.Count >= resultClasses.Count, "whole classes' count is " + wholeClass.Count + ", result classes' count is " + resultClasses.Count);
                foreach (string cls in mandatoryClass)
                {
                    log.AreEqual<bool>(true, resultClasses.ContainsKey(cls), "Verify entity class " + cls);
                }
            }
            else
            {
                log.AreEqual<int>(1, resultClasses.Count);
                log.AreEqual<string>(patternString, resultClasses.Keys[0], "Verify entity class " + patternString);
            }
        }
    }
}
using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;
using Verification;

namespace PowerShellAutomation
{

    public class GetEmcEntity : BaseClass
    {
        class PhyscalStructure
        {
            string storageSystem;

            public string StorageSystem
            {
                get { return storageSystem; }
                set { storageSystem = value; }
            }
            string enclosure;

            public string Enclosure
            {
                get { return enclosure; }
                set { enclosure = value; }
            }
            List<SortedList<string, string>> keyValueList;

            public List<SortedList<string, string>> KeyValueList
            {
                get { return keyValueList; }
                set { keyValueList = value; }
            }
            public PhyscalStructure(string storageSystemString, string enclosureString, string info)
            {
                storageSystem = storageSystemString;
                enclosure = enclosureString;
                keyValueList = HelperAdapter.GenerateKeyValuePairsList(info);
            }
        }

        private TestLog log = TestLog.GetInstance();
        private static bool isEnclosureSet = false;
        #region AutoGenerate
        
        private string patternString = null;
        private string silentString = null;
        private string serviceurlString = null;
        private string entityidString = null;
        private string relatedtargetString = null;
        private string relatedsourceString = null;
        private string targetclassString = null;
        private string sourceclassString = null;
        private string relationshipString = null;
        private string classString = null;

        
        /// <summary>
        /// GetEmcEntity
        ///     Constructor for GetEmcEntity class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcEntity(string pattern = null, string silent = null, string serviceurl = null, string entityid = null, string relatedtarget = null, string relatedsource = null, string targetclass = null, string sourceclass = null, string relationship = null, string classStr = null,  string cmd = null)
        {

            patternString = pattern;
            silentString = silent;
            serviceurlString = serviceurl;
            entityidString = entityid;
            relatedtargetString = relatedtarget;
            relatedsourceString = relatedsource;
            targetclassString = targetclass;
            sourceclassString = sourceclass;
            relationshipString = relationship;
            classString = classStr;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcEntity");

			if (patternString != null)
            {
		        sb.AppendFormat(" -Pattern {0}", patternString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (serviceurlString != null)
            {
		        sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }
			if (entityidString != null)
            {
		        sb.AppendFormat(" -EntityId {0}", entityidString);
            }
			if (relatedtargetString != null)
            {
		        sb.AppendFormat(" -RelatedTarget");
            }
			if (relatedsourceString != null)
            {
		        sb.AppendFormat(" -RelatedSource");
            }
			if (targetclassString != null)
            {
		        sb.AppendFormat(" -TargetClass {0}", targetclassString);
            }
			if (sourceclassString != null)
            {
		        sb.AppendFormat(" -SourceClass {0}", sourceclassString);
            }
			if (relationshipString != null)
            {
		        sb.AppendFormat(" -Relationship {0}", relationshipString);
            }
			if (classString != null)
            {
		        sb.AppendFormat(" -Class {0}", classString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcEntity commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcEntity</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("Entity");

            string result = RunCMD(psMachine);

            VerifyFields(psMachine, result);
           // VerifyClassField(psMachine, result);
            
            return result;
        }

        private void VerifyClassField(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> keyValueList = null;

            if (result != null)
            {
                keyValueList = HelperAdapter.GenerateKeyValuePairsList(result);
            }
            if (classString != null)
            {
                foreach (SortedList<string, string> temp in keyValueList)
                {
                    if (temp["Classs"] != classString)
                    {
                        log.AreEqual<string>(classString,temp["Class"],"ClassName is equal");
                    }
                }
            }
            if(((targetclassString != null)&&(relatedtargetString != null))||((sourceclassString != null)&& (relatedsourceString != null)))
            {
                foreach (SortedList<string, string> temp in keyValueList)
                {
                    if((temp["Class"]!=sourceclassString)&&(temp["Class"]!=targetclassString))
                    {
                        log.LogError(string.Format("Get Type of {0},expected {1} or {2}",temp["Class"],sourceclassString,targetclassString));
                    }
                }
            }
            if ((relatedtargetString != null) && (relatedsourceString != null) && (targetclassString != null) && (sourceclassString != null) && (relationshipString == null) &&
                (patternString == null))
            {
                int count = keyValueList.Count;
                GetEmcEntity source = new GetEmcEntity(patternString, serviceurlString, silentString, entityidString, null, relatedsourceString, null, sourceclassString,
                    relationshipString, classString);
                GetEmcEntity target = new GetEmcEntity(patternString, serviceurlString, silentString, entityidString, relatedtargetString, null, targetclassString, null,
                    relationshipString, classString);
                int sourceCount = HelperAdapter.GenerateKeyValuePairsList(source.RunCMD(psMachine, false)).Count;
                int targetCount = HelperAdapter.GenerateKeyValuePairsList(target.RunCMD(psMachine, false)).Count;
                log.AreEqual<int>(count, sourceCount + targetCount, "entity Count from both source and target");
            }
            if (CmdString == "Get-EmcEntity")
            {
                int count = keyValueList.Count;
                string classes = TestSetup.GetValue("Get-EmcEntityClass");
                string[] entityClasses = classes.Split(new string[] { "\r\n" }, StringSplitOptions.RemoveEmptyEntries);
                int allEntityCount = 0;
                foreach (string temp in entityClasses)
                {
                    string resultForGetEntity = TestSetup.GetValue("Get-EmcEntity -Class "+temp);
                    allEntityCount = allEntityCount + HelperAdapter.GenerateKeyValuePairsList(resultForGetEntity).Count;
                }
                log.AreEqual<int>(count, allEntityCount, "Entity count from all entity");
            }
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            List<SortedList<string, string>> keyValueList = null;

            if (result != null)
            {
                keyValueList = HelperAdapter.GenerateKeyValuePairsList(result);
            }
            String classToTest = null;

           
            if ((classString != null)&&(patternString==null) && (targetclassString == null) && (sourceclassString == null) && 
                (relationshipString == null) && (relatedsourceString == null) && (relatedtargetString == null)&&
                (entityidString==null))
            {
                classToTest = classString;
            }
                /*
            else
            {
                if ((classString == null) && (targetclassString != null) && (sourceclassString == null) && (relationshipString == null) &&
                    (relatedsourceString == null) && (relatedtargetString != null))
                {
                    classToTest = targetclassString;
                }
                else
                {
                    if ((classString == null) && (targetclassString == null) && (sourceclassString != null) && (relationshipString == null) &&
                                (relatedsourceString != null) && (relatedtargetString == null))
                    {
                        classToTest = sourceclassString;
                    }
                    else
                    {
                        return;
                    }
                }
            }
                 * */


            switch (classToTest)
            {
                case "StorageSystem":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "Name", "Get-EmcStorageSystem");
                    break;

                case "Enclosure":
                    {
                        List<PhyscalStructure> enclosureList = GetValueFromEnclosure(psMachine,null);
                        VerifyPhysicalComponent(keyValueList, enclosureList, "EnclosureId");
                        VerifiedPhysicalCount(keyValueList, enclosureList);
                    }
                    break;

                case "DiskDrive":
                    List<PhyscalStructure> diskList = GetValueFromEnclosure(psMachine, "DiskDrives");
                    VerifyPhysicalComponent(keyValueList, diskList, "DiskId");
                    VerifiedPhysicalCount(keyValueList, diskList);
                    break;

                case "PowerSupply":
                    List<PhyscalStructure> powersupplyList = GetValueFromEnclosure(psMachine, "PowerSupplies");
                    VerifyPhysicalComponent(keyValueList, powersupplyList,"Id");
                    VerifiedPhysicalCount(keyValueList, powersupplyList);
                    break;

                case "StandbyPowerSupply":
                    List<PhyscalStructure> standbyPowerSypplyList = GetValueFromEnclosure(psMachine, "StandbyPowerSupplies");
                    VerifyPhysicalComponent(keyValueList, standbyPowerSypplyList, "Id");
                    VerifiedPhysicalCount(keyValueList, standbyPowerSypplyList);
                    break;

                case "LunStorageServiceNode":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "ServiceNodeId", "$block|foreach{Get-emcstorageservicenode -storagesystem $_}", "$block=Get-EmcStorageSystem -SystemType VNX-Block");
                    break;

                case "FcStoragePort":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "PortId", "Get-EmcTargetPort | where { $_.wwn -ne $null}");
                    break;

                case "IscsiStoragePort":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "Iqn", "Get-EmcTargetPort | where { $_.iqn -ne $null}");
                    break;

                case "CPUModule":
                    List<PhyscalStructure> cpuList = GetValueFromEnclosure(psMachine, "Modules", "Enclosures","ServiceNodes");
                    VerifyPhysicalComponent(keyValueList, cpuList, "ModuleId");
                    VerifiedPhysicalCount(keyValueList, cpuList, "DisplayName", "CPU");
                    break;

                case "IOModule":
                    List<PhyscalStructure> ioModuleList = GetValueFromEnclosure(psMachine, "Modules", "Enclosures", "ServiceNodes");
                    VerifyPhysicalComponent(keyValueList, ioModuleList, "ModuleId");
                    VerifiedPhysicalCount(keyValueList, ioModuleList, "DisplayName", "I/O,IO Module");
                    break;

                case "MemoryModule":
                    List<PhyscalStructure> memoryModuleList = GetValueFromEnclosure(psMachine, "Modules", "ServiceNodes");
                    VerifyPhysicalComponent(keyValueList, memoryModuleList, "ModuleId");
                    VerifiedPhysicalCount(keyValueList, memoryModuleList, "DisplayName", "DIMM");
                    break;

                case "LinkControlCard":
                    List<PhyscalStructure> linkControlCardList = GetValueFromEnclosure(psMachine, "ServiceNodes");
                    VerifyPhysicalComponent(keyValueList, linkControlCardList, "ServiceNodeId");
                    VerifiedPhysicalCount(keyValueList, linkControlCardList, "ServiceNodeId", "LCC");
                    break;

                case "LunStoragePool":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "Name", "Get-EmcStoragePool -PoolType Block");
                    break;

                case "ConcreteLun":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "WWN", "Get-EmcLun");
                    break;

                case "SnapshotLun":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "WWN", "Get-EmcSnapshotLun");
                    break;

                case "LunMaskingView":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "Name", "Get-EmcLunMaskingView");
                    break;

                case "StorageManagementServiceEndpoint":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "IpAddress", "foreach($a in $system){$a.ManagementServiceEndpointList}", "$system = Get-EmcStorageSystem");
                    break;

                case "SnapshotPool":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "PoolId", "Get-EmcSnapshotPool");
                    break;

                case "CifsStoragePool":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "Name", "Get-EmcStoragePool -PoolType File");
                    break;

                case "CifsSharedFolder":
                    VerifiedByESIPowerShell(psMachine, keyValueList, "Name", "Get-EmcSharedFolder");
                    break;

                case "ManagementStorageServiceNode":
                    List<PhyscalStructure> managementServiceNodeList = GetValueFromEnclosure(psMachine, null);
                    VerifyPhysicalComponent(keyValueList, managementServiceNodeList, "DisplayName",null,null,true);
                    VerifiedPhysicalCount(keyValueList, managementServiceNodeList, "EnclosureId", "Control Station");
                    break;

                case "CoolingComponent":
                    List<PhyscalStructure> coolingComponentList = GetValueFromEnclosure(psMachine, "CoolingComponents");
                    VerifyPhysicalComponent(keyValueList, coolingComponentList, "Id");
                    VerifiedPhysicalCount(keyValueList, coolingComponentList);
                    break;

                case "CifsStorageServiceNode":
                    List<PhyscalStructure> cifsServiceNodeList = GetValueFromEnclosure(psMachine, "ServiceNodes");
                    VerifyPhysicalComponent(keyValueList, cifsServiceNodeList, "ServiceNodeId");
                    VerifiedPhysicalCount(keyValueList, cifsServiceNodeList, "ServiceNodeId", "Data Mover");
                    break;

                case "NetworkSwitch":
                    List<PhyscalStructure> networkSwitchList = GetValueFromEnclosure(psMachine, "NetworkSwitches");
                    VerifyPhysicalComponent(keyValueList, networkSwitchList, "SwitchId");
                    VerifiedPhysicalCount(keyValueList, networkSwitchList);
                    break;
                case "ServiceNodeContainer":
                    List<PhyscalStructure> serviceNodeContainer = GetValueFromEnclosure(psMachine, "ServiceNodeContainers");
                    VerifyPhysicalComponent(keyValueList, serviceNodeContainer, "ContainerId");
                    VerifiedPhysicalCount(keyValueList, serviceNodeContainer);
                    break;
            }
        }

        private void VerifiedPhysicalCount(List<SortedList<string, string>> keyValueList, List<PhyscalStructure> physicalList, string property = null, string propertyValue = null)
        {
            int countForlist = keyValueList.Count;
            int countForPhy = 0;
            if (propertyValue == "DIMM")
            {
                if (HelperAdapter.GetParameter("SystemType", ConfigType.ESIService).IndexOf("VNX-CIFS") >= 0)
                {
                    string ipaddress=HelperAdapter.GetParameter("ControlStationIPAddress","VNX-CIFS",ConfigType.System);
                    string userName = HelperAdapter.GetParameter("Username", "VNX-CIFS", ConfigType.System);
                    string password = HelperAdapter.GetParameter("Password", "VNX-CIFS", ConfigType.System);
                    VNXFileStorage file = new VNXFileStorage(ipaddress, userName, password);
                    Dictionary<string, MemoryModule> meFile = file.GetMemoryModules();
                    countForPhy = meFile.Count + countForPhy;
                }
                if (HelperAdapter.GetParameter("SystemType", ConfigType.ESIService).IndexOf("VMAX") >= 0)
                {
                    string sid = HelperAdapter.GetParameter("SerialNumber", "VMAX", ConfigType.System);
                    SymStorage vmax = new SymStorage(sid);
                    Dictionary<string, MemoryModule> moVmax = vmax.GetMemoryModules();
                    countForPhy = countForPhy + moVmax.Count;
                }

            }
            if (property == null)
            {
                foreach (PhyscalStructure temp in physicalList)
                {
                    if (temp.KeyValueList != null)
                    {
                        countForPhy = countForPhy + temp.KeyValueList.Count;
                    }
                }
                log.AreEqual<int>(countForPhy, countForlist, "Physical entity count is equal");
            }
            else
            {
                foreach (PhyscalStructure temp in physicalList)
                {
                    if (temp.KeyValueList != null)
                    {
                        foreach (SortedList<string, string> temp2 in temp.KeyValueList)
                        {
                            string[] propertyValueList = propertyValue.Split(',');
                            foreach (string temppropervalue in propertyValueList)
                            {
                                if (temp2[property].IndexOf(temppropervalue) >= 0)
                                {
                                    countForPhy = countForPhy + 1;
                                }
                            }
                        }
                    }
                }
                log.AreEqual<int>(countForPhy, countForlist, "Physical entity count is equal");
            }
        }

        private void VerifiedByESIPowerShell(PowershellMachine paMachine, List<SortedList<string, string>> keyValueList, string keyId, string cmd, string precmd = null )
        {
            string prefix = "$verify";
        //    TestSetup.RunPSCMD("Get-EmcStorageSystem|Update-EmcSystem"); //Don't update logical component
            if (precmd != null)
            {
                TestSetup.RunPSCMD(precmd);
            }
            string expRes = TestSetup.RunPSCMD( prefix + "=" + cmd + ";" + prefix);
            
            List<SortedList<string, string>> expKeyValueList = HelperAdapter.GenerateKeyValuePairsList(expRes);

            string keyId2 = keyId;
            if (keyId == "WWN")
            {
                keyId2 = "Wwn";
            }
            foreach (SortedList<string, string> keyValue in keyValueList)
            {
                if ((entityidString  != null)&&(relatedsourceString ==null)&&(relatedtargetString==null))
                {
                    try
                    {
                        log.AreEqual<string>(keyValue["EntityId"], entityidString, "Verify id:EntityId");
                        log.AreEqual<int>(1, keyValueList.Count, "Verify count");
                    }
                    catch
                    {
                        log.AreEqual<string>(keyValue["Class"], entityidString, "Verify id:Class");
                        log.AreEqual<int>(expKeyValueList.Count, keyValueList.Count, "Verify count");
                    }
                }
                else
                {
                   // log.AreEqual<int>(expKeyValueList.Count, keyValueList.Count, "Verify count");
                }
            }

            if (cmd=="Get-EmcLun")
            {
                int snapCount = HelperAdapter.GenerateKeyValuePairsList(TestSetup.GetValue("Get-EmcSnapshotLun")).Count;
                log.AreEqual<int>(expKeyValueList.Count - snapCount, keyValueList.Count, "Lun number");
            } 
            else
            {
                int expKeyValueListCount = expKeyValueList.Count;
                if (cmd.IndexOf("$block|foreach{Get-emcstorageservicenode") >= 0)
                {
                    if (HelperAdapter.GetParameter("SystemType", ConfigType.ESIService).IndexOf("VMAX") >= 0)
                    {
                        string sid = HelperAdapter.GetParameter("SerialNumber", "VMAX", ConfigType.System);
                        SymStorage vmax = new SymStorage(sid);
                        Dictionary<string, ServiceNode> symSN = vmax.GetServiceNodes();
                        expKeyValueListCount = expKeyValueListCount + symSN.Count; 
                    }
                }
                if (cmd.IndexOf("Get-EmcTargetPort | where { $_.iqn -ne $null}") >= 0)
                {
                    if (HelperAdapter.GetParameter("SystemType", ConfigType.ESIService).IndexOf("VMAX") >= 0)
                    {
                        string sid = HelperAdapter.GetParameter("SerialNumber", "VMAX", ConfigType.System);
                        SymStorage vmax = new SymStorage(sid);
                        Dictionary<string, ServiceNode> sd3 = vmax.GetSEServiceNodes();
                        foreach (KeyValuePair<string, ServiceNode> temp in sd3)
                        {
                            Dictionary<string, TargetPort> fc = vmax.GetServiceNodeTargetPorts(temp.Value);
                            expKeyValueListCount = expKeyValueListCount + fc.Count;
                        }
                    }
                    if (HelperAdapter.GetParameter("SystemType", ConfigType.ESIService).IndexOf("VNX-CIFS") >= 0)
                    {
                        string ipaddress = HelperAdapter.GetParameter("ControlStationIPAddress", "VNX-CIFS", ConfigType.System);
                        string userName = HelperAdapter.GetParameter("Username", "VNX-CIFS", ConfigType.System);
                        string password = HelperAdapter.GetParameter("Password", "VNX-CIFS", ConfigType.System);
                        VNXFileStorage file = new VNXFileStorage(ipaddress, userName, password);
                        Dictionary<string, TargetPort> fsn = file.GetCifsTargetPort();
                        expKeyValueListCount = expKeyValueListCount + fsn.Count;
                    }
                }

                //   if (cmd != "Get-EmcTargetPort | where { $_.iqn -ne $null}")   //Bypass IscsiStoragePort count checking.
                //  {
                log.AreEqual<int>(expKeyValueListCount, keyValueList.Count, "Count is equal");
                // }
                
            }
            foreach (SortedList<string, string> expKeyValue in expKeyValueList)
            {
                #region
                int i = 0;
                foreach (SortedList<string, string> keyValue in keyValueList)
                {
                    string keyT = keyId;
                    string keyT2 = keyId2;
                    if (keyValue["PhysicalPath"].IndexOf("VNX") >= 0)
                    {
                        if (keyId == "PortId")
                        {
                            keyT = "PortLocation";
                            keyT2 = keyT;
                        }
                    }
                   
                    if (keyValue[keyT] == expKeyValue[keyT2])
                    {
                        #region
                        foreach (string key in keyValue.Keys)
                        {
                            if (key == "HealthState")
                            {
                                log.AreEqual<bool>(true, VerifyStatus(keyValue["HealthState"], expKeyValue["OperationalStatus"]));
                            }
                            else if (key == "Class")
                            {
                                log.AreEqual<string>(classString, keyValue["Class"], "Verify Class");
                            }
                            else if (key != "EntityId")
                            {
                                string verifyKey = null;
                            
                                foreach (string expKey in expKeyValue.Keys)
                                {
                                    if (expKey.ToLower() == key.ToLower())
                                    {
                                        verifyKey = expKey;
                                        break;
                                    }
                                }
                                if (key == "PhysicalPath")
                                {
                                    continue; //physicalPath is not list in PowerShell
                                }
                                log.AreEqual<bool>(false, string.IsNullOrEmpty(verifyKey), "Verify verifyKey key exists keyname :" + key);
                                if (key.ToLower().Contains("capacity") && !keyValue[key].ToLower().Contains("b"))
                                {
                                    if (expKeyValueList.Count == 1)
                                    {
                                       // log.AreEqual<string>(TestSetup.GetPropertyValue(prefix + "." + verifyKey + ".Value"), keyValue[key], "Verify " + key);
                                    }
                                    else
                                    {
                                        string capacityExpect = expKeyValue[key];
                                        string capacityGet = HelperAdapter.ParseCapacity(keyValue[key], false);
  //                                      log.AreEqual<string>(capacityExpect, capacityGet, key);   //Capacity check is disable.
                                    }
                                }
                                else
                                {

                                        log.AreEqual<string>(expKeyValue[verifyKey], keyValue[key], "Verify " + key);
                                    
                                }
                            }
                        }
                        #endregion
                        break;
                    }
                    i++;
                }
            #endregion
                if (i == keyValueList.Count)
                {
                    if ((cmd.IndexOf("Get-EmcLun") >= 0) && expKeyValue.ContainsKey("SourceLunId"))
                    {
                        continue;   //The concreateLun don't have snapshot lun
                    }
                    throw new PSException("Entity with " + keyId + ":" + expKeyValue[keyId2] + " is not listed in ESI Service entity ");
                }
            }

        }

        private void VerifyPhysicalComponent(List<SortedList<string,string>> keyValueList,List<PhyscalStructure> phyList,string keyId,string healthStringinPS=null,string healthStringInService=null,bool isSimi=false)
        {
            foreach (SortedList<string, string> tempForKeyValue in keyValueList)
            {
                string physicalPath = tempForKeyValue["PhysicalPath"];
                foreach (PhyscalStructure tempPhy in phyList)
                {
                    if (physicalPath.IndexOf(tempPhy.StorageSystem) >= 0)
                    {
                        if (physicalPath.IndexOf(tempPhy.Enclosure) >= 0)
                        {
                            foreach (SortedList<string, string> tempEntity in tempPhy.KeyValueList)
                            {
                                if (isSimi == false)
                                {
                                    if (tempForKeyValue[keyId] == tempEntity[keyId])
                                    {
                                        if (healthStringinPS == null)
                                        {
                                            healthStringinPS = "OperationalStatus";
                                        }
                                        if (healthStringInService == null)
                                        {
                                            healthStringInService = "HealthState";
                                        }
                                        log.AreEqual<bool>(true, VerifyStatus(tempForKeyValue[healthStringInService], tempEntity[healthStringinPS]));
                                    }
                                }
                                else
                                {
                                    if (tempForKeyValue[keyId].IndexOf(tempEntity[keyId])>=0)
                                    {
                                        if (healthStringinPS == null)
                                        {
                                            healthStringinPS = "OperationalStatus";
                                        }
                                        if (healthStringInService == null)
                                        {
                                            healthStringInService = "HealthState";
                                        }
                                        log.AreEqual<bool>(true, VerifyStatus(tempForKeyValue[healthStringInService], tempEntity[healthStringinPS]));
                                    }
                                }
                            }
                        }
                    }
                }
            }
            #region 
            /*
            List<SortedList<string, string>> keyValuePairListInPS = HelperAdapter.GenerateKeyValuePairsList(physicalStringInPowerShell);
            if (healthStringinPS == null)
            {
                healthStringinPS = "OperationalStatus";
            }
            if (healthStringInService == null)
            {
                healthStringInService = "HealthState";
            }
            SortedList<string, string> healthPairs = GenerateHealthStatePairs();
            foreach (SortedList<string, string> tempService in keyValueList)
            {
                foreach (SortedList<string, string> tempInPs in keyValuePairListInPS)
                {
                    if (tempInPs[keyId] == tempService[keyId])
                    {
                        log.AreEqual<string>(healthPairs[tempInPs[healthStringinPS]], tempService[healthStringInService], "The health status are equal");
                    }
                }
            }
 * */
            #endregion
        }

        private bool VerifyStatus(string healthString, string operationStatusString)
        { 
            if((operationStatusString.Trim()==string.Empty)&&(healthString=="Warning"))
            {
                return true;
            }
            if((operationStatusString.IndexOf("Error")>=0)&&(healthString=="Error"))
            {
                return true;
            }
            if (((operationStatusString.IndexOf("OK") >= 0) ||(operationStatusString.IndexOf("Online")>=0))
                && (healthString == "Success"))
            {
                return true;
            }
            if (((operationStatusString.IndexOf("Unknown") >= 0) || (operationStatusString.IndexOf("Degraded") >= 0) || (operationStatusString.IndexOf("Offline")>=0)||
               (operationStatusString.IndexOf("Dormant")>=0)||(operationStatusString.IndexOf("Other")>=0))
                && (healthString == "Warning"))
            {
                return true;
            }
            log.LogError(string.Format("OperationStatus is {0} and healthString is {1}",operationStatusString,healthString));
            return false;
        }
         
        private void SetEnclosureEnvironment(PowershellMachine psMachine)
        {
            if (isEnclosureSet == false)
            {
                TestSetup.RunPSCMD("Get-EmcStorageSystem|Update-EmcSystem");
                TestSetup.RunPSCMD("$sysPSTemp=Get-EmcStorageSystem");
                isEnclosureSet = true;
            }

        }

        private List<PhyscalStructure> GetValueFromEnclosure(PowershellMachine psMachine, string property, string rootProperty = "Enclosures",string secondRootProperty=null)
        {
            SetEnclosureEnvironment(psMachine);
            List<PhyscalStructure> listStructure = new List<PhyscalStructure>();
            string countString = TestSetup.RunPSCMD("$sysPSTemp.Count");
            int count = 1;
            if (countString != string.Empty)
            {
                count = int.Parse(countString);
            }
            for (int i = 0; i < count; i++)
            {

                TestSetup.GetValue("$sysPSTempTemp=$sysPSTemp");
                TestSetup.GetValue("$sysPSTempTemp=$sysPSTemp[" + i + "]");
                string storageSystemTemp = TestSetup.RunPSCMD("$sysPSTempTemp.SerialNumber");
                TestSetup.RunPSCMD("$enclosureTemp=$sysPSTempTemp." + rootProperty);
                string countStringforEnclosure = TestSetup.RunPSCMD("$enclosureTemp.Count");
                int countForEnclosure = int.Parse(countStringforEnclosure);
                for (int j = 0; j < countForEnclosure; j++)
                {
                    string nameForSecondLayerTemp = null;
                    if (rootProperty == "Enclosures")
                    {
                        nameForSecondLayerTemp = TestSetup.RunPSCMD("$enclosureTemp[" + j + "].EnclosureId");
                    }
                    if (rootProperty == "ServiceNodes")
                    {
                        nameForSecondLayerTemp = TestSetup.RunPSCMD("$enclosureTemp[" + j + "].ServiceNodeId");
                    }
                    int countForSecond = 1;
                    if (secondRootProperty != null)
                    {
                        TestSetup.RunPSCMD("$secondRoot=$enclosureTemp[" + j + "]." + secondRootProperty);
                        string countForSecondRoot = TestSetup.GetValue("$secondRoot.Count");
                        if (countForSecondRoot != string.Empty)
                        {
                            countForSecond = int.Parse(countForSecondRoot);
                        }
                    }
                    for (int n = 0; n < countForSecond; n++)
                    {
                        if (secondRootProperty == null)
                        {
                            TestSetup.GetValue("$encTTT=$enclosureTemp[" + j + "]");
                        }
                        else
                        {
                            TestSetup.GetValue("$encTTT=$secondRoot");
                            TestSetup.GetValue("$encTTT=$secondRoot[" + n + "]");
                        }
                        string propertyString = null;
                        if (property != null)
                        {
                            propertyString = "." + property;
                        }
                        string propertyInfo = TestSetup.RunPSCMD("$encTTT" + propertyString);
                        listStructure.Add(new PhyscalStructure(storageSystemTemp, nameForSecondLayerTemp, propertyInfo));
                    }
                }
                
            }
            return listStructure;
        }


    }
}
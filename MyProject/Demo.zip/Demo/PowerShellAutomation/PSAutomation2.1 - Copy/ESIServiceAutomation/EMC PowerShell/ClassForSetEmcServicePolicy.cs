using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class SetEmcServicePolicy : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string refreshintervalinminutesString = null;
        private string silentString = null;
        private string serviceurlString = null;

        
        /// <summary>
        /// SetEmcServicePolicy
        ///     Constructor for SetEmcServicePolicy class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public SetEmcServicePolicy(string refreshintervalinminutes = null, string silent = null, string serviceurl = null,  string cmd = null)
        {

            refreshintervalinminutesString = refreshintervalinminutes;
            silentString = silent;
            serviceurlString = serviceurl;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Set-EmcServicePolicy");

			if (refreshintervalinminutesString != null)
            {
		        sb.AppendFormat(" -RefreshIntervalInMinutes {0}", refreshintervalinminutesString);
            }
			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (serviceurlString != null)
            {
		        sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Set-EmcServicePolicy commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Set-EmcServicePolicy</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("ServicePolicy");
            string result = RunCMD(psMachine, true);
            

            VerifyFields(psMachine);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine)
        {
            string refreshInterval = TestSetup.GetPropertyValue(PrefixString, "SystemRefreshIntervalMinutes");
            log.AreEqual(refreshintervalinminutesString, refreshInterval, "Refresh Interval In Minutes: ");
            string interval;
            if (serviceurlString != null)
            {
                interval = TestSetup.GetRefreshInterval(serviceurlString);
            }
            else
            {
                interval = TestSetup.GetRefreshInterval();
            }
            log.AreEqual(interval, refreshInterval, "Refresh Interval In Minutes of Get/Set command: ");
        }
    }
}
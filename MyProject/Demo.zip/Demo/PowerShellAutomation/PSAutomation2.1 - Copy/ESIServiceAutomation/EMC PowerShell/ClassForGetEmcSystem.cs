using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcSystem : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string silentString = null;
        private string serviceurlString = null;

        
        /// <summary>
        /// GetEmcSystem
        ///     Constructor for GetEmcSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcSystem(string silent = null, string serviceurl = null, string cmd = null)
        {

            silentString = silent;
            serviceurlString = serviceurl;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcSystem");

			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
            if (serviceurlString != null)
            {
                sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcSystem commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Get-EmcSystem</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, List<string> systems)
        {
            PrefixString = HelperAdapter.GetParameter("System");

            string result = RunCMD(psMachine, true);

            TestSetup.SetEmcServiceEnvironment();

            List<SortedList<string, string>> keyValueList = HelperAdapter.GenerateKeyValuePairsList(result);
            if (keyValueList == null)
            {
                log.AreEqual<int>(0, systems.Count, "Verify systems count");
            }
            else
            {
                log.AreEqual<int>(systems.Count, keyValueList.Count, "Verify systems count");

                int i = 0;

                List<string> temp = new List<string>(systems);

                foreach (SortedList<string, string> keyValue in keyValueList)
                {
                    string prefix = PrefixString;

                    if (keyValueList.Count > 1)
                    {
                        prefix = PrefixString + "[" + i + "]";
                    }

                    string type = keyValue["SystemType"];

                    log.AreEqual<bool>(true, temp.Contains(type), "Verify " + type + " is added");

                    temp.Remove(type);

                    VerifyFields(psMachine, keyValue, type, prefix);

                    i++;
                }
            }

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, SortedList<string, string> keyValue, string systemType, string prefix)
        {
            log.AreEqual<string>(systemType.ToLower(), keyValue["FriendlyName"], "Verify FriendlyName");
            log.AreEqual<string>(systemType, keyValue["SystemType"], "Verify SystemType");

            Dictionary<string, string> dic = HelperAdapter.Load(ConfigType.System, systemType);

            int count = int.Parse(TestSetup.GetPropertyValue(prefix, "Properties.count"));

            for (int i = 0; i < count; i++)
            {
                string name = TestSetup.GetPropertyValue(prefix + ".Properties[" + i + "]", "Name");
                string value = TestSetup.GetPropertyValue(prefix + ".Properties[" + i + "]", "Value");
                if (name.Contains("Password"))
                {
                    log.AreEqual<string>("*****", value, "Verify property " + name + "'s value");
                }
                else
                {
                    if (dic.ContainsKey(name.Replace("-", "")))
                    {
                        log.AreEqual<string>(dic[name.Replace("-", "")], value, "Verify property " + name + "'s value");
                    }
                    else
                    {
                        log.LogInfo("name:" + name + "; Value:" + value);
                    }
                }
            }
        }
    }
}
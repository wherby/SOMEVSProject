using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class AddEmcSystem : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string silentString = null;
        private string serviceurlString = null;
        private string paramsString = null;
        private string systemtypeString = null;
        private string userfriendlynameString = null;

        
        /// <summary>
        /// AddEmcSystem
        ///     Constructor for AddEmcSystem class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public AddEmcSystem(string silent = null, string serviceurl = null, string paramsS = null, string systemtype = null, string userfriendlyname = null,  string cmd = null)
        {

            silentString = silent;
            serviceurlString = serviceurl;
            paramsString = paramsS;
            systemtypeString = systemtype;
            userfriendlynameString = userfriendlyname;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Add-EmcSystem");

			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
            if (serviceurlString != null)
            {
                sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }
			if (paramsString != null)
            {
		        sb.AppendFormat(" -Params {0}", paramsString);
            }
			if (systemtypeString != null)
            {
		        sb.AppendFormat(" -SystemType {0}", systemtypeString);
            }
			if (userfriendlynameString != null)
            {
		        sb.AppendFormat(" -UserFriendlyName {0}", userfriendlynameString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Add-EmcSystem commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <returns>the result of Add-EmcSystem</returns>
        public string VerifyTheCMD(PowershellMachine psMachine)
        {
            PrefixString = HelperAdapter.GetParameter("System");
            string result = RunCMD(psMachine, true);

            TestSetup.SetEmcServiceEnvironment();

            VerifyFields(psMachine, result);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string result)
        {
            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);
            
            log.AreEqual<string>(systemtypeString.ToLower(), keyValue["FriendlyName"], "Verify FriendlyName");
            log.AreEqual<string>(systemtypeString, keyValue["SystemType"], "Verify SystemType");

            Dictionary<string, string> dic = HelperAdapter.Load(ConfigType.System, systemtypeString);

            int count = int.Parse(TestSetup.GetPropertyValue(PrefixString, "Properties.count"));

            for(int i = 0; i < count; i++)
            {
                string name = TestSetup.GetPropertyValue(PrefixString + ".Properties[" + i + "]", "Name");
                string value = TestSetup.GetPropertyValue(PrefixString + ".Properties[" + i + "]", "Value");
                if (name.Contains("Password"))
                {
                    log.AreEqual<string>("*****", value, "Verify property " + name + "'s value");
                }
                else
                {
                    if(dic.ContainsKey(name.Replace("-", "")))
                    {
                        log.AreEqual<string>(dic[name.Replace("-", "")], value, "Verify property " + name + "'s value");
                    }
                    else
                    {
                        log.LogInfo("name:" + name + "; Value:" + value);
                    }
                }
            }
            
        }
    }
}
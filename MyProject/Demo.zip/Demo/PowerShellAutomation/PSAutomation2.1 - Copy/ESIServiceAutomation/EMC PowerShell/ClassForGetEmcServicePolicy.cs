using System;
using System.Collections.Generic;
using System.Text;

using System.Threading;
using PowerShellTestTools;

namespace PowerShellAutomation
{

    public class GetEmcServicePolicy : BaseClass
    {
        private TestLog log = TestLog.GetInstance();

        #region AutoGenerate
        
        private string silentString = null;
        private string serviceurlString = null;

        
        /// <summary>
        /// GetEmcServicePolicy
        ///     Constructor for GetEmcServicePolicy class
        /// </summary>
        /// <param name=""> object string</param>
        /// <param name="cmd">command string to test</param>
        public GetEmcServicePolicy(string silent = null, string serviceurl = null,  string cmd = null)
        {

            silentString = silent;
            serviceurlString = serviceurl;

            CmdString = cmd;
        }

        /// <summary>
        /// ToCMDString
        ///     Override ToCMDString method in BaseClass, build a command string
        /// </summary>
        /// <returns>command string</returns>
        public override string ToCMDString()
        {
            StringBuilder sb = new StringBuilder();
            sb.Append("Get-EmcServicePolicy");

			if (silentString != null)
            {
		        sb.AppendFormat(" -Silent");
            }
			if (serviceurlString != null)
            {
		        sb.AppendFormat(" -ServiceUrl {0}", serviceurlString);
            }


            return sb.ToString();
        }
        #endregion

        /// <summary>
        /// VerifyTheCMD
        ///     Verify whether Get-EmcServicePolicy commands succeeds or not
        /// </summary>
        /// <param name="psMachine">powershell machine</param>
        /// <param name="refreshInterval">the refresh interval used in Set-EmcServicePolicy command</param>
        /// <returns>the result of Get-EmcServicePolicy</returns>
        public string VerifyTheCMD(PowershellMachine psMachine, string refreshInterval)
        {
            PrefixString = HelperAdapter.GetParameter("ServicePolicy");
            string result = RunCMD(psMachine, true);            

            VerifyFields(psMachine, refreshInterval);

            return result;
        }

        private void VerifyFields(PowershellMachine psMachine, string refreshInterval)
        {
            string interval = TestSetup.GetPropertyValue(PrefixString, "SystemRefreshIntervalMinutes");
            log.AreEqual(refreshInterval, interval, "Refresh Interval In Minutes: ");
            
        }
    }
}
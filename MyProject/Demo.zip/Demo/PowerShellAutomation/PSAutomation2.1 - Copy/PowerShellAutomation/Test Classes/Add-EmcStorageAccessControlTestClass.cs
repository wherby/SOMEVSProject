using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;

namespace PowerShellAutomation
{
    /// <summary>
    /// AddEmcStorageAccessControlTest: test class for Add-EmcStorageAccessControl cmdlet
    /// </summary>
    [TestClass]
    public partial class AddEmcStorageAccessControlTest
    {
        public AddEmcStorageAccessControlTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }


        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static string storageGlobalID;
        private static string storageSystemName;
        private static string poolName;
        private static string poolType;
        private static bool removeFlag = false;
        
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Init Start---------");

            log.LogInfo("--------Test Init End---------");            
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            if (removeFlag)
            {
                log.LogInfo("--------Test Clean Up Start---------");
                RemoveEmcStorageAccessControl removeEmcStorageAcceccControl = 
                    new RemoveEmcStorageAccessControl(HelperAdapter.GetParameter("AccessControl"),
                        HelperAdapter.GetParameter("Pool"));

                removeEmcStorageAcceccControl.VerifyTheCMD(psMachine, storageGlobalID, poolName, poolType);
                log.LogInfo("--------Test Clean Up End---------");
            }
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Initialize Start--------");   

            // Connect to EMC storage system          
            log.LogInfo("Class Initialize: Connect Storage System");
            string storage = TestSetup.SetStorageEnvironment(psMachine, "All");
            string result = TestSetup.ConnectSystem(psMachine, storage);
            storageGlobalID = HelperAdapter.GenerateKeyValuePairs(result)["GlobalId"];
            storageSystemName = HelperAdapter.GenerateKeyValuePairs(result)["Name"];

            // Select a random pool          
            log.LogInfo("Class Initialize: Get Storage Pool");
            Pool pool = TestSetup.GetRandomStoragePool(psMachine);
            poolType = pool.PoolType;
            poolName = pool.PoolName;            

            // New Access Control
            log.LogInfo("Class Initialize: New Access Control");
            NewEmcStorageAccessControl accessControl = new NewEmcStorageAccessControl();
            accessControl.PrefixString = HelperAdapter.GetParameter("AccessControl");
            accessControl.VerifyTheCMD(psMachine);
            log.LogInfo("--------Class Initialize End--------");  
            
        }

        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");            
            // Disconnect Storage System
            log.LogInfo("Class Cleanup:Disconnect Storage System");
            TestSetup.DisconnectSystem(psMachine);
            log.LogInfo("--------Class Clean Up End--------");
        }
        #endregion

        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a Add-EmcStorageAccessControl instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>Add-EmcStorageAccessControl instance</returns>  
        public AddEmcStorageAccessControl ParseCmd(string cmd)
        {
            #region AutoGenerate
            string accesscontrol = null;
            string pool = null;
            string accesslist = null;
            string silent = null;


            string cmdString = cmd;
   
            #endregion

            if (cmd.IndexOf("accesscontrol", StringComparison.OrdinalIgnoreCase) > 0)
            {
                accesscontrol = HelperAdapter.GetParameter("AccessControl");
                cmdString = cmdString.Replace("$AccessControl", accesscontrol);
            }
            if (cmd.IndexOf("pool", StringComparison.OrdinalIgnoreCase) > 0)
            {
                pool = HelperAdapter.GetParameter("Pool");
                cmdString = cmdString.Replace("$Pool", pool);
            }
            if (cmd.IndexOf("accesslist", StringComparison.OrdinalIgnoreCase) > 0)
            {                
                accesslist = HelperAdapter.GenerateRandomAccessListString(poolType);
                cmdString = cmdString.Replace("$AccessList", accesslist);
            }            
            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }
                        
            AddEmcStorageAccessControl instance = new AddEmcStorageAccessControl(accesscontrol, pool, accesslist, silent, cmdString);
            return instance;
        }


        /// <summary>  
        /// Add-EmcStorageAccessControl:
        ///    The method to implement Add-EmcStorageAccessControl poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcStorageAccessControlTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            AddEmcStorageAccessControl cmdClass = ParseCmd(cmd);

            cmdClass.VerifyTheCMD(psMachine, storageGlobalID, storageSystemName, poolName, poolType);

            removeFlag = true;
        }

        /// <summary>  
        /// AddEmcStorageAccessControlNegativeTestMethod:
        ///    The method to implement Add-EmcStorageAccessControl negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcStorageAccessControlNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            AddEmcStorageAccessControl addemcstorageaccesscontrolClass = ParseCmd(cmd);

            try
            {
                addemcstorageaccesscontrolClass.VerifyTheCMD(psMachine, storageGlobalID, storageSystemName, poolName, poolType);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", addemcstorageaccesscontrolClass.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}

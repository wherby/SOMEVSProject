using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;

using System.Text.RegularExpressions;
using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class ConnectEmcSystemTest
    {
        public ConnectEmcSystemTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }
        
        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private string globalId;
     
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }
       

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);

            log.LogInfo("--------Class Initialize End--------");
        }

        [TestInitialize()]
        public void TestInit() 
        {
            log.LogInfo("--------Test Initialize Start--------");

            globalId = null;
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Initialize End--------");
        }
        
        [TestCleanup()]
        public void TestTearDown() 
        {
            log.LogInfo("--------Test Clean Up Start--------");

            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Test Clean Up End--------");
        }
        
        #endregion

             
       
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a BewEmcLun instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>NewEmcLun instance</returns>  
        public ConnectEmcSystem ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string creationblob = null;
            string refresh = null;
            string silent = null;
            string creationparameters = null;
            string systemtype = null;


            string cmdString = cmd;
   
            #endregion
#endif
            
            if (cmd.Contains("_Blob"))
            {
                Regex reg = new Regex(@"\$([\s\S]*?)_Blob");
                Match m = reg.Match(cmd);
                if (m.Groups.Count > 1)
                {
                    systemtype = m.Groups[1].Value;
                    if (systemtype == "Cluster" && !HelperAdapter.IsClusterSet() || systemtype == "HyperV" && !HelperAdapter.IsHyperVSet())
                    {
                        log.BypassTest();
                    }
                    creationblob = TestSetup.GenerateBlob(psMachine, systemtype);
                    if (creationblob == null)
                    {
                        log.BypassTest();
                    }
                    
                    cmdString = cmd.Replace("$" + systemtype + "_Blob", creationblob);
                }
            }

            if (cmd.IndexOf("CreationParameters", StringComparison.OrdinalIgnoreCase) > 0)
            {
                TestSetup.GetPropertyValue(psMachine, "$CreationParameters=$null");

                Regex reg = new Regex(@"\$('[\s\S]*?')");
                Match m = reg.Match(cmd);
                if (m.Groups.Count > 1)
                {
                    bool isCluster = false;
                    systemtype = m.Groups[1].Value;
                    if (systemtype == "Cluster")
                    {
                        isCluster = true;
                    }
                    cmdString = cmd.Replace("$" + systemtype, systemtype);
                    creationparameters = TestSetup.GenerateCreationParameters(psMachine, systemtype.Replace("'", ""), "$CreationParameters", null, isCluster);
                    TestSetup.GetPropertyValue(psMachine, creationparameters);
                }
            }

            if (cmd.IndexOf("Refresh", StringComparison.OrdinalIgnoreCase) > 0)
            {
                refresh = "Refresh";
            }
            
            if (cmd.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            ConnectEmcSystem system = new ConnectEmcSystem(creationblob, refresh, silent, creationparameters, systemtype, cmdString);
            system.SystemType = systemtype;

            return system;
        }
        
        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ConnectEmcSystemTestMethod(string cmd)
        {

            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            ConnectEmcSystem system = ParseCmd(cmd);
            
            string result =  system.VerifyTheCMD(psMachine);

            SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

            globalId = keyValue["GlobalId"];
               
        }

        /// <summary>  
        /// TestMethod:
        ///    The method to implement test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void ConnectEmcSystemNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            bool caseFail = false;

            ConnectEmcSystem system = ParseCmd(cmd);

            try
            {
                string result = system.VerifyTheCMD(psMachine);

                SortedList<string, string> keyValue = HelperAdapter.GenerateKeyValuePairs(result);

                globalId = keyValue["GlobalId"];
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", system.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }

            log.AreEqual<bool>(true, caseFail, "Negative test case failed");

        }

    }
            
}

using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;

using System.Management;
using System.Management.Automation;
using System.Management.Automation.Runspaces;
using System.IO;
using System.Diagnostics;
using System.Threading;

using PowerShellTestTools;



namespace PowerShellAutomation
{
    /// <summary>
    /// Summary description for UnitTest1
    /// </summary>
    [TestClass]
    public partial class AddEmcHostDiskToClusterTest
    {
        public AddEmcHostDiskToClusterTest()
        {
            //
            // TODO: Add constructor logic here
            // 
        }

        private TestContext testContextInstance;

        private static TestLog log;

        private static PowershellMachine psMachine;

        private static string clusterGlobalId;

        //private static string lunId;

        private static string groupName;

        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }


        
        [TestCleanup]
        public void TestTearDown()
        {
            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }

            RemoveEmcHostDiskFromCluster removeDisk = new RemoveEmcHostDiskFromCluster(null, "Force", null, null, HelperAdapter.GetParameter("Cluster"), null, HelperAdapter.GetParameter("Disk"));
            removeDisk.RunCMD(psMachine);

            Thread.Sleep(10000);

            UpdateEmcSystem updateSystem = new UpdateEmcSystem(null, null, HelperAdapter.GetParameter("Cluster"));
            updateSystem.RunCMD(psMachine);

        }

        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch
            {
                log.BypassTest();
            }
        }
        public static void ClassInit()
        {
            // You can call class contructor here
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            psMachine = new PowershellMachine();
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            if (!HelperAdapter.IsClusterSet())
            {
                log.BypassTest();
            }

            string lun = HelperAdapter.GetParameter("Lun");
            string cluster = HelperAdapter.GetParameter("Cluster");
            string hostDisk = HelperAdapter.GetParameter("Disk");

            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);
            TestSetup.SetLunEnvironment(psMachine);
            string clusterResult = TestSetup.ConnectSystem(psMachine, "Cluster", cluster);
            SortedList<string, string> clusterKeyValue = HelperAdapter.GenerateKeyValuePairs(clusterResult);
            clusterGlobalId = clusterKeyValue["GlobalId"];

            string result = TestSetup.SetDiskEnvironment(psMachine, hostDisk, null, null, cluster);

            try
            {
                TestSetup.SetVolumeEnvironment(psMachine, hostDisk, null, cluster, HelperAdapter.GetParameter("Volume"));
            }
            catch
            {
                log.LogWarning("New-EmcVolume error");
            }

            GetEmcHostLunIdentifier lunId = new GetEmcHostLunIdentifier(lun, null, null, cluster);
            lunId.PrefixString = HelperAdapter.GetParameter("LunIdentifier");
            lunId.RunCMD(psMachine, true);

            GetEmcClusterGroup getGroup = new GetEmcClusterGroup(cluster);
            string groupResult = getGroup.RunCMD(psMachine, true);

            List<SortedList<string, string>> groupList = HelperAdapter.GenerateKeyValuePairsList(groupResult);
            groupName = groupList[0]["Name"];
        }

        [ClassCleanup]
        public static void ESIPSTestClassCleanup()
        {
            if (!HelperAdapter.IsClusterSet())
            {
                return;
            }
            TestSetup.ClearVolumeEnvironment(psMachine, HelperAdapter.GetParameter("Volume"), null, HelperAdapter.GetParameter("Cluster"));
            TestSetup.ClearDiskEnvironment(psMachine, null, HelperAdapter.GetParameter("Cluster"));
            TestSetup.ClearLunEnvironment(psMachine);
            TestSetup.DisconnectSystem(psMachine);
        }


        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a AddEmcHostDiskToCluster instance.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>AddEmcHostDiskToCluster instance</returns>  
        public AddEmcHostDiskToCluster ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string hostlunidentifier = null;
            string clustersystem = null;
            string clustergroupname = null;
            string silent = null;
            string addtoclustersharedvolume = null;
            string hostdisk = null;


            string cmdString = cmd;
   
            #endregion
#endif
            

            if (cmdString.IndexOf("$ClusterSystem", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustersystem = HelperAdapter.GetParameter("Cluster");
                cmdString = cmdString.Replace("$ClusterSystem", clustersystem);
            }
            if (cmdString.IndexOf("$HostLunIdentifier", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostlunidentifier = HelperAdapter.GetParameter("LunIdentifier");
                cmdString = cmdString.Replace("$HostLunIdentifier", hostlunidentifier);
            }
            if (cmdString.IndexOf("$HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                hostdisk = HelperAdapter.GetParameter("Disk");
                cmdString = cmdString.Replace("$HostDisk", hostdisk);
            }
            if (cmdString.IndexOf("$ClusterGroupName", StringComparison.OrdinalIgnoreCase) > 0)
            {
                clustergroupname = groupName;
                cmdString = cmdString.Replace("$ClusterGroupName", "\"" + clustergroupname + "\"");
            }
            if (cmdString.IndexOf("AddToClusterSharedVolume", StringComparison.OrdinalIgnoreCase) > 0)
            {
                addtoclustersharedvolume = "AddToClusterSharedVolume";
            }
            if (cmdString.IndexOf("Silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            AddEmcHostDiskToCluster addDisk = new AddEmcHostDiskToCluster(hostlunidentifier, clustersystem, clustergroupname, silent, addtoclustersharedvolume, hostdisk, cmdString);

            return addDisk;
        }

       public void AddEmcHostDiskToClusterTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsClusterSet())
            {
                log.BypassTest();
            }

            AddEmcHostDiskToCluster addDisk = ParseCmd(cmd);

            addDisk.VerifyTheCMD(psMachine, clusterGlobalId);
        }


        public void AddEmcHostDiskToClusterNegativeTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsClusterSet())
            {
                log.BypassTest();
            }

            bool failCMD = false;

            AddEmcHostDiskToCluster addDisk = ParseCmd(cmd);
            
            try
            {
                addDisk.VerifyTheCMD(psMachine, clusterGlobalId);
            }
            catch (PSException pe)
            {
                failCMD = true;

                log.LogTestCase(pe.Message);
            }
            log.AreEqual<bool>(true, failCMD, "The command is not executed successfully.");
        }
    }

}


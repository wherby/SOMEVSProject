using System;
using System.Text;
using System.Collections.Generic;
using System.Linq;
using Microsoft.VisualStudio.TestTools.UnitTesting;
using System.IO;
using PowerShellTestTools;
using System.Threading;
using System.Text.RegularExpressions;

namespace PowerShellAutomation
{   
    /// <summary>
    /// AddEmcPassthroughDiskToVirtualMachineTest: test class for Get-EmcVirtualMachineConfiguration cmdlet
    /// </summary>
    [TestClass]
    public partial class AddEmcPassthroughDiskToVirtualMachineTest
    {
        public AddEmcPassthroughDiskToVirtualMachineTest()
        {
            //
            // TODO: Add constructor logic here
            //
        }
        

        private TestContext testContextInstance;

        private static TestLog log;
        private static PowershellMachine psMachine;
        private static SortedList<string, string>[] passthroughDisk;
        private static string[] locations;
        private static SortedList<string, string>[] scsiController;
        private static int vmIndex;
        private static string[] hypervisor;
        private static string[] hyperHost;
                
        /// <summary>
        ///Gets or sets the test context which provides
        ///information about and functionality for the current test run.
        ///</summary>
        public TestContext TestContext
        {
            get
            {
                return testContextInstance;
            }
            set
            {
                testContextInstance = value;
            }
        }

        #region Additional test attributes
        //
        // You can use the following additional attributes as you write your tests:
        //
        [TestInitialize()]
        public void TestInit()
        {
            log.LogInfo("--------Test Initialize Start--------");

            for (int i = 0; i < hypervisor.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                string vmPrefix = HelperAdapter.GetParameter("VirtualMachine") + i;

                GetEmcHostSystem vm = new GetEmcHostSystem(TestSetup.GetPropertyValue(psMachine, vmPrefix, "IpAddress"));
                vm.PrefixString = vmPrefix;
                vm.RunCMD(psMachine, true);

                GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, vmPrefix);
                vmConfig.PrefixString = vmConfigPrefix;
                vmConfig.RunCMD(psMachine, true);

                scsiController[i] = TestSetup.GetRandomScsiController(psMachine, HelperAdapter.GetParameter("ScsiController") + i, vmConfigPrefix);
                locations[i] = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController[i]["ScsiControllerIndex"], null, vmConfigPrefix);
                
            }

            log.LogInfo("--------Test Initialize End--------");        
        }

        // Use TestCleanup to run code after each test has run
        [TestCleanup()]
        public void TestTearDown()
        {
            log.LogInfo("--------Test Clean Up Start---------");

            if (!HelperAdapter.IsHyperVSet() && vmIndex == 0 || !HelperAdapter.IsVMwareSet() && vmIndex == 1)
            {
                return;
            }

            string vmConfig = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
            GetEmcVirtualMachineConfiguration getVMConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine") + vmIndex);
            getVMConfig.PrefixString = vmConfig;
            getVMConfig.RunCMD(psMachine, true);

            RemoveEmcVirtualDiskFromVm removeDisk = new RemoveEmcVirtualDiskFromVm(vmConfig, locations[vmIndex], "Force", null, scsiController[vmIndex]["ScsiControllerIndex"] );
            try
            {
                removeDisk.RunCMD(psMachine);
            }
            catch
            {
                log.LogInfo("do not need to remove virtual disk");
            }
            
            log.LogInfo("--------Test Clean Up End---------");
        }

        // Use ClassInitialize to run code before running the first test in the class        
        [ClassInitialize]
        public static void ESIPSTestClassInit(TestContext testContext)
        {
            try
            {
                ClassInit();
            }
            catch(PSException e)
            {
                log.BypassTest(e);
            }
        }
        public static void ClassInit()
        {
            // Get log instance
            log = TestLog.GetInstance();
            log.LogInfo("--------Class Initialize Start--------");

            // Open PowerShell Session
            psMachine = new PowershellMachine();

            // Import ESIPSToolKit
            TestSetup.InitForEMCStorage(psMachine);
            TestSetup.DisconnectSystem(psMachine);

            vmIndex = 0;
            hypervisor = new string[2] { "HyperV", "VMWare" };
            hyperHost = new string[2] { "HyperV", "ESXHost"};
            scsiController = new SortedList<string, string>[2];
            locations = new string[2];
            passthroughDisk = new SortedList<string, string>[2];

            //Connect to Storage System
            string storage = TestSetup.SetStorageEnvironment(psMachine);
            TestSetup.ConnectSystem(psMachine, storage);
            TestSetup.SetPoolEnvironment(psMachine);

            for (int i = 0; i < hypervisor.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }
                // Connect to Hypervisor          
                string prefix = HelperAdapter.GetParameter(hypervisor[i]);
                string hostPrefix = HelperAdapter.GetParameter(hyperHost[i]);
                
                TestSetup.ConnectSystem(psMachine, hypervisor[i], prefix);
                if (i == 1)
                {
                    GetEmcESXHost esxHost = new GetEmcESXHost(null, prefix);
                    esxHost.PrefixString = hostPrefix;
                    esxHost.RunCMD(psMachine, true);
                }

                // Connect Hyperv's VM
                HyperVisorType type = HyperVisorType.HyperV;
                if (i == 1)
                {
                    type = HyperVisorType.VMWare;
                }
                TestSetup.ConnectSystem(psMachine, type.ToString() + "VM", HelperAdapter.GetParameter("VirtualMachine") + i);

                string lun = HelperAdapter.GetParameter("Lun") + i;
                TestSetup.SetLunEnvironment(psMachine, true, null, lun);
                string result = TestSetup.SetDiskEnvironment(psMachine, HelperAdapter.GetParameter("PassthroughDisk") + i, hostPrefix, lun, null, false);

                UpdateEmcSystem updateSystem = new UpdateEmcSystem(prefix);
                updateSystem.RunCMD(psMachine);

                if (i == 1)
                {
                    Dictionary<string, string> datastoreDic = HelperAdapter.Load(ConfigType.Misc, "DataStore");
                    GetEmcDataStore dataStore = new GetEmcDataStore(datastoreDic["Name"], prefix);
                    dataStore.PrefixString = HelperAdapter.GetParameter("DataStore");
                    dataStore.RunCMD(psMachine, true);
                }

                string vmConfigPrefix = HelperAdapter.GetParameter("VirtualMachineConfiguration") + i;
                GetEmcVirtualMachineConfiguration vmConfig = new GetEmcVirtualMachineConfiguration(null, HelperAdapter.GetParameter("VirtualMachine") + i);
                vmConfig.PrefixString = vmConfigPrefix;
                vmConfig.RunCMD(psMachine, true);

                passthroughDisk[i] = HelperAdapter.GenerateKeyValuePairs(result);

                updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter(hypervisor[i]));
                updateSystem.RunCMD(psMachine);

                updateSystem = new UpdateEmcSystem(HelperAdapter.GetParameter("VirtualMachine") + i);
                updateSystem.RunCMD(psMachine);

            }

            log.LogInfo("--------Class Initialize End--------");
        }
        
        // Use ClassCleanup to run code after all tests in a class have run        
        [ClassCleanup]
        public static void ESIPSTestClassCleanUP()
        {
            log.LogInfo("--------Class Clean Up Start--------");

            Thread.Sleep(5000);
            for (int i = 0; i < hypervisor.Length; i++)
            {
                if (!HelperAdapter.IsHyperVSet() && i == 0 || !HelperAdapter.IsVMwareSet() && i == 1)
                {
                    continue;
                }

                string lun = HelperAdapter.GetParameter("Lun") + i;
                if (i == 1)
                {
                    GetEmcESXHost esxHost = new GetEmcESXHost(null, HelperAdapter.GetParameter(hypervisor[i]));
                    esxHost.PrefixString = HelperAdapter.GetParameter(hyperHost[i]);
                    esxHost.RunCMD(psMachine, true);
                }
                TestSetup.ClearDiskEnvironment(psMachine, HelperAdapter.GetParameter(hyperHost[i]), null, lun, false);
                TestSetup.ClearLunEnvironment(psMachine, lun);
            }
            TestSetup.DisconnectSystem(psMachine);

            log.LogInfo("--------Class Clean Up End--------");
        } 
        #endregion  
      
        /// <summary>  
        /// ParseCmd:
        ///    Parse command string to a AddEmcPassthroughDiskToVirtualMachine instance.  
        /// </summary>
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns>AddEmcPassthroughDiskToVirtualMachine instance</returns>  
        public AddEmcPassthroughDiskToVirtualMachine ParseCmd(string cmd)
        {
            
#if true
        #region AutoGenerate
            string diskid = null;
            string virtualmachineconfiguration = null;
            string location = null;
            string scsicontrollerid = null;
            string scsicontrollerindex = null;
            string silent = null;
            string disknumber = null;
            string hostdisk = null;
            string scsilun = null;
            string persistence = null;
            string compatibility = null;
            string datastore = null;


            string cmdString = cmd;
   
            #endregion
#endif
            int number = 0;

            vmIndex = 0;

            if (!HelperAdapter.IsHyperVSet() && (cmd.Contains("HostDisk") || cmd.Contains("DiskId") || cmd.Contains("DiskNumber"))
                || !HelperAdapter.IsVMwareSet() && cmd.Contains("ScsiLun"))
            {
                return null;
            }

            if (passthroughDisk[0] != null)
            {
                Regex reg = new Regex(@"\\\\\?\\PhysicalDrive(\d+)");
                GroupCollection gc = reg.Match(passthroughDisk[0]["HostDiskIdentifier"]).Groups;
                number = int.Parse(gc[1].Value);
            }

            int scsiIndex = -1;
            
            if (cmd.IndexOf("IndependentPersistent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                persistence = "IndependentPersistent";
                cmdString = cmdString.Replace("$IndependentPersistent", persistence);
            }
            else if (cmd.IndexOf("IndependentNonPersistent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                persistence = "IndependentNonPersistent";
                cmdString = cmdString.Replace("$IndependentNonPersistent", persistence);
            }
            else if (cmd.IndexOf("Persistent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                persistence = "Persistent";
                cmdString = cmdString.Replace("$Persistent", persistence);
            }

            if (cmd.IndexOf("ScsiLun", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                scsilun = HelperAdapter.GetParameter("PassthroughDisk") + vmIndex;
                cmdString = cmdString.Replace("$ScsiLun", scsilun);
            }

            if (cmd.IndexOf("VirtualMachineConfiguration", StringComparison.OrdinalIgnoreCase) > 0)
            {
                virtualmachineconfiguration = HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex;
                cmdString = cmdString.Replace("$VirtualMachineConfiguration", virtualmachineconfiguration);
            }

            if (cmd.IndexOf("Compatibility", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                if (cmd.IndexOf("Physical", StringComparison.OrdinalIgnoreCase) > 0)
                {                    
                    compatibility = "Physical";
                    cmdString = cmdString.Replace("$Physical", compatibility);
                }
                else if (cmd.IndexOf("Compatibility $Virtual", StringComparison.OrdinalIgnoreCase) > 0)
                {
                    compatibility = "Virtual";
                    cmdString = cmdString.Replace("Compatibility $Virtual", "Compatibility " + compatibility);
                }
            }

            if (cmd.IndexOf("Datastore", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 1;
                datastore = HelperAdapter.GetParameter("DataStore");
                cmdString = cmdString.Replace("$Datastore", datastore);
            }

            if (cmd.IndexOf("DiskId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 0;
                diskid = passthroughDisk[vmIndex]["HostDiskIdentifier"];
                cmdString = cmdString.Replace("$DiskId", diskid);
            }
            else if (cmd.IndexOf("DiskNumber", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 0;
                disknumber = number.ToString();
                cmdString = cmdString.Replace("$DiskNumber", disknumber);
            }
            else if (cmd.IndexOf("HostDisk", StringComparison.OrdinalIgnoreCase) > 0)
            {
                vmIndex = 0;
                hostdisk = HelperAdapter.GetParameter("PassthroughDisk") + vmIndex;
                cmdString = cmdString.Replace("$HostDisk", hostdisk);
            }

            
            if (cmd.IndexOf("ScsiControllerId", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerid = scsiController[vmIndex]["ScsiControllerId"];
                cmdString = cmdString.Replace("$ScsiControllerId", "\"" + scsicontrollerid + "\"");
                scsiIndex = int.Parse(scsiController[vmIndex]["ScsiControllerIndex"]);
            }

            if (cmd.IndexOf("ScsiControllerIndex", StringComparison.OrdinalIgnoreCase) > 0)
            {
                scsicontrollerindex = scsiController[vmIndex]["ScsiControllerIndex"];
                cmdString = cmdString.Replace("$ScsiControllerIndex", scsicontrollerindex);
                scsiIndex = int.Parse(scsiController[vmIndex]["ScsiControllerIndex"]);
            }

            if (cmd.IndexOf("Location", StringComparison.OrdinalIgnoreCase) > 0)
            {
                if (scsiIndex == -1)
                {
                    scsiController[vmIndex]["ScsiControllerIndex"] = "0";
                    locations[vmIndex] = TestSetup.GetRandomScsiControllerLocation(psMachine, scsiController[vmIndex]["ScsiControllerIndex"] = "0", null, HelperAdapter.GetParameter("VirtualMachineConfiguration") + vmIndex);
                    location = locations[vmIndex];
                }
                else
                {
                    location = locations[vmIndex];
                }
                cmdString = cmdString.Replace("$Location", location);
            }

            if (cmd.IndexOf("silent", StringComparison.OrdinalIgnoreCase) > 0)
            {
                silent = "Silent";
            }

            AddEmcPassthroughDiskToVirtualMachine addDisk = new AddEmcPassthroughDiskToVirtualMachine(diskid, virtualmachineconfiguration, location, scsicontrollerid, scsicontrollerindex, silent, disknumber, hostdisk, scsilun, persistence, compatibility, datastore, cmdString);
            addDisk.DiskNumber = number;
            addDisk.PrefixString = HelperAdapter.GetParameter("PassthroughDiskConfiguration") + vmIndex;
            addDisk.VMIndex = vmIndex;

            return addDisk;
        }

        
        /// <summary>  
        /// AddEmcPassthroughDiskToVirtualMachineTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration poistive test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcPassthroughDiskToVirtualMachineTestMethod(string cmd)
        {
            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsHyperVSet() && !cmd.Contains("ScsiLun") || !HelperAdapter.IsVMwareSet() && cmd.Contains("ScsiLun"))
            {
                log.BypassTest();
            }

            AddEmcPassthroughDiskToVirtualMachine addDisk = ParseCmd(cmd);

            if (addDisk == null)
            {
                return;
            }

            addDisk.VerifyTheCMD(psMachine, scsiController[vmIndex]);
        }

        /// <summary>  
        /// AddEmcPassthroughDiskToVirtualMachineNegativeTestMethod:
        ///    The method to implement Get-EmcVirtualMachineConfiguration negative test case.  
        /// </summary>  
        /// <param name="cmd">command string retrieved from parameter combination file</param>  
        /// <returns></returns>  
        public void AddEmcPassthroughDiskToVirtualMachineNegativeTestMethod(string cmd)
        {


            log.LogTestCase(testContextInstance.TestName + ": " + cmd);

            if (!HelperAdapter.IsHyperVSet() && !cmd.Contains("ScsiLun") || !HelperAdapter.IsVMwareSet() && cmd.Contains("ScsiLun"))
            {
                log.BypassTest();
            }

            bool caseFail = false;

            AddEmcPassthroughDiskToVirtualMachine addDisk = ParseCmd(cmd);

            if (addDisk == null)
            {
                return;
            }

            try
            {
                addDisk.VerifyTheCMD(psMachine, scsiController[vmIndex]);
            }
            catch (PSException psEx)
            {
                log.LogTestCase(string.Format("Test with {0} failed.", addDisk.GetFullString()));
                log.LogTestCase(psEx.messageDetail);
                caseFail = true;
            }
            log.AreEqual<bool>(true, caseFail, "Negative test case result:");

        }
    }
}
